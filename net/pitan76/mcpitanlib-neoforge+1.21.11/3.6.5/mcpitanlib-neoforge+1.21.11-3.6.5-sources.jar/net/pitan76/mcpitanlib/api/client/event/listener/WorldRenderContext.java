package net.pitan76.mcpitanlib.api.client.event.listener;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.Camera;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.render.*;
import net.minecraft.client.renderer.GameRenderer;
import net.minecraft.client.renderer.LevelRenderer;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.culling.Frustum;
import net.minecraft.client.renderer.rendertype.RenderTypes;
import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.shapes.VoxelShape;
import net.pitan76.mcpitanlib.api.util.VoxelShapeUtil;
import net.pitan76.mcpitanlib.api.util.client.render.VertexRenderingUtil;
import net.pitan76.mcpitanlib.midohra.client.render.CameraWrapper;
import org.jetbrains.annotations.Nullable;
import org.joml.Matrix4f;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import java.util.Objects;
import java.util.Optional;

public interface WorldRenderContext {

    LevelRenderer getWorldRenderer();

    PoseStack getMatrixStack();

    float getTickDelta();

    Camera getCamera();

    GameRenderer getGameRenderer();

    LightTexture getLightmapTextureManager();

    @Deprecated
    Matrix4f getProjectionMatrix();

    ClientLevel getWorld();

    @Deprecated
    boolean isAdvancedTranslucency();

    @Nullable MultiBufferSource getConsumers();
    @Nullable Frustum getFrustum();

    @Environment(EnvType.CLIENT)
    interface BlockOutlineContext {
        @Deprecated
        VertexConsumer vertexConsumer();

        Entity entity();

        double cameraX();

        double cameraY();

        double cameraZ();

        BlockPos blockPos();

        BlockState blockState();
    }

    default HitResult getHitResult() {
        return Minecraft.getInstance().hitResult;
    }

    default Optional<BlockState> getBlockState() {
        return Optional.ofNullable(getWorld().getBlockState(getBlockPos().orElse(null)));
    }

    default Optional<BlockPos> getBlockPos() {
        return Optional.ofNullable(((BlockHitResult) getHitResult()).getBlockPos());
    }

    default boolean isBlockType() {
        return getHitResultType() == HitResult.Type.BLOCK;
    }

    default HitResult.Type getHitResultType() {
        return getHitResult().getType();
    }

    default Optional<VoxelShape> getOutlineShape() {
        return getBlockState().map(blockState -> blockState.getShape(getWorld(),
                getBlockPos().orElse(null)));
    }

    default void push() {
        getMatrixStack().pushPose();
    }

    default void translate(double x, double y, double z) {
        getMatrixStack().translate(x, y, z);
    }

    default void pop() {
        getMatrixStack().popPose();
    }

    default Optional<VertexConsumer> getVertexConsumer() {
        if (getConsumers() == null)
            return Optional.empty();

        return Optional.of(Objects.requireNonNull(getConsumers()).getBuffer(RenderTypes.lines()));
    }

    default void drawBox(float red, float green, float blue, float alpha) {
        Optional<VoxelShape> outlineShape = getOutlineShape();
        if (!outlineShape.isPresent()) return;

        drawBox(VoxelShapeUtil.getBoundingBox(outlineShape.get()), red, green, blue, alpha);
    }

    default void drawBox(AABB box, float red, float green, float blue, float alpha) {
        Optional<VertexConsumer> vertexConsumer = getVertexConsumer();

        if (!vertexConsumer.isPresent())
            return;

        VertexConsumer consumer = vertexConsumer.get();

        double x1 = box.minX;
        double y1 = box.minY;
        double z1 = box.minZ;
        double x2 = box.maxX;
        double y2 = box.maxY;
        double z2 = box.maxZ;

        VertexRenderingUtil.drawBox(getMatrixStack(), consumer, x1, y1, z1, x2, y2, z2, red, green, blue, alpha);
    }

    default CameraWrapper getCameraWrapper() {
        return CameraWrapper.of(getCamera());
    }
}
