package net.pitan76.mcpitanlib.api.event.item;

import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_1937;
import net.minecraft.class_2561;
import net.pitan76.mcpitanlib.api.event.BaseEvent;
import net.pitan76.mcpitanlib.api.registry.CompatRegistryLookup;
import net.pitan76.mcpitanlib.api.text.TextComponent;
import net.pitan76.mcpitanlib.api.util.RegistryLookupUtil;
import net.pitan76.mcpitanlib.api.util.TextUtil;
import org.jetbrains.annotations.Nullable;

import java.util.List;

public class ItemAppendTooltipEvent extends BaseEvent {
    public class_1799 stack;
    public class_1937 world;
    public List<class_2561> tooltip;

    public class_1836 type;
    public class_1792.class_9635 context;

    public ItemAppendTooltipEvent(class_1799 stack, @Nullable class_1937 world, List<class_2561> tooltip, class_1836 type, class_1792.class_9635 context) {
        this.stack = stack;
        this.world = world;
        this.tooltip = tooltip;
        this.type = type;
        this.context = context;
    }

    public class_1799 getStack() {
        return stack;
    }

    public class_1937 getWorld() {
        return world;
    }

    public List<class_2561> getTooltip() {
        return tooltip;
    }

    public class_1792.class_9635 getContext() {
        return context;
    }

    public void addTooltip(class_2561 text) {
        tooltip.add(text);
    }

    public void addTooltip(List<class_2561> texts) {
        tooltip.addAll(texts);
    }

    public boolean removeTooltip(class_2561 text) {
        return tooltip.remove(text);
    }

    public boolean isCreative() {
        return type.method_47370();
    }

    public boolean isAdvanced() {
        return type.method_8035();
    }

    public CompatRegistryLookup getRegistryLookup() {
        return RegistryLookupUtil.getRegistryLookup(this);
    }

    public void addTooltip(TextComponent textComponent) {
        addTooltip(textComponent.getText());
    }

    public void addTooltip(String text) {
        addTooltip(TextUtil.literal(text));
    }
}
