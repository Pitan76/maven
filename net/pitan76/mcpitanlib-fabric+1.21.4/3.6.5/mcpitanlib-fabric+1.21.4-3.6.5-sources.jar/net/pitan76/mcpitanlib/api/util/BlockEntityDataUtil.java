package net.pitan76.mcpitanlib.api.util;

import net.minecraft.class_1799;
import net.minecraft.class_2487;
import net.minecraft.class_9279;
import net.minecraft.class_9334;
import net.pitan76.mcpitanlib.api.event.nbt.ReadNbtArgs;
import net.pitan76.mcpitanlib.api.event.nbt.WriteNbtArgs;
import net.pitan76.mcpitanlib.api.tile.CompatBlockEntity;

public class BlockEntityDataUtil {
    public static class_2487 getBlockEntityNbt(class_1799 stack) {
        if (!stack.method_57826(class_9334.field_49611)) return NbtUtil.create();
        class_9279 component = stack.method_57824(class_9334.field_49611);
        if (component == null) return NbtUtil.create();

        class_2487 nbt = component.method_57461();
        if (nbt == null) return NbtUtil.create();
        return nbt;
    }

    public static void setBlockEntityNbt(class_1799 stack, class_2487 nbt) {
        stack.method_57379(class_9334.field_49611, class_9279.method_57456(nbt));
    }

    public static boolean hasBlockEntityNbt(class_1799 stack) {
        return stack.method_57824(class_9334.field_49611) != null;
    }

    public static void readCompatBlockEntityNbtFromStack(class_1799 stack, CompatBlockEntity blockEntity) {
        class_2487 nbt = getBlockEntityNbt(stack);
        blockEntity.readNbt(new ReadNbtArgs(nbt, RegistryLookupUtil.getRegistryLookup(blockEntity)));
    }

    public static void writeCompatBlockEntityNbtToStack(class_1799 stack, CompatBlockEntity blockEntity) {
        class_2487 nbt = getBlockEntityNbt(stack);
        blockEntity.writeNbt(new WriteNbtArgs(nbt, RegistryLookupUtil.getRegistryLookup(blockEntity)));
        NbtUtil.set(nbt, "id", BlockEntityTypeUtil.toID(blockEntity.method_11017()).toString());
        setBlockEntityNbt(stack, nbt);
    }

    public static void removeBlockEntityNbt(class_1799 stack) {
        stack.method_57381(class_9334.field_49611);
    }

    public static boolean hasBlockEntityNbt(net.pitan76.mcpitanlib.midohra.item.ItemStack stack) {
        return hasBlockEntityNbt(stack.toMinecraft());
    }

    public static net.pitan76.mcpitanlib.midohra.nbt.NbtCompound getBlockEntityNbt(net.pitan76.mcpitanlib.midohra.item.ItemStack stack) {
        return net.pitan76.mcpitanlib.midohra.nbt.NbtCompound.of(getBlockEntityNbt(stack.toMinecraft()));
    }

    public static void setBlockEntityNbt(net.pitan76.mcpitanlib.midohra.item.ItemStack stack, net.pitan76.mcpitanlib.midohra.nbt.NbtCompound nbt) {
        setBlockEntityNbt(stack.toMinecraft(), nbt.toMinecraft());
    }

    public static void removeBlockEntityNbt(net.pitan76.mcpitanlib.midohra.item.ItemStack stack) {
        removeBlockEntityNbt(stack.toMinecraft());
    }

    public static void readCompatBlockEntityNbtFromStack(net.pitan76.mcpitanlib.midohra.item.ItemStack stack, CompatBlockEntity blockEntity) {
        readCompatBlockEntityNbtFromStack(stack.toMinecraft(), blockEntity);
    }

    public static void writeCompatBlockEntityNbtToStack(net.pitan76.mcpitanlib.midohra.item.ItemStack stack, CompatBlockEntity blockEntity) {
        writeCompatBlockEntityNbtToStack(stack.toMinecraft(), blockEntity);
    }
}
