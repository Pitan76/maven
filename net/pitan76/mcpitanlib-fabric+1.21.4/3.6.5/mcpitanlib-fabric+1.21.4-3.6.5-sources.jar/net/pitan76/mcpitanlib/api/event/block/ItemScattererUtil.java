package net.pitan76.mcpitanlib.api.event.block;

import net.minecraft.class_1263;
import net.minecraft.class_1264;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2371;
import net.minecraft.class_2586;
import net.minecraft.class_2680;

public class ItemScattererUtil {
    public static void spawn(class_1937 world, class_2338 pos, class_2586 blockEntity) {
        if (blockEntity instanceof class_1263) {
            spawn(world, pos, (class_1263) blockEntity);
        }
    }

    public static void spawn(class_1937 world, class_2338 pos, class_1263 inventory) {
        class_1264.method_5451(world, pos, inventory);
    }

    public static void spawn(class_1937 world, class_2338 pos, class_1799 stack) {
        class_1264.method_5449(world, pos.method_10263(), pos.method_10264(), pos.method_10260(), stack);
    }

    public static void spawn(class_1937 world, class_2338 pos, class_2371<class_1799> stacks) {
        class_1264.method_17349(world, pos, stacks);
    }

    public static void onStateReplaced(StateReplacedEvent e) {
        onStateReplaced(e.getState(), e.getNewState(), e.getWorld(), e.getPos());
    }

    public static void onStateReplaced(class_2680 state, class_2680 newState, class_1937 world, class_2338 pos) {
        class_1264.method_54291(state, newState, world, pos);
    }

    public static void spawn(net.pitan76.mcpitanlib.midohra.world.World world, net.pitan76.mcpitanlib.midohra.util.math.BlockPos pos, class_1799 stack) {
        spawn(world.getRaw(), pos.toMinecraft(), stack);
    }

    public static void spawn(net.pitan76.mcpitanlib.midohra.world.World world, net.pitan76.mcpitanlib.midohra.util.math.BlockPos pos, class_2371<class_1799> stacks) {
        spawn(world.getRaw(), pos.toMinecraft(), stacks);
    }

    public static void spawn(net.pitan76.mcpitanlib.midohra.world.World world, net.pitan76.mcpitanlib.midohra.util.math.BlockPos pos, class_1263 inventory) {
        spawn(world.getRaw(), pos.toMinecraft(), inventory);
    }
}
