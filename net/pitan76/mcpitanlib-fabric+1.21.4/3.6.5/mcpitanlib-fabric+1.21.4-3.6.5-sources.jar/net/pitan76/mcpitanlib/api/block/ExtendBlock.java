package net.pitan76.mcpitanlib.api.block;

import com.google.common.collect.ImmutableMap;
import com.mojang.serialization.MapCodec;
import net.minecraft.class_10;
import net.minecraft.class_10225;
import net.minecraft.class_1269;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1703;
import net.minecraft.class_1750;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_1922;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2561;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_3218;
import net.minecraft.class_3610;
import net.minecraft.class_3726;
import net.minecraft.class_3908;
import net.minecraft.class_3965;
import net.minecraft.class_4538;
import net.minecraft.class_5819;
import net.minecraft.class_747;
import net.minecraft.class_8567;
import net.minecraft.class_9904;
import net.pitan76.mcpitanlib.api.entity.Player;
import net.pitan76.mcpitanlib.api.event.block.*;
import net.pitan76.mcpitanlib.api.event.block.result.BlockBreakResult;
import net.pitan76.mcpitanlib.api.event.item.ItemAppendTooltipEvent;
import net.pitan76.mcpitanlib.api.util.CompatActionResult;
import net.pitan76.mcpitanlib.api.util.TextUtil;
import net.pitan76.mcpitanlib.api.util.math.random.CompatRandom;
import net.pitan76.mcpitanlib.core.serialization.CompatMapCodec;
import org.jetbrains.annotations.Nullable;

import java.util.List;
import java.util.function.Function;

public class ExtendBlock extends class_2248 {
    public CompatibleBlockSettings compatSettings;

    public ExtendBlock(class_2251 settings) {
        super(settings);
    }

    public ExtendBlock(CompatibleBlockSettings settings) {
        super(settings.build());
        this.compatSettings = settings;
    }

    /**
     * get compatible block settings
     * @return CompatibleBlockSettings
     */
    public CompatibleBlockSettings getCompatSettings() {
        return compatSettings;
    }

    /**
     * get collision voxel shape
     * @param event CollisionShapeEvent
     * @return VoxelShape
     */
    public class_265 getCollisionShape(CollisionShapeEvent event) {
        return super.method_9549(event.state, event.world, event.pos, event.context);
    }

    @Deprecated
    @Override
    public class_265 method_9549(class_2680 state, class_1922 world, class_2338 pos, class_3726 context) {
        return getCollisionShape(new CollisionShapeEvent(state, world, pos, context));
    }

    /**
     * get outline voxel shape
     * @param event OutlineShapeEvent
     * @return VoxelShape
     */
    public class_265 getOutlineShape(OutlineShapeEvent event) {
        return super.method_9530(event.state, event.world, event.pos, event.context);
    }

    @Deprecated
    @Override
    public class_265 method_9530(class_2680 state, class_1922 world, class_2338 pos, class_3726 context) {
        return getOutlineShape(new OutlineShapeEvent(state, world, pos, context));
    }

    /**
     * block scheduled tick event
     * @param event BlockScheduledTickEvent
     */
    public void scheduledTick(BlockScheduledTickEvent event) {
        super.method_9588(event.state, event.world, event.pos, event.random.getMcRandom());
    }

    @Override
    @Deprecated
    public void method_9588(class_2680 state, class_3218 world, class_2338 pos, class_5819 random) {
        scheduledTick(new BlockScheduledTickEvent(state, world, pos, random));
    }

    @Override
    @Deprecated
    protected class_1269 method_55766(class_2680 state, class_1937 world, class_2338 pos, class_1657 player, class_3965 hit) {
        return onRightClick(new BlockUseEvent(state, world, pos, player, player.method_6058(), hit)).toActionResult();
    }

    /**
     * block right click event
     * @param event ActionResultType
     * @return BlockUseEvent
     */
    public CompatActionResult onRightClick(BlockUseEvent event) {
        return CompatActionResult.create(super.method_55766(event.state, event.world, event.pos, event.player.getPlayerEntity(), event.hit));
    }

    @Deprecated
    @Nullable
    @Override
    public class_3908 method_17454(class_2680 state, class_1937 world, class_2338 pos) {
        return new class_747((syncId, inventory, player) ->
                createScreenHandler(new ScreenHandlerCreateEvent(state, world, pos, syncId, inventory, player)), getScreenTitle()
        );
    }

    /**
     * screen handler create event
     * @param event ScreenHandlerCreateEvent
     * @return ScreenHandler
     */
    @Nullable
    public class_1703 createScreenHandler(ScreenHandlerCreateEvent event) {
        return null;
    }

    /**
     * get screen title
     * @return Text
     */
    @Nullable
    public class_2561 getScreenTitle() {
        return TextUtil.literal("");
    }

    @Override
    @Deprecated
    public void method_9567(class_1937 world, class_2338 pos, class_2680 state, @Nullable class_1309 placer, class_1799 itemStack) {
        onPlaced(new BlockPlacedEvent(world, pos, state, placer, itemStack));
    }

    /**
     * block placed event
     * @param event BlockPlacedEvent
     */
    public void onPlaced(BlockPlacedEvent event) {
        super.method_9567(event.world, event.pos, event.state, event.placer, event.stack);
    }

    @Override
    @Deprecated
    public class_2680 method_9576(class_1937 world, class_2338 pos, class_2680 state, class_1657 player) {
        return onBreak(new BlockBreakEvent(world, pos, state, player)).state;
    }

    /**
     * block break event
     * @param event BlockBreakEvent
     * @return BlockBreakResult
     */
    public BlockBreakResult onBreak(BlockBreakEvent event) {
        class_2680 state = super.method_9576(event.world, event.pos, event.state, event.getPlayerEntity());
        return new BlockBreakResult(state);
    }

    @Override
    @Deprecated
    public class_1799 method_9574(class_4538 world, class_2338 pos, class_2680 state, boolean includeData) {
        PickStackEvent event = new PickStackEvent(world, pos, state);
        event.setIncludeData(includeData);
        return getPickStack(event);
    }

    /**
     * block pick stack event
     * @param event PickStackEvent
     * @return ItemStack
     */
    public class_1799 getPickStack(PickStackEvent event) {
        return super.method_9574(event.worldView, event.pos, event.state, event.includeData);
    }

    @Override
    @Deprecated
    public void method_9536(class_2680 state, class_1937 world, class_2338 pos, class_2680 newState, boolean moved) {
        onStateReplaced(new StateReplacedEvent(state, world, pos, newState, moved));
    }

    /**
     * block state replaced event
     * @param event StateReplacedEvent
     */
    public void onStateReplaced(StateReplacedEvent event) {
        super.method_9536(event.state, event.world, event.pos, event.newState, event.moved);
    }

    @Deprecated
    @Override
    public List<class_1799> method_9560(class_2680 state, class_8567.class_8568 builder) {
        return getDroppedStacks(new DroppedStacksArgs(state, builder));
    }

    /**
     * block dropped stacks event
     * @param args DroppedStacksArgs
     * @return List<ItemStack>
     */
    public List<class_1799> getDroppedStacks(DroppedStacksArgs args) {
        return super.method_9560(args.state, args.builder);
    }

    @Deprecated
    @Override
    public void method_9612(class_2680 state, class_1937 world, class_2338 pos, class_2248 sourceBlock, class_9904 wireOrientation, boolean notify) {
        neighborUpdate(new NeighborUpdateEvent(state, world, pos, sourceBlock, wireOrientation, notify));
    }

    /**
     * block neighbor update event
     * @param event NeighborUpdateEvent
     */
    public void neighborUpdate(NeighborUpdateEvent event) {
        super.method_9612(event.state, event.world, event.pos, event.sourceBlock, event.wireOrientation, event.notify);
    }

    @Deprecated
    @Override
    public void method_9515(class_2689.class_2690<class_2248, class_2680> builder) {
        appendProperties(new AppendPropertiesArgs(builder));
    }

    /**
     * append properties event
     * @param args AppendPropertiesArgs
     */
    public void appendProperties(AppendPropertiesArgs args) {
        super.method_9515(args.builder);
    }

    /**
     * Compatible for getDefaultState()
     * @return default block state
     */
    public class_2680 getNewDefaultState() {
        return super.method_9564();
    }

    /**
     * Compatible for setDefaultState()
     * @param state BlockState
     */
    public void setNewDefaultState(class_2680 state) {
        super.method_9590(state);
    }

    @Deprecated
    @Override
    public @Nullable class_2680 method_9605(class_1750 ctx) {
        return this.getPlacementState(new PlacementStateArgs(ctx, this));
    }

    /**
     * get placement state
     * @param args PlacementStateArgs
     * @return BlockState
     */
    public @Nullable class_2680 getPlacementState(PlacementStateArgs args) {
        return super.method_9605(args.ctx);
    }

    @Deprecated
    @Override
    public void method_9568(class_1799 stack, class_1792.class_9635 context, List<class_2561> tooltip, class_1836 type) {
        appendTooltip(new ItemAppendTooltipEvent(stack, null, tooltip, type, context));
    }

    /**
     * append tooltip to item
     * @param event ItemAppendTooltipEvent
     */
    public void appendTooltip(ItemAppendTooltipEvent event) {
        super.method_9568(event.stack, event.context, event.tooltip, event.type);
    }

    @Deprecated
    @Override
    public boolean method_9516(class_2680 state, class_10 type) {
        return canPathfindThrough(new CanPathfindThroughArgs(state, type));
    }

    public boolean canPathfindThrough(CanPathfindThroughArgs args) {
        return super.method_9516(args.state, args.type);
    }

    @Deprecated
    @Override
    public void method_9548(class_2680 state, class_1937 world, class_2338 pos, class_1297 entity) {
        onEntityCollision(new EntityCollisionEvent(state, world, pos, entity));
    }

    public void onEntityCollision(EntityCollisionEvent e) {
        super.method_9548(e.state, e.world, e.pos, e.entity);
    }

    @Deprecated
    @Override
    public void method_9606(class_2680 state, class_1937 world, class_2338 pos, class_1657 player) {
        onBlockBreakStart(new BlockBreakStartEvent(state, world, pos, new Player(player)));
    }

    public void onBlockBreakStart(BlockBreakStartEvent e) {
        super.method_9606(e.state, e.world, e.pos, e.player.getPlayerEntity());
    }

    @Deprecated
    @Override
    protected MapCodec<? extends class_2248> method_53969() {
        return getCompatCodec().getCodec();
    }

    public CompatMapCodec<? extends class_2248> getCompatCodec() {
        return CompatMapCodec.of(super.method_53969());
    }

    @Deprecated
    @Override
    protected class_3610 method_9545(class_2680 state) {
        return getFluidState(new FluidStateArgs(state));
    }

    public class_3610 getFluidState(FluidStateArgs args) {
        return super.method_9545(args.getState());
    }

    @Deprecated
    @Override
    protected class_2680 method_9559(class_2680 state, class_4538 world, class_10225 tickView, class_2338 pos, class_2350 direction, class_2338 neighborPos, class_2680 neighborState, class_5819 random) {
        return getStateForNeighborUpdate(new StateForNeighborUpdateArgs(state, direction, neighborState, world, pos, neighborPos, tickView, new CompatRandom(random)));
    }

    public class_2680 getStateForNeighborUpdate(StateForNeighborUpdateArgs args) {
        return super.method_9559(args.state, args.world, args.tickView, args.pos, args.direction, args.neighborPos, args.neighborState, args.random.getMcRandom());
    }

    @Deprecated
    @Override
    protected ImmutableMap<class_2680, class_265> method_33615(Function<class_2680, class_265> stateToShape) {
        return getShapesForStates(new ShapesForStatesArgs(stateToShape));
    }

    public ImmutableMap<class_2680, class_265> getShapesForStates(ShapesForStatesArgs args) {
        return super.method_33615(args.stateToShape);
    }

    public class_2689<class_2248, class_2680> callGetStateManager() {
        return super.method_9595();
    }
}
