package net.pitan76.mcpitanlib.api.util.client;

import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.class_10142;
import net.minecraft.class_2960;

public class RenderUtil {
    public static void setShaderToPositionTexProgram() {
        RenderSystem.setShader(class_10142.field_53879);
    }

    public static void setShaderColor(float red, float green, float blue, float alpha) {
        RenderSystem.setShaderColor(red, green, blue, alpha);
    }

    public static void setShaderTexture(int texture, class_2960 id) {
        RenderSystem.setShaderTexture(texture, id);
    }

    public static void enableDepthTest() {
        RenderSystem.enableDepthTest();
    }

    public static void enableTexture() {
        // ～1.19.2
    }

    public static void disableTexture() {
        // ～1.19.2
    }

    public static class RendererUtil extends ScreenUtil.RendererUtil {}
}