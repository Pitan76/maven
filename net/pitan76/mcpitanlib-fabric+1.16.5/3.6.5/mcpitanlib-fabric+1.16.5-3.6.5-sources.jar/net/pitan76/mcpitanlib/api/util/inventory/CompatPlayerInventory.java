package net.pitan76.mcpitanlib.api.util.inventory;

import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1799;
import net.pitan76.mcpitanlib.api.entity.Player;

public class CompatPlayerInventory implements ICompatInventory {
    public class_1661 inv;

    public CompatPlayerInventory(class_1661 inv) {
        this.inv = inv;
    }

    public Player getPlayer() {
        return PlayerInventoryUtil.getPlayer(inv);
    }

    public int getSelectedSlot() {
        return PlayerInventoryUtil.getSelectedSlot(inv);
    }

    public void setSelectedSlot(int slot) {
        PlayerInventoryUtil.setSelectedSlot(inv, slot);
    }

    public void dropAllItems() {
        PlayerInventoryUtil.dropAllItems(inv);
    }

    public void offerOrDrop(class_1799 stack) {
        inv.method_7398(inv.field_7546.field_6002, stack);
    }

    public void offerOrDrop(net.pitan76.mcpitanlib.midohra.item.ItemStack stack) {
        offerOrDrop(stack.toMinecraft());
    }

    public class_1661 getRaw() {
        return inv;
    }

    @Override
    public int method_5439() {
        return inv.method_5439();
    }

    @Override
    public boolean method_5442() {
        return inv.method_5442();
    }

    @Override
    public class_1799 method_5438(int slot) {
        return inv.method_5438(slot);
    }

    @Override
    public class_1799 method_5434(int slot, int count) {
        return inv.method_5434(slot, count);
    }

    @Override
    public class_1799 method_5441(int slot) {
        return inv.method_5441(slot);
    }

    @Override
    public void method_5447(int slot, class_1799 itemStack) {
        inv.method_5447(slot, itemStack);
    }

    @Override
    public void method_5431() {
        inv.method_5431();
    }

    @Override
    public boolean method_5443(class_1657 player) {
        return inv.method_5443(player);
    }

    @Override
    public void method_5448() {
        inv.method_5448();
    }
}

