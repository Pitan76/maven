package net.pitan76.mcpitanlib.api.tile;

import net.minecraft.class_2338;
import net.minecraft.class_2487;
import net.minecraft.class_2591;
import net.minecraft.class_2595;
import net.minecraft.class_2622;
import net.minecraft.class_2680;
import net.pitan76.mcpitanlib.api.event.block.TileCreateEvent;
import net.pitan76.mcpitanlib.api.event.nbt.ReadNbtArgs;
import net.pitan76.mcpitanlib.api.event.nbt.WriteNbtArgs;
import net.pitan76.mcpitanlib.api.packet.UpdatePacketType;

public class CompatChestBlockEntity extends class_2595 {
    protected CompatChestBlockEntity(class_2591<?> blockEntityType, class_2338 blockPos, class_2680 blockState) {
        super(blockEntityType);
    }

    public CompatChestBlockEntity(class_2591<?> type, TileCreateEvent event) {
        this(type, event.getBlockPos(), event.getBlockState());
    }

    @Override
    @Deprecated
    public class_2622 method_16886() {
        switch (getUpdatePacketType().name) {
            case "BLOCK_ENTITY_UPDATE_S2C":
                class_2487 nbt = new class_2487();
                writeNbtOverride(nbt);
                return new class_2622(method_11016(), 1, nbt);
        }
        return super.method_16886();
    }

    public UpdatePacketType getUpdatePacketType() {
        return UpdatePacketType.NONE;
    }

    public void writeNbt(WriteNbtArgs args) {

    }

    public void readNbt(ReadNbtArgs args) {

    }


    // deprecated

    /**
     * @deprecated Use {@link #writeNbt(WriteNbtArgs)} instead
     */
    @Deprecated
    public void writeNbtOverride(class_2487 nbt) {
        super.method_11007(nbt);
    }

    /**
     * @deprecated Use {@link #readNbt(ReadNbtArgs)} instead
     */
    @Deprecated
    public void readNbtOverride(class_2487 nbt) {
        super.method_11014(method_11010(), nbt);
    }

    // ----

    @Deprecated
    @Override
    public class_2487 method_11007(class_2487 nbt) {
        // deprecated
        writeNbtOverride(nbt);
        // ----

        writeNbt(new WriteNbtArgs(nbt));
        return nbt;
    }

    @Deprecated
    @Override
    public void method_11014(class_2680 state, class_2487 nbt) {
        // deprecated
        readNbtOverride(nbt);
        // ----

        readNbt(new ReadNbtArgs(nbt));
    }
}