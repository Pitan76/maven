package net.pitan76.mcpitanlib.api.util.client.render;

import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_310;
import net.minecraft.class_918;
import net.pitan76.mcpitanlib.api.client.render.block.entity.event.BlockEntityRenderEvent;

/**
 * Cross-version utility for rendering items in block entity renderers.
 */
public class CompatItemRenderUtil {
    /**
     * Renders an ItemStack in FIXED transform mode.
     */
    public static void renderItemFixed(class_1799 stack, BlockEntityRenderEvent<?> e, class_1937 world) {
        renderItem(stack, CompatItemDisplayContext.FIXED, e, world);
    }

    /**
     * Renders an ItemStack
     */
    public static void renderItem(class_1799 stack, CompatItemDisplayContext displayContext, BlockEntityRenderEvent<?> e, class_1937 world) {
        class_918 renderer = e.getItemRenderer() != null ? e.getItemRenderer() : class_310.method_1551().method_1480();
        renderer.method_23178(stack, displayContext.getContext(), e.getLight(), e.getOverlay(), e.matrices, e.vertexConsumers);
    }

    public static void renderItemFixed(net.pitan76.mcpitanlib.midohra.item.ItemStack stack, BlockEntityRenderEvent<?> e, net.pitan76.mcpitanlib.midohra.world.World world) {
        renderItemFixed(stack.toMinecraft(), e, world.toMinecraft());
    }

    public static void renderItem(net.pitan76.mcpitanlib.midohra.item.ItemStack stack, CompatItemDisplayContext displayContext, BlockEntityRenderEvent<?> e, net.pitan76.mcpitanlib.midohra.world.World world) {
        renderItem(stack.toMinecraft(), displayContext, e, world.toMinecraft());
    }
}
