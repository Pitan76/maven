package net.pitan76.mcpitanlib.api.event;

import com.mojang.brigadier.Command;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.context.StringRange;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_2168;
import net.minecraft.class_2561;
import net.pitan76.mcpitanlib.api.entity.Player;
import net.pitan76.mcpitanlib.api.text.TextComponent;
import net.pitan76.mcpitanlib.api.util.TextUtil;
import net.pitan76.mcpitanlib.api.util.WorldUtil;

public class ServerCommandEvent extends CommandEvent<class_2168> {

    public CommandContext<class_2168> getContext() {
        return context;
    }

    public void setContext(CommandContext<class_2168> context) {
        this.context = context;
    }

    public class_2168 getSource() {
        return getContext().getSource();
    }

    public class_1657 getPlayerEntity() throws CommandSyntaxException {
        return getSource().method_9207();
    }

    public Player getPlayer() throws CommandSyntaxException {
        return new Player(getPlayerEntity());
    }

    public class_1937 getWorld() {
        return getSource().method_9225();
    }

    public class_1297 getEntity() {
        return getSource().method_9228();
    }

    public String getInput() {
        return getContext().getInput();
    }

    public Command<class_2168> getContextCommand() {
        return getContext().getCommand();
    }

    public CommandContext<class_2168> getChild() {
        return getContext().getChild();
    }

    public CommandContext<class_2168> getLastChild() {
        return getContext().getLastChild();
    }

    public StringRange getRange() {
        return getContext().getRange();
    }

    // Text
    public void sendSuccess(class_2561 message, boolean broadcastToOps) {
        getSource().method_9226(message, broadcastToOps);
    }

    public void sendFailure(class_2561 message) {
        getSource().method_9213(message);
    }

    public void sendSuccess(class_2561 message) {
        sendSuccess(message, false);
    }

    // String (Formatted)
    public void sendSuccess(String message, boolean broadcastToOps) {
        sendSuccess(TextUtil.convert(message), broadcastToOps);
    }

    public void sendSuccess(String message) {
        sendSuccess(message, false);
    }

    public void sendFailure(String message) {
        sendFailure(TextUtil.convert(message));
    }

    // Translatable
    public void sendSuccessWithTranslatable(String message, boolean broadcastToOps) {
        sendSuccess(TextUtil.convertWithTranslatable(message), broadcastToOps);
    }

    public void sendSuccessWithTranslatable(String message) {
        sendSuccessWithTranslatable(message, false);
    }

    public void sendFailureWithTranslatable(String message) {
        sendFailure(TextUtil.convertWithTranslatable(message));
    }

    // Raw
    public void sendSuccessRaw(String message, boolean broadcastToOps) {
        sendSuccess(TextUtil.literal(message), broadcastToOps);
    }

    public void sendSuccessRaw(String message) {
        sendSuccessRaw(message, false);
    }

    public void sendFailureRaw(String message) {
        sendFailure(TextUtil.literal(message));
    }

    public boolean isClient() {
        return WorldUtil.isClient(getWorld());
    }

    public void sendSuccess(TextComponent message, boolean broadcastToOps) {
        sendSuccess(message.getText(), broadcastToOps);
    }

    public void sendSuccess(TextComponent message) {
        sendSuccess(message.getText());
    }

    public void sendFailure(TextComponent message) {
        sendFailure(message.getText());
    }
}
