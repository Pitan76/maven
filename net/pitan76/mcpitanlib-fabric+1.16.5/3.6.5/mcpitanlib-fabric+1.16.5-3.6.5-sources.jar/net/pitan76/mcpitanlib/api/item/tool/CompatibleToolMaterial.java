package net.pitan76.mcpitanlib.api.item.tool;

import net.minecraft.class_1792;
import net.minecraft.class_1832;
import net.minecraft.class_1856;
import net.minecraft.class_3489;
import net.pitan76.mcpitanlib.api.tag.TagKey;

public interface CompatibleToolMaterial {

    int getCompatMiningLevel();

    float getCompatAttackDamage();

    float getCompatMiningSpeedMultiplier();

    default class_1856 getCompatRepairIngredient() {
        return class_1856.method_8106(getRepairTag().getTagKey());
    }

    int getCompatDurability();

    int getCompatEnchantability();

    @Deprecated
    default float getAttackDamage() {
        return getCompatAttackDamage();
    }

    @Deprecated
    default float getMiningSpeedMultiplier() {
        return getCompatMiningSpeedMultiplier();
    }

    @Deprecated
    default class_1856 getRepairIngredient() {
        return getCompatRepairIngredient();
    }

    @Deprecated
    default int getDurability() {
        return getCompatDurability();
    }

    @Deprecated
    default int getEnchantability() {
        return getCompatEnchantability();
    }

    default TagKey<class_1792> getRepairTag() {
        return (TagKey<class_1792>) TagKey.create(TagKey.Type.ITEM, class_3489.field_23802.method_26791());
    }

    default class_1832 build() {
        return new class_1832() {
            @Override
            public int method_8025() {
                return getCompatDurability();
            }

            @Override
            public float method_8027() {
                return getCompatMiningSpeedMultiplier();
            }

            @Override
            public float method_8028() {
                return getCompatAttackDamage();
            }

            @Override
            public int method_8024() {
                return getCompatMiningLevel();
            }

            @Override
            public int method_8026() {
                return getCompatEnchantability();
            }

            @Override
            public class_1856 method_8023() {
                return getCompatRepairIngredient();
            }
        };
    }
}