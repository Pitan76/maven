package net.pitan76.mcpitanlib.api.util.math;

import net.minecraft.class_2382;

public class Vec3iUtil {
    public static class_2382 create(int x, int y, int z) {
        return new class_2382(x, y, z);
    }

    public static class_2382 add(class_2382 a, class_2382 b) {
        return new class_2382(a.method_10263() + b.method_10263(), a.method_10264() + b.method_10264(), a.method_10260() + b.method_10260());
    }

    public static class_2382 subtract(class_2382 a, class_2382 b) {
        return new class_2382(a.method_10263() - b.method_10263(), a.method_10264() - b.method_10264(), a.method_10260() - b.method_10260());
    }

    public static class_2382 multiply(class_2382 a, int b) {
        return new class_2382(a.method_10263() * b, a.method_10264() * b, a.method_10260() * b);
    }

    public static class_2382 cross(class_2382 a, class_2382 b) {
        return a.method_10259(b);
    }

    public static class_2382 add(class_2382 a, int x, int y, int z) {
        return new class_2382(a.method_10263() + x, a.method_10264() + y, a.method_10260() + z);
    }

    public static class_2382 subtract(class_2382 a, int x, int y, int z) {
        return new class_2382(a.method_10263() - x, a.method_10264() - y, a.method_10260() - z);
    }
}
