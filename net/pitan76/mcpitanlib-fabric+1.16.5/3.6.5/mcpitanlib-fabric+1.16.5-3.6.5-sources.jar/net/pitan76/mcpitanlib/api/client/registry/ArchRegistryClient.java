package net.pitan76.mcpitanlib.api.client.registry;

import dev.architectury.registry.menu.MenuRegistry;
import me.shedaniel.architectury.registry.BlockEntityRenderers;
import me.shedaniel.architectury.registry.ParticleProviderRegistry;
import me.shedaniel.architectury.registry.RenderTypes;
import me.shedaniel.architectury.registry.entity.EntityRenderers;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1058;
import net.minecraft.class_1059;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1723;
import net.minecraft.class_1921;
import net.minecraft.class_2248;
import net.minecraft.class_2394;
import net.minecraft.class_2396;
import net.minecraft.class_2561;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_2960;
import net.minecraft.class_3611;
import net.minecraft.class_3917;
import net.minecraft.class_3936;
import net.minecraft.class_4002;
import net.minecraft.class_437;
import net.minecraft.class_707;
import net.minecraft.class_824;
import net.minecraft.class_827;
import net.minecraft.class_897;
import net.minecraft.class_898;
import java.util.List;
import java.util.Random;
import java.util.function.Function;
import java.util.function.Supplier;

@Deprecated
@Environment(EnvType.CLIENT)
public class ArchRegistryClient {
    public static <H extends class_1703, S extends class_437 & class_3936<H>> void registerScreen(class_3917<? extends H> type, ScreenFactory<H, S> factory) {
        MenuRegistry.registerScreenFactory(type, factory::create);
    }

    public interface ScreenFactory<H extends class_1703, S extends class_437 & class_3936<H>> {
        S create(H handler, class_1661 inventory, class_2561 text);
    }

    public static <T extends class_2394> void registerParticle(class_2396<T> type, class_707<T> factory) {
        ParticleProviderRegistry.register(type, factory);
    }

    public static <T extends class_2394> void registerParticle(class_2396<T> type, DeferredParticleProvider<T> provider) {
        ParticleProviderRegistry.register(type, spriteSet -> provider.create(new ExtendedSpriteSet() {
            @Override
            public class_1059 getAtlas() {
                return spriteSet.getAtlas();
            }

            @Override
            public List<class_1058> getSprites() {
                return spriteSet.getSprites();
            }

            @Override
            public class_1058 method_18138(int age, int maxAge) {
                return spriteSet.method_18138(age, maxAge);
            }

            @Override
            public class_1058 method_18139(Random random) {
                return spriteSet.method_18139(random);
            }
        }));
    }

    public static <T extends class_1297> void registerEntityRenderer(Supplier<? extends class_1299<? extends T>> type, Function<class_898, class_897<T>> factory) {
        EntityRenderers.register((class_1299<T>) type.get(), factory);
    }

    @FunctionalInterface
    public interface DeferredParticleProvider<T extends class_2394> {
        class_707<T> create(ExtendedSpriteSet spriteSet);
    }

    public interface ExtendedSpriteSet extends class_4002 {
        class_1059 getAtlas();

        List<class_1058> getSprites();
    }

    public static void registryClientSpriteAtlasTexture(class_2960 identifier) {
        registryClientSprite(class_1723.field_21668, identifier);
    }

    public static void registryClientSpriteAtlasTexture(class_1058 sprite) {
        registryClientSprite(class_1723.field_21668, sprite);
    }

    public static void registryClientSprite(class_2960 atlasId, class_2960 identifier) {
        //?
    }

    public static void registryClientSprite(class_2960 atlasId, class_1058 sprite) {
        //?
    }

    public static <T extends class_2586> void registerBlockEntityRenderer(class_2591<T> type, BlockEntityRendererFactory<T> provider) {
        BlockEntityRenderers.registerRenderer(type, dispatcher -> provider.create(new BlockEntityRendererFactory.Context(dispatcher)));
    }

    @FunctionalInterface
    public interface BlockEntityRendererFactory<T extends class_2586> {
        class_827<T> create(BlockEntityRendererFactory.Context ctx);

        class Context {
            private final class_824 renderDispatcher;

            public Context(class_824 renderDispatcher) {
                this.renderDispatcher = renderDispatcher;
            }

            public class_824 getRenderDispatcher() {
                return this.renderDispatcher;
            }
        }
    }


    public static void registerRenderTypeBlock(class_1921 layer, class_2248 block) {
        RenderTypes.register(layer, block);
    }

    public static void registerRenderTypeFluid(class_1921 layer, class_3611 fluid) {
        RenderTypes.register(layer, fluid);
    }
}
