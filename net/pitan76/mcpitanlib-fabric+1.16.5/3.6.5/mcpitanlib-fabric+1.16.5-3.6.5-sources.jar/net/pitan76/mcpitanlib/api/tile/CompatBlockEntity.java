package net.pitan76.mcpitanlib.api.tile;

import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2487;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_2622;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.pitan76.mcpitanlib.api.event.block.TileCreateEvent;
import net.pitan76.mcpitanlib.api.event.nbt.ReadNbtArgs;
import net.pitan76.mcpitanlib.api.event.nbt.WriteNbtArgs;
import net.pitan76.mcpitanlib.api.packet.UpdatePacketType;
import net.pitan76.mcpitanlib.api.registry.CompatRegistryLookup;
import net.pitan76.mcpitanlib.api.util.BlockEntityUtil;
import net.pitan76.mcpitanlib.api.util.WorldUtil;
import org.jetbrains.annotations.Nullable;

public class CompatBlockEntity extends class_2586 {
    public CompatBlockEntity(class_2591<?> type) {
        super(type);
    }

    public CompatBlockEntity(class_2591<?> type, TileCreateEvent event) {
        this(type);
    }

    @Override
    @Deprecated
    public class_2622 method_16886() {
        switch (getUpdatePacketType().name) {
            case "BLOCK_ENTITY_UPDATE_S2C":
                class_2487 nbt = new class_2487();
                writeNbtOverride(nbt);
                return new class_2622(method_11016(), 1, nbt);
        }
        return super.method_16886();
    }

    public UpdatePacketType getUpdatePacketType() {
        return UpdatePacketType.NONE;
    }

    public void writeNbt(WriteNbtArgs args) {

    }

    public void readNbt(ReadNbtArgs args) {

    }

    public class_2487 toInitialChunkDataNbt(CompatRegistryLookup registryLookup) {
        return super.method_16887();
    }

    @Deprecated
    @Override
    public class_2487 method_16887() {
        return toInitialChunkDataNbt(new CompatRegistryLookup());
    }

    // deprecated

    /**
     * @deprecated Use {@link #writeNbt(WriteNbtArgs)} instead
     */
    @Deprecated
    public void writeNbtOverride(class_2487 nbt) {
        super.method_11007(nbt);
    }

    /**
     * @deprecated Use {@link #readNbt(ReadNbtArgs)} instead
     */
    @Deprecated
    public void readNbtOverride(class_2487 nbt) {
        super.method_11014(method_11010(), nbt);
    }

    // ----

    @Deprecated
    @Override
    public class_2487 method_11007(class_2487 nbt) {
        // deprecated
        writeNbtOverride(nbt);
        // ----

        writeNbt(new WriteNbtArgs(nbt));
        return nbt;
    }

    @Deprecated
    @Override
    public void method_11014(class_2680 state, class_2487 nbt) {
        // deprecated
        readNbtOverride(nbt);
        // ----

        readNbt(new ReadNbtArgs(nbt));
    }

    public boolean isClient() {
        if (method_10997() == null)
            return false;

        return WorldUtil.isClient(method_10997());
    }

    @Deprecated
    @Override
    public @Nullable class_1937 method_10997() {
        return callGetWorld();
    }

    @Deprecated
    @Override
    public class_2338 method_11016() {
        return callGetPos();
    }

    public class_1937 callGetWorld() {
        return super.method_10997();
    }

    public class_2338 callGetPos() {
        return super.method_11016();
    }

    public class_2680 callGetBlockState() {
        return BlockEntityUtil.getBlockState(this);
    }

    public class_2680 callGetCachedState() {
        return BlockEntityUtil.getCachedState(this);
    }

    public boolean hasServerWorld() {
        return callGetWorld() instanceof class_3218;
    }

    public class_3218 getServerWorld() {
        return BlockEntityUtil.getServerWorld(this);
    }

    public void callMarkDirty() {
        BlockEntityUtil.markDirty(this);
    }

    @Deprecated
    @Override
    public void method_11012() {
        markRemovedOverride();
    }

    public void markRemovedOverride() {
        super.method_11012();
    }

    public net.pitan76.mcpitanlib.midohra.world.World getMidohraWorld() {
        return net.pitan76.mcpitanlib.midohra.world.World.of(callGetWorld());
    }

    public net.pitan76.mcpitanlib.midohra.util.math.BlockPos getMidohraPos() {
        return net.pitan76.mcpitanlib.midohra.util.math.BlockPos.of(callGetPos());
    }

    public net.pitan76.mcpitanlib.midohra.block.BlockState getMidohraBlockState() {
        return net.pitan76.mcpitanlib.midohra.block.BlockState.of(callGetBlockState());
    }

    public net.pitan76.mcpitanlib.midohra.block.BlockState getMidohraCachedState() {
        return net.pitan76.mcpitanlib.midohra.block.BlockState.of(callGetCachedState());
    }
}
