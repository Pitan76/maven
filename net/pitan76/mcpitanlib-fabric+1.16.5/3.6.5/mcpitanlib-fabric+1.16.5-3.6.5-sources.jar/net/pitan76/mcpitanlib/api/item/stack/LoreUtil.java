package net.pitan76.mcpitanlib.api.item.stack;

import net.minecraft.class_1799;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2561;
import net.pitan76.mcpitanlib.api.nbt.NbtTypeBytes;
import net.pitan76.mcpitanlib.api.util.NbtUtil;
import net.pitan76.mcpitanlib.api.util.TextUtil;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

public class LoreUtil {
    public static boolean hasLore(class_1799 stack) {
        return stack.method_7941("display") != null && stack.method_7941("display").method_10545("Lore");
    }

    public static List<class_2561> getLore(class_1799 stack) {
        if (!hasLore(stack)) return new ArrayList<>();
        return NbtUtil.getList(stack.method_7941("display"), "Lore", NbtTypeBytes.STRING).stream()
                    .map(nbt -> {
                        String str = NbtUtil.asString(nbt);
                        if (str == null) return TextUtil.empty();

                        Pattern pattern = Pattern.compile("\"text\":\"([^\"]+)\"");
                        java.util.regex.Matcher matcher = pattern.matcher(str);
                        if (matcher.find()) {
                            String text = matcher.group(1);
                            return class_2561.method_30163(text);
                        }

                        return class_2561.method_30163(str);
                    }).collect(Collectors.toList());
    }

    public static List<String> getLoreAsStringList(class_1799 stack) {
        return getLore(stack).stream()
                .map(class_2561::getString)
                .collect(Collectors.toList());
    }

    public static String getLoreAsString(class_1799 stack) {
        return getLoreAsStringList(stack).stream()
                .reduce("", (a, b) -> a + "\n" + b);
    }

    public static void setLore(class_1799 stack, List<class_2561> lore) {
        class_2499 nbtList = NbtUtil.createNbtList();

        for (class_2561 text : lore) {
            String str = text.getString();
            str = "{\"text\":\"" + str + "\"}";

            nbtList.add(NbtUtil.createString(str));
        }

        class_2487 displayNbt = stack.method_7911("display");
        displayNbt.method_10566("Lore", nbtList);
        stack.method_7959("display", displayNbt);
    }

    public static void setLoreStringList(class_1799 stack, List<String> lore) {
        setLore(stack, lore.stream()
                .map(class_2561::method_30163)
                .collect(Collectors.toList()));
    }

    public static void setLore(class_1799 stack, String lore) {
        List<class_2561> loreList = new ArrayList<>();
        for (String line : lore.split("\n")) {
            loreList.add(class_2561.method_30163(line));
        }
        
        setLore(stack, loreList);
    }
}
