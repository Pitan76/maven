package net.pitan76.mcpitanlib.api.util.item;

import net.minecraft.class_1761;
import net.minecraft.class_2588;
import net.minecraft.class_2960;
import net.pitan76.mcpitanlib.api.util.CompatIdentifier;

public class ItemGroupUtil {
    public static class_2960 toID(class_1761 itemGroup) {
        if (itemGroup.method_7737() instanceof class_2588) {
            class_2588 translatableText = (class_2588) itemGroup.method_7737();
                String[] strings = translatableText.method_11022().split("\\.");

                if (strings.length == 3)
                    return new class_2960(strings[1], strings[2]);
        }

        return CompatIdentifier.empty().toMinecraft();
    }

    public static class_1761 fromId(class_2960 identifier) {
        return null;
    }

    public static boolean isExist(class_2960 identifier) {
        return false;
    }

    public static CompatIdentifier toCompatID(class_1761 itemGroup) {
        return CompatIdentifier.fromMinecraft(toID(itemGroup));
    }

    public static class_1761 fromId(CompatIdentifier identifier) {
        return fromId(identifier.toMinecraft());
    }

    public static boolean isExist(CompatIdentifier identifier) {
        return isExist(identifier.toMinecraft());
    }

    public static int getRawId(class_1761 itemGroup) {
        return itemGroup.method_7741();
    }

    public static class_1761 fromIndex(int index) {
        return class_1761.field_7921[index];
    }
}
