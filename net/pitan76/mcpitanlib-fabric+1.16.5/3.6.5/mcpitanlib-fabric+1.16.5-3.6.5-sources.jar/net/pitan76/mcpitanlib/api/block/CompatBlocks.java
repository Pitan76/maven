package net.pitan76.mcpitanlib.api.block;

import net.minecraft.class_2246;
import net.minecraft.class_2248;

public class CompatBlocks {
    public static final class_2248 AIR = class_2246.field_10124;
    public static final class_2248 STONE = class_2246.field_10340;
    public static final class_2248 COBBLESTONE = class_2246.field_10445;
    public static final class_2248 GRASS_BLOCK = class_2246.field_10219;
    public static final class_2248 DIRT = class_2246.field_10566;
    public static final class_2248 SAND = class_2246.field_10102;
    public static final class_2248 RED_SAND = class_2246.field_10534;
    public static final class_2248 GRANITE = class_2246.field_10474;
    public static final class_2248 POLISHED_GRANITE = class_2246.field_10289;
    public static final class_2248 DIORITE = class_2246.field_10508;
    public static final class_2248 POLISHED_DIORITE = class_2246.field_10346;
    public static final class_2248 ANDESITE = class_2246.field_10115;
    public static final class_2248 POLISHED_ANDESITE = class_2246.field_10093;
    public static final class_2248 COARSE_DIRT = class_2246.field_10253;
    public static final class_2248 PODZOL = class_2246.field_10520;

    public static final class_2248 OAK_LOG = class_2246.field_10431;
    public static final class_2248 SPRUCE_LOG = class_2246.field_10037;
    public static final class_2248 BIRCH_LOG = class_2246.field_10511;
    public static final class_2248 JUNGLE_LOG = class_2246.field_10306;
    public static final class_2248 ACACIA_LOG = class_2246.field_10533;
    public static final class_2248 DARK_OAK_LOG = class_2246.field_10010;
    public static final class_2248 OAK_PLANKS = class_2246.field_10161;
    public static final class_2248 SPRUCE_PLANKS = class_2246.field_9975;
    public static final class_2248 BIRCH_PLANKS = class_2246.field_10148;
    public static final class_2248 JUNGLE_PLANKS = class_2246.field_10334;
    public static final class_2248 ACACIA_PLANKS = class_2246.field_10218;
    public static final class_2248 DARK_OAK_PLANKS = class_2246.field_10075;
    public static final class_2248 OAK_SAPLING = class_2246.field_10394;
    public static final class_2248 SPRUCE_SAPLING = class_2246.field_10217;
    public static final class_2248 BIRCH_SAPLING = class_2246.field_10575;
    public static final class_2248 JUNGLE_SAPLING = class_2246.field_10276;
    public static final class_2248 ACACIA_SAPLING = class_2246.field_10385;
    public static final class_2248 DARK_OAK_SAPLING = class_2246.field_10160;

    public static final class_2248 SANDSTONE = class_2246.field_9979;
    public static final class_2248 CHISELED_SANDSTONE = class_2246.field_10292;
    public static final class_2248 CUT_SANDSTONE = class_2246.field_10361;
    public static final class_2248 NOTE_BLOCK = class_2246.field_10179;
    public static final class_2248 POWERED_RAIL = class_2246.field_10425;
    public static final class_2248 DETECTOR_RAIL = class_2246.field_10025;
    public static final class_2248 PISTON = class_2246.field_10560;
    public static final class_2248 STICKY_PISTON = class_2246.field_10615;
    public static final class_2248 COBWEB = class_2246.field_10343;
    public static final class_2248 GRAVEL = class_2246.field_10255;
    public static final class_2248 GLASS = class_2246.field_10033;
    public static final class_2248 DISPENSER = class_2246.field_10200;

    public static final class_2248 COAL_ORE = class_2246.field_10418;
    public static final class_2248 IRON_ORE = class_2246.field_10212;
    public static final class_2248 COPPER_ORE = class_2246.field_10212;
    public static final class_2248 GOLD_ORE = class_2246.field_10571;
    public static final class_2248 DIAMOND_ORE = class_2246.field_10442;
    public static final class_2248 REDSTONE_ORE = class_2246.field_10080;
    public static final class_2248 EMERALD_ORE = class_2246.field_10013;
    public static final class_2248 LAPIS_ORE = class_2246.field_10090;
    public static final class_2248 NETHER_QUARTZ_ORE = class_2246.field_10213;

    public static final class_2248 COAL_BLOCK = class_2246.field_10381;
    public static final class_2248 IRON_BLOCK = class_2246.field_10085;
    public static final class_2248 COPPER_BLOCK = class_2246.field_10085;
    public static final class_2248 GOLD_BLOCK = class_2246.field_10205;
    public static final class_2248 DIAMOND_BLOCK = class_2246.field_10201;
    public static final class_2248 REDSTONE_BLOCK = class_2246.field_10002;
    public static final class_2248 EMERALD_BLOCK = class_2246.field_10234;
    public static final class_2248 LAPIS_BLOCK = class_2246.field_10441;
    public static final class_2248 QUARTZ_BLOCK = class_2246.field_10153;

    public static final class_2248 TNT = class_2246.field_10375;
    public static final class_2248 BOOKSHELF = class_2246.field_10504;
    public static final class_2248 OBSIDIAN = class_2246.field_10540;
    public static final class_2248 TORCH = class_2246.field_10336;
    public static final class_2248 WALL_TORCH = class_2246.field_10099;
    public static final class_2248 FIRE = class_2246.field_10036;
    public static final class_2248 SOUL_FIRE = class_2246.field_22089;
    public static final class_2248 SPAWNER = class_2246.field_10260;
    public static final class_2248 OAK_STAIRS = class_2246.field_10563;
    public static final class_2248 CHEST = class_2246.field_10034;
    public static final class_2248 REDSTONE_WIRE = class_2246.field_10091;

    public static final class_2248 WATER = class_2246.field_10382;
    public static final class_2248 LAVA = class_2246.field_10164;
    public static final class_2248 BEDROCK = class_2246.field_9987;

    // ----

    public static boolean isExist(class_2248 block) {
        return block != null && block != class_2246.field_10124;
    }
}
