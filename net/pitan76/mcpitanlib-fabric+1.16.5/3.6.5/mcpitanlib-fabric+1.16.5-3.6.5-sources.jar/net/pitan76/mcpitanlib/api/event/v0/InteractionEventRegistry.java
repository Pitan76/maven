package net.pitan76.mcpitanlib.api.event.v0;

import me.shedaniel.architectury.event.events.InteractionEvent;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1271;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.pitan76.mcpitanlib.api.entity.Player;
import net.pitan76.mcpitanlib.api.event.result.EventResult;
import net.pitan76.mcpitanlib.api.event.v0.event.ClickBlockEvent;
import net.pitan76.mcpitanlib.api.util.CompatActionResult;
import net.pitan76.mcpitanlib.api.util.StackActionResult;

public class InteractionEventRegistry {
    public static void registerRightClickBlock(RightClickBlock rightClickBlock) {
        InteractionEvent.RIGHT_CLICK_BLOCK.register((player, hand, pos, direction) -> rightClickBlock.click(new ClickBlockEvent(player, hand, pos, direction)).toActionResult());
    }

    public static void registerLeftClickBlock(LeftClickBlock leftClickBlock) {
        InteractionEvent.LEFT_CLICK_BLOCK.register((player, hand, pos, direction) -> leftClickBlock.click(new ClickBlockEvent(player, hand, pos, direction)).toActionResult());
    }

    public static void registerRightClickItem(RightClickItem rightClickItem) {
        InteractionEvent.RIGHT_CLICK_ITEM.register(rightClickItem::click);
    }

    public static void registerClientLeftClickAir(ClientLeftClickAir clientLeftClickAir) {
        InteractionEvent.CLIENT_LEFT_CLICK_AIR.register(clientLeftClickAir::click);
    }

    public static void registerClientRightClickAir(ClientRightClickAir clientRightClickAir) {
        InteractionEvent.CLIENT_RIGHT_CLICK_AIR.register(clientRightClickAir::click);
    }

    public static void registerInteractEntity(InteractEntity interactEntity) {
        InteractionEvent.INTERACT_ENTITY.register(interactEntity::interact);
    }

    // ----

    public interface LeftClickBlock {
        EventResult click(ClickBlockEvent event);
    }

    public interface RightClickBlock {
        EventResult click(ClickBlockEvent event);
    }

    public interface RightClickItem {
        default class_1271<class_1799> click(class_1657 var1, class_1268 var2) {
            CompatActionResult result = click(new Player(var1), var2);
            if (result instanceof StackActionResult) {
                return ((StackActionResult) result).toTypedActionResult();
            } else {
                class_1799 stack = var1.method_5998(var2);
                return StackActionResult.create(result, stack).toTypedActionResult();
            }
        }

        CompatActionResult click(Player player, class_1268 hand);
    }

    public interface ClientLeftClickAir {
        default void click(class_1657 var1, class_1268 var2) {
            click(new Player(var1), var2);
        }

        void click(Player player, class_1268 hand);
    }

    public interface ClientRightClickAir {
        default void click(class_1657 var1, class_1268 var2) {
            click(new Player(var1), var2);
        }

        void click(Player player, class_1268 hand);
    }

    public interface InteractEntity {
        default class_1269 interact(class_1657 var1, class_1297 var2, class_1268 var3) {
            return interact(new Player(var1), var2, var3).toActionResult();
        }

        CompatActionResult interact(Player player, class_1297 entity, class_1268 hand);
    }
}
