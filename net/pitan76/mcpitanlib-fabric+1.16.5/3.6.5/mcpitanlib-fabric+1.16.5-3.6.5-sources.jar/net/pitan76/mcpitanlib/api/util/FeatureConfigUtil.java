package net.pitan76.mcpitanlib.api.util;

import net.minecraft.class_2248;
import net.minecraft.class_2680;
import net.minecraft.class_2975;
import net.minecraft.class_3031;
import net.minecraft.class_3124;
import net.minecraft.class_3825;

public class FeatureConfigUtil {

    /**
     * Create a new ConfiguredFeature
     * @param oreFeatureConfig The ore feature config
     * @return The new ConfiguredFeature
     */
    public static class_2975<?, ?> createConfiguredFeature(class_3124 oreFeatureConfig) {
        return new class_2975<>(class_3031.field_13517, oreFeatureConfig);
    }

    /**
     * Create a new OreFeatureConfig
     * @param test The rule test
     * @param state The block state
     * @param size The size
     * @return The new OreFeatureConfig
     */
    public static class_3124 createOreFeatureConfig(class_3825 test, class_2680 state, int size) {
        return new class_3124(test, state, size);
    }

    /**
     * Create a new OreFeatureConfig
     * @param test The rule test
     * @param block The block
     * @param size The size
     * @return The new OreFeatureConfig
     */
    public static class_3124 createOreFeatureConfig(class_3825 test, class_2248 block, int size) {
        return createOreFeatureConfig(test, block.method_9564(), size);
    }

    /**
     * Create a new OreFeatureConfig
     * @param state The block state
     * @param size The size
     * @return The new OreFeatureConfig
     */
    public static class_3124 createStoneOreFeatureConfig(class_2680 state, int size) {
        class_3825 ruleTest = class_3124.class_5436.field_25845;
        return createOreFeatureConfig(ruleTest, state, size);
    }
}
