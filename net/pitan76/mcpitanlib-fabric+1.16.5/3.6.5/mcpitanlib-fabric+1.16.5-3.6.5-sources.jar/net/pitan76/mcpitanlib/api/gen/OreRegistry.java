package net.pitan76.mcpitanlib.api.gen;

import net.minecraft.class_2248;
import net.minecraft.class_2893;
import net.minecraft.class_2960;
import net.minecraft.class_2975;
import net.pitan76.mcpitanlib.api.registry.WorldGenRegistry;
import net.pitan76.mcpitanlib.api.util.BlockUtil;
import net.pitan76.mcpitanlib.api.util.FeatureConfigUtil;

@Deprecated
public class OreRegistry {
    /**
     * Generating custom ore in stone
     * @param registry WorldGenRegistry
     * @param block Block
     * @param size Ore size
     * @param height generating height
     * @param count generating count per chunk
     * @return Identifier of feature
     */
    public static class_2960 registerStoneOre(WorldGenRegistry registry, class_2248 block, int size, int height, int count) {
        class_2960 blockId = BlockUtil.toID(block);
        class_2960 identifier = new class_2960(blockId.method_12836(), blockId.method_12832() + "_ore_feature");
        class_2975<?, ?> configuredFuture = registry.registerFeature(identifier,
                () -> FeatureConfigUtil.createConfiguredFeature(
                        FeatureConfigUtil.createStoneOreFeatureConfig(block.method_9564(), size)
                )
        );

        WorldGenRegistry.addProperties(class_2893.class_2895.field_13176, configuredFuture);
        return identifier;
    }
}
