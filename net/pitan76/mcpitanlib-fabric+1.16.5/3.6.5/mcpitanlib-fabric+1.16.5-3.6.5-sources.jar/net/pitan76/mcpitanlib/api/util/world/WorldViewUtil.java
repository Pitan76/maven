package net.pitan76.mcpitanlib.api.util.world;

import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1936;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_2680;
import net.minecraft.class_2874;
import net.minecraft.class_3486;
import net.minecraft.class_3610;
import net.minecraft.class_3611;
import net.minecraft.class_4538;
import net.pitan76.mcpitanlib.midohra.entity.EntityTypeWrapper;

import java.util.List;
import java.util.Optional;
import java.util.function.Predicate;

public class WorldViewUtil {

    public static boolean isClient(class_4538 world) {
        return world.method_8608();
    }

    public static class_2680 getBlockState(class_4538 world, class_2338 pos) {
        return world.method_8320(pos);
    }

    public static class_2248 getBlock(class_4538 world, class_2338 pos) {
        return getBlockState(world, pos).method_26204();
    }

    public static class_2586 getBlockEntity(class_4538 world, class_2338 pos) {
        return world.method_8321(pos);
    }

    public static <T extends class_2586> Optional<T> getBlockEntity(class_4538 world, class_2338 pos, class_2591<T> type) {
        return Optional.ofNullable(type.method_24182(world, pos));
    }

    public static class_3610 getFluidState(class_4538 world, class_2338 pos) {
        return getBlockState(world, pos).method_26227();
    }

    public static class_3611 getFluid(class_4538 world, class_2338 pos) {
        return getFluidState(world, pos).method_15772();
    }

    public static int getBottomY(class_4538 world) {
        return 0;
    }

    public static int getTopY(class_4538 world) {
        return world.method_8322();
    }

    public static boolean isChunkLoaded(class_4538 world, class_2338 pos) {
        return world.method_22340(pos);
    }

    public static boolean isRegionLoaded(class_4538 world, class_2338 min, class_2338 max) {
        return world.method_22343(min, max);
    }

    public static class_2874 getDimensionType(class_4538 world) {
        return world.method_8597();
    }

    public static boolean isAirBlock(class_4538 world, class_2338 pos) {
        return getBlockState(world, pos).method_26215();
    }

    public static boolean isOpaqueBlock(class_4538 world, class_2338 pos) {
        return getBlockState(world, pos).method_26225();
    }

    public static boolean isWater(class_4538 world, class_2338 pos) {
        return getFluidState(world, pos).method_15767(class_3486.field_15517);
    }

    public static <T extends class_1297> List<T> getEntitiesByClass(class_1936 world, Class<T> entityClass, class_238 box, Predicate<? super T> predicate) {
        return world.method_8390(entityClass, box, predicate);
    }

    public static <T extends class_1297> List<T> getEntitiesByClass(class_1936 world, Class<T> entityClass, net.pitan76.mcpitanlib.midohra.util.math.Box box, Predicate<? super T> predicate) {
        return getEntitiesByClass(world, entityClass, box.toMinecraft(), predicate);
    }

    public static <T extends class_1297> List<T> getEntitiesByType(class_1936 world, class_1299<T> entityType, class_238 box, Predicate<? super class_1297> predicate) {
        if (world instanceof class_1937) {
            return ((class_1937) world).method_18023(entityType, box, predicate);
        }

        // EntityType<T> のTを
        return (List<T>) world.method_8390(class_1297.class, box, predicate.and(entity -> ((class_1297) entity).method_5864() == entityType));
    }

    public static <T extends class_1297> List<T> getEntitiesByType(class_1936 world, class_1299<T> entityType, net.pitan76.mcpitanlib.midohra.util.math.Box box, Predicate<? super class_1297> predicate) {
        return getEntitiesByType(world, entityType, box.toMinecraft(), predicate);
    }

    public static List<?> getEntitiesByType(class_1936 world, EntityTypeWrapper entityType, class_238 box, Predicate<? super class_1297> predicate) {
        return getEntitiesByType(world, entityType.get(), box, predicate);
    }
}
