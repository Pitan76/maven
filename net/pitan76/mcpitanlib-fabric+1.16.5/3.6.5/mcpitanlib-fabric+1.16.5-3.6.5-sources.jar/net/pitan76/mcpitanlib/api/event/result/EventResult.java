package net.pitan76.mcpitanlib.api.event.result;

import net.minecraft.class_1269;
import net.pitan76.mcpitanlib.api.util.CompatActionResult;

public class EventResult {

    protected final me.shedaniel.architectury.event.EventResult result;

    private static final EventResult TRUE = new EventResult(me.shedaniel.architectury.event.EventResult.interruptTrue());
    private static final EventResult STOP = new EventResult(me.shedaniel.architectury.event.EventResult.interruptDefault());
    private static final EventResult PASS = new EventResult(me.shedaniel.architectury.event.EventResult.pass());
    private static final EventResult FALSE = new EventResult(me.shedaniel.architectury.event.EventResult.interruptFalse());


    protected EventResult(me.shedaniel.architectury.event.EventResult result) {
        this.result = result;
    }

    public static EventResult success() {
        return TRUE;
    }

    public static EventResult stop() {
        return STOP;
    }

    public static EventResult pass() {
        return PASS;
    }

    public static EventResult fail() {
        return FALSE;
    }

    @Deprecated
    public me.shedaniel.architectury.event.EventResult getResult() {
        return result;
    }

    public class_1269 toActionResult() {
        if (this.equals(TRUE)) {
            return class_1269.field_5812;
        }
        if (this.equals(FALSE)) {
            return class_1269.field_5814;
        }
        if (this.equals(PASS)) {
            return class_1269.field_5811;
        }
        if (this.equals(STOP)) {
            return class_1269.field_5811;
        }
        return class_1269.field_21466;
    }

    public CompatActionResult toCompatActionResult() {
        return CompatActionResult.create(toActionResult());
    }
}
