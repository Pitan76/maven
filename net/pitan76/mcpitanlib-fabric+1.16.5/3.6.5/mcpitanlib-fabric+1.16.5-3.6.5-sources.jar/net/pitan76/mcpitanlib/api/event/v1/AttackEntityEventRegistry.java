package net.pitan76.mcpitanlib.api.event.v1;

import dev.architectury.injectables.annotations.ExpectPlatform;
import me.shedaniel.architectury.event.EventResult;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_3966;
import net.pitan76.mcpitanlib.api.event.v1.event.AttackEntityEvent;
import net.pitan76.mcpitanlib.api.util.CompatActionResult;
import org.jetbrains.annotations.Nullable;

public class AttackEntityEventRegistry {
    @ExpectPlatform
    public static void register(AttackEntity attackEntity) {
        throw new AssertionError();
    }

    public interface AttackEntity {
        default EventResult attack(class_1657 player, class_1937 level, class_1297 target, class_1268 hand, @Nullable class_3966 result) {
            return attack(new AttackEntityEvent(player, level, target, hand, result)).toEventResult().getResult();
        }

        CompatActionResult attack(AttackEntityEvent event);
    }
}
