package net.pitan76.mcpitanlib.api.util.client;

import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_4493;

public class RenderUtil {
    public static void setShaderToPositionTexProgram() {
        //
    }

    public static void setShaderColor(float red, float green, float blue, float alpha) {
        class_4493.method_22000(1.0F, 1.0F, 1.0F, 1.0F);
    }

    public static void setShaderTexture(int texture, class_2960 id) {
        class_310.method_1551().method_1531().method_22813(id);
    }

    public static void enableDepthTest() {
        RenderSystem.enableDepthTest();
    }

    public static void enableTexture() {
        RenderSystem.enableTexture();
    }

    public static void disableTexture() {
        RenderSystem.disableTexture();
    }

    public static class RendererUtil extends ScreenUtil.RendererUtil {}
}