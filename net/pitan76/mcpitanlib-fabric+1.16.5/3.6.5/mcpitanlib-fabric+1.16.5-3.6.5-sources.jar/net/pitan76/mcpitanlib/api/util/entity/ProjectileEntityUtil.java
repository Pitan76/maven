package net.pitan76.mcpitanlib.api.util.entity;

import net.minecraft.class_1297;
import net.minecraft.class_1676;
import net.minecraft.class_243;
import net.minecraft.class_3532;

public class ProjectileEntityUtil {
    public static void setVelocity(class_1676 projectileEntity, class_1297 shooter, float pitch, float yaw, float roll, float speed, float divergence) {
        float f = -class_3532.method_15374(yaw * ((float)Math.PI / 180F)) * class_3532.method_15362(pitch * ((float)Math.PI / 180F));
        float g = -class_3532.method_15374((pitch + roll) * ((float)Math.PI / 180F));
        float h = class_3532.method_15362(yaw * ((float)Math.PI / 180F)) * class_3532.method_15362(pitch * ((float)Math.PI / 180F));
        projectileEntity.method_7485(f, g, h, speed, divergence);
        class_243 vec3d = shooter.method_18798();
        projectileEntity.method_18799(projectileEntity.method_18798().method_1031(vec3d.field_1352, shooter.method_24828() ? (double)0.0F : vec3d.field_1351, vec3d.field_1350));
    }

    public static void setVelocity(class_1676 projectileEntity, double x, double y, double z, float power, float uncertainty) {
        projectileEntity.method_7485(x, y, z, power, uncertainty);
    }
}
