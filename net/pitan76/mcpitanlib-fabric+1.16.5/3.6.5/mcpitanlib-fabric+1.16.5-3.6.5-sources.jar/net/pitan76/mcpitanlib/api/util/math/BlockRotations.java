package net.pitan76.mcpitanlib.api.util.math;

import net.minecraft.class_2470;
import net.pitan76.mcpitanlib.api.util.math.random.CompatRandom;

public class BlockRotations {
    public static class_2470 NONE = class_2470.field_11467;
    public static class_2470 CLOCKWISE_90 = class_2470.field_11463;
    public static class_2470 CLOCKWISE_180 = class_2470.field_11464;
    public static class_2470 COUNTERCLOCKWISE_90 = class_2470.field_11465;

    public static class_2470 rotate(class_2470 rotation, class_2470 rotation2) {
        return rotation.method_10501(rotation2);
    }

    public static class_2470 random(CompatRandom random) {
        return class_2470.method_16548(random.getJavaRandom());
    }
}
