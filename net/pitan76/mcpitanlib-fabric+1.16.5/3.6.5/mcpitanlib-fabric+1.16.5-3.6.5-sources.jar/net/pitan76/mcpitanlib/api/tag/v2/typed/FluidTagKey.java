package net.pitan76.mcpitanlib.api.tag.v2.typed;

import me.shedaniel.architectury.hooks.TagHooks;
import net.minecraft.class_3494;
import net.minecraft.class_3611;
import net.pitan76.mcpitanlib.api.tag.v2.CompatTagKey;
import net.pitan76.mcpitanlib.api.tag.v2.CompatTagKeyType;
import net.pitan76.mcpitanlib.api.util.CompatIdentifier;

public class FluidTagKey extends CompatTagKey<class_3611> {
    @Deprecated
    public FluidTagKey(class_3494.class_5123<class_3611> tagKey) {
        super(tagKey);
    }

    public static FluidTagKey of(CompatIdentifier identifier) {
        return new FluidTagKey(TagHooks.getOptional(identifier.toMinecraft(), CompatTagKeyType.FLUID::getTagGroup));
    }
}
