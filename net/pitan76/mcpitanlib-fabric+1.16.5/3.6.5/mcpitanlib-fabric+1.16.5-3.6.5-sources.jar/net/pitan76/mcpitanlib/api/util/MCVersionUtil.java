package net.pitan76.mcpitanlib.api.util;

import net.minecraft.class_155;
import net.pitan76.mcpitanlib.api.util.client.ClientUtil;

public class MCVersionUtil {

    public static int getProtocolVersion() {
        return class_155.method_16673().getProtocolVersion();
    }

    public static String getGameVersion() {
        return ClientUtil.getClient().method_1515();
    }

    public static boolean isSupportedComponent() {
        return getProtocolVersion() >= 766;
    }
}
