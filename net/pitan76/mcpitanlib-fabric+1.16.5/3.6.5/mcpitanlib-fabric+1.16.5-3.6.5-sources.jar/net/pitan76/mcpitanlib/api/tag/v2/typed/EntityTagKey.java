package net.pitan76.mcpitanlib.api.tag.v2.typed;

import me.shedaniel.architectury.hooks.TagHooks;
import net.minecraft.class_1299;
import net.minecraft.class_3494;
import net.pitan76.mcpitanlib.api.tag.v2.CompatTagKey;
import net.pitan76.mcpitanlib.api.tag.v2.CompatTagKeyType;
import net.pitan76.mcpitanlib.api.util.CompatIdentifier;

public class EntityTagKey extends CompatTagKey<class_1299<?>> {
    @Deprecated
    public EntityTagKey(class_3494.class_5123<class_1299<?>> tagKey) {
        super(tagKey);
    }

    public static EntityTagKey of(CompatIdentifier identifier) {
        return new EntityTagKey(TagHooks.getOptional(identifier.toMinecraft(), CompatTagKeyType.ENTITY_TYPE::getTagGroup));
    }
}
