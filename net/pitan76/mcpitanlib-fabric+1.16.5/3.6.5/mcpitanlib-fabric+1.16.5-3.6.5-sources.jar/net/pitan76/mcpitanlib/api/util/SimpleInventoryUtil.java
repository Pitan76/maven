package net.pitan76.mcpitanlib.api.util;

import net.minecraft.class_1277;
import net.minecraft.class_1799;
import net.minecraft.class_2371;

public class SimpleInventoryUtil {
    public static class_2371<class_1799> getHeldStacks(class_1277 inventory) {
        class_2371<class_1799> stacks = class_2371.method_10213(inventory.method_5439(), class_1799.field_8037);
        for (int i = 0; i < inventory.method_5439(); i++) {
            stacks.add(i, inventory.method_5438(i));
        }
        return stacks;
    }

    public static class_1277 create(int size) {
        return InventoryUtil.createSimpleInventory(size);
    }

    public static class_1799 getStack(class_1277 inventory, int slot) {
        return inventory.method_5438(slot);
    }

    public static void setStack(class_1277 inventory, int slot, class_1799 stack) {
        inventory.method_5447(slot, stack);
    }

    public static void clear(class_1277 inventory) {
        inventory.method_5448();
    }

    public static int size(class_1277 inventory) {
        return inventory.method_5439();
    }

    public static boolean isEmpty(class_1277 inventory) {
        return inventory.method_5442();
    }
}
