package net.pitan76.mcpitanlib.api.gui;

import me.shedaniel.architectury.registry.MenuRegistry;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_2540;
import net.minecraft.class_3917;
import net.pitan76.mcpitanlib.api.gui.args.CreateMenuEvent;

public class ExtendedScreenHandlerTypeBuilder<T extends class_1703> {

    private final Factory<T> factory;

    public ExtendedScreenHandlerTypeBuilder(Factory<T> factory) {
        this.factory = factory;
    }

    public ExtendedScreenHandlerTypeBuilder(Factory2<T> factory) {
        this.factory = factory;
    }

    public class_3917<T> build() {
        return MenuRegistry.ofExtended(factory::create);
    }

    @FunctionalInterface
    public interface Factory<T extends class_1703> {
        T create(int syncId, class_1661 inventory, class_2540 buf);
    }

    @FunctionalInterface
    public interface Factory2<T extends class_1703> extends Factory<T> {
        T create(CreateMenuEvent e, class_2540 buf);

        @Override
        default T create(int syncId, class_1661 inventory, class_2540 buf) {
            return create(new CreateMenuEvent(syncId, inventory), buf);
        }
    }
}
