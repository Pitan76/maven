package net.pitan76.mcpitanlib.api.util.math;

import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2374;
import net.minecraft.class_2382;
import net.minecraft.class_243;
import net.minecraft.util.math.*;

public class PosUtil {
    public static class_2338 flooredBlockPos(double x, double y, double z) {
        return new class_2338(x, y, z);
    }

    public static class_2338 flooredBlockPos(class_2374 pos) {
        return new class_2338(pos);
    }

    public static class_2338 flooredBlockPos(class_243 pos) {
        return new class_2338(pos);
    }

    public static net.pitan76.mcpitanlib.midohra.util.math.BlockPos midohraBlockPos(int x, int y, int z) {
        return net.pitan76.mcpitanlib.midohra.util.math.BlockPos.of(x, y, z);
    }

    public static net.pitan76.mcpitanlib.midohra.util.math.BlockPos flooredMidohraBlockPos(double x, double y, double z) {
        int x1 = (int) Math.floor(x);
        int y1 = (int) Math.floor(y);
        int z1 = (int) Math.floor(z);
        return midohraBlockPos(x1, y1, z1);
    }

    public static double getSquaredDistance(class_2338 pos1, class_2338 pos2) {
        return pos1.method_10262(pos2);
    }

    public static double getSquaredDistance(class_2338 pos1, double x, double y, double z) {
        return getSquaredDistance(pos1, new class_2338(x, y, z));
    }

    public static Iterable<class_2338> iterate(class_2338 start, class_2338 end) {
        return class_2338.method_10097(start, end);
    }

    public static class_2338[] getNeighborPoses(class_2338 pos) {
        return new class_2338[]{pos.method_10095(), pos.method_10072(), pos.method_10078(), pos.method_10067(), pos.method_10084(), pos.method_10074()};
    }

    public static class_2338 up(class_2338 pos) {
        return pos.method_10084();
    }

    public static class_2338 down(class_2338 pos) {
        return pos.method_10074();
    }

    public static class_2338 north(class_2338 pos) {
        return pos.method_10095();
    }

    public static class_2338 south(class_2338 pos) {
        return pos.method_10072();
    }

    public static class_2338 east(class_2338 pos) {
        return pos.method_10078();
    }

    public static class_2338 west(class_2338 pos) {
        return pos.method_10067();
    }

    public static class_2338 add(class_2338 pos, int x, int y, int z) {
        return pos.method_10069(x, y, z);
    }

    public static class_2338 sub(class_2338 pos, int x, int y, int z) {
        return pos.method_10059(new class_2382(x, y, z));
    }

    public static class_2338 mul(class_2338 pos, int n) {
        return new class_2338(pos.method_10263() * n, pos.method_10264() * n, pos.method_10260() * n);
    }

    public static int x(class_2338 pos) {
        return pos.method_10263();
    }

    public static int y(class_2338 pos) {
        return pos.method_10264();
    }

    public static int z(class_2338 pos) {
        return pos.method_10260();
    }

    public static class_2338 offset(class_2338 pos, class_2350 direction) {
        return pos.method_10093(direction);
    }

    public static class_2338 offset(class_2338 pos, class_2350 direction, int n) {
        return pos.method_10079(direction, n);
    }

    public static class_2338 offset(class_2338 pos, net.pitan76.mcpitanlib.midohra.util.math.Direction direction) {
        return pos.method_10093(direction.toMinecraft());
    }

    public static class_2338 offset(class_2338 pos, net.pitan76.mcpitanlib.midohra.util.math.Direction direction, int n) {
        return pos.method_10079(direction.toMinecraft(), n);
    }

    public static class_2338 toImmutable(class_2338 pos) {
        return pos.method_10062();
    }

    public static long asLong(class_2338 pos) {
        return pos.method_10063();
    }
}
