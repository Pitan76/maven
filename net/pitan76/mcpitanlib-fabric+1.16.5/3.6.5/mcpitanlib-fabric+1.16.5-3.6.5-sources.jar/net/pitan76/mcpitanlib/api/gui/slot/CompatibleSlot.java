package net.pitan76.mcpitanlib.api.gui.slot;

import net.minecraft.class_1263;
import net.minecraft.class_1657;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.pitan76.mcpitanlib.api.entity.Player;
import net.pitan76.mcpitanlib.api.util.inventory.ICompatInventory;

public class CompatibleSlot extends class_1735 {
    public class_1263 inventory;
    public int index;
    public int x;
    public int y;

    public CompatibleSlot(class_1263 inventory, int index, int x, int y) {
        super(inventory, index, x, y);
        this.field_7871 = inventory;
        this.index = index;
        this.field_7873 = x;
        this.field_7872 = y;
    }

    public CompatibleSlot(ICompatInventory inventory, int index, int x, int y) {
        super(inventory, index, x, y);
        this.field_7871 = inventory;
        this.index = index;
        this.field_7873 = x;
        this.field_7872 = y;
    }

    public void callSetStack(class_1799 stack) {
        super.method_7673(stack);
    }

    public void callSetStackNoCallbacks(class_1799 stack) {
        //super.setStackNoCallbacks(stack);
    }

    public class_1799 callGetStack() {
        return super.method_7677();
    }

    public class_1799 callTakeStack(int amount) {
        return super.method_7671(amount);
    }

    public boolean callHasStack() {
        return super.method_7681();
    }

    @Deprecated
    @Override
    public void method_7673(class_1799 stack) {
       callSetStack(stack);
    }

    @Deprecated
    @Override
    public class_1799 method_7677() {
        return callGetStack();
    }

    @Deprecated
    @Override
    public class_1799 method_7671(int amount) {
        return callTakeStack(amount);
    }

    @Deprecated
    @Override
    public boolean method_7681() {
        return callHasStack();
    }

    public class_1263 callGetInventory() {
        return field_7871;
    }

    public int callGetIndex() {
        return index;
    }

    public int callGetId() {
        return super.field_7874;
    }

    public int callGetX() {
        return super.field_7873;
    }

    public int callGetY() {
        return super.field_7872;
    }

    public void callMarkDirty() {
        super.method_7668();
    }

    @Override
    public boolean method_7680(class_1799 stack) {
        return canInsert(net.pitan76.mcpitanlib.midohra.item.ItemStack.of(stack));
    }

    @Override
    public boolean method_7674(class_1657 playerEntity) {
        return canTakeItems(new Player(playerEntity));
    }

    public boolean canInsert(net.pitan76.mcpitanlib.midohra.item.ItemStack stack) {
        return super.method_7680(stack.toMinecraft());
    }

    public boolean canTakeItems(Player player) {
        return super.method_7674(player.getEntity());
    }

    public boolean canTakePartial(Player player) {
        return canTakeItems(player);
    }
}
