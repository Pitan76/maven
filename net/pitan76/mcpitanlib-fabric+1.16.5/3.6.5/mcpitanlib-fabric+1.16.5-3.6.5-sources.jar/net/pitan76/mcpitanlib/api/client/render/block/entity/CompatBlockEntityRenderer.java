package net.pitan76.mcpitanlib.api.client.render.block.entity;

import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_824;
import net.minecraft.class_827;
import net.pitan76.mcpitanlib.api.client.render.block.entity.event.BlockEntityRenderEvent;
import net.pitan76.mcpitanlib.api.tile.CompatBlockEntity;

// TODO: 1.16.5ではextendsで1.18ではimplementsに変更されているため、ラッパーを作成する必要がある
@Deprecated
public abstract class CompatBlockEntityRenderer<T extends CompatBlockEntity> extends class_827<T> {

    public CompatBlockEntityRenderer(class_824 dispatcher) {
        super(dispatcher);
    }

    abstract void render(BlockEntityRenderEvent<T> event);

    @Override
    public void render(T entity, float tickDelta, class_4587 matrices, class_4597 vertexConsumers, int light, int overlay) {
        render(new BlockEntityRenderEvent<>(this, entity, tickDelta, matrices, vertexConsumers, light, overlay));
    }

    public boolean rendersOutsideBoundingBoxOverride(T blockEntity) {
        return super.method_3563(blockEntity);
    }

    public int getRenderDistanceOverride() {
        return 64;
    }

    @Deprecated
    @Override
    public boolean rendersOutsideBoundingBox(T blockEntity) {
        return rendersOutsideBoundingBoxOverride(blockEntity);
    }

}
