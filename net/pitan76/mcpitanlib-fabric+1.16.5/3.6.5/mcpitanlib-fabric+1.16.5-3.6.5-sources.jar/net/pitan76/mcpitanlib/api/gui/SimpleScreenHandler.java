package net.pitan76.mcpitanlib.api.gui;

import net.minecraft.class_1263;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1713;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_3917;
import net.pitan76.mcpitanlib.api.entity.Player;
import net.pitan76.mcpitanlib.api.gui.args.CreateMenuEvent;
import net.pitan76.mcpitanlib.api.gui.args.SlotClickEvent;
import net.pitan76.mcpitanlib.api.util.ItemStackUtil;
import net.pitan76.mcpitanlib.api.util.ScreenHandlerUtil;
import net.pitan76.mcpitanlib.api.util.SlotUtil;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.List;

public class SimpleScreenHandler extends class_1703 {
    protected SimpleScreenHandler(@Nullable class_3917<?> type, int syncId) {
        super(type, syncId);
    }

    protected SimpleScreenHandler(@Nullable class_3917<?> type, CreateMenuEvent e) {
        this(type, e.getSyncId());
    }

    public boolean hasMainInventory = false;
    public boolean hasHotbar = false;

    @Deprecated
    @Override
    public boolean method_7597(class_1657 player) {
        return canUse(new Player(player));
    }

    public boolean canUse(Player player) {
        return true;
    }

    public class_1735 addNormalSlot(class_1263 inventory, int index, int x, int y) {
        class_1735 slot = new class_1735(inventory, index, x, y);
        return this.method_7621(slot);
    }

    public <T extends class_1735> class_1735 addSlot(class_1263 inventory, int index, int x, int y, SlotFactory<T> factory) {
        class_1735 slot = factory.create(inventory, index, x, y);
        return this.method_7621(slot);
    }

    public interface SlotFactory<T extends class_1735> {
        T create(class_1263 inventory, int index, int x, int y);
    }

    public class_1735 callAddSlot(class_1735 slot) {
        return this.method_7621(slot);
    }

    @Deprecated
    @Override
    protected class_1735 method_7621(class_1735 slot) {
        return super.method_7621(slot);
    }

    @Deprecated
    @Override
    public void method_7595(class_1657 player) {
        this.close(new Player(player));
    }

    public void close(Player player) {
        super.method_7595(player.getPlayerEntity());
    }


    public static final int DEFAULT_SLOT_SIZE = 18;

    /**
     * Add player main inventory slots
     * @param inventory target player inventory
     * @param x start x
     * @param y start y
     */
    protected List<class_1735> addPlayerMainInventorySlots(class_1661 inventory, int x, int y) {
        hasMainInventory = true;
        return this.addSlots(inventory, 9, x, y, DEFAULT_SLOT_SIZE, 9, 3);
    }

    /**
     * Add player hotbar slots
     * @param inventory target player inventory
     * @param x start x
     * @param y start y
     */
    protected List<class_1735> addPlayerHotbarSlots(class_1661 inventory, int x, int y) {
        hasHotbar = true;
        return this.addSlotsX(inventory, 0, x, y, DEFAULT_SLOT_SIZE, 9);
    }

    /**
     * 一括でスロットを設置する
     * @param inventory target inventory
     * @param firstIndex fisrt index
     * @param firstX first x
     * @param firstY first y
     * @param size a slot size (if this is -1, set 18 to this)
     * @param maxAmountX x line slot max amount
     * @param maxAmountY y line slot max amount
     * @return Slot list
     */
    protected List<class_1735> addSlots(class_1263 inventory, int firstIndex, int firstX, int firstY, int size, int maxAmountX, int maxAmountY) {
        if (size < 0) size = DEFAULT_SLOT_SIZE;
        List<class_1735> slots = new ArrayList<>();
        for (int y = 0; y < maxAmountY; ++y) {
            List<class_1735> xSlots = this.addSlotsX(inventory, firstIndex + (y * maxAmountX), firstX, firstY + (y * size), size, maxAmountX);
            slots.addAll(xSlots);
        }
        return slots;
    }

    /**
     * 一括で横にスロットを設置する
     * @param inventory target inventory
     * @param firstIndex first index
     * @param firstX first x
     * @param y y
     * @param size a slot size (if this is -1, set 18 to this)
     * @param amount slot amount
     * @return Slot list
     */
    protected List<class_1735> addSlotsX(class_1263 inventory, int firstIndex, int firstX, int y, int size, int amount) {
        if (size < 0) size = DEFAULT_SLOT_SIZE;
        List<class_1735> slots = new ArrayList<>();
        for (int x = 0; x < amount; ++x) {
            class_1735 slot = this.addNormalSlot(inventory, firstIndex + x, firstX + (x * size), y);
            slots.add(slot);
        }
        return slots;
    }

    /**
     * 一括で縦にスロットを設置する
     * @param inventory target inventory
     * @param firstIndex first index
     * @param x x
     * @param firstY first y
     * @param size a slot size (if this is -1, set 18 to this)
     * @param amount slot amount
     * @return Slot list
     */
    protected List<class_1735> addSlotsY(class_1263 inventory, int firstIndex, int x, int firstY, int size, int amount) {
        if (size < 0) size = DEFAULT_SLOT_SIZE;
        List<class_1735> slots = new ArrayList<>();
        for (int y = 0; y < amount; ++y) {
            class_1735 slot = this.addNormalSlot(inventory, firstIndex + x, x, firstY + (y * size));
            slots.add(slot);
        }
        return slots;
    }

    @Deprecated
    public class_1799 quickMoveOverride(class_1657 player, int index) {
        return quickMoveOverride(new Player(player), index);
    }

    public boolean callInsertItem(class_1799 stack, int startIndex, int endIndex, boolean fromLast) {
        return this.method_7616(stack, startIndex, endIndex, fromLast);
    }

    @Deprecated
    @Override
    protected boolean method_7616(class_1799 stack, int startIndex, int endIndex, boolean fromLast) {
        return super.method_7616(stack, startIndex, endIndex, fromLast);
    }

    public class_1799 quickMoveOverride(Player player, int index) {
        class_1799 itemStack = ItemStackUtil.empty();
        class_1735 slot = ScreenHandlerUtil.getSlot(this, index);
        int size = ScreenHandlerUtil.getSlots(this).size();

        if (SlotUtil.hasStack(slot)) {
            class_1799 itemStack2 = SlotUtil.getStack(slot);
            itemStack = itemStack2.method_7972();

            if (hasMainInventory && hasHotbar) {
                if (index > 35) {
                    if (!this.callInsertItem(itemStack2, 0, 9, false)) {
                        if (!this.callInsertItem(itemStack2, 9, 36, true)) {
                            return ItemStackUtil.empty();
                        }
                    }
                } else if (size > 36 && !this.callInsertItem(itemStack2, 36, size, false)) {
                    return ItemStackUtil.empty();
                }
            }

            if (itemStack2.method_7960()) {
                SlotUtil.setStack(slot, ItemStackUtil.empty());
            } else {
                SlotUtil.markDirty(slot);
            }

            if (itemStack2.method_7947() == itemStack.method_7947()) {
                return ItemStackUtil.empty();
            }

            SlotUtil.onTakeItem(slot, player, itemStack2);
        }

        return itemStack;
    }


    @Deprecated
    @Override
    public class_1799 method_7601(class_1657 player, int slot) {
        return quickMoveOverride(player, slot);
    }

    @Deprecated
    @Override
    public class_1735 method_7611(int index) {
        return callGetSlot(index);
    }

    public class_1735 callGetSlot(int index) {
        return super.method_7611(index);
    }

    @Deprecated
    @Override
    public class_1799 method_7593(int slotIndex, int button, class_1713 actionType, class_1657 player) {
        overrideOnSlotClick(slotIndex, button, actionType, new Player(player));
        return super.method_7593(slotIndex, button, actionType, player);
    }

    public void overrideOnSlotClick(int slotIndex, int button, class_1713 actionType, Player player) {
        onSlotClick(new SlotClickEvent(slotIndex, button, actionType, player));
    }

    public void onSlotClick(SlotClickEvent e) {
        super.method_7593(e.slot, e.button, e.actionType, e.player.getEntity());
    }

    public void callSetCursorStack(class_1799 stack) {
        if (stack.method_27319() instanceof class_1657) {
            Player player = new Player((class_1657) stack.method_27319());
            player.getInventory().method_7396(stack);
        }
    }

    @Override
    @Deprecated
    public void method_7619(int slot, class_1799 stack) {
        callSetStackInSlot(slot, -1, stack);
    }

    public void callSetStackInSlot(int slot, int revision, class_1799 stack) {
        super.method_7619(slot, stack);
    }

    public int callGetRevision() {
        return -1;
    }

    public net.pitan76.mcpitanlib.midohra.item.ItemStack getCursorStackM() {
        return ScreenHandlerUtil.getCursorStackM(this);
    }

    public class_1799 callGetCursorStack() {
        return ScreenHandlerUtil.getCursorStack(this);
    }

    public void setCursorStack(net.pitan76.mcpitanlib.midohra.item.ItemStack stack) {
        ScreenHandlerUtil.setCursorStackM(this, stack);
    }

    @Deprecated
    @Override
    public boolean method_7613(class_1799 carried, class_1735 target) {
        return canInsertIntoSlotOverride(net.pitan76.mcpitanlib.midohra.item.ItemStack.of(carried), target);
    }

    @Deprecated
    @Override
    public boolean method_7615(class_1735 slot) {
        return canInsertIntoSlotOverride(slot);
    }

    public boolean canInsertIntoSlotOverride(net.pitan76.mcpitanlib.midohra.item.ItemStack carried, class_1735 target) {
        return super.method_7613(carried.toMinecraft(), target);
    }

    public boolean canInsertIntoSlotOverride(class_1735 slot) {
        return super.method_7615(slot);
    }
}
