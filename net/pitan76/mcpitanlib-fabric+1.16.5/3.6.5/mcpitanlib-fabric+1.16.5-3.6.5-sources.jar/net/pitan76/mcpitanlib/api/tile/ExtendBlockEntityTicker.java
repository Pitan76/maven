package net.pitan76.mcpitanlib.api.tile;

import net.minecraft.class_2586;
import net.pitan76.mcpitanlib.api.event.tile.TileTickEvent;

public interface ExtendBlockEntityTicker<T extends class_2586> {
    void tick(TileTickEvent<T> event);
}
