package net.pitan76.mcpitanlib.api.event.item;

import net.minecraft.class_1268;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1838;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_3965;
import net.pitan76.mcpitanlib.api.entity.Player;
import net.pitan76.mcpitanlib.api.event.BaseEvent;
import net.pitan76.mcpitanlib.api.util.CompatActionResult;
import net.pitan76.mcpitanlib.api.util.WorldUtil;
import net.pitan76.mcpitanlib.midohra.block.BlockWrapper;
import net.pitan76.mcpitanlib.midohra.block.entity.BlockEntityWrapper;
import net.pitan76.mcpitanlib.midohra.item.ItemWrapper;
import net.pitan76.mcpitanlib.midohra.world.IWorldView;
import org.jetbrains.annotations.Nullable;

public class ItemUseOnBlockEvent extends BaseEvent {
    public Player player;
    public class_1268 hand;
    public class_3965 hit;
    public class_1799 stack;
    public class_1937 world;
    public class_2338 blockPos;

    public ItemUseOnBlockEvent(class_1657 player, class_1268 hand, class_3965 hit) {
        this(player.field_6002, player, hand, player.method_5998(hand), hit);
    }

    public ItemUseOnBlockEvent(class_1937 world, @Nullable class_1657 player, class_1268 hand, class_1799 stack, class_3965 hit) {
        if (player != null)
            this.player = new Player(player);
        this.hand = hand;
        this.hit = hit;
        this.stack = stack;
        this.world = world;
        this.blockPos = hit.method_17777();
    }

    public ItemUseOnBlockEvent(Player player, class_1268 hand, class_3965 hit) {
        this(player.getWorld(), player.getEntity(), hand, player.getStackInHand(hand), hit);
    }

    public class_1838 toIUC() {
        return new class_1838(player.getPlayerEntity(), hand, hit);
    }

    public boolean isClient() {
        return world.method_8608();
    }

    public Player getPlayer() {
        return player;
    }

    public class_1937 getWorld() {
        return world;
    }

    public class_3965 getHit() {
        return hit;
    }

    public class_2338 getBlockPos() {
        return blockPos;
    }

    public class_1268 getHand() {
        return hand;
    }

    public class_1799 getStack() {
        return stack;
    }

    public CompatActionResult success() {
        return CompatActionResult.SUCCESS;
    }

    public CompatActionResult fail() {
        return CompatActionResult.FAIL;
    }

    public CompatActionResult pass() {
        return CompatActionResult.PASS;
    }

    public CompatActionResult consume() {
        return CompatActionResult.CONSUME;
    }

    public class_2586 getBlockEntity() {
        return WorldUtil.getBlockEntity(world, blockPos);
    }

    public boolean hasBlockEntity() {
        return WorldUtil.hasBlockEntity(world, blockPos);
    }

    public class_2680 getBlockState() {
        return WorldUtil.getBlockState(world, blockPos);
    }

    public class_243 getPos() {
        return hit.method_17784();
    }

    public class_2350 getSide() {
        return hit.method_17780();
    }

    public net.pitan76.mcpitanlib.midohra.world.World getMidohraWorld() {
        return net.pitan76.mcpitanlib.midohra.world.World.of(world);
    }

    public IWorldView getWorldView() {
        return getMidohraWorld();
    }

    public net.pitan76.mcpitanlib.midohra.block.BlockState getMidohraState() {
        return net.pitan76.mcpitanlib.midohra.block.BlockState.of(getBlockState());
    }

    public net.pitan76.mcpitanlib.midohra.util.math.BlockPos getMidohraPos() {
        return net.pitan76.mcpitanlib.midohra.util.math.BlockPos.of(getBlockPos());
    }

    public BlockWrapper getBlockWrapper() {
        return getMidohraState().getBlock();
    }

    public BlockEntityWrapper getBlockEntityWrapper() {
        return BlockEntityWrapper.of(getBlockEntity());
    }

    public boolean isSneaking() {
        return player.isSneaking();
    }

    public net.pitan76.mcpitanlib.midohra.item.ItemStack getStackM() {
        return net.pitan76.mcpitanlib.midohra.item.ItemStack.of(stack);
    }

    public class_1792 getItem() {
        return stack.method_7909();
    }

    public ItemWrapper getItemWrapper() {
        return ItemWrapper.of(getItem());
    }
}
