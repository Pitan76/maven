package net.pitan76.mcpitanlib.api.tag.v2.typed;

import me.shedaniel.architectury.hooks.TagHooks;
import net.minecraft.class_1792;
import net.minecraft.class_1856;
import net.minecraft.class_3494;
import net.pitan76.mcpitanlib.api.tag.v2.CompatTagKey;
import net.pitan76.mcpitanlib.api.tag.v2.CompatTagKeyType;
import net.pitan76.mcpitanlib.api.util.CompatIdentifier;
import net.pitan76.mcpitanlib.api.util.IngredientUtil;

import java.util.List;

public class ItemTagKey extends CompatTagKey<class_1792> {
    @Deprecated
    public ItemTagKey(class_3494.class_5123<class_1792> tagKey) {
        super(tagKey);
    }

    public static ItemTagKey of(CompatIdentifier identifier) {
        return new ItemTagKey(TagHooks.getOptional(identifier.toMinecraft(), CompatTagKeyType.ITEM::getTagGroup));
    }

    public class_1856 asIngredient() {
        return IngredientUtil.fromTagByIdentifier(getTagKey().method_26791());
    }

    public List<class_1792> values() {
        return getTagKey().method_15138();
    }
}
