package net.pitan76.mcpitanlib.api.block;

import net.minecraft.class_3414;
import net.minecraft.class_3737;
import net.pitan76.mcpitanlib.api.sound.CompatSoundEvent;
import net.pitan76.mcpitanlib.api.sound.CompatSoundEvents;

import java.util.Optional;

public interface CompatWaterloggable extends class_3737 {

    default Optional<class_3414> getBucketFillSound() {
        return getCompactBucketFillSound()
                .map(CompatSoundEvent::get);
    }

    default Optional<CompatSoundEvent> getCompactBucketFillSound() {
        return Optional.of(CompatSoundEvents.ITEM_BUCKET_FILL);
    }
}
