package net.pitan76.mcpitanlib.api.item.consume;

import net.minecraft.class_1839;
import net.pitan76.mcpitanlib.api.util.CompatStringIdentifiable;

public class CompatUseAction implements CompatStringIdentifiable {
    private final class_1839 useAction;

    public static final CompatUseAction NONE = of(class_1839.field_8952);
    public static final CompatUseAction EAT = of(class_1839.field_8950);
    public static final CompatUseAction DRINK = of(class_1839.field_8946);
    public static final CompatUseAction BLOCK = of(class_1839.field_8949);
    public static final CompatUseAction BOW = of(class_1839.field_8953);
    public static final CompatUseAction SPEAR = of(class_1839.field_8951);
    public static final CompatUseAction CROSSBOW = of(class_1839.field_8947);
    public static final CompatUseAction SPYGLASS = of(class_1839.field_8952);
    public static final CompatUseAction TOOT_HORN = of(class_1839.field_8952);
    public static final CompatUseAction BRUSH = of(class_1839.field_8952);

    public CompatUseAction(class_1839 useAction) {
        this.useAction = useAction;
    }

    public static CompatUseAction of(class_1839 useAction) {
        return new CompatUseAction(useAction);
    }

    @Deprecated
    public class_1839 getUseAction() {
        return useAction;
    }

    public int getId() {
        return -1;
    }

    public String getName() {
        return useAction.name();
    }

    @Override
    public String asString_compat() {
        return getName();
    }
}
