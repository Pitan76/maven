package net.pitan76.mcpitanlib.api.registry;

import me.shedaniel.architectury.registry.RegistrySupplier;
import net.minecraft.class_1291;
import net.minecraft.class_1299;
import net.minecraft.class_1761;
import net.minecraft.class_1792;
import net.minecraft.class_1887;
import net.minecraft.class_1935;
import net.minecraft.class_2248;
import net.minecraft.class_2396;
import net.minecraft.class_2591;
import net.minecraft.class_2960;
import net.minecraft.class_3414;
import net.minecraft.class_3611;
import net.minecraft.class_3917;
import net.pitan76.mcpitanlib.MCPitanLib;
import net.pitan76.mcpitanlib.api.block.CompatibleMaterial;
import net.pitan76.mcpitanlib.api.block.v2.CompatibleBlockSettings;
import net.pitan76.mcpitanlib.api.gui.ExtendedScreenHandlerTypeBuilder;
import net.pitan76.mcpitanlib.api.item.CreativeTabBuilder;
import net.pitan76.mcpitanlib.api.item.CreativeTabManager;
import net.pitan76.mcpitanlib.api.item.v2.CompatibleItemSettings;
import net.pitan76.mcpitanlib.api.registry.result.RegistryResult;
import net.pitan76.mcpitanlib.api.util.CompatIdentifier;
import net.pitan76.mcpitanlib.api.util.block.BlockUtil;
import net.pitan76.mcpitanlib.api.util.item.ItemUtil;
import net.pitan76.mcpitanlib.core.registry.FuelRegistry;
import net.pitan76.mcpitanlib.core.registry.MCPLRegistry;
import net.pitan76.mcpitanlib.core.registry.MCPLRegistry1_20;

import java.util.function.Supplier;

public class CompatRegistry {

    protected final MCPLRegistry mcplr;
    protected final MCPLRegistry1_20 mcplr1_20;
    protected final WorldGenRegistry worldGenRegistry;

    protected String MOD_ID;

    /**
     * @deprecated Use {@link #createRegistry(String)} instead
     */
    @Deprecated
    public CompatRegistry(String MOD_ID) {
        mcplr = new MCPLRegistry(MOD_ID);
        mcplr1_20 = new MCPLRegistry1_20(mcplr, MOD_ID);
        worldGenRegistry = new WorldGenRegistry(MOD_ID);
        this.MOD_ID = MOD_ID;
    }

    /**
     * create(new CompatRegistry)'s alias
     * @see #create(String)
     */
    public static CompatRegistry createRegistry(String MOD_ID) {
        return new CompatRegistry(MOD_ID);
    }

    /**
     * Create a new CompatRegistry
     * @param MOD_ID The mod id
     * @return The new CompatRegistry
     */
    public static CompatRegistry create(String MOD_ID) {
        return createRegistry(MOD_ID);
    }

    /**
     * Register an item
     * @param id The item id
     * @param supplier The item supplier
     * @return The registry result
     */
    public RegistryResult<class_1792> registerItem(class_2960 id, Supplier<class_1792> supplier) {
        if (MCPitanLib.isItemBlackListed(id)) supplier = () -> ItemUtil.create(CompatibleItemSettings.of(CompatIdentifier.fromMinecraft(id)));
        RegistrySupplier<class_1792> registrySupplier = mcplr.registryItem(id, supplier);
        CreativeTabManager.register(id);
        return new RegistryResult<>(registrySupplier);
    }

    public RegistryResult<class_2248> registerBlock(class_2960 id, Supplier<class_2248> supplier) {
        if (MCPitanLib.isBlockBlackListed(id)) supplier = () -> BlockUtil.create(CompatibleBlockSettings.of(CompatIdentifier.fromMinecraft(id), CompatibleMaterial.STONE));
        return new RegistryResult<>(mcplr.registryBlock(id, supplier));
    }

    public RegistryResult<class_3917<?>> registerScreenHandlerType(class_2960 id, Supplier<class_3917<?>> supplier) {
        return new RegistryResult<>(mcplr.registryScreenHandlerType(id, supplier));
    }

    @Deprecated
    public RegistryResult<class_3917<?>> registerExtendedScreenHandlerType(class_2960 id, Supplier<ExtendedScreenHandlerTypeBuilder<?>> supplier) {
        return registerScreenHandlerType(id, () -> supplier.get().build());
    }

    public RegistryResult<class_3917<?>> registerMenu(class_2960 id, Supplier<class_3917<?>> supplier) {
        return registerScreenHandlerType(id, supplier);
    }

    public RegistryResult<class_2591<?>> registerBlockEntityType(class_2960 id, Supplier<class_2591<?>> supplier) {
        return new RegistryResult<>(mcplr.registryBlockEntityType(id, supplier));
    }

    public RegistryResult<class_1299<?>> registerEntity(class_2960 id, Supplier<class_1299<?>> supplier) {
        return new RegistryResult<>(mcplr.registryEntityType(id, supplier));
    }

    @Deprecated
    public RegistryResult<class_3414> registerSoundEvent(class_2960 id, Supplier<class_3414> supplier) {
        return new RegistryResult<>(mcplr.registrySoundEvent(id, supplier));
    }

    public RegistryResult<class_3414> registerSoundEvent(class_2960 id) {
        return registerSoundEvent(id, () -> new class_3414(id));
    }

    public RegistryResult<class_3414> registerSoundEvent(class_2960 id, float distanceToTravel) {
        return registerSoundEvent(id, () -> new class_3414(id));
    }

    public RegistryResult<class_3611> registerFluid(class_2960 id, Supplier<class_3611> supplier) {
        return new RegistryResult<>(mcplr.registryFluid(id, supplier));
    }

    public RegistryResult<class_2396<?>> registerParticleType(class_2960 id, Supplier<class_2396<?>> supplier) {
        return new RegistryResult<>(mcplr.registryParticleType(id, supplier));
    }

    public RegistryResult<class_1887> registerEnchantment(class_2960 id, Supplier<class_1887> supplier) {
        return new RegistryResult<>(mcplr.registryEnchantment(id, supplier));
    }

    public RegistryResult<class_1291> registerStatusEffect(class_2960 id, Supplier<class_1291> supplier) {
        return new RegistryResult<>(mcplr.registryStatusEffect(id, supplier));
    }

    public RegistryResult<class_1761> registerItemGroup(class_2960 id, Supplier<class_1761> supplier) {
        return new RegistryResult<>(null);
    }

    public RegistryResult<class_1761> registerItemGroup(class_2960 id, CreativeTabBuilder builder) {
        return new RegistryResult<>(mcplr1_20.registryItemGroup(id, builder));
    }

    public RegistryResult<class_1761> registerItemGroup(CreativeTabBuilder builder) {
        return registerItemGroup(builder.getIdentifier(), builder);
    }

    public static void registerFuel(int time, class_1935... item) {
        FuelRegistry.register(time, item);
    }

    public void allRegister() {
        // 1.16 Register
        mcplr.allRegister1_16();

        mcplr1_20.register();

        // ItemGroup
        CreativeTabManager.allRegister();
    }

    @Deprecated
    public MCPLRegistry getMcplr() {
        return mcplr;
    }

    @Deprecated
    public MCPLRegistry1_20 getMcplr1_20() {
        return mcplr1_20;
    }

    public String getNamespace() {
        return MOD_ID;
    }
}
