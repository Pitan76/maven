package net.pitan76.mcpitanlib.api.tag.v2;

import me.shedaniel.architectury.hooks.TagHooks;
import net.minecraft.class_3494;
import net.pitan76.mcpitanlib.api.tag.TagKey;
import net.pitan76.mcpitanlib.api.util.CompatIdentifier;

public class CompatTagKey<T> extends TagKey<T> {
    @Deprecated
    public CompatTagKey(class_3494.class_5123<T> tagKey) {
        super(tagKey);
    }

    @Deprecated
    public static <T> CompatTagKey<T> of(class_3494.class_5123<T> tagKey) {
        return new CompatTagKey<>(tagKey);
    }

    public static <T> CompatTagKey<T> of(CompatTagKeyType<T> type, CompatIdentifier identifier) {
        return of(TagHooks.getOptional(identifier.toMinecraft(), type::getTagGroup));
    }

    public boolean isOf(T value) {
        return getTagKey().method_15141(value);
    }

    public CompatIdentifier getId() {
        return CompatIdentifier.fromMinecraft(getTagKey().method_26791());
    }
}
