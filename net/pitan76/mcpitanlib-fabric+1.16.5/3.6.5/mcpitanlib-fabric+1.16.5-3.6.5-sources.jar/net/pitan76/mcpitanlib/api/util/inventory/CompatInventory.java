package net.pitan76.mcpitanlib.api.util.inventory;

import net.minecraft.class_1263;
import net.minecraft.class_1277;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_2371;
import net.pitan76.mcpitanlib.api.entity.CompatContainerUser;
import net.pitan76.mcpitanlib.api.entity.Player;
import net.pitan76.mcpitanlib.api.registry.CompatRegistryLookup;
import net.pitan76.mcpitanlib.api.util.collection.ItemStackList;
import net.pitan76.mcpitanlib.api.util.inventory.args.CanInsertArgs;
import net.pitan76.mcpitanlib.midohra.nbt.NbtList;

import java.util.List;

public class CompatInventory extends class_1277 implements ICompatInventory {
    public CompatInventory(int size) {
        super(size);
    }

    @Override
    public void method_5447(int slot, class_1799 stack) {
        super.method_5447(slot, stack);
    }

    /**
     * super method of setStack(slot, stack)
     */
    public final void superSetStack(int slot, class_1799 stack) {
        super.method_5447(slot, stack);
    }

    /**
     * super method of removeStack(slot, amount)
     */
    public final class_1799 superRemoveStack(int slot, int amount) {
        return super.method_5434(slot, amount);
    }

    @Override
    public class_1799 method_5434(int slot, int amount) {
        return callRemoveStack(slot, amount);
    }

    public class_1799 callRemoveStack(int slot, int amount) {
        return super.method_5434(slot, amount);
    }

    @Override
    public class_1799 method_5441(int slot) {
        return super.method_5441(slot);
    }

    @Override
    public class_1799 method_20631(class_1792 item, int count) {
        return super.method_20631(item, count);
    }

    @Deprecated
    @Override
    public void method_5435(class_1657 player) {
        onOpen(new Player(player));
    }

    @Deprecated
    @Override
    public void method_5432(class_1657 player) {
        onClose(new Player(player));
    }

    @Deprecated
    @Override
    public net.minecraft.class_2499 method_7660() {
        return toNbtList(new CompatRegistryLookup()).toMinecraft();
    }

    @Deprecated
    @Override
    public void method_7659(net.minecraft.class_2499 list) {
        readNbtList(NbtList.of(list), new CompatRegistryLookup());
    }

    @Deprecated
    @Override
    public boolean method_5443(class_1657 player) {
        return canPlayerUse(new Player(player));
    }

    @Deprecated
    @Override
    public boolean method_27070(class_1799 stack) {
        return canInsert(new CanInsertArgs(stack));
    }

    public void onOpen(Player player) {
        this.onOpen(new CompatContainerUser(player.getEntity()));
    }

    public void onClose(Player player) {
        this.onClose(new CompatContainerUser(player.getEntity()));
    }

    public void onOpen(CompatContainerUser user) {
        super.method_5435(user.getRaw());
    }

    public void onClose(CompatContainerUser user) {
        super.method_5432(user.getRaw());
    }

    public NbtList toNbtList(CompatRegistryLookup registries) {
        return NbtList.of(super.method_7660());
    }

    public void readNbtList(NbtList list, CompatRegistryLookup registries) {
        super.method_7659(list.toMinecraft());
    }

    public boolean canPlayerUse(Player player) {
        return true;
    }

    public boolean canInsert(CanInsertArgs args) {
        return super.method_27070(args.getMcStack());
    }

    @Deprecated
    @Override
    public List<class_1799> method_24514() {
        return callClearToList();
    }

    public List<class_1799> callClearToList() {
        return super.method_24514();
    }

    public class_2371<class_1799> callGetHeldStacks() {
        ItemStackList list = ItemStackList.ofSize(method_5439());
        for (int i = 0; i < method_5439(); i++) {
            list.add(callGetStack(i));
        }

        return list;
    }

    public ItemStackList callGetHeldStacksAsItemStackList() {
        return ItemStackList.of(callGetHeldStacks());
    }

    @Deprecated
    @Override
    public class_1799 method_5438(int slot) {
        return callGetStack(slot);
    }

    public class_1799 callGetStack(int slot) {
        return super.method_5438(slot);
    }

    @Deprecated
    @Override
    public int method_5439() {
        return getSize();
    }

    public int getSize() {
        return super.method_5439();
    }

    @Deprecated
    @Override
    public boolean method_5442() {
        return callIsEmpty();
    }

    public boolean callIsEmpty() {
        return super.method_5442();
    }

    public boolean callCanTransferTo(class_1263 hopperInventory, int slot, class_1799 stack) {
        return hopperInventory.method_5437(slot, stack);
    }

    @Deprecated
    @Override
    public class_1799 method_5491(class_1799 stack) {
        return callAddStack(stack);
    }

    public class_1799 callAddStack(class_1799 stack) {
        return super.method_5491(stack);
    }

    @Deprecated
    @Override
    public int method_5444() {
        return callGetMaxCountPerStack();
    }

    public int callGetMaxCountPerStack() {
        return super.method_5444();
    }
}
