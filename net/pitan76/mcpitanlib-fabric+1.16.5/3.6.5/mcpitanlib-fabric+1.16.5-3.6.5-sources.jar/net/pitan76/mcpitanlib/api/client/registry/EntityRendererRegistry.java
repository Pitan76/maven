package net.pitan76.mcpitanlib.api.client.registry;

import java.util.function.Supplier;
import net.minecraft.class_1299;
import net.minecraft.class_310;
import net.minecraft.class_897;
import net.minecraft.class_953;

public class EntityRendererRegistry {
    public static void registerEntityRendererAsFlyingItem(Supplier<class_1299<?>> entityType) {
        CompatRegistryClient.registerEntityRenderer(entityType, dispatcher -> (class_897) new class_953<>(dispatcher, class_310.method_1551().method_1480()));
    }
}
