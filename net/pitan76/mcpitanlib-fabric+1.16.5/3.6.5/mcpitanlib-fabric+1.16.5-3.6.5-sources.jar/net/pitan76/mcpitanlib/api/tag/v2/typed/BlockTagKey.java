package net.pitan76.mcpitanlib.api.tag.v2.typed;

import me.shedaniel.architectury.hooks.TagHooks;
import net.minecraft.class_2248;
import net.minecraft.class_3494;
import net.pitan76.mcpitanlib.api.tag.v2.CompatTagKey;
import net.pitan76.mcpitanlib.api.tag.v2.CompatTagKeyType;
import net.pitan76.mcpitanlib.api.util.CompatIdentifier;

import java.util.List;

public class BlockTagKey extends CompatTagKey<class_2248> {
    @Deprecated
    public BlockTagKey(class_3494.class_5123<class_2248> tagKey) {
        super(tagKey);
    }

    public static BlockTagKey of(CompatIdentifier identifier) {
        return new BlockTagKey(TagHooks.getOptional(identifier.toMinecraft(), CompatTagKeyType.BLOCK::getTagGroup));
    }

    public List<class_2248> values() {
        return getTagKey().method_15138();
    }
}
