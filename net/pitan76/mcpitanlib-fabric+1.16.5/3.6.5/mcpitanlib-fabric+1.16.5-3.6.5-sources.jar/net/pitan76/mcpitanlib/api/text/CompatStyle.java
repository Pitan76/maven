package net.pitan76.mcpitanlib.api.text;

import net.minecraft.class_2583;
import net.minecraft.class_5251;

public class CompatStyle {
    private final class_2583 style;

    public CompatStyle(class_2583 style) {
        this.style = style;
    }

    public CompatStyle() {
        this(class_2583.field_24360);
    }

    public static CompatStyle of(class_2583 style) {
        return new CompatStyle(style);
    }

    public static CompatStyle of() {
        return new CompatStyle();
    }

    public CompatStyle withColor(CompatTextColor color) {
        return new CompatStyle(style.method_27703(color.getRaw()));
    }

    public CompatStyle withColor(CompatFormatting formatting) {
        return new CompatStyle(style.method_10977(formatting.getRaw()));
    }

    public CompatStyle withColor(int rgbColor) {
        return new CompatStyle(style.method_27703(class_5251.method_27717(rgbColor)));
    }

    public CompatStyle withBold(boolean bold) {
        return new CompatStyle(style.method_10982(bold));
    }

    public CompatStyle withItalic(boolean italic) {
        return new CompatStyle(style.method_10978(italic));
    }

    public CompatStyle withUnderline(boolean underline) {
        return new CompatStyle(style.method_30938(underline));
    }

    public CompatStyle withStrikethrough(boolean strikethrough) {
        return withFormatting(CompatFormatting.STRIKETHROUGH);
    }

    public CompatStyle withObfuscated(boolean obfuscated) {
        return withFormatting(CompatFormatting.OBFUSCATED);
    }

    public CompatTextColor getColor() {
        if (style.method_10973() == null) return null;
        return new CompatTextColor(style.method_10973());
    }

    public boolean isBold() {
        return style.method_10984();
    }

    public boolean isItalic() {
        return style.method_10966();
    }

    public boolean isUnderlined() {
        return style.method_10965();
    }

    public boolean isStrikethrough() {
        return style.method_10986();
    }

    public boolean isObfuscated() {
        return style.method_10987();
    }

    public boolean isEmpty() {
        return style.method_10967();
    }

    public CompatStyle withFormatting(CompatFormatting formatting) {
        return withColor(formatting);
    }

    public class_2583 getRaw() {
        return style;
    }

    @Override
    public int hashCode() {
        return style.hashCode();
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        CompatStyle that = (CompatStyle) obj;
        return style.equals(that.style);
    }
}
