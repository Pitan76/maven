package net.pitan76.mcpitanlib.api.item;

import net.minecraft.class_1792;
import net.minecraft.class_1802;

public class CompatItems {
    public static class_1792 SHORT_GRASS = class_1802.field_8602;
    public static class_1792 TALL_GRASS = class_1802.field_8256;
    public static class_1792 TURTLE_SCUTE = class_1802.field_8161;

    // Compatibility
    public static class_1792 GRASS = SHORT_GRASS;
    public static class_1792 SCUTE = TURTLE_SCUTE;

    // ----

    public static class_1792 AIR = class_1802.field_8162;
    public static class_1792 STONE = class_1802.field_20391;
    public static class_1792 COBBLESTONE = class_1802.field_20412;
    public static class_1792 GRASS_BLOCK = class_1802.field_8270;
    public static class_1792 DIRT = class_1802.field_8831;
    public static class_1792 SAND = class_1802.field_8858;
    public static class_1792 RED_SAND = class_1802.field_8200;
    public static class_1792 GRANITE = class_1802.field_20394;
    public static class_1792 POLISHED_GRANITE = class_1802.field_20397;
    public static class_1792 DIORITE = class_1802.field_20401;
    public static class_1792 POLISHED_DIORITE = class_1802.field_20403;
    public static class_1792 ANDESITE = class_1802.field_20407;
    public static class_1792 POLISHED_ANDESITE = class_1802.field_20411;
    public static class_1792 COARSE_DIRT = class_1802.field_8460;
    public static class_1792 PODZOL = class_1802.field_8382;
    public static class_1792 OAK_LOG = class_1802.field_8583;
    public static class_1792 SPRUCE_LOG = class_1802.field_8684;
    public static class_1792 BIRCH_LOG = class_1802.field_8170;
    public static class_1792 JUNGLE_LOG = class_1802.field_8125;
    public static class_1792 ACACIA_LOG = class_1802.field_8820;
    public static class_1792 DARK_OAK_LOG = class_1802.field_8652;
    public static class_1792 OAK_PLANKS = class_1802.field_8118;
    public static class_1792 SPRUCE_PLANKS = class_1802.field_8113;
    public static class_1792 BIRCH_PLANKS = class_1802.field_8191;
    public static class_1792 JUNGLE_PLANKS = class_1802.field_8842;
    public static class_1792 ACACIA_PLANKS = class_1802.field_8651;
    public static class_1792 DARK_OAK_PLANKS = class_1802.field_8404;
    public static class_1792 GLASS = class_1802.field_8280;

    public static class_1792 STICK = class_1802.field_8600;
    public static class_1792 GLASS_BOTTLE = class_1802.field_8469;
    public static class_1792 EXP_BOTTLE = class_1802.field_8287;

    public static class_1792 GUNPOWDER = class_1802.field_8054;
    public static class_1792 REDSTONE = class_1802.field_8725;
    public static class_1792 COAL = class_1802.field_8713;
    public static class_1792 CHARCOAL = class_1802.field_8665;
    public static class_1792 IRON_INGOT = class_1802.field_8620;
    public static class_1792 COPPER_INGOT = class_1802.field_8162;
    public static class_1792 GOLD_INGOT = class_1802.field_8695;
    public static class_1792 DIAMOND = class_1802.field_8477;
    public static class_1792 EMERALD = class_1802.field_8687;
    public static class_1792 LAPIS_LAZULI = class_1802.field_8759;
    public static class_1792 NETHERITE_INGOT = class_1802.field_22020;
    public static class_1792 NETHERITE_SCRAP = class_1802.field_22021;
    public static class_1792 QUARTZ = class_1802.field_8155;

    // ----

    public static boolean isExist(class_1792 item) {
        return item != null && item != class_1802.field_8162;
    }
}
