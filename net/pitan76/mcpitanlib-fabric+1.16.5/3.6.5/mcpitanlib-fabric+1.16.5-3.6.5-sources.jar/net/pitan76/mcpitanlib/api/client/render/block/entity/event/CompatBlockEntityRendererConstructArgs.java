package net.pitan76.mcpitanlib.api.client.render.block.entity.event;

import net.minecraft.class_824;

public class CompatBlockEntityRendererConstructArgs {
    public final class_824 dispatcher;

    public CompatBlockEntityRendererConstructArgs(class_824 dispatcher) {
        this.dispatcher = dispatcher;
    }

    public CompatBlockEntityRendererConstructArgs() {
        this(null);
    }
}
