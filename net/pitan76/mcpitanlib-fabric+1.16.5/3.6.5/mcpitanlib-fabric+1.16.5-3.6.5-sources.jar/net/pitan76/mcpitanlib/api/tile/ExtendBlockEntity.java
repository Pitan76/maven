package net.pitan76.mcpitanlib.api.tile;

import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2591;
import net.pitan76.mcpitanlib.api.event.block.TileCreateEvent;
import net.pitan76.mcpitanlib.api.world.ExtendWorld;

public class ExtendBlockEntity extends CompatBlockEntity {
    public ExtendWorld world;

    public ExtendBlockEntity(class_2591<?> type) {
        super(type);
    }

    public ExtendBlockEntity(class_2591<?> type, TileCreateEvent event) {
        this(type);
    }

    @Override
    public void method_11009(class_1937 world, class_2338 pos) {
        super.method_11009(world, pos);
        this.world = new ExtendWorld(world);
    }
}
