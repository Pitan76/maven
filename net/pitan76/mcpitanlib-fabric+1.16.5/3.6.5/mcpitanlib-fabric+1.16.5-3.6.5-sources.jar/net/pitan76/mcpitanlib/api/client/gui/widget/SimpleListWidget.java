package net.pitan76.mcpitanlib.api.client.gui.widget;

import com.google.common.collect.ImmutableList;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_310;
import net.minecraft.class_339;
import net.minecraft.class_364;
import net.minecraft.class_4265;
import net.minecraft.class_4587;
import net.pitan76.mcpitanlib.api.client.render.DrawObjectDM;
import net.pitan76.mcpitanlib.api.client.render.handledscreen.RenderArgs;
import org.jetbrains.annotations.Nullable;

import java.util.List;
import java.util.Optional;

@Environment(EnvType.CLIENT)
public class SimpleListWidget extends class_4265<SimpleListWidget.WidgetEntry> {

    public SimpleListWidget(class_310 client, int width, int height, int top, int bottom, int itemHeight) {
        super(client, width, height, top, bottom, itemHeight);
        this.field_22744 = false;
    }

    public SimpleListWidget(class_310 client, int width, int height, int y, int itemHeight) {
        this(client, width, height, y, height - y, itemHeight);
    }

    public void add(class_339 widget) {
        super.method_25321(WidgetEntry.create(widget));
    }

    @Override
    public int method_25322() {
        return 400;
    }

    public int getWidth() {
        return this.field_22742;
    }

    public int getHeight() {
        return this.field_22743;
    }

    @Override
    protected int method_25329() {
        return super.method_25329() + 32;
    }

    @Nullable
    public class_339 getWidget(int index) {
        if (index < 0 || index >= this.method_25396().size()) {
            return null;
        }
        return this.method_25396().get(index).getWidget();
    }

    public Optional<class_339> getHoveredWidget(double mouseX, double mouseY) {
        for (WidgetEntry entry : this.method_25396()) {
            if (entry.getWidget().method_25405(mouseX, mouseY)) {
                return Optional.of(entry.getWidget());
            }
        }
        return Optional.empty();
    }

    @Deprecated
    @Override
    public void method_25394(class_4587 matrices, int mouseX, int mouseY, float delta) {
        this.render(new RenderArgs(new DrawObjectDM(matrices), mouseX, mouseY, delta));
    }

    public void render(RenderArgs args) {
        super.method_25394(args.drawObjectDM.getStack(), args.mouseX, args.mouseY, args.delta);
    }

    @Environment(EnvType.CLIENT)
    public static class WidgetEntry extends Entry<WidgetEntry> {
        protected final class_339 widget;

        public WidgetEntry(class_339 widget) {
            this.widget = widget;
        }

        public static WidgetEntry create(class_339 widget) {
            return new WidgetEntry(widget);
        }

        @Deprecated
        @Override
        public void render(class_4587 matrices, int index, int y, int x, int entryWidth, int entryHeight, int mouseX, int mouseY, boolean hovered, float tickDelta) {
            widget.field_22761 = y;
            widget.method_25394(matrices, mouseX, mouseY, tickDelta);
        }

        @Deprecated
        @Override
        public List<? extends class_364> children() {
            return ImmutableList.of(widget);
        }

        public class_339 getWidget() {
            return widget;
        }
    }
}
