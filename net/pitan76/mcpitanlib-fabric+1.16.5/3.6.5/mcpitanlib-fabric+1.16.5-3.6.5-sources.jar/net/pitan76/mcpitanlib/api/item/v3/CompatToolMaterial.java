package net.pitan76.mcpitanlib.api.item.v3;

import net.minecraft.class_1792;
import net.pitan76.mcpitanlib.api.item.tool.CompatibleToolMaterial;
import net.pitan76.mcpitanlib.api.tag.TagKey;
import net.pitan76.mcpitanlib.api.tag.item.RepairIngredientTag;

public interface CompatToolMaterial extends CompatibleToolMaterial {
    @Deprecated
    default TagKey<class_1792> getRepairTag() {
        return getRepairIngredientTag().getTag();
    }

    RepairIngredientTag getRepairIngredientTag();
}