package net.pitan76.mcpitanlib.api.util.v1;

import net.minecraft.class_2248;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_4970;
import net.pitan76.mcpitanlib.api.block.CompatibleBlockSettings;
import net.pitan76.mcpitanlib.api.tag.MineableToolTags;

import java.util.ArrayList;
import java.util.List;

public class BlockUtilV1 {
    public static class_2248 block(class_2960 id) {
        return class_2378.field_11146.method_10223(id);
    }

    /**
     * ～1.16?
     * @param settings
     * @param toolTags
     * @param level
     * @return
     */
    public static class_4970.class_2251 breakByTool(class_4970.class_2251 settings, MineableToolTags toolTags, int level) {
        return settings;
    }

    public static class_4970.class_2251 dropsNothing(class_4970.class_2251 settings) {
        return settings.method_16229();
    }

    public static class_4970.class_2251 requiresTool(class_4970.class_2251 settings) {
        return settings.method_29292();
    }

    public static boolean isExist(class_2960 identifier) {
        return class_2378.field_11146.method_10250(identifier);
    }

    public static class_2960 toID(class_2248 block) {
        return class_2378.field_11146.method_10221(block);
    }

    public static class_2248 fromId(class_2960 identifier) {
        return class_2378.field_11146.method_10223(identifier);
    }

    public static List<class_2248> getAllBlocks() {
        List<class_2248> blocks = new ArrayList<>();
        for (class_2248 block : class_2378.field_11146) {
            blocks.add(block);
        }
        return blocks;
    }

    @Deprecated
    public static class_2248 of(class_4970.class_2251 settings) {
        return new class_2248(settings);
    }

    public static class_2248 of(CompatibleBlockSettings settings) {
        return of(settings.build());
    }

    public static int getRawId(class_2248 block) {
        return class_2378.field_11146.method_10206(block);
    }

    public static class_2248 fromIndex(int index) {
        return class_2378.field_11146.method_10200(index);
    }
}
