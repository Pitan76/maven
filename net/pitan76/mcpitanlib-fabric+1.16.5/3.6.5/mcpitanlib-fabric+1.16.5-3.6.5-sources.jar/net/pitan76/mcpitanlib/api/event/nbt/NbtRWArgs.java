package net.pitan76.mcpitanlib.api.event.nbt;

import net.minecraft.class_2487;
import net.pitan76.mcpitanlib.api.registry.CompatRegistryLookup;

public class NbtRWArgs {
    public class_2487 nbt;
    public CompatRegistryLookup registryLookup;

    public NbtRWArgs(class_2487 nbt, CompatRegistryLookup registryLookup) {
        this.nbt = nbt;
        this.registryLookup = registryLookup;
    }

    public NbtRWArgs(class_2487 nbt) {
        this.nbt = nbt;
    }

    public class_2487 getNbt() {
        return nbt;
    }

    public CompatRegistryLookup getRegistryLookup() {
        return registryLookup;
    }

    public boolean hasRegistryLookup() {
        return registryLookup != null;
    }

    public boolean isNbtEmpty() {
        return nbt != null && !nbt.isEmpty();
    }

    public boolean isViewEmpty() {
        return false;
    }

    public boolean isEmpty() {
        return isNbtEmpty() || isViewEmpty();
    }

    public NbtRWArgs copy() {
        return new NbtRWArgs(nbt.method_10553(), registryLookup);
    }

    public net.pitan76.mcpitanlib.midohra.nbt.NbtCompound getNbtM() {
        return net.pitan76.mcpitanlib.midohra.nbt.NbtCompound.of(nbt);
    }
}
