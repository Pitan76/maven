package net.pitan76.mcpitanlib.api.tag.v2;

import me.shedaniel.architectury.mixin.FluidTagsAccessor;
import net.minecraft.class_1299;
import net.minecraft.class_1792;
import net.minecraft.class_2248;
import net.minecraft.class_2378;
import net.minecraft.class_2591;
import net.minecraft.class_3481;
import net.minecraft.class_3483;
import net.minecraft.class_3489;
import net.minecraft.class_3611;
import net.minecraft.class_3917;
import net.minecraft.class_5321;
import net.minecraft.class_5414;
import net.minecraft.tag.*;
import net.pitan76.mcpitanlib.api.util.CompatIdentifier;

public class CompatTagKeyType<T> {
    public static final CompatTagKeyType<class_2248> BLOCK = of("block", class_3481.method_15073());
    public static final CompatTagKeyType<class_1792> ITEM = of("item", class_3489.method_15106());
    public static final CompatTagKeyType<class_3611> FLUID = of("fluid", FluidTagsAccessor.getHelper().method_26770());
    public static final CompatTagKeyType<class_1299<?>> ENTITY_TYPE = of("entity_type", class_3483.method_15082());
    public static final CompatTagKeyType<class_2591<?>> BLOCK_ENTITY_TYPE = of("block_entity_type", class_5414.method_30214());
    public static final CompatTagKeyType<class_3917<?>> SCREEN_HANDLER = of("screen_handler", class_5414.method_30214());

    public final CompatIdentifier id;

    protected CompatTagKeyType(CompatIdentifier id) {
        this.id = id;
    }

    public static <T> CompatTagKeyType<T> of(CompatIdentifier id) {
        return new CompatTagKeyType<>(id);
    }

    private class_5414<T> tagGroup;

    protected CompatTagKeyType(CompatIdentifier id, class_5414<T> tagGroup) {
        this.id = id;
        this.tagGroup = tagGroup;
    }

    protected static <T> CompatTagKeyType<T> of(String id, class_5414<T> tagGroup) {
        return new CompatTagKeyType<>(CompatIdentifier.of(id), tagGroup);
    }

    @Deprecated
    public class_5414<T> getTagGroup() {
        return tagGroup;
    }

    // RegistryKey
    private class_5321<class_2378<T>> key;

    protected CompatTagKeyType(class_5321<class_2378<T>> key) {
        this.id = CompatIdentifier.fromMinecraft(key.method_29177());
        this.key = key;
    }

    public static <T> CompatTagKeyType<T> of(class_5321<class_2378<T>> key) {
        return new CompatTagKeyType<>(key);
    }

    @Deprecated
    public class_5321<class_2378<T>> getRegistryKey() {
        return key;
    }
}
