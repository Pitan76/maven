package net.pitan76.mcpitanlib.api.item;

import net.minecraft.class_1304;
import org.jetbrains.annotations.Nullable;

public class ArmorEquipmentType {
    // 1.19.4～ ArmorItem.Type

    public static ArmorEquipmentType HEAD = new ArmorEquipmentType(class_1304.field_6169);
    public static ArmorEquipmentType CHEST = new ArmorEquipmentType(class_1304.field_6174);
    public static ArmorEquipmentType LEGS = new ArmorEquipmentType(class_1304.field_6172);
    public static ArmorEquipmentType FEET = new ArmorEquipmentType(class_1304.field_6166);

    // New type for animals from 1.20.5
    public static ArmorEquipmentType BODY = new ArmorEquipmentType(null);

    protected final class_1304 slot;

    protected ArmorEquipmentType(class_1304 slot) {
        this.slot = slot;
    }

    @Deprecated
    public class_1304 getSlot() {
        return slot;
    }

    @Nullable
    public static ArmorEquipmentType of(class_1304 slot) {
        switch (slot) {
            case field_6169:
                return HEAD;
            case field_6174:
                return CHEST;
            case field_6172:
                return LEGS;
            case field_6166:
                return FEET;
            default:
                return null;
        }
    }
}
