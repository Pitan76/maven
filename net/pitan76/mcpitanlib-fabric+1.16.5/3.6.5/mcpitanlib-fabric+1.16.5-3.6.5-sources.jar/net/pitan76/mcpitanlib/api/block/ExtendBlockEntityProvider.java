package net.pitan76.mcpitanlib.api.block;

import net.minecraft.class_1922;
import net.minecraft.class_1937;
import net.minecraft.class_2343;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_2680;
import net.pitan76.mcpitanlib.api.event.block.TileCreateEvent;
import net.pitan76.mcpitanlib.api.tile.ExtendBlockEntityTicker;
import org.jetbrains.annotations.Nullable;

public interface ExtendBlockEntityProvider extends class_2343 {

    /**
     * @deprecated Use {@link #createBlockEntity(TileCreateEvent)} instead.
     */
    @Deprecated
    @Nullable
    @Override
    default class_2586 method_10123(class_1922 world) {
        return createBlockEntity(new TileCreateEvent(world));
    }

    /**
     * create instance of BlockEntity
     * @param event TileCreateEvent
     * @return BlockEntity
     *
     * <pre>{@code
     * public BlockEntity createBlockEntity(TileCreateEvent e) {
     *    return new ExampleBlockEntity(e); // ExampleBlockEntity extends CompatBlockEntity
     * }</pre>
     */
    @Nullable
    default class_2586 createBlockEntity(TileCreateEvent event) {
        if (getBlockEntityType() == null) return null;

        // return new ...BlockEntity(world)
        return getBlockEntityType().method_11032();
    }

    @Nullable
    default <T extends class_2586> class_2591<T> getBlockEntityType() {
        return null;
    }

    @Nullable
    default <T extends class_2586> ExtendBlockEntityTicker<T> getCompatibleTicker(class_1937 world, class_2680 state, class_2591<T> type) {

        return null;
    }

    default boolean isTick() {
        return false;
    }
}
