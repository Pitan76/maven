package net.pitan76.mcpitanlib.api.event.block;

import net.minecraft.class_10;
import net.minecraft.class_1922;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_3610;
import net.pitan76.mcpitanlib.api.event.BaseEvent;
import net.pitan76.mcpitanlib.api.util.FluidStateUtil;

public class CanPathfindThroughArgs extends BaseEvent {
    public class_2680 state;
    private class_1922 blockView;
    private class_2338 pos;
    public class_10 type;

    public CanPathfindThroughArgs(class_2680 state, class_1922 blockView, class_2338 pos, class_10 type) {
        this.state = state;
        this.blockView = blockView;
        this.pos = pos;
        this.type = type;
    }

    public class_2680 getState() {
        return state;
    }

    public class_10 getType() {
        return type;
    }

    public class_3610 getFluidState() {
        return state.method_26227();
    }

    public boolean isWaterNavigationType() {
        return type == class_10.field_48;
    }

    public boolean isAirNavigationType() {
        return type == class_10.field_51;
    }

    public boolean isLandNavigationType() {
        return type == class_10.field_50;
    }

    public boolean isWaterState() {
        return FluidStateUtil.isWater(getFluidState());
    }

    public boolean isLavaState() {
        return FluidStateUtil.isLava(getFluidState());
    }

    public class_2338 getPos() {
        return pos;
    }

    public class_1922 getBlockView() {
        return blockView;
    }
}
