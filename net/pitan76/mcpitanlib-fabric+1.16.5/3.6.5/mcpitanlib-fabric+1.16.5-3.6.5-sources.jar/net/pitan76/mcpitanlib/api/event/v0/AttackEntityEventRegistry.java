package net.pitan76.mcpitanlib.api.event.v0;

import dev.architectury.injectables.annotations.ExpectPlatform;
import me.shedaniel.architectury.event.EventResult;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_3966;
import net.pitan76.mcpitanlib.api.entity.Player;
import org.jetbrains.annotations.Nullable;

@Deprecated
public class AttackEntityEventRegistry {
    @ExpectPlatform
    public static void register(AttackEntity attackEntity) {

    }

    public interface AttackEntity {
        default EventResult attack(class_1657 player, class_1937 level, class_1297 target, class_1268 hand, @Nullable class_3966 result) {
            return attack(new Player(player), level, target, hand, result);
        }

        EventResult attack(Player player, class_1937 level, class_1297 target, class_1268 hand, @Nullable class_3966 result);
    }
}
