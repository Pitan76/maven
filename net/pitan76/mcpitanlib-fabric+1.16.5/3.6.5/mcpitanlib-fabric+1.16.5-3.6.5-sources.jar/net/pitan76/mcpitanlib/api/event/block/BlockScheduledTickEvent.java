package net.pitan76.mcpitanlib.api.event.block;

import net.minecraft.class_2338;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.pitan76.mcpitanlib.api.event.BaseEvent;
import net.pitan76.mcpitanlib.api.util.WorldUtil;
import net.pitan76.mcpitanlib.api.util.math.random.CompatRandom;
import net.pitan76.mcpitanlib.midohra.holder.BlockStatePropertyHolder;

import java.util.Random;

public class BlockScheduledTickEvent extends BaseEvent implements BlockStatePropertyHolder {
    public class_2680 state;
    public class_3218 world;
    public class_2338 pos;
    public CompatRandom random;

    public BlockScheduledTickEvent(class_2680 state, class_3218 world, class_2338 pos, Random random) {
        this.state = state;
        this.world = world;
        this.pos = pos;
        this.random = new CompatRandom(random);
    }

    public class_2680 getState() {
        return state;
    }

    public class_2338 getPos() {
        return pos;
    }

    public class_3218 getWorld() {
        return world;
    }

    public CompatRandom getRandom() {
        return random;
    }

    public class_2586 getBlockEntity() {
        return WorldUtil.getBlockEntity(getWorld(), getPos());
    }

    @Override
    public net.pitan76.mcpitanlib.midohra.block.BlockState getBlockState() {
        return net.pitan76.mcpitanlib.midohra.block.BlockState.of(state);
    }
}
