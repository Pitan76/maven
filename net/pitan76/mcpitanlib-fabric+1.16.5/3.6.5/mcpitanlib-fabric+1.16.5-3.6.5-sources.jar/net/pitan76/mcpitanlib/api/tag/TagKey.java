package net.pitan76.mcpitanlib.api.tag;

import me.shedaniel.architectury.hooks.TagHooks;
import net.minecraft.class_2960;
import net.minecraft.class_3494;
import net.pitan76.mcpitanlib.api.util.*;

public class TagKey<T> {
    private final class_3494.class_5123<T> tagKey;

    @Deprecated
    public TagKey(class_3494.class_5123<T> tagKey) {
        this.tagKey = tagKey;
    }

    public static TagKey<?> create(Type type, class_2960 identifier) {
        switch (type) {
            case BLOCK:
                return new TagKey<>(TagHooks.getBlockOptional(identifier));
            case ITEM:
                return new TagKey<>(TagHooks.getItemOptional(identifier));
            case FLUID:
                return new TagKey<>(TagHooks.getFluidOptional(identifier));
            case ENTITY_TYPE:
                return new TagKey<>(TagHooks.getEntityTypeOptional(identifier));
            default:
                throw new IllegalArgumentException();
        }
    }

    public static TagKey<?> create(Type type, CompatIdentifier id) {
        return create(type, id.toMinecraft());
    }

    @Deprecated
    public class_3494.class_5123<T> getTagKey() {
        return tagKey;
    }

    public enum Type {
        BLOCK,
        ITEM,
        FLUID,
        ENTITY_TYPE;
    }

    public boolean isOf(T value) {
        return tagKey.method_15141(value);
    }
}
