package net.pitan76.mcpitanlib.api.util;

import me.shedaniel.architectury.registry.MenuRegistry;
import me.shedaniel.architectury.registry.menu.ExtendedMenuProvider;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_2371;
import net.minecraft.class_2378;
import net.minecraft.class_2540;
import net.minecraft.class_3222;
import net.minecraft.class_3908;
import net.minecraft.class_3917;
import net.pitan76.mcpitanlib.api.util.client.ClientUtil;
import net.pitan76.mcpitanlib.midohra.server.MCServer;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;

public class ScreenHandlerUtil {
    public static class_2371<class_1735> getSlots(class_1703 screenHandler) {
        class_2371<class_1735> slots = class_2371.method_10211();
        slots.addAll(screenHandler.field_7761);
        return slots;
    }

    public static class_1735 getSlot(class_1703 screenHandler, int index) {
        return screenHandler.method_7611(index);
    }

    public static List<class_3917<?>> getAllScreenHandlerTypes() {
        List<class_3917<?>> screenHandlerTypes = new ArrayList<>();
        for (class_3917<?> screenHandler : class_2378.field_17429) {
            screenHandlerTypes.add(screenHandler);
        }
        return screenHandlerTypes;
    }

    public static void openExtendedMenu(class_3222 player, class_3908 provider, Consumer<class_2540> bufWriter) {
        MenuRegistry.openExtendedMenu(player, provider, bufWriter);
    }

    public static void openExtendedMenu(class_3222 player, ExtendedMenuProvider provider) {
        MenuRegistry.openExtendedMenu(player, provider);
    }

    public static void openMenu(class_3222 player, class_3908 provider) {
        MenuRegistry.openMenu(player, provider);
    }

    public static int getRawId(class_3917<?> type) {
        return class_2378.field_17429.method_10206(type);
    }

    public static class_3917<?> fromIndex(int index) {
        return class_2378.field_17429.method_10200(index);
    }

    public static class_1799 getCursorStack(class_1703 screenHandler) {
        if (PlatformUtil.isClient()) {
            return ClientUtil.getClientPlayer().field_7514.method_7399();
        }
        for (class_1735 slot : screenHandler.field_7761) {
            if (slot.field_7871 instanceof class_1661) {
                class_1661 inventory = (class_1661) slot.field_7871;
                return inventory.method_7399();
            }
        }
        for (class_1799 tmp : screenHandler.method_7602()) {
            if (tmp.method_27319() instanceof class_3222) {
                class_3222 player = (class_3222) tmp.method_27319();
                return player.field_7514.method_7399();
            }
        }
        return class_1799.field_8037;
    }

    public static net.pitan76.mcpitanlib.midohra.item.ItemStack getCursorStackM(class_1703 screenHandler) {
        return net.pitan76.mcpitanlib.midohra.item.ItemStack.of(getCursorStack(screenHandler));
    }

    public static void setCursorStack(class_1703 screenHandler, class_1799 stack) {
        if (PlatformUtil.isClient()) {
            ClientUtil.getClientPlayer().field_7514.method_7396(stack);
            return;
        }
        for (class_1735 slot : screenHandler.field_7761) {
            if (slot.field_7871 instanceof class_1661) {
                class_1661 inventory = (class_1661) slot.field_7871;
                inventory.method_7396(stack);
                return;
            }
        }
        for (class_1799 tmp : screenHandler.method_7602()) {
            if (tmp.method_27319() instanceof class_3222) {
                class_3222 player = (class_3222) tmp.method_27319();
                player.field_7514.method_7396(stack);
                return;
            }
        }
    }

    public static void setCursorStackM(class_1703 screenHandler, net.pitan76.mcpitanlib.midohra.item.ItemStack stack) {
        setCursorStack(screenHandler, stack.toMinecraft());
    }
}
