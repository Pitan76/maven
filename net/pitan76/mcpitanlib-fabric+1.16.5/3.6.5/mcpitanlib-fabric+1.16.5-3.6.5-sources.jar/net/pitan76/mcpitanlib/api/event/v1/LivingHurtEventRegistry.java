package net.pitan76.mcpitanlib.api.event.v1;

import dev.architectury.event.events.common.EntityEvent;
import net.minecraft.class_1269;
import net.minecraft.class_1282;
import net.minecraft.class_1309;
import net.pitan76.mcpitanlib.api.event.v0.event.LivingHurtEvent;

public class LivingHurtEventRegistry {
    public static void register(LivingHurt livingHurt) {
        EntityEvent.LIVING_ATTACK.register(livingHurt::hurt);
    }

    public interface LivingHurt {

        default class_1269 hurt(class_1309 var1, class_1282 var2, float var3) {
            return hurt(new LivingHurtEvent(var1, var2, var3)).toActionResult();
        }

        net.pitan76.mcpitanlib.api.event.result.EventResult hurt(LivingHurtEvent event);
    }
}
