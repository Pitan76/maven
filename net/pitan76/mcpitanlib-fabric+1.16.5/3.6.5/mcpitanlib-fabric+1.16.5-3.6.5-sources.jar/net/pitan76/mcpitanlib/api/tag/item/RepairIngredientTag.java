package net.pitan76.mcpitanlib.api.tag.item;

import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1856;
import net.pitan76.mcpitanlib.MCPitanLib;
import net.pitan76.mcpitanlib.api.tag.TagKey;
import net.pitan76.mcpitanlib.api.util.CompatIdentifier;
import net.pitan76.mcpitanlib.api.util.item.ItemUtil;

public class RepairIngredientTag {

    public static final RepairIngredientTag REPAIRS_LEATHER_ARMOR = of("leather_armor_materials");
    public static final RepairIngredientTag REPAIRS_CHAIN_ARMOR = of("iron_tool_materials");
    public static final RepairIngredientTag REPAIRS_IRON_ARMOR = of("iron_tool_materials");
    public static final RepairIngredientTag REPAIRS_GOLD_ARMOR = of("golden_tool_materials");
    public static final RepairIngredientTag REPAIRS_DIAMOND_ARMOR = of("diamond_tool_materials");
    public static final RepairIngredientTag REPAIRS_NETHERITE_ARMOR = of("netherite_tool_materials");
    public static final RepairIngredientTag REPAIRS_TURTLE_HELMET = of("turtle_helmet_materials");
    public static final RepairIngredientTag REPAIRS_WOLF_ARMOR = of("leather_armor_materials");
    public static final RepairIngredientTag WOODEN_TOOL_MATERIALS = of("wooden_tool_materials");
    public static final RepairIngredientTag STONE_TOOL_MATERIALS = of("stone_tool_materials");
    public static final RepairIngredientTag IRON_TOOL_MATERIALS = of("iron_tool_materials");
    public static final RepairIngredientTag GOLDEN_TOOL_MATERIALS = of("golden_tool_materials");
    public static final RepairIngredientTag DIAMOND_TOOL_MATERIALS = of("diamond_tool_materials");
    public static final RepairIngredientTag NETHERITE_TOOL_MATERIALS = of("netherite_tool_materials");

    private TagKey<class_1792> tag;

    protected static RepairIngredientTag of(String path) {
        return new RepairIngredientTag(CompatIdentifier.of(MCPitanLib.MOD_ID, path));
    }

    public RepairIngredientTag(CompatIdentifier identifier) {
        this.tag = (TagKey<class_1792>) TagKey.create(TagKey.Type.ITEM, identifier.toMinecraft());
    }

    @Deprecated
    public RepairIngredientTag(TagKey<class_1792> tag) {
        this.tag = tag;
    }

    @Deprecated
    public TagKey<class_1792> getTag() {
        return tag;
    }

    @Deprecated
    public class_1856 getIngredient() {
        return class_1856.method_8106(tag.getTagKey());
    }

    public boolean contains(class_1792 item) {
        if (item == null || tag == null)
            return false;

        return ItemUtil.isInTag(item, tag);
    }

    public boolean contains(class_1799 stack) {
        if (stack.method_7960() || tag == null)
            return false;

        return getIngredient().method_8093(stack);
    }
}
