package net.pitan76.mcpitanlib.api.command.argument;

import net.minecraft.class_2248;
import net.minecraft.class_2257;
import net.pitan76.mcpitanlib.api.event.BlockCommandEvent;
import net.pitan76.mcpitanlib.api.event.ServerCommandEvent;

public abstract class BlockCommand extends RequiredCommand<class_2248> {
    @Override
    public class_2257 getArgumentType() {
        return class_2257.method_9653();
    }

    public abstract void execute(BlockCommandEvent event);

    @Override
    public void execute(ServerCommandEvent event) {
        execute((BlockCommandEvent) event);
    }
}
