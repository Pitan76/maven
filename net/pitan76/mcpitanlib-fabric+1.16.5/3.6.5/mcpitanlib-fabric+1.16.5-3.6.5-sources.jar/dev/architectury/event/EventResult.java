package dev.architectury.event;

import net.minecraft.class_1269;

public class EventResult {
    public static me.shedaniel.architectury.event.EventResult pass() {
        return me.shedaniel.architectury.event.EventResult.pass();
    }

    public static me.shedaniel.architectury.event.EventResult interrupt(Boolean value) {
        return me.shedaniel.architectury.event.EventResult.interrupt(value);
    }

    public static me.shedaniel.architectury.event.EventResult interruptTrue() {
        return me.shedaniel.architectury.event.EventResult.interruptTrue();
    }

    public static me.shedaniel.architectury.event.EventResult interruptDefault() {
        return me.shedaniel.architectury.event.EventResult.interruptDefault();
    }

    public static me.shedaniel.architectury.event.EventResult interruptFalse() {
        return me.shedaniel.architectury.event.EventResult.interruptFalse();
    }

    public static class_1269 toActionResult(me.shedaniel.architectury.event.EventResult result) {
        if (result == interruptFalse()) {
            return class_1269.field_5814;
        } else if (result == pass()) {
            return class_1269.field_5811;
        } else if (result == interruptTrue()) {
            return class_1269.field_5812;
        } else {
            return class_1269.field_21466;
        }
    }
}
