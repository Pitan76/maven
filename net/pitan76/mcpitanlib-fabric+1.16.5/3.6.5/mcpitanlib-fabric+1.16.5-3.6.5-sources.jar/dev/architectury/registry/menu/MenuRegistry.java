package dev.architectury.registry.menu;

import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_2561;
import net.minecraft.class_3917;
import net.minecraft.class_3936;
import net.minecraft.class_437;

public class MenuRegistry {
    public static <H extends class_1703, S extends class_437 & class_3936<H>> void registerScreenFactory(class_3917<? extends H> type, ScreenFactory<H, S> factory) {
        me.shedaniel.architectury.registry.MenuRegistry.registerScreenFactory(type, factoryConvert(factory));
    }

    public interface ScreenFactory<H extends class_1703, S extends class_437 & class_3936<H>> {
        S create(H containerMenu, class_1661 inventory, class_2561 component);
    }

    private static <H extends class_1703, S extends class_437 & class_3936<H>> me.shedaniel.architectury.registry.MenuRegistry.ScreenFactory<H, S> factoryConvert(ScreenFactory<H, S> factory) {
        return factory::create;
    }
}
