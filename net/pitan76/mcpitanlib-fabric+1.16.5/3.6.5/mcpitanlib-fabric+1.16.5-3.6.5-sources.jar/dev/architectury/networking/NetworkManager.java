package dev.architectury.networking;

import me.shedaniel.architectury.networking.transformers.PacketSink;
import me.shedaniel.architectury.networking.transformers.PacketTransformer;
import me.shedaniel.architectury.utils.Env;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_2540;
import net.minecraft.class_2596;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import org.jetbrains.annotations.ApiStatus;
import org.jetbrains.annotations.Nullable;

import java.util.List;

public final class NetworkManager {
    public static void registerReceiver(Side side, class_2960 id, NetworkReceiver receiver) {
        me.shedaniel.architectury.networking.NetworkManager.registerReceiver(sideConvert(side), id, (buf, context) -> {receiver.receive(buf, contextConvert(context));});
    }

    @ApiStatus.Experimental
    public static void registerReceiver(Side side, class_2960 id, List<PacketTransformer> packetTransformers, NetworkReceiver receiver) {
        me.shedaniel.architectury.networking.NetworkManager.registerReceiver(sideConvert(side), id, packetTransformers, (buf, context) -> {receiver.receive(buf, contextConvert(context));});
    }

    @Deprecated
    @ApiStatus.ScheduledForRemoval
    @SuppressWarnings("unchecked")
    public static class_2596<?> toPacket(Side side, class_2960 id, class_2540 buf) {
        return me.shedaniel.architectury.networking.NetworkManager.toPacket(sideConvert(side), id, buf);
    }

    @Deprecated
    @ApiStatus.ScheduledForRemoval
    @SuppressWarnings("unchecked")
    public static List<class_2596<?>> toPackets(Side side, class_2960 id, class_2540 buf) {
        return me.shedaniel.architectury.networking.NetworkManager.toPackets(sideConvert(side), id, buf);

    }

    public static void collectPackets(PacketSink sink, Side side, class_2960 id, class_2540 buf) {
        me.shedaniel.architectury.networking.NetworkManager.collectPackets(sink, sideConvert(side), id, buf);
    }

    public static void sendToPlayer(class_3222 player, class_2960 id, class_2540 buf) {
        me.shedaniel.architectury.networking.NetworkManager.sendToPlayer(player, id, buf);
    }

    public static void sendToPlayers(Iterable<class_3222> players, class_2960 id, class_2540 buf) {
        me.shedaniel.architectury.networking.NetworkManager.sendToPlayers(players, id, buf);
    }

    @Environment(EnvType.CLIENT)
    public static void sendToServer(class_2960 id, class_2540 buf) {
        me.shedaniel.architectury.networking.NetworkManager.sendToServer(id, buf);
    }

    @Environment(EnvType.CLIENT)
    public static boolean canServerReceive(class_2960 id) {
        return me.shedaniel.architectury.networking.NetworkManager.canServerReceive(id);
    }

    public static boolean canPlayerReceive(class_3222 player, class_2960 id) {
        return me.shedaniel.architectury.networking.NetworkManager.canPlayerReceive(player, id);
    }

    public static class_2596<?> createAddEntityPacket(class_1297 entity) {
        return me.shedaniel.architectury.networking.NetworkManager.createAddEntityPacket(entity);
    }

    @FunctionalInterface
    public interface NetworkReceiver {
        void receive(class_2540 buf, PacketContext context);
    }

    public interface PacketContext {
        class_1657 getPlayer();

        void queue(Runnable runnable);

        Env getEnvironment();

        default EnvType getEnv() {
            return getEnvironment().toPlatform();
        }
    }

    public static Side s2c() {
        return Side.S2C;
    }

    public static Side c2s() {
        return Side.C2S;
    }

    public static Side serverToClient() {
        return Side.S2C;
    }

    public static Side clientToServer() {
        return Side.C2S;
    }

    public enum Side {
        S2C,
        C2S
    }

    @Nullable
    private static me.shedaniel.architectury.networking.NetworkManager.Side sideConvert(Side side) {
        switch (side) {
            case S2C:
                return me.shedaniel.architectury.networking.NetworkManager.Side.S2C;
            case C2S:
                return me.shedaniel.architectury.networking.NetworkManager.Side.C2S;
        }
        return null;
    }

    private static PacketContext contextConvert(me.shedaniel.architectury.networking.NetworkManager.PacketContext context) {
        return new PacketContext() {
            @Override
            public class_1657 getPlayer() {
                return context.getPlayer();
            }

            @Override
            public void queue(Runnable runnable) {
                context.queue(runnable);
            }

            @Override
            public Env getEnvironment() {
                return context.getEnvironment();
            }
        };
    }
}