package dev.architectury.registry.menu;

import net.minecraft.client.gui.IHasContainer;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.inventory.container.Container;
import net.minecraft.inventory.container.ContainerType;
import net.minecraft.util.text.ITextComponent;

public class MenuRegistry {
    public static <H extends Container, S extends Screen & IHasContainer<H>> void registerScreenFactory(ContainerType<? extends H> type, ScreenFactory<H, S> factory) {
        me.shedaniel.architectury.registry.MenuRegistry.registerScreenFactory(type, factoryConvert(factory));
    }

    public interface ScreenFactory<H extends Container, S extends Screen & IHasContainer<H>> {
        S create(H containerMenu, PlayerInventory inventory, ITextComponent component);
    }

    private static <H extends Container, S extends Screen & IHasContainer<H>> me.shedaniel.architectury.registry.MenuRegistry.ScreenFactory<H, S> factoryConvert(ScreenFactory<H, S> factory) {
        return factory::create;
    }
}
