package net.pitan76.mcpitanlib.api.block;

import net.minecraft.block.Block;
import net.minecraft.block.Blocks;

public class CompatBlocks {
    public static final Block AIR = Blocks.field_150350_a;
    public static final Block STONE = Blocks.field_150348_b;
    public static final Block COBBLESTONE = Blocks.field_150347_e;
    public static final Block GRASS_BLOCK = Blocks.field_196658_i;
    public static final Block DIRT = Blocks.field_150346_d;
    public static final Block SAND = Blocks.field_150354_m;
    public static final Block RED_SAND = Blocks.field_196611_F;
    public static final Block GRANITE = Blocks.field_196650_c;
    public static final Block POLISHED_GRANITE = Blocks.field_196652_d;
    public static final Block DIORITE = Blocks.field_196654_e;
    public static final Block POLISHED_DIORITE = Blocks.field_196655_f;
    public static final Block ANDESITE = Blocks.field_196656_g;
    public static final Block POLISHED_ANDESITE = Blocks.field_196657_h;
    public static final Block COARSE_DIRT = Blocks.field_196660_k;
    public static final Block PODZOL = Blocks.field_196661_l;

    public static final Block OAK_LOG = Blocks.field_196617_K;
    public static final Block SPRUCE_LOG = Blocks.field_196618_L;
    public static final Block BIRCH_LOG = Blocks.field_196619_M;
    public static final Block JUNGLE_LOG = Blocks.field_196620_N;
    public static final Block ACACIA_LOG = Blocks.field_196621_O;
    public static final Block DARK_OAK_LOG = Blocks.field_196623_P;
    public static final Block OAK_PLANKS = Blocks.field_196662_n;
    public static final Block SPRUCE_PLANKS = Blocks.field_196664_o;
    public static final Block BIRCH_PLANKS = Blocks.field_196666_p;
    public static final Block JUNGLE_PLANKS = Blocks.field_196668_q;
    public static final Block ACACIA_PLANKS = Blocks.field_196670_r;
    public static final Block DARK_OAK_PLANKS = Blocks.field_196672_s;
    public static final Block OAK_SAPLING = Blocks.field_196674_t;
    public static final Block SPRUCE_SAPLING = Blocks.field_196675_u;
    public static final Block BIRCH_SAPLING = Blocks.field_196676_v;
    public static final Block JUNGLE_SAPLING = Blocks.field_196678_w;
    public static final Block ACACIA_SAPLING = Blocks.field_196679_x;
    public static final Block DARK_OAK_SAPLING = Blocks.field_196680_y;

    public static final Block SANDSTONE = Blocks.field_150322_A;
    public static final Block CHISELED_SANDSTONE = Blocks.field_196583_aj;
    public static final Block CUT_SANDSTONE = Blocks.field_196585_ak;
    public static final Block NOTE_BLOCK = Blocks.field_196586_al;
    public static final Block POWERED_RAIL = Blocks.field_196552_aC;
    public static final Block DETECTOR_RAIL = Blocks.field_150319_E;
    public static final Block PISTON = Blocks.field_150331_J;
    public static final Block STICKY_PISTON = Blocks.field_150320_F;
    public static final Block COBWEB = Blocks.field_196553_aF;
    public static final Block GRAVEL = Blocks.field_150351_n;
    public static final Block GLASS = Blocks.field_150359_w;
    public static final Block DISPENSER = Blocks.field_150367_z;

    public static final Block COAL_ORE = Blocks.field_150365_q;
    public static final Block IRON_ORE = Blocks.field_150366_p;
    public static final Block COPPER_ORE = Blocks.field_150366_p;
    public static final Block GOLD_ORE = Blocks.field_150352_o;
    public static final Block DIAMOND_ORE = Blocks.field_150482_ag;
    public static final Block REDSTONE_ORE = Blocks.field_150450_ax;
    public static final Block EMERALD_ORE = Blocks.field_150412_bA;
    public static final Block LAPIS_ORE = Blocks.field_150369_x;
    public static final Block NETHER_QUARTZ_ORE = Blocks.field_196766_fg;

    public static final Block COAL_BLOCK = Blocks.field_150402_ci;
    public static final Block IRON_BLOCK = Blocks.field_150339_S;
    public static final Block COPPER_BLOCK = Blocks.field_150339_S;
    public static final Block GOLD_BLOCK = Blocks.field_150340_R;
    public static final Block DIAMOND_BLOCK = Blocks.field_150484_ah;
    public static final Block REDSTONE_BLOCK = Blocks.field_150451_bX;
    public static final Block EMERALD_BLOCK = Blocks.field_150475_bE;
    public static final Block LAPIS_BLOCK = Blocks.field_150368_y;
    public static final Block QUARTZ_BLOCK = Blocks.field_150371_ca;

    public static final Block TNT = Blocks.field_150335_W;
    public static final Block BOOKSHELF = Blocks.field_150342_X;
    public static final Block OBSIDIAN = Blocks.field_150343_Z;
    public static final Block TORCH = Blocks.field_150478_aa;
    public static final Block WALL_TORCH = Blocks.field_196591_bQ;
    public static final Block FIRE = Blocks.field_150480_ab;
    public static final Block SOUL_FIRE = Blocks.field_235335_bO_;
    public static final Block SPAWNER = Blocks.field_150474_ac;
    public static final Block OAK_STAIRS = Blocks.field_150476_ad;
    public static final Block CHEST = Blocks.field_150486_ae;
    public static final Block REDSTONE_WIRE = Blocks.field_150488_af;

    public static final Block WATER = Blocks.field_150355_j;
    public static final Block LAVA = Blocks.field_150353_l;
    public static final Block BEDROCK = Blocks.field_150357_h;

    // ----

    public static boolean isExist(Block block) {
        return block != null && block != Blocks.field_150350_a;
    }
}
