package net.pitan76.mcpitanlib.api.util;

import com.google.common.collect.ImmutableList;
import net.minecraft.state.StateContainer;
import net.minecraft.state.StateHolder;

public class StateManagerUtil {
    public static <T, S extends StateHolder<T, S>> S getDefaultState(StateContainer<T, S> manager) {
        return manager.func_177621_b();
    }

    public <T, S extends StateHolder<T, S>> ImmutableList<S> getStates(StateContainer<T, S> manager) {
        return manager.func_177619_a();
    }
}
