package net.pitan76.mcpitanlib.api.item;

import me.shedaniel.architectury.registry.CreativeTabs;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroup;
import net.minecraft.item.ItemStack;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.text.ITextComponent;
import net.pitan76.mcpitanlib.api.util.CompatIdentifier;

import java.util.HashMap;
import java.util.Map;
import java.util.function.Supplier;

public class CreativeTabBuilder {
    @Deprecated
    public static final Map<ResourceLocation, ItemGroup> itemGroupMap = new HashMap<>();

    @Deprecated
    public static final Map<ResourceLocation, CreativeTabBuilder> itemGroupBuilderMap = new HashMap<>();

    private final ResourceLocation identifier;
    private ITextComponent displayName = null;
    private Supplier<ItemStack> iconSupplier = null;
    private boolean noRenderedName = false;
    private boolean noScrollbar = false;
    private boolean special = false;
    private String texture;

    @Deprecated
    // Recommend: create(identifier)
    public CreativeTabBuilder(ResourceLocation identifier) {
        this.identifier = identifier;
        itemGroupBuilderMap.put(identifier, this);
    }

    public static CreativeTabBuilder create(ResourceLocation identifier) {
        return new CreativeTabBuilder(identifier);
    }

    public static CreativeTabBuilder create(CompatIdentifier identifier) {
        return create(identifier.toMinecraft());
    }

    public CreativeTabBuilder setDisplayName(ITextComponent text) {
        this.displayName = text;
        return this;
    }

    /**
     * Set icon
     * @param iconSupplier Icon supplier
     * @return CreativeTabBuilder
     */
    public CreativeTabBuilder setIcon(Supplier<ItemStack> iconSupplier) {
        this.iconSupplier = iconSupplier;
        return this;
    }

    /**
     * Set icon (Already registered item only)
     * @param item Item
     * @return CreativeTabBuilder
     */
    public CreativeTabBuilder setIcon(Item item) {
        return setIcon(() -> new ItemStack(item));
    }

    public void noRenderedName() {
        this.noRenderedName = true;
    }

    public void noScrollbar() {
        this.noScrollbar = true;
    }

    public void special() {
        this.special = true;
    }

    public void setTexture(String texture) {
        this.texture = texture;
    }

    /**
     * Build ItemGroup (If loader is forge, not recommended)
     * @return ItemGroup
     */
    public ItemGroup build() {
        if (itemGroupMap.containsKey(identifier)) return itemGroupMap.get(identifier);
        ItemGroup itemGroup = CreativeTabs.create(identifier, iconSupplier);
        if (displayName != null) itemGroup.func_199783_b(displayName.getString());
        if (noRenderedName) itemGroup.func_199783_b("");
        if (noScrollbar) itemGroup.func_78022_j();
        if (special) itemGroup.func_192394_m();
        if (texture != null) itemGroup.func_78025_a(texture);
        itemGroupMap.put(identifier, itemGroup);
        return itemGroup;
    }

    public ResourceLocation getIdentifier() {
        return identifier;
    }
}
