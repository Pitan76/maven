package net.pitan76.mcpitanlib.api.gui;

import net.minecraft.inventory.container.ContainerType;
import net.minecraft.network.PacketBuffer;
import org.jetbrains.annotations.Nullable;

public class ExtendedScreenHandler extends SimpleScreenHandler {
    protected ExtendedScreenHandler(@Nullable ContainerType<?> type, int syncId, PacketBuffer buf) {
        this(type, syncId);
    }

    protected ExtendedScreenHandler(@Nullable ContainerType<?> type, int syncId) {
        super(type, syncId);
    }
}
