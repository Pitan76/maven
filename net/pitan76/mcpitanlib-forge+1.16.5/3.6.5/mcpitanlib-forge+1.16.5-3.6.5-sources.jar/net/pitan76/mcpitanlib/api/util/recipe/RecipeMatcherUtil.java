package net.pitan76.mcpitanlib.api.util.recipe;

import it.unimi.dsi.fastutil.ints.IntList;
import net.minecraft.item.ItemStack;
import net.minecraft.item.crafting.IRecipe;
import net.minecraft.item.crafting.RecipeItemHelper;
import net.pitan76.mcpitanlib.api.recipe.CompatibleRecipeEntry;

public class RecipeMatcherUtil {
    public static ItemStack getStackFromId(int itemId) {
        return RecipeItemHelper.func_194115_b(itemId);
    }

    public static int getItemId(ItemStack stack) {
        return RecipeItemHelper.func_194113_b(stack);
    }

    public static boolean match(RecipeItemHelper matcher, CompatibleRecipeEntry entry, IntList output) {
        return match(matcher, entry.getRecipe(), output);
    }

    public static boolean match(RecipeItemHelper matcher, CompatibleRecipeEntry entry, IntList output, int multiplier) {
        return match(matcher, entry.getRecipe(), output, multiplier);
    }

    @Deprecated
    public static boolean match(RecipeItemHelper matcher, IRecipe<?> recipe, IntList output) {
        return matcher.func_194116_a(recipe, output);
    }

    @Deprecated
    public static boolean match(RecipeItemHelper matcher, IRecipe<?> recipe, IntList output, int multiplier) {
        return matcher.func_194118_a(recipe, output, multiplier);
    }

    public static void clear(RecipeItemHelper matcher) {
        matcher.func_194119_a();
    }
}
