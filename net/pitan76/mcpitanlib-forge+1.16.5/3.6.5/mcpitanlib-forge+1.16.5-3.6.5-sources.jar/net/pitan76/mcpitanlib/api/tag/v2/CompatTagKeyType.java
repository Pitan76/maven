package net.pitan76.mcpitanlib.api.tag.v2;

import me.shedaniel.architectury.mixin.FluidTagsAccessor;
import net.minecraft.block.Block;
import net.minecraft.entity.EntityType;
import net.minecraft.fluid.Fluid;
import net.minecraft.inventory.container.ContainerType;
import net.minecraft.item.Item;
import net.minecraft.tag.*;
import net.minecraft.tags.BlockTags;
import net.minecraft.tags.EntityTypeTags;
import net.minecraft.tags.ITagCollection;
import net.minecraft.tags.ItemTags;
import net.minecraft.tileentity.TileEntityType;
import net.minecraft.util.RegistryKey;
import net.minecraft.util.registry.Registry;
import net.pitan76.mcpitanlib.api.util.CompatIdentifier;

public class CompatTagKeyType<T> {
    public static final CompatTagKeyType<Block> BLOCK = of("block", BlockTags.func_199896_a());
    public static final CompatTagKeyType<Item> ITEM = of("item", ItemTags.func_199903_a());
    public static final CompatTagKeyType<Fluid> FLUID = of("fluid", FluidTagsAccessor.getHelper().func_232939_b_());
    public static final CompatTagKeyType<EntityType<?>> ENTITY_TYPE = of("entity_type", EntityTypeTags.func_219762_a());
    public static final CompatTagKeyType<TileEntityType<?>> BLOCK_ENTITY_TYPE = of("block_entity_type", ITagCollection.func_242205_c());
    public static final CompatTagKeyType<ContainerType<?>> SCREEN_HANDLER = of("screen_handler", ITagCollection.func_242205_c());

    public final CompatIdentifier id;

    protected CompatTagKeyType(CompatIdentifier id) {
        this.id = id;
    }

    public static <T> CompatTagKeyType<T> of(CompatIdentifier id) {
        return new CompatTagKeyType<>(id);
    }

    private ITagCollection<T> tagGroup;

    protected CompatTagKeyType(CompatIdentifier id, ITagCollection<T> tagGroup) {
        this.id = id;
        this.tagGroup = tagGroup;
    }

    protected static <T> CompatTagKeyType<T> of(String id, ITagCollection<T> tagGroup) {
        return new CompatTagKeyType<>(CompatIdentifier.of(id), tagGroup);
    }

    @Deprecated
    public ITagCollection<T> getTagGroup() {
        return tagGroup;
    }

    // RegistryKey
    private RegistryKey<Registry<T>> key;

    protected CompatTagKeyType(RegistryKey<Registry<T>> key) {
        this.id = CompatIdentifier.fromMinecraft(key.func_240901_a_());
        this.key = key;
    }

    public static <T> CompatTagKeyType<T> of(RegistryKey<Registry<T>> key) {
        return new CompatTagKeyType<>(key);
    }

    @Deprecated
    public RegistryKey<Registry<T>> getRegistryKey() {
        return key;
    }
}
