package net.pitan76.mcpitanlib.api.block;

import net.minecraft.block.*;
import net.minecraft.block.material.Material;
import net.minecraft.block.material.MaterialColor;
import net.minecraft.item.DyeColor;
import net.pitan76.mcpitanlib.api.sound.CompatBlockSoundGroup;

import java.util.function.Function;
import java.util.function.ToIntFunction;

@Deprecated
public class CompatibleBlockSettings {
    private float resistance, hardness = 0.0f;

    protected final AbstractBlock.Properties settings;

    public CompatibleBlockSettings() {
        this.settings = AbstractBlock.Properties.func_200945_a(Material.field_151576_e);
    }

    @Deprecated
    public static CompatibleBlockSettings of() {
        return new CompatibleBlockSettings();
    }

    public CompatibleBlockSettings(CompatibleMaterial material, MaterialColor mapColor) {
        this.settings = AbstractBlock.Properties.func_200949_a(material.getMaterial(), mapColor);
    }

    public CompatibleBlockSettings(CompatibleMaterial material, DyeColor dyeColor) {
        this.settings = AbstractBlock.Properties.func_200952_a(material.getMaterial(), dyeColor);
    }

    public CompatibleBlockSettings(CompatibleMaterial material) {
        this.settings = AbstractBlock.Properties.func_200945_a(material.getMaterial());
    }

    @Deprecated
    public CompatibleBlockSettings(Material material) {
        this.settings = AbstractBlock.Properties.func_200945_a(material);
    }

    public CompatibleBlockSettings(CompatibleMaterial material, Function<BlockState, MaterialColor> mapColor) {
        this.settings = AbstractBlock.Properties.func_235836_a_(material.getMaterial(), mapColor);
    }

    @Deprecated
    public static CompatibleBlockSettings of(CompatibleMaterial material, MaterialColor mapColor) {
        return new CompatibleBlockSettings(material, mapColor);
    }

    @Deprecated
    public static CompatibleBlockSettings of(CompatibleMaterial material, DyeColor dyeColor) {
        return new CompatibleBlockSettings(material, dyeColor);
    }

    @Deprecated
    public static CompatibleBlockSettings of(Material material) {
        return new CompatibleBlockSettings(material);
    }

    @Deprecated
    public static CompatibleBlockSettings of(CompatibleMaterial material) {
        return new CompatibleBlockSettings(material);
    }

    @Deprecated
    public static CompatibleBlockSettings of(CompatibleMaterial material, Function<BlockState, MaterialColor> mapColor) {
        return new CompatibleBlockSettings(material, mapColor);
    }

    public CompatibleBlockSettings(AbstractBlock block) {
        this.settings = AbstractBlock.Properties.func_200950_a(block);
    }

    @Deprecated
    public static CompatibleBlockSettings copy(AbstractBlock block) {
        return new CompatibleBlockSettings(block);
    }

    public CompatibleBlockSettings air() {
        settings.func_235859_g_();
        return this;
    }

    public CompatibleBlockSettings blockVision(AbstractBlock.IPositionPredicate predicate) {
        settings.func_235847_c_(predicate);
        return this;
    }

    public CompatibleBlockSettings postProcess(AbstractBlock.IPositionPredicate predicate) {
        settings.func_235852_d_(predicate);
        return this;
    }

    public CompatibleBlockSettings solidBlock(AbstractBlock.IPositionPredicate predicate) {
        settings.func_235828_a_(predicate);
        return this;
    }

    public CompatibleBlockSettings suffocates(AbstractBlock.IPositionPredicate predicate) {
        settings.func_235842_b_(predicate);
        return this;
    }

    public CompatibleBlockSettings mapColor(MaterialColor color) {
        //settings.mapColor(color);
        return this;
    }

    @Deprecated
    public CompatibleBlockSettings mapColor(DyeColor color) {
        return this;
    }

    @Deprecated
    public CompatibleBlockSettings mapColor(Function<BlockState, MaterialColor> color) {
        return this;
    }

    @Deprecated
    public CompatibleBlockSettings dropsLike(Block source) {
        settings.func_222379_b(source);
        return this;
    }

    public CompatibleBlockSettings breakInstantly() {
        settings.func_200946_b();
        return this;
    }

    public CompatibleBlockSettings dropsNothing() {
        settings.func_222380_e();
        return this;
    }

    public CompatibleBlockSettings dynamicBounds() {
        settings.func_208770_d();
        return this;
    }

    public CompatibleBlockSettings hardness(float hardness) {
        settings.func_200948_a(hardness, resistance);
        this.hardness = hardness;
        return this;
    }

    public CompatibleBlockSettings noBlockBreakParticles() {
        //?
        return this;
    }

    public CompatibleBlockSettings requiresTool() {
        settings.func_235861_h_();
        return this;
    }

    public CompatibleBlockSettings noCollision() {
        settings.func_200942_a();
        return this;
    }

    public CompatibleBlockSettings nonOpaque() {
        settings.func_226896_b_();
        return this;
    }

    public CompatibleBlockSettings resistance(float resistance) {
        settings.func_200948_a(hardness, resistance);
        this.resistance = resistance;
        return this;
    }

    public CompatibleBlockSettings strength(float strength) {
        settings.func_200943_b(strength);
        return this;
    }

    public CompatibleBlockSettings strength(float hardness, float resistance) {
        settings.func_200948_a(hardness, resistance);
        this.resistance = resistance;
        this.hardness = hardness;
        return this;
    }

    public CompatibleBlockSettings ticksRandomly() {
        settings.func_200944_c();
        return this;
    }

    public CompatibleBlockSettings sounds(SoundType blockSoundGroup) {
        settings.func_200947_a(blockSoundGroup);
        return this;
    }

    public CompatibleBlockSettings sounds(CompatBlockSoundGroup blockSoundGroup) {
        return sounds(blockSoundGroup.get());
    }

    public CompatibleBlockSettings luminance(ToIntFunction<BlockState> luminance) {
        settings.func_235838_a_(luminance);
        return this;
    }

    public CompatibleBlockSettings jumpVelocityMultiplier(float jumpVelocityMultiplier) {
        settings.func_226898_c_(jumpVelocityMultiplier);
        return this;
    }

    public CompatibleBlockSettings slipperiness(float slipperiness) {
        settings.func_200941_a(slipperiness);
        return this;
    }

    public CompatibleBlockSettings velocityMultiplier(float velocityMultiplier) {
        settings.func_226897_b_(velocityMultiplier);
        return this;
    }

    public CompatibleBlockSettings emissiveLighting(AbstractBlock.IPositionPredicate predicate) {
        settings.func_235856_e_(predicate);
        return this;
    }

    public CompatibleBlockSettings offset(AbstractBlock.OffsetType offsetType) {
        // ?
        return this;
    }

    public CompatibleBlockSettings allowsSpawning(AbstractBlock.IExtendedPositionPredicate<net.minecraft.entity.EntityType<?>> predicate) {
        settings.func_235827_a_(predicate);
        return this;
    }

    public AbstractBlock.Properties build() {
        return settings;

    }
}
