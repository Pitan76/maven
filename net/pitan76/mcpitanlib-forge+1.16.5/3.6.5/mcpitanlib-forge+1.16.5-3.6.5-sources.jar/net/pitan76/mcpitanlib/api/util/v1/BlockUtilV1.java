package net.pitan76.mcpitanlib.api.util.v1;

import net.minecraft.block.AbstractBlock;
import net.minecraft.block.Block;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.registry.Registry;
import net.pitan76.mcpitanlib.api.block.CompatibleBlockSettings;
import net.pitan76.mcpitanlib.api.tag.MineableToolTags;

import java.util.ArrayList;
import java.util.List;

public class BlockUtilV1 {
    public static Block block(ResourceLocation id) {
        return Registry.field_212618_g.func_82594_a(id);
    }

    /**
     * ～1.16?
     * @param settings
     * @param toolTags
     * @param level
     * @return
     */
    public static AbstractBlock.Properties breakByTool(AbstractBlock.Properties settings, MineableToolTags toolTags, int level) {
        return settings;
    }

    public static AbstractBlock.Properties dropsNothing(AbstractBlock.Properties settings) {
        return settings.func_222380_e();
    }

    public static AbstractBlock.Properties requiresTool(AbstractBlock.Properties settings) {
        return settings.func_235861_h_();
    }

    public static boolean isExist(ResourceLocation identifier) {
        return Registry.field_212618_g.func_212607_c(identifier);
    }

    public static ResourceLocation toID(Block block) {
        return Registry.field_212618_g.func_177774_c(block);
    }

    public static Block fromId(ResourceLocation identifier) {
        return Registry.field_212618_g.func_82594_a(identifier);
    }

    public static List<Block> getAllBlocks() {
        List<Block> blocks = new ArrayList<>();
        for (Block block : Registry.field_212618_g) {
            blocks.add(block);
        }
        return blocks;
    }

    @Deprecated
    public static Block of(AbstractBlock.Properties settings) {
        return new Block(settings);
    }

    public static Block of(CompatibleBlockSettings settings) {
        return of(settings.build());
    }

    public static int getRawId(Block block) {
        return Registry.field_212618_g.func_148757_b(block);
    }

    public static Block fromIndex(int index) {
        return Registry.field_212618_g.func_148745_a(index);
    }
}
