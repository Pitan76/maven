package net.pitan76.mcpitanlib.api.util.recipe;

import net.minecraft.item.crafting.IRecipe;
import net.minecraft.item.crafting.IRecipeType;
import net.minecraft.world.World;
import net.pitan76.mcpitanlib.api.recipe.v3.CompatRecipe;
import net.pitan76.mcpitanlib.api.util.CompatIdentifier;
import net.pitan76.mcpitanlib.midohra.recipe.CraftingRecipe;
import net.pitan76.mcpitanlib.midohra.recipe.entry.CraftingRecipeEntry;
import net.pitan76.mcpitanlib.midohra.recipe.entry.RecipeEntry;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

public class RecipeUtil {
    public static Collection<IRecipe<?>> getMCRecipes(World world) {
        return world.func_199532_z().func_199510_b();
    }

    public static Collection<CompatRecipe> getRecipes(World world) {
        List<CompatRecipe> recipes = new ArrayList<>();

        for (IRecipe<?> recipe : getMCRecipes(world)) {
            recipes.add(new CompatRecipe(recipe, recipe.func_199560_c()));
        }

        return recipes;
    }

    public static Collection<CompatRecipe> getRecipesByType(World world, IRecipeType<?> type) {
        List<CompatRecipe> recipes = new ArrayList<>();

        for (IRecipe<?> recipe : getMCRecipes(world)) {
            if (recipe.func_222127_g() == type) {
                recipes.add(new CompatRecipe(recipe, recipe.func_199560_c()));
            }
        }

        return recipes;
    }

    // MidohraAPI
    public static Collection<CompatRecipe> getRecipes(net.pitan76.mcpitanlib.midohra.world.World world) {
        return getRecipes(world.getRaw());
    }

    public static Collection<CompatRecipe> getRecipesByType(net.pitan76.mcpitanlib.midohra.world.World world, net.pitan76.mcpitanlib.midohra.recipe.RecipeType type) {
        return getRecipesByType(world.getRaw(), type.getRaw());
    }

    public static Collection<RecipeEntry> getRecipeEntries(net.pitan76.mcpitanlib.midohra.world.World world) {
        List<RecipeEntry> entries = new ArrayList<>();

        for (IRecipe<?> recipe : getMCRecipes(world.getRaw())) {
            entries.add(RecipeEntry.of(recipe, CompatIdentifier.fromMinecraft(recipe.func_199560_c())));
        }

        return entries;
    }

    public static Collection<CraftingRecipe> getCraftingRecipes(net.pitan76.mcpitanlib.midohra.world.World world) {
        List<CraftingRecipe> recipes = new ArrayList<>();

        for (CompatRecipe recipe : getRecipesByType(world, net.pitan76.mcpitanlib.midohra.recipe.RecipeType.CRAFTING)) {
            if (recipe.getRecipe() instanceof net.minecraft.item.crafting.ICraftingRecipe) {
                recipes.add(CraftingRecipe.of((net.minecraft.item.crafting.ICraftingRecipe) recipe.getRecipe()));
            }
        }

        return recipes;
    }

    public static Collection<CraftingRecipeEntry> getCraftingRecipeEntries(net.pitan76.mcpitanlib.midohra.world.World world) {
        List<CraftingRecipeEntry> entries = new ArrayList<>();

        for (IRecipe<?> recipe : getMCRecipes(world.getRaw())) {
            if (recipe instanceof net.minecraft.item.crafting.ICraftingRecipe) {
                entries.add(CraftingRecipeEntry.of((net.minecraft.item.crafting.ICraftingRecipe) recipe, CompatIdentifier.fromMinecraft(recipe.func_199560_c())));
            }
        }

        return entries;
    }
}
