package net.pitan76.mcpitanlib.api.client.render.block.entity.event;

import net.minecraft.client.renderer.tileentity.TileEntityRendererDispatcher;

public class CompatBlockEntityRendererConstructArgs {
    public final TileEntityRendererDispatcher dispatcher;

    public CompatBlockEntityRendererConstructArgs(TileEntityRendererDispatcher dispatcher) {
        this.dispatcher = dispatcher;
    }

    public CompatBlockEntityRendererConstructArgs() {
        this(null);
    }
}
