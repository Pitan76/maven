package net.pitan76.mcpitanlib.api.util;

import net.minecraft.block.BlockState;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.IBlockReader;

public class BlockViewUtil {
    public static BlockState getBlockState(IBlockReader blockView, BlockPos pos) {
        return blockView.func_180495_p(pos);
    }

    public static TileEntity getBlockEntity(IBlockReader blockView, BlockPos pos) {
        return blockView.func_175625_s(pos);
    }

    public static boolean hasBlockEntity(IBlockReader blockView, BlockPos pos) {
        return getBlockEntity(blockView, pos) != null;
    }

    public static boolean isAir(IBlockReader blockView, BlockPos pos) {
        return getBlockState(blockView, pos).func_196958_f();
    }
}
