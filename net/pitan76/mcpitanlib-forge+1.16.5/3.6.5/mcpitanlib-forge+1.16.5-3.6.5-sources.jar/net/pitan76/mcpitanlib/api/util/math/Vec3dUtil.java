package net.pitan76.mcpitanlib.api.util.math;

import net.minecraft.util.math.vector.Vector3d;

public class Vec3dUtil {
    public static Vector3d create(double x, double y, double z) {
        return new Vector3d(x, y, z);
    }

    public static Vector3d add(Vector3d a, Vector3d b) {
        return a.func_178787_e(b);
    }

    public static Vector3d subtract(Vector3d a, Vector3d b) {
        return a.func_178788_d(b);
    }

    public static Vector3d multiply(Vector3d a, double b) {
        return a.func_186678_a(b);
    }

    public static Vector3d divide(Vector3d a, double b) {
        return a.func_186678_a(1.0D / b);
    }

    public static double dot(Vector3d a, Vector3d b) {
        return a.func_72430_b(b);
    }

    public static Vector3d cross(Vector3d a, Vector3d b) {
        return a.func_72431_c(b);
    }

    public static Vector3d normalize(Vector3d a) {
        return a.func_72432_b();
    }

    public static Vector3d rotateX(Vector3d a, float angle) {
        return a.func_178789_a(angle);
    }

    public static Vector3d rotateY(Vector3d a, float angle) {
        return a.func_178785_b(angle);
    }

    public static Vector3d rotateZ(Vector3d a, float angle) {
        return a.func_242988_c(angle);
    }

    public static Vector3d add(Vector3d a, double x, double y, double z) {
        return a.func_72441_c(x, y, z);
    }

    public static Vector3d subtract(Vector3d a, double x, double y, double z) {
        return a.func_178786_a(x, y, z);
    }

    public static Vector3d multiply(Vector3d a, double x, double y, double z) {
        return a.func_216372_d(x, y, z);
    }

    public static double distanceTo(Vector3d a, Vector3d b) {
        return a.func_72438_d(b);
    }

    public static Vector3d ofCenter(double x, double y, double z) {
        return new Vector3d(x + 0.5, y + 0.5, z + 0.5);
    }
}
