package net.pitan76.mcpitanlib.api.client.gui.screen;

import com.mojang.blaze3d.matrix.MatrixStack;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.gui.IGuiEventListener;
import net.minecraft.client.gui.IRenderable;
import net.minecraft.client.gui.screen.inventory.ContainerScreen;
import net.minecraft.client.gui.widget.Widget;
import net.minecraft.client.renderer.ItemRenderer;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.inventory.container.Container;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.text.ITextComponent;
import net.pitan76.mcpitanlib.api.client.gui.widget.CompatibleTexturedButtonWidget;
import net.pitan76.mcpitanlib.api.client.render.DrawObjectDM;
import net.pitan76.mcpitanlib.api.client.render.handledscreen.*;
import net.pitan76.mcpitanlib.api.client.render.screen.RenderBackgroundTextureArgs;
import net.pitan76.mcpitanlib.api.text.TextComponent;
import net.pitan76.mcpitanlib.api.util.CompatIdentifier;
import net.pitan76.mcpitanlib.api.util.IdentifierUtil;
import net.pitan76.mcpitanlib.api.util.client.ClientUtil;
import net.pitan76.mcpitanlib.api.util.client.RenderUtil;
import net.pitan76.mcpitanlib.api.util.client.ScreenUtil;
import net.pitan76.mcpitanlib.core.datafixer.Pair;

public abstract class SimpleHandledScreen<S extends Container> extends ContainerScreen<S> {

    public int field_230708_k_, field_230709_l_, field_146999_f, field_147000_g, field_147003_i, field_147009_r;
    public S field_147002_h;
    public FontRenderer field_230712_o_;
    public ItemRenderer field_230707_j_;

    public ITextComponent field_230704_d_;
    public Minecraft field_230706_i_;
    public SimpleHandledScreen(S handler, PlayerInventory inventory, ITextComponent title) {
        super(handler, inventory, title);
        fixScreen();
        this.field_147002_h = handler;
        this.field_230704_d_ = title;

    }

    @Deprecated
    @Override
    public S func_212873_a_() {
        return getScreenHandlerOverride();
    }

    public S getScreenHandlerOverride() {
        return super.func_212873_a_();
    }

    public <T extends IGuiEventListener & IRenderable> T addDrawableChild_compatibility(T drawableElement) {
        if (drawableElement instanceof Widget)
            return (T) super.func_230480_a_((Widget) drawableElement);
        else
            return super.func_230481_d_(drawableElement);
    }

    public <T extends IGuiEventListener> T addSelectableChild_compatibility(T selectableElement) {
        if (selectableElement instanceof Widget)
            return (T) super.func_230480_a_((Widget) selectableElement);
        else
            return super.func_230481_d_(selectableElement);
    }

    public CompatibleTexturedButtonWidget addDrawableCTBW(CompatibleTexturedButtonWidget widget) {
        return addDrawableChild_compatibility(widget);
    }

    @Deprecated
    @Override
    protected void func_230450_a_(MatrixStack stack, float delta, int mouseX, int mouseY) {
        DrawObjectDM drawObjectDM = new DrawObjectDM(stack, this);
        drawBackgroundOverride(new DrawBackgroundArgs(drawObjectDM, delta, mouseX, mouseY));
    }

    public abstract void drawBackgroundOverride(DrawBackgroundArgs args);

    @Deprecated
    @Override
    protected void func_230451_b_(MatrixStack stack, int mouseX, int mouseY) {
        DrawObjectDM drawObjectDM = new DrawObjectDM(stack, this);
        drawForegroundOverride(new DrawForegroundArgs(drawObjectDM, mouseX, mouseY));
    }

    protected void drawForegroundOverride(DrawForegroundArgs args) {
        super.func_230451_b_(args.drawObjectDM.getStack(), args.mouseX, args.mouseY);
    }

    public void callDrawTexture(DrawObjectDM drawObjectDM, ResourceLocation texture, int x, int y, int u, int v, int width, int height) {
        ScreenUtil.setBackground(texture);
        func_238474_b_(drawObjectDM.getStack(), x, y, u, v, width, height);
    }

    public void callDrawTexture(DrawObjectDM drawObjectDM, CompatIdentifier texture, int x, int y, int u, int v, int width, int height) {
        callDrawTexture(drawObjectDM, texture.toMinecraft(), x, y, u, v, width, height);
    }

    @Deprecated
    public void callRenderBackground(DrawObjectDM drawObjectDM) {
        super.func_230446_a_(drawObjectDM.getStack());
        callRenderBackground(new RenderArgs(drawObjectDM, 0, 0, 0));
    }


    public void callRenderBackground(RenderArgs args) {
        super.func_230446_a_(args.drawObjectDM.getStack());
    }

    public void callDrawMouseoverTooltip(DrawMouseoverTooltipArgs args) {
        super.func_230459_a_(args.drawObjectDM.getStack(), args.mouseX, args.mouseY);
    }

    public void renderOverride(RenderArgs args) {
        super.func_230430_a_(args.drawObjectDM.getStack(), args.mouseX, args.mouseY, args.delta);
    }

    public void resizeOverride(Minecraft client, int width, int height) {
    }

    public void initOverride() {
    }

    @Deprecated
    @Override
    protected void func_231160_c_() {
        super.func_231160_c_();
        fixScreen();
        initOverride();
    }

    @Deprecated
    @Override
    public void func_231152_a_(Minecraft client, int width, int height) {
        super.func_231152_a_(client, width, height);
        fixScreen();
        resizeOverride(client, width, height);
    }

    public void fixScreen() {
        this.field_146999_f = getBackgroundWidth();
        this.field_147000_g = getBackgroundHeight();
        this.field_147003_i = super.field_147003_i; //(this.width - this.backgroundWidth) / 2;
        this.field_147009_r = super.field_147009_r; //(this.height - this.backgroundHeight) / 2;
        this.field_230712_o_ = super.field_230712_o_;
        this.field_230707_j_ = super.field_230707_j_;
        this.field_230708_k_ = super.field_230708_k_;
        this.field_230709_l_ = super.field_230709_l_;
        if (super.field_230706_i_ == null)
            this.field_230706_i_ = Minecraft.func_71410_x();
        else
            this.field_230706_i_ = super.field_230706_i_;
    }

    public void setX(int x) {
        this.field_147003_i = x;
        super.field_147003_i = x;
    }

    public void setY(int y) {
        this.field_147009_r = y;
        super.field_147009_r = y;
    }

    public void setTextRenderer(FontRenderer textRenderer) {
        this.field_230712_o_ = textRenderer;
        super.field_230712_o_ = textRenderer;
    }

    public void setItemRenderer(ItemRenderer itemRenderer) {
        this.field_230707_j_ = itemRenderer;
        super.field_230707_j_ = itemRenderer;
    }

    public void setWidth(int width) {
        this.field_230708_k_ = width;
        super.field_230708_k_ = width;
    }

    public void setBackgroundWidth(int backgroundWidth) {
        this.field_146999_f = backgroundWidth;
        super.field_146999_f = backgroundWidth;
    }

    public void setBackgroundHeight(int backgroundHeight) {
        this.field_147000_g = backgroundHeight;
        super.field_147000_g = backgroundHeight;
    }

    public void setHeight(int height) {
        this.field_230709_l_ = height;
        super.field_230709_l_ = height;
    }

    public int getBackgroundWidth() {
        return super.field_146999_f;
    }

    public int getBackgroundHeight() {
        return super.field_147000_g;
    }

    @Deprecated
    @Override
    public void func_230430_a_(MatrixStack stack, int mouseX, int mouseY, float delta) {
        DrawObjectDM drawObjectDM = new DrawObjectDM(stack, this);
        renderOverride(new RenderArgs(drawObjectDM, mouseX, mouseY, delta));
    }

    public boolean keyReleased(KeyEventArgs args) {
        return super.func_223281_a_(args.keyCode, args.scanCode, args.modifiers);
    }

    public boolean keyPressed(KeyEventArgs args) {
        return super.func_231046_a_(args.keyCode, args.scanCode, args.modifiers);
    }

    public void renderBackgroundTexture(RenderBackgroundTextureArgs args) {
        if (getBackgroundTexture() == null) {
            super.func_231165_f_(args.getvOffset());
            return;
        }

        RenderUtil.setShaderToPositionTexProgram();
        RenderUtil.setShaderTexture(0, getBackgroundTexture());
        RenderUtil.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);

        callDrawTexture(args.drawObjectDM, getBackgroundTexture(), 0, 0, 0, 0, this.field_230708_k_, this.field_230709_l_);
    }

    @Deprecated
    @Override
    public boolean func_223281_a_(int keyCode, int scanCode, int modifiers) {
        return this.keyReleased(new KeyEventArgs(keyCode, scanCode, modifiers));
    }

    @Deprecated
    @Override
    public boolean func_231046_a_(int keyCode, int scanCode, int modifiers) {
        return this.keyPressed(new KeyEventArgs(keyCode, scanCode, modifiers));
    }

    @Deprecated
    @Override
    public void func_231165_f_(int vOffset) {
        this.renderBackgroundTexture(new RenderBackgroundTextureArgs(new DrawObjectDM(null, this), vOffset));
    }

    public void closeOverride() {
        super.func_231175_as__();
    }

    public void removedOverride() {
        super.func_231164_f_();
    }

    @Override
    public void func_231175_as__() {
        closeOverride();
    }

    @Override
    public void func_231164_f_() {
        removedOverride();
    }

    public ResourceLocation getBackgroundTexture() {
        return IdentifierUtil.from(getCompatBackgroundTexture());
    }

    public CompatIdentifier getCompatBackgroundTexture() {
        return null;
    }

    public void setTitleX(int x) {
        this.field_238742_p_ = x;
    }

    public void setTitleY(int y) {
        this.field_238743_q_ = y;
    }

    public void setTitlePos(int x, int y) {
        setTitleX(x);
        setTitleY(y);
    }

    public void setTitleXCenter() {
        if (field_230712_o_ == null)
            field_230712_o_ = ClientUtil.getTextRenderer();

        setTitleX(field_146999_f / 2 - field_230712_o_.func_238414_a_(field_230704_d_) / 2);
    }

    public int getTitleX() {
        return field_238742_p_;
    }

    public int getTitleY() {
        return field_238743_q_;
    }

    public void drawText(DrawObjectDM drawObjectDM, ITextComponent text, int x, int y, int color) {
        ScreenUtil.RendererUtil.drawText(field_230712_o_, drawObjectDM, text, x, y, color);
    }

    public void drawText(DrawObjectDM drawObjectDM, TextComponent text, int x, int y, int color) {
        ScreenUtil.RendererUtil.drawText(field_230712_o_, drawObjectDM, text, x, y, color);
    }

    public void drawText(DrawObjectDM drawObjectDM, ITextComponent text, int x, int y) {
        ScreenUtil.RendererUtil.drawText(field_230712_o_, drawObjectDM, text, x, y);
    }

    public void drawText(DrawObjectDM drawObjectDM, TextComponent text, int x, int y) {
        ScreenUtil.RendererUtil.drawText(field_230712_o_, drawObjectDM, text, x, y);
    }

    @Deprecated
    @Override
    public ITextComponent func_231171_q_() {
        return callGetTitle();
    }

    public ITextComponent callGetTitle() {
        return super.func_231171_q_();
    }

    public Pair<Integer, Integer> getTitlePosP() {
        return new Pair<>(getTitleX(), getTitleY());
    }

    public int getPlayerInvTitleX() {
        return field_238744_r_;
    }

    public int getPlayerInvTitleY() {
        return field_238745_s_;
    }

    public void setPlayerInvTitleX(int x) {
        field_238744_r_ = x;
    }

    public void setPlayerInvTitleY(int y) {
        field_238745_s_ = y;
    }

    public void setPlayerInvTitle(int x, int y) {
        setPlayerInvTitleX(x);
        setPlayerInvTitleY(y);
    }

    public FontRenderer callGetTextRenderer() {
        if (field_230712_o_ != null)
            return field_230712_o_;

        if (super.field_230712_o_ != null)
            return super.field_230712_o_;

        return ClientUtil.getTextRenderer();
    }

    public ItemRenderer callGetItemRenderer() {
        if (field_230707_j_ != null)
            return field_230707_j_;

        return ClientUtil.getItemRenderer();
    }

    public ITextComponent getPlayerInvTitle() {
        return super.field_213127_e.func_200200_C_();
    }
}
