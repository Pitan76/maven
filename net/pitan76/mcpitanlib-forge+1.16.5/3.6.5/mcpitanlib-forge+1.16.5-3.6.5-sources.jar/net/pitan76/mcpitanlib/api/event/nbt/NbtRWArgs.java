package net.pitan76.mcpitanlib.api.event.nbt;

import net.minecraft.nbt.CompoundNBT;
import net.pitan76.mcpitanlib.api.registry.CompatRegistryLookup;

public class NbtRWArgs {
    public CompoundNBT nbt;
    public CompatRegistryLookup registryLookup;

    public NbtRWArgs(CompoundNBT nbt, CompatRegistryLookup registryLookup) {
        this.nbt = nbt;
        this.registryLookup = registryLookup;
    }

    public NbtRWArgs(CompoundNBT nbt) {
        this.nbt = nbt;
    }

    public CompoundNBT getNbt() {
        return nbt;
    }

    public CompatRegistryLookup getRegistryLookup() {
        return registryLookup;
    }

    public boolean hasRegistryLookup() {
        return registryLookup != null;
    }

    public boolean isNbtEmpty() {
        return nbt != null && !nbt.isEmpty();
    }

    public boolean isViewEmpty() {
        return false;
    }

    public boolean isEmpty() {
        return isNbtEmpty() || isViewEmpty();
    }

    public NbtRWArgs copy() {
        return new NbtRWArgs(nbt.func_74737_b(), registryLookup);
    }

    public net.pitan76.mcpitanlib.midohra.nbt.NbtCompound getNbtM() {
        return net.pitan76.mcpitanlib.midohra.nbt.NbtCompound.of(nbt);
    }
}
