package net.pitan76.mcpitanlib.api.util.world;

import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.fluid.Fluid;
import net.minecraft.fluid.FluidState;
import net.minecraft.tags.FluidTags;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.tileentity.TileEntityType;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.DimensionType;
import net.minecraft.world.IWorld;
import net.minecraft.world.IWorldReader;
import net.minecraft.world.World;
import net.pitan76.mcpitanlib.midohra.entity.EntityTypeWrapper;

import java.util.List;
import java.util.Optional;
import java.util.function.Predicate;

public class WorldViewUtil {

    public static boolean isClient(IWorldReader world) {
        return world.func_201670_d();
    }

    public static BlockState getBlockState(IWorldReader world, BlockPos pos) {
        return world.func_180495_p(pos);
    }

    public static Block getBlock(IWorldReader world, BlockPos pos) {
        return getBlockState(world, pos).func_177230_c();
    }

    public static TileEntity getBlockEntity(IWorldReader world, BlockPos pos) {
        return world.func_175625_s(pos);
    }

    public static <T extends TileEntity> Optional<T> getBlockEntity(IWorldReader world, BlockPos pos, TileEntityType<T> type) {
        return Optional.ofNullable(type.func_226986_a_(world, pos));
    }

    public static FluidState getFluidState(IWorldReader world, BlockPos pos) {
        return getBlockState(world, pos).func_204520_s();
    }

    public static Fluid getFluid(IWorldReader world, BlockPos pos) {
        return getFluidState(world, pos).func_206886_c();
    }

    public static int getBottomY(IWorldReader world) {
        return 0;
    }

    public static int getTopY(IWorldReader world) {
        return world.func_217301_I();
    }

    public static boolean isChunkLoaded(IWorldReader world, BlockPos pos) {
        return world.func_175667_e(pos);
    }

    public static boolean isRegionLoaded(IWorldReader world, BlockPos min, BlockPos max) {
        return world.func_175707_a(min, max);
    }

    public static DimensionType getDimensionType(IWorldReader world) {
        return world.func_230315_m_();
    }

    public static boolean isAirBlock(IWorldReader world, BlockPos pos) {
        return getBlockState(world, pos).func_196958_f();
    }

    public static boolean isOpaqueBlock(IWorldReader world, BlockPos pos) {
        return getBlockState(world, pos).func_200132_m();
    }

    public static boolean isWater(IWorldReader world, BlockPos pos) {
        return getFluidState(world, pos).func_206884_a(FluidTags.field_206959_a);
    }

    public static <T extends Entity> List<T> getEntitiesByClass(IWorld world, Class<T> entityClass, AxisAlignedBB box, Predicate<? super T> predicate) {
        return world.func_175647_a(entityClass, box, predicate);
    }

    public static <T extends Entity> List<T> getEntitiesByClass(IWorld world, Class<T> entityClass, net.pitan76.mcpitanlib.midohra.util.math.Box box, Predicate<? super T> predicate) {
        return getEntitiesByClass(world, entityClass, box.toMinecraft(), predicate);
    }

    public static <T extends Entity> List<T> getEntitiesByType(IWorld world, EntityType<T> entityType, AxisAlignedBB box, Predicate<? super Entity> predicate) {
        if (world instanceof World) {
            return ((World) world).func_217394_a(entityType, box, predicate);
        }

        // EntityType<T> のTを
        return (List<T>) world.func_175647_a(Entity.class, box, predicate.and(entity -> ((Entity) entity).func_200600_R() == entityType));
    }

    public static <T extends Entity> List<T> getEntitiesByType(IWorld world, EntityType<T> entityType, net.pitan76.mcpitanlib.midohra.util.math.Box box, Predicate<? super Entity> predicate) {
        return getEntitiesByType(world, entityType, box.toMinecraft(), predicate);
    }

    public static List<?> getEntitiesByType(IWorld world, EntityTypeWrapper entityType, AxisAlignedBB box, Predicate<? super Entity> predicate) {
        return getEntitiesByType(world, entityType.get(), box, predicate);
    }
}
