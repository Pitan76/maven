package net.pitan76.mcpitanlib.api.command.argument;

import net.minecraft.block.Block;
import net.minecraft.command.arguments.BlockStateArgument;
import net.pitan76.mcpitanlib.api.event.BlockCommandEvent;
import net.pitan76.mcpitanlib.api.event.ServerCommandEvent;

public abstract class BlockCommand extends RequiredCommand<Block> {
    @Override
    public BlockStateArgument getArgumentType() {
        return BlockStateArgument.func_197239_a();
    }

    public abstract void execute(BlockCommandEvent event);

    @Override
    public void execute(ServerCommandEvent event) {
        execute((BlockCommandEvent) event);
    }
}
