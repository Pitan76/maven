package net.pitan76.mcpitanlib.api.client.render.block.entity;

import com.mojang.blaze3d.matrix.MatrixStack;
import net.minecraft.client.renderer.IRenderTypeBuffer;
import net.minecraft.client.renderer.tileentity.TileEntityRenderer;
import net.minecraft.client.renderer.tileentity.TileEntityRendererDispatcher;
import net.pitan76.mcpitanlib.api.client.render.block.entity.event.BlockEntityRenderEvent;
import net.pitan76.mcpitanlib.api.tile.CompatBlockEntity;

// TODO: 1.16.5ではextendsで1.18ではimplementsに変更されているため、ラッパーを作成する必要がある
@Deprecated
public abstract class CompatBlockEntityRenderer<T extends CompatBlockEntity> extends TileEntityRenderer<T> {

    public CompatBlockEntityRenderer(TileEntityRendererDispatcher dispatcher) {
        super(dispatcher);
    }

    abstract void render(BlockEntityRenderEvent<T> event);

    @Override
    public void render(T entity, float tickDelta, MatrixStack matrices, IRenderTypeBuffer vertexConsumers, int light, int overlay) {
        render(new BlockEntityRenderEvent<>(this, entity, tickDelta, matrices, vertexConsumers, light, overlay));
    }

    public boolean rendersOutsideBoundingBoxOverride(T blockEntity) {
        return super.func_188185_a(blockEntity);
    }

    public int getRenderDistanceOverride() {
        return 64;
    }

    @Deprecated
    @Override
    public boolean rendersOutsideBoundingBox(T blockEntity) {
        return rendersOutsideBoundingBoxOverride(blockEntity);
    }

}
