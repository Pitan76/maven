package net.pitan76.mcpitanlib.api.client.event.listener;

import net.minecraft.client.util.ITooltipFlag;
import net.minecraft.item.ItemStack;
import net.minecraft.util.text.ITextComponent;
import java.util.List;

@FunctionalInterface
public interface ItemTooltipListener {
    void onTooltip(ItemTooltipContext context);

    default void onTooltip(ItemStack stack, List<ITextComponent> texts, ITooltipFlag tooltipContext) {
        onTooltip(new ItemTooltipContext(stack, texts, tooltipContext));
    }
}