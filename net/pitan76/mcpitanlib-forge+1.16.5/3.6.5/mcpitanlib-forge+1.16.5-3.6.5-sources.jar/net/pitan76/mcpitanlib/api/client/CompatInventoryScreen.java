package net.pitan76.mcpitanlib.api.client;

import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.inventory.container.Container;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.text.ITextComponent;
import net.pitan76.mcpitanlib.api.util.CompatIdentifier;

@Deprecated
public abstract class CompatInventoryScreen extends SimpleInventoryScreen {

    public CompatInventoryScreen(Container handler, PlayerInventory inventory, ITextComponent title) {
        super(handler, inventory, title);
    }

    public abstract CompatIdentifier getCompatTexture();

    @Override
    public ResourceLocation getTexture() {
        return getCompatTexture().toMinecraft();
    }
}
