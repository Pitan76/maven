package net.pitan76.mcpitanlib.api.event.block;

import net.minecraft.block.BlockState;
import net.minecraft.state.Property;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.shapes.ISelectionContext;
import net.minecraft.world.IBlockReader;
import net.pitan76.mcpitanlib.api.event.BaseEvent;
import net.pitan76.mcpitanlib.api.state.property.IProperty;

public class OutlineShapeEvent extends BaseEvent {
    public BlockState state;
    public IBlockReader world;
    public BlockPos pos;
    public ISelectionContext context;

    public OutlineShapeEvent(BlockState state, IBlockReader world, BlockPos pos, ISelectionContext context) {
        this.state = state;
        this.world = world;
        this.pos = pos;
        this.context = context;
    }

    public BlockPos getPos() {
        return pos;
    }

    public BlockState getState() {
        return state;
    }

    public IBlockReader getWorld() {
        return world;
    }

    public ISelectionContext getContext() {
        return context;
    }

    public <T extends Comparable<T>> T getProperty(Property<T> property) {
        return state.func_177229_b(property);
    }

    public <T extends Comparable<T>> boolean containsProperty(Property<T> property) {
        return state.func_235901_b_(property);
    }

    public <T extends Comparable<T>, V extends T> BlockState with(Property<T> property, V value) {
        return state.func_206870_a(property, value);
    }

    public <T extends Comparable<T>> T get(IProperty<T> property) {
        return getProperty(property.getProperty());
    }

    public <T extends Comparable<T>> boolean contains(IProperty<T> property) {
        return containsProperty(property.getProperty());
    }

    public <T extends Comparable<T>, V extends T> net.pitan76.mcpitanlib.midohra.block.BlockState with(IProperty<T> property, V value) {
        return net.pitan76.mcpitanlib.midohra.block.BlockState.of(with(property.getProperty(), value));
    }
}
