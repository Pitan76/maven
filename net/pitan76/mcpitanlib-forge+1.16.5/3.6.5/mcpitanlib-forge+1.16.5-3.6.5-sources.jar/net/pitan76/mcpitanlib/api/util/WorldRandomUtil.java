package net.pitan76.mcpitanlib.api.util;

import net.minecraft.world.World;

public class WorldRandomUtil {
    public static int nextInt(World world) {
        return world.func_201674_k().nextInt();
    }

    public static int nextInt(World world, int bound) {
        return world.func_201674_k().nextInt(bound);
    }

    public static long nextLong(World world) {
        return world.func_201674_k().nextLong();
    }

    public static double nextDouble(World world) {
        return world.func_201674_k().nextDouble();
    }

    public static double nextGaussian(World world) {
        return world.func_201674_k().nextGaussian();
    }

    public static float nextFloat(World world) {
        return world.func_201674_k().nextFloat();
    }

    public static int nextBetween(World world, int min, int max) {
        return nextInt(world, max - min + 1) + min;
    }

    public static int nextBetweenExclusive(World world, int min, int max) {
        if (min >= max) {
            throw new IllegalArgumentException("bound - origin is non positive");
        } else {
            return min + nextInt(world, max - min);
        }
    }
}
