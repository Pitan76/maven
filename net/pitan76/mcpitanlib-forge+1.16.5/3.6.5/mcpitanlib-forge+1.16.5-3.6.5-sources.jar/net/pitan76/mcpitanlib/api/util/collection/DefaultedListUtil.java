package net.pitan76.mcpitanlib.api.util.collection;

import net.minecraft.util.NonNullList;

public class DefaultedListUtil {

    public static <E> NonNullList<E> of() {
        return NonNullList.func_191196_a();
    }

    public static <E> NonNullList<E> ofSize(int size, E defaultElement) {
        return NonNullList.func_191197_a(size, defaultElement);
    }

}
