package net.pitan76.mcpitanlib.api.block;

import net.minecraft.block.*;
import net.minecraft.item.BlockItemUseContext;
import net.minecraft.pathfinding.PathType;
import net.minecraft.state.BooleanProperty;
import net.minecraft.state.EnumProperty;
import net.minecraft.state.StateContainer;
import net.minecraft.state.properties.Half;
import net.minecraft.state.properties.StairsShape;
import net.pitan76.mcpitanlib.api.block.v2.CompatBlockProvider;
import net.pitan76.mcpitanlib.api.block.v2.CompatibleBlockSettings;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.shapes.ISelectionContext;
import net.minecraft.util.math.shapes.VoxelShape;
import net.minecraft.world.IBlockReader;
import net.pitan76.mcpitanlib.api.event.block.AppendPropertiesArgs;
import net.pitan76.mcpitanlib.api.event.block.CanPathfindThroughArgs;
import net.pitan76.mcpitanlib.api.event.block.OutlineShapeEvent;
import net.pitan76.mcpitanlib.api.event.block.PlacementStateArgs;
import net.pitan76.mcpitanlib.api.state.property.CompatProperties;
import net.pitan76.mcpitanlib.api.state.property.DirectionProperty;
import net.pitan76.mcpitanlib.core.serialization.CompatMapCodec;

public class CompatStairsBlock extends StairsBlock implements CompatBlockProvider {

    public static final DirectionProperty FACING = CompatProperties.HORIZONTAL_FACING;
    public static final EnumProperty<Half> HALF = StairsBlock.field_176308_b;
    public static final EnumProperty<StairsShape> SHAPE = StairsBlock.field_176310_M;
    public static final BooleanProperty WATERLOGGED = StairsBlock.field_204513_t;

    public CompatibleBlockSettings compatSettings;
    
    private final BlockState baseBlockState;

    /**
     * get compatible block settings
     * @return CompatibleBlockSettings
     */
    @Override
    public CompatibleBlockSettings getCompatSettings() {
        return compatSettings;
    }

    public CompatStairsBlock(BlockState baseBlockState, Properties settings) {
        super(baseBlockState, settings);
        this.baseBlockState = baseBlockState;
    }

    public CompatStairsBlock(BlockState baseBlockState, CompatibleBlockSettings settings) {
        this(baseBlockState, settings.build());
        this.compatSettings = settings;
    }

    public VoxelShape getOutlineShape(OutlineShapeEvent event) {
        return super.func_220053_a(event.state, event.world, event.pos, event.context);
    }

    public void appendProperties(AppendPropertiesArgs args) {
        super.func_206840_a(args.builder);
    }

    public BlockState getPlacementState(PlacementStateArgs args) {
        return super.func_196258_a(args.ctx);
    }

    @Deprecated
    @Override
    public void func_206840_a(StateContainer.Builder<Block, BlockState> builder) {
        appendProperties(new AppendPropertiesArgs(builder));
    }

    @Deprecated
    @Override
    public BlockState func_196258_a(BlockItemUseContext ctx) {
        return getPlacementState(new PlacementStateArgs(ctx));
    }

    @Deprecated
    @Override
    public VoxelShape func_220053_a(BlockState state, IBlockReader world, BlockPos pos, ISelectionContext context) {
        return getOutlineShape(new OutlineShapeEvent(state, world, pos, context));
    }

    // ExtendBlockProvider
    @Deprecated
    @Override
    public void appendProperties(AppendPropertiesArgs args, Options options) {
        CompatBlockProvider.super.appendProperties(args, options);
    }

    @Deprecated
    @Override
    public BlockState getPlacementState(PlacementStateArgs args, Options options) {
        return CompatBlockProvider.super.getPlacementState(args, options);
    }

    @Deprecated
    @Override
    public VoxelShape getOutlineShape(OutlineShapeEvent event, Options options) {
        return CompatBlockProvider.super.getOutlineShape(event, options);
    }

    public CompatMapCodec<? extends StairsBlock> getCompatCodec() {
        return CompatMapCodec.of();
    }

    @Deprecated
    @Override
    public boolean func_196266_a(BlockState state, IBlockReader world, BlockPos pos, PathType type) {
        return canPathfindThrough(new CanPathfindThroughArgs(state, world, pos, type));
    }

    @SuppressWarnings("removal")
    public boolean canPathfindThrough(CanPathfindThroughArgs args) {
        return super.func_196266_a(args.state, args.getBlockView(), args.getPos(), args.type);
    }

    @Override
    public Boolean canPathfindThrough(CanPathfindThroughArgs args, Options options) {
        return CompatBlockProvider.super.canPathfindThrough(args, options);
    }

    public BlockState getBaseBlockState() {
        return this.baseBlockState;
    }
}
