package net.pitan76.mcpitanlib.api.util.math;

import net.minecraft.util.math.vector.Vector3i;

public class Vec3iUtil {
    public static Vector3i create(int x, int y, int z) {
        return new Vector3i(x, y, z);
    }

    public static Vector3i add(Vector3i a, Vector3i b) {
        return new Vector3i(a.func_177958_n() + b.func_177958_n(), a.func_177956_o() + b.func_177956_o(), a.func_177952_p() + b.func_177952_p());
    }

    public static Vector3i subtract(Vector3i a, Vector3i b) {
        return new Vector3i(a.func_177958_n() - b.func_177958_n(), a.func_177956_o() - b.func_177956_o(), a.func_177952_p() - b.func_177952_p());
    }

    public static Vector3i multiply(Vector3i a, int b) {
        return new Vector3i(a.func_177958_n() * b, a.func_177956_o() * b, a.func_177952_p() * b);
    }

    public static Vector3i cross(Vector3i a, Vector3i b) {
        return a.func_177955_d(b);
    }

    public static Vector3i add(Vector3i a, int x, int y, int z) {
        return new Vector3i(a.func_177958_n() + x, a.func_177956_o() + y, a.func_177952_p() + z);
    }

    public static Vector3i subtract(Vector3i a, int x, int y, int z) {
        return new Vector3i(a.func_177958_n() - x, a.func_177956_o() - y, a.func_177952_p() - z);
    }
}
