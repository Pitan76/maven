package net.pitan76.mcpitanlib.api.util.client;

import net.minecraft.client.MainWindow;

public class WindowUtil {

    public static MainWindow getWindow() {
        return ClientUtil.getWindow();
    }

    public static int getWindowScaledWidth() {
        return getWindow().func_198107_o();
    }

    public static int getWindowScaledHeight() {
        return getWindow().func_198087_p();
    }

    public static int getWindowWidth() {
        return getWindow().func_198105_m();
    }

    public static int getWindowHeight() {
        return getWindow().func_198083_n();
    }

    public static int getWindowX() {
        return getWindow().func_198099_q();
    }

    public static int getWindowY() {
        return getWindow().func_198079_r();
    }

    public static void setTitle(String title) {
        getWindow().func_230148_b_(title);
    }

    public static void close() {
        getWindow().close();
    }
}
