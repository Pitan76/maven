package net.pitan76.mcpitanlib.api.item;

import net.minecraft.inventory.EquipmentSlotType;
import org.jetbrains.annotations.Nullable;

public class ArmorEquipmentType {
    // 1.19.4～ ArmorItem.Type

    public static ArmorEquipmentType HEAD = new ArmorEquipmentType(EquipmentSlotType.HEAD);
    public static ArmorEquipmentType CHEST = new ArmorEquipmentType(EquipmentSlotType.CHEST);
    public static ArmorEquipmentType LEGS = new ArmorEquipmentType(EquipmentSlotType.LEGS);
    public static ArmorEquipmentType FEET = new ArmorEquipmentType(EquipmentSlotType.FEET);

    // New type for animals from 1.20.5
    public static ArmorEquipmentType BODY = new ArmorEquipmentType(null);

    protected final EquipmentSlotType slot;

    protected ArmorEquipmentType(EquipmentSlotType slot) {
        this.slot = slot;
    }

    @Deprecated
    public EquipmentSlotType getSlot() {
        return slot;
    }

    @Nullable
    public static ArmorEquipmentType of(EquipmentSlotType slot) {
        switch (slot) {
            case HEAD:
                return HEAD;
            case CHEST:
                return CHEST;
            case LEGS:
                return LEGS;
            case FEET:
                return FEET;
            default:
                return null;
        }
    }
}
