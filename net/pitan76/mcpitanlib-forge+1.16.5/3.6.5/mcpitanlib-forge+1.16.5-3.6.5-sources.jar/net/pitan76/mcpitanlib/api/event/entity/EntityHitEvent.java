package net.pitan76.mcpitanlib.api.event.entity;

import net.minecraft.entity.Entity;
import net.minecraft.util.math.EntityRayTraceResult;
import net.minecraft.util.math.RayTraceResult;
import net.pitan76.mcpitanlib.midohra.entity.EntityWrapper;
import net.pitan76.mcpitanlib.midohra.util.hit.HitResultType;

public class EntityHitEvent {

    public EntityRayTraceResult entityHitResult;

    public EntityHitEvent(EntityRayTraceResult result) {
        this.entityHitResult = result;
    }

    public EntityRayTraceResult getEntityHitResult() {
        return entityHitResult;
    }

    public Entity getEntity() {
        return entityHitResult.func_216348_a();
    }

    public RayTraceResult.Type getType() {
        return entityHitResult.func_216346_c();
    }

    public EntityWrapper getEntityWrapper() {
        return EntityWrapper.of(getEntity());
    }

    public HitResultType getTypeM() {
        return HitResultType.from(getType());
    }
}
