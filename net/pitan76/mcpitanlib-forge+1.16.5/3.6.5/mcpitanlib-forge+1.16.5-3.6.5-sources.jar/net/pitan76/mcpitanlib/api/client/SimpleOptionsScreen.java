package net.pitan76.mcpitanlib.api.client;

import net.minecraft.client.GameSettings;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.util.text.ITextComponent;

public class SimpleOptionsScreen extends SimpleScreen {

    protected final Screen parent;
    protected final GameSettings gameOptions;

    public SimpleOptionsScreen(ITextComponent title, Screen parent, GameSettings gameOptions) {
        super(title);
        this.parent = parent;
        this.gameOptions = gameOptions;
    }

    @Override
    public void func_231164_f_() {
        field_230706_i_.field_71474_y.func_74303_b();
    }

    @Override
    public void func_231175_as__() {
        field_230706_i_.func_147108_a(parent);
    }
}
