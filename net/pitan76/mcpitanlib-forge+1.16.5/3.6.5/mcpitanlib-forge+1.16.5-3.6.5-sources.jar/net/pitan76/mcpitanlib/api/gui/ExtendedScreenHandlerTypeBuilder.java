package net.pitan76.mcpitanlib.api.gui;

import me.shedaniel.architectury.registry.MenuRegistry;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.inventory.container.Container;
import net.minecraft.inventory.container.ContainerType;
import net.minecraft.network.PacketBuffer;
import net.pitan76.mcpitanlib.api.gui.args.CreateMenuEvent;

public class ExtendedScreenHandlerTypeBuilder<T extends Container> {

    private final Factory<T> factory;

    public ExtendedScreenHandlerTypeBuilder(Factory<T> factory) {
        this.factory = factory;
    }

    public ExtendedScreenHandlerTypeBuilder(Factory2<T> factory) {
        this.factory = factory;
    }

    public ContainerType<T> build() {
        return MenuRegistry.ofExtended(factory::create);
    }

    @FunctionalInterface
    public interface Factory<T extends Container> {
        T create(int syncId, PlayerInventory inventory, PacketBuffer buf);
    }

    @FunctionalInterface
    public interface Factory2<T extends Container> extends Factory<T> {
        T create(CreateMenuEvent e, PacketBuffer buf);

        @Override
        default T create(int syncId, PlayerInventory inventory, PacketBuffer buf) {
            return create(new CreateMenuEvent(syncId, inventory), buf);
        }
    }
}
