package net.pitan76.mcpitanlib.api.registry;

import net.minecraft.nbt.CompoundNBT;
import net.pitan76.mcpitanlib.api.event.nbt.NbtRWArgs;
import net.pitan76.mcpitanlib.api.event.nbt.ReadNbtArgs;
import net.pitan76.mcpitanlib.api.event.nbt.WriteNbtArgs;

public class CompatRegistryLookup {

    public CompatRegistryLookup() {

    }

    public NbtRWArgs getNbtRWArgs(CompoundNBT nbt) {
        return new NbtRWArgs(nbt);
    }

    public WriteNbtArgs createWriteNbtArgs(CompoundNBT nbt) {
        return new WriteNbtArgs(nbt);
    }

    public ReadNbtArgs createReadNbtArgs(CompoundNBT nbt) {
        return new ReadNbtArgs(nbt);
    }
}
