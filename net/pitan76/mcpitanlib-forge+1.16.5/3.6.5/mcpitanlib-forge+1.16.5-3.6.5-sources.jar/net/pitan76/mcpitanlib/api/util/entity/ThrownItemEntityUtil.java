package net.pitan76.mcpitanlib.api.util.entity;

import net.minecraft.entity.Entity;
import net.minecraft.entity.projectile.ProjectileItemEntity;
import net.minecraft.item.ItemStack;
import net.pitan76.mcpitanlib.api.entity.CompatThrownItemEntity;

public class ThrownItemEntityUtil {
    public static ItemStack getItem(ProjectileItemEntity entity) {
        return entity.func_184543_l();
    }

    public static void setItem(ProjectileItemEntity entity, ItemStack stack) {
        entity.func_213884_b(stack);
    }

    public static ItemStack getStack(ProjectileItemEntity entity) {
        return entity.func_184543_l();
    }

    public static void setVelocity(ProjectileItemEntity entity, Entity shooter, float pitch, float yaw, float roll, float speed, float divergence) {
        ProjectileEntityUtil.setVelocity(entity, shooter, pitch, yaw, roll, speed, divergence);
    }

    public static void setVelocity(CompatThrownItemEntity entity, Entity shooter, float pitch, float yaw, float roll, float speed, float divergence) {
        ProjectileEntityUtil.setVelocity(entity, shooter, pitch, yaw, roll, speed, divergence);
    }

    public static void setVelocity(ProjectileItemEntity entity, double x, double y, double z, float power, float uncertainty) {
        ProjectileEntityUtil.setVelocity(entity, x, y, z, power, uncertainty);
    }

    public static void setVelocity(CompatThrownItemEntity entity, double x, double y, double z, float power, float uncertainty) {
        ProjectileEntityUtil.setVelocity(entity, x, y, z, power, uncertainty);
    }
}
