package net.pitan76.mcpitanlib.api.tag.v2;

import me.shedaniel.architectury.hooks.TagHooks;
import net.minecraft.tags.ITag;
import net.pitan76.mcpitanlib.api.tag.TagKey;
import net.pitan76.mcpitanlib.api.util.CompatIdentifier;

public class CompatTagKey<T> extends TagKey<T> {
    @Deprecated
    public CompatTagKey(ITag.INamedTag<T> tagKey) {
        super(tagKey);
    }

    @Deprecated
    public static <T> CompatTagKey<T> of(ITag.INamedTag<T> tagKey) {
        return new CompatTagKey<>(tagKey);
    }

    public static <T> CompatTagKey<T> of(CompatTagKeyType<T> type, CompatIdentifier identifier) {
        return of(TagHooks.getOptional(identifier.toMinecraft(), type::getTagGroup));
    }

    public boolean isOf(T value) {
        return getTagKey().func_230235_a_(value);
    }

    public CompatIdentifier getId() {
        return CompatIdentifier.fromMinecraft(getTagKey().func_230234_a_());
    }
}
