package net.pitan76.mcpitanlib.api.client.registry;

import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.SpriteRenderer;
import net.minecraft.entity.EntityType;

import java.util.function.Supplier;

public class EntityRendererRegistry {
    public static void registerEntityRendererAsFlyingItem(Supplier<EntityType<?>> entityType) {
        CompatRegistryClient.registerEntityRenderer(entityType, dispatcher -> (EntityRenderer) new SpriteRenderer<>(dispatcher, Minecraft.func_71410_x().func_175599_af()));
    }
}
