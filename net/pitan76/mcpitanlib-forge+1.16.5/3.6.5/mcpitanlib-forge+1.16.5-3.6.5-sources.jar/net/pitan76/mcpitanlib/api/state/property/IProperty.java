package net.pitan76.mcpitanlib.api.state.property;

import net.minecraft.block.BlockState;
import net.minecraft.state.Property;
import net.pitan76.mcpitanlib.api.event.block.AppendPropertiesArgs;

public interface IProperty<T extends Comparable<T>> {
    default void apply(AppendPropertiesArgs args) {
        args.addProperty(getProperty());
    }

    default T get(BlockState state) {
        return state.func_177229_b(getProperty());
    }

    default BlockState with(BlockState state, T value) {
        return state.func_206870_a(getProperty(), value);
    }

    default boolean contains(BlockState state) {
        return state.func_235901_b_(getProperty());
    }

    default BlockState cycle(BlockState state) {
        return state.func_235896_a_(getProperty());
    }

    default String getName() {
        return getProperty().func_177701_a();
    }

    Property<T> getProperty();

    default net.pitan76.mcpitanlib.midohra.block.BlockState with(net.pitan76.mcpitanlib.midohra.block.BlockState state, T value) {
        return state.with(getProperty(), value);
    }

    default T get(net.pitan76.mcpitanlib.midohra.block.BlockState state) {
        return state.get(getProperty());
    }

    default boolean contains(net.pitan76.mcpitanlib.midohra.block.BlockState state) {
        return state.contains(getProperty());
    }

    default net.pitan76.mcpitanlib.midohra.block.BlockState cycle(net.pitan76.mcpitanlib.midohra.block.BlockState state) {
        return state.cycle(getProperty());
    }
}
