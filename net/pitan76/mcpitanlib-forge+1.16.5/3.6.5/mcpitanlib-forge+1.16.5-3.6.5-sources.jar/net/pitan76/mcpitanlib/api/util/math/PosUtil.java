package net.pitan76.mcpitanlib.api.util.math;

import net.minecraft.dispenser.IPosition;
import net.minecraft.util.Direction;
import net.minecraft.util.math.*;
import net.minecraft.util.math.vector.Vector3d;
import net.minecraft.util.math.vector.Vector3i;

public class PosUtil {
    public static BlockPos flooredBlockPos(double x, double y, double z) {
        return new BlockPos(x, y, z);
    }

    public static BlockPos flooredBlockPos(IPosition pos) {
        return new BlockPos(pos);
    }

    public static BlockPos flooredBlockPos(Vector3d pos) {
        return new BlockPos(pos);
    }

    public static net.pitan76.mcpitanlib.midohra.util.math.BlockPos midohraBlockPos(int x, int y, int z) {
        return net.pitan76.mcpitanlib.midohra.util.math.BlockPos.of(x, y, z);
    }

    public static net.pitan76.mcpitanlib.midohra.util.math.BlockPos flooredMidohraBlockPos(double x, double y, double z) {
        int x1 = (int) Math.floor(x);
        int y1 = (int) Math.floor(y);
        int z1 = (int) Math.floor(z);
        return midohraBlockPos(x1, y1, z1);
    }

    public static double getSquaredDistance(BlockPos pos1, BlockPos pos2) {
        return pos1.func_177951_i(pos2);
    }

    public static double getSquaredDistance(BlockPos pos1, double x, double y, double z) {
        return getSquaredDistance(pos1, new BlockPos(x, y, z));
    }

    public static Iterable<BlockPos> iterate(BlockPos start, BlockPos end) {
        return BlockPos.func_218278_a(start, end);
    }

    public static BlockPos[] getNeighborPoses(BlockPos pos) {
        return new BlockPos[]{pos.func_177978_c(), pos.func_177968_d(), pos.func_177974_f(), pos.func_177976_e(), pos.func_177984_a(), pos.func_177977_b()};
    }

    public static BlockPos up(BlockPos pos) {
        return pos.func_177984_a();
    }

    public static BlockPos down(BlockPos pos) {
        return pos.func_177977_b();
    }

    public static BlockPos north(BlockPos pos) {
        return pos.func_177978_c();
    }

    public static BlockPos south(BlockPos pos) {
        return pos.func_177968_d();
    }

    public static BlockPos east(BlockPos pos) {
        return pos.func_177974_f();
    }

    public static BlockPos west(BlockPos pos) {
        return pos.func_177976_e();
    }

    public static BlockPos add(BlockPos pos, int x, int y, int z) {
        return pos.func_177982_a(x, y, z);
    }

    public static BlockPos sub(BlockPos pos, int x, int y, int z) {
        return pos.func_177973_b(new Vector3i(x, y, z));
    }

    public static BlockPos mul(BlockPos pos, int n) {
        return new BlockPos(pos.func_177958_n() * n, pos.func_177956_o() * n, pos.func_177952_p() * n);
    }

    public static int x(BlockPos pos) {
        return pos.func_177958_n();
    }

    public static int y(BlockPos pos) {
        return pos.func_177956_o();
    }

    public static int z(BlockPos pos) {
        return pos.func_177952_p();
    }

    public static BlockPos offset(BlockPos pos, Direction direction) {
        return pos.func_177972_a(direction);
    }

    public static BlockPos offset(BlockPos pos, Direction direction, int n) {
        return pos.func_177967_a(direction, n);
    }

    public static BlockPos offset(BlockPos pos, net.pitan76.mcpitanlib.midohra.util.math.Direction direction) {
        return pos.func_177972_a(direction.toMinecraft());
    }

    public static BlockPos offset(BlockPos pos, net.pitan76.mcpitanlib.midohra.util.math.Direction direction, int n) {
        return pos.func_177967_a(direction.toMinecraft(), n);
    }

    public static BlockPos toImmutable(BlockPos pos) {
        return pos.func_185334_h();
    }

    public static long asLong(BlockPos pos) {
        return pos.func_218275_a();
    }
}
