package net.pitan76.mcpitanlib.api.item;

import net.minecraft.item.Item;
import net.minecraft.item.Items;

public class CompatItems {
    public static Item SHORT_GRASS = Items.field_221674_ay;
    public static Item TALL_GRASS = Items.field_221916_fp;
    public static Item TURTLE_SCUTE = Items.field_203183_eM;

    // Compatibility
    public static Item GRASS = SHORT_GRASS;
    public static Item SCUTE = TURTLE_SCUTE;

    // ----

    public static Item AIR = Items.field_190931_a;
    public static Item STONE = Items.field_221574_b;
    public static Item COBBLESTONE = Items.field_221585_m;
    public static Item GRASS_BLOCK = Items.field_221581_i;
    public static Item DIRT = Items.field_221582_j;
    public static Item SAND = Items.field_221548_A;
    public static Item RED_SAND = Items.field_221549_B;
    public static Item GRANITE = Items.field_221575_c;
    public static Item POLISHED_GRANITE = Items.field_221576_d;
    public static Item DIORITE = Items.field_221577_e;
    public static Item POLISHED_DIORITE = Items.field_221578_f;
    public static Item ANDESITE = Items.field_221579_g;
    public static Item POLISHED_ANDESITE = Items.field_221580_h;
    public static Item COARSE_DIRT = Items.field_221583_k;
    public static Item PODZOL = Items.field_221584_l;
    public static Item OAK_LOG = Items.field_221554_G;
    public static Item SPRUCE_LOG = Items.field_221555_H;
    public static Item BIRCH_LOG = Items.field_221556_I;
    public static Item JUNGLE_LOG = Items.field_221557_J;
    public static Item ACACIA_LOG = Items.field_221558_K;
    public static Item DARK_OAK_LOG = Items.field_221559_L;
    public static Item OAK_PLANKS = Items.field_221586_n;
    public static Item SPRUCE_PLANKS = Items.field_221587_o;
    public static Item BIRCH_PLANKS = Items.field_221588_p;
    public static Item JUNGLE_PLANKS = Items.field_221589_q;
    public static Item ACACIA_PLANKS = Items.field_221590_r;
    public static Item DARK_OAK_PLANKS = Items.field_221591_s;
    public static Item GLASS = Items.field_221650_am;

    public static Item STICK = Items.field_151055_y;
    public static Item GLASS_BOTTLE = Items.field_151069_bo;
    public static Item EXP_BOTTLE = Items.field_151062_by;

    public static Item GUNPOWDER = Items.field_151016_H;
    public static Item REDSTONE = Items.field_151137_ax;
    public static Item COAL = Items.field_151044_h;
    public static Item CHARCOAL = Items.field_196155_l;
    public static Item IRON_INGOT = Items.field_151042_j;
    public static Item COPPER_INGOT = Items.field_190931_a;
    public static Item GOLD_INGOT = Items.field_151043_k;
    public static Item DIAMOND = Items.field_151045_i;
    public static Item EMERALD = Items.field_151166_bC;
    public static Item LAPIS_LAZULI = Items.field_196128_bn;
    public static Item NETHERITE_INGOT = Items.field_234759_km_;
    public static Item NETHERITE_SCRAP = Items.field_234760_kn_;
    public static Item QUARTZ = Items.field_151128_bU;

    // ----

    public static boolean isExist(Item item) {
        return item != null && item != Items.field_190931_a;
    }
}
