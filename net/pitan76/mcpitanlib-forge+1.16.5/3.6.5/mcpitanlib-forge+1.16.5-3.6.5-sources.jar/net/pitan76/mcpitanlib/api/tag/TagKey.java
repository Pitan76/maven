package net.pitan76.mcpitanlib.api.tag;

import me.shedaniel.architectury.hooks.TagHooks;
import net.minecraft.tags.ITag;
import net.minecraft.util.ResourceLocation;
import net.pitan76.mcpitanlib.api.util.*;

public class TagKey<T> {
    private final ITag.INamedTag<T> tagKey;

    @Deprecated
    public TagKey(ITag.INamedTag<T> tagKey) {
        this.tagKey = tagKey;
    }

    public static TagKey<?> create(Type type, ResourceLocation identifier) {
        switch (type) {
            case BLOCK:
                return new TagKey<>(TagHooks.getBlockOptional(identifier));
            case ITEM:
                return new TagKey<>(TagHooks.getItemOptional(identifier));
            case FLUID:
                return new TagKey<>(TagHooks.getFluidOptional(identifier));
            case ENTITY_TYPE:
                return new TagKey<>(TagHooks.getEntityTypeOptional(identifier));
            default:
                throw new IllegalArgumentException();
        }
    }

    public static TagKey<?> create(Type type, CompatIdentifier id) {
        return create(type, id.toMinecraft());
    }

    @Deprecated
    public ITag.INamedTag<T> getTagKey() {
        return tagKey;
    }

    public enum Type {
        BLOCK,
        ITEM,
        FLUID,
        ENTITY_TYPE;
    }

    public boolean isOf(T value) {
        return tagKey.func_230235_a_(value);
    }
}
