package net.pitan76.mcpitanlib.api.util.screen;

import net.minecraft.inventory.IInventory;
import net.minecraft.inventory.container.Container;
import net.minecraft.inventory.container.Slot;
import net.minecraft.item.ItemStack;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.math.MathHelper;
import org.jetbrains.annotations.Nullable;

import java.util.Set;

public class ScreenHandlerUtil {
    public static int calcComparatorOutput(@Nullable IInventory inventory) {
        return Container.func_94526_b(inventory);
    }

    public static int calcComparatorOutput(@Nullable TileEntity blockEntity) {
        return Container.func_178144_a(blockEntity);
    }

    public static int calculateStackSize(Set<Slot> slots, int mode, ItemStack stack) {
        int stackSize;

        switch (mode) {
            case 0:
                stackSize = MathHelper.func_76141_d((float)stack.func_190916_E() / (float)slots.size());
                break;
            case 1:
                stackSize = 1;
                break;
            case 2:
                stackSize = stack.func_77976_d();
                break;
            default:
                stackSize = stack.func_190916_E();
        }

        return stackSize;
    }

    public static boolean canInsertItemIntoSlot(@Nullable Slot slot, ItemStack stack, boolean allowOverflow) {
        return Container.func_94527_a(slot, stack, allowOverflow);
    }
}
