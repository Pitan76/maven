package net.pitan76.mcpitanlib.api.util.client.render;

import net.minecraft.client.renderer.model.ItemCameraTransforms;
import net.pitan76.mcpitanlib.api.util.CompatStringIdentifiable;

public class CompatItemDisplayContext implements CompatStringIdentifiable {
    private final ItemCameraTransforms.TransformType context;

    public static final CompatItemDisplayContext NONE = of(ItemCameraTransforms.TransformType.NONE);
    public static final CompatItemDisplayContext THIRD_PERSON_LEFT_HAND = of(ItemCameraTransforms.TransformType.THIRD_PERSON_LEFT_HAND);
    public static final CompatItemDisplayContext THIRD_PERSON_RIGHT_HAND = of(ItemCameraTransforms.TransformType.THIRD_PERSON_RIGHT_HAND);
    public static final CompatItemDisplayContext FIRST_PERSON_LEFT_HAND = of(ItemCameraTransforms.TransformType.FIRST_PERSON_LEFT_HAND);
    public static final CompatItemDisplayContext FIRST_PERSON_RIGHT_HAND = of(ItemCameraTransforms.TransformType.FIRST_PERSON_RIGHT_HAND);
    public static final CompatItemDisplayContext HEAD = of(ItemCameraTransforms.TransformType.HEAD);
    public static final CompatItemDisplayContext GUI = of(ItemCameraTransforms.TransformType.GUI);
    public static final CompatItemDisplayContext GROUND = of(ItemCameraTransforms.TransformType.GROUND);
    public static final CompatItemDisplayContext FIXED = of(ItemCameraTransforms.TransformType.FIXED);

    public CompatItemDisplayContext(ItemCameraTransforms.TransformType context) {
        this.context = context;
    }

    public static CompatItemDisplayContext of(ItemCameraTransforms.TransformType context) {
        return new CompatItemDisplayContext(context);
    }

    public ItemCameraTransforms.TransformType getContext() {
        return context;
    }

    public String getName() {
        return context.name();
    }

    @Override
    public String asString_compat() {
        return getName();
    }
}
