package net.pitan76.mcpitanlib.api.gui.v2;

import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.inventory.container.Container;
import net.pitan76.mcpitanlib.api.gui.args.CreateMenuEvent;

@SuppressWarnings("deprecation")
public interface ExtendedScreenHandlerFactory extends net.pitan76.mcpitanlib.api.gui.ExtendedScreenHandlerFactory {

    @Override
    default Container createMenu(int syncId, PlayerInventory playerInventory, PlayerEntity player) {
        return createMenu(new CreateMenuEvent(syncId, playerInventory, player));
    }

    Container createMenu(CreateMenuEvent event);
}
