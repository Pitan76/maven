package net.pitan76.mcpitanlib.api.util.client;

import net.minecraft.client.resources.I18n;
import net.minecraft.client.resources.LanguageManager;
import net.pitan76.mcpitanlib.midohra.resource.ResourceManager;

public class LanguageUtil {
    public static boolean hasTranslation(String key) {
        return I18n.func_188566_a(key);
    }

    public static String translate(String key) {
        return I18n.func_135052_a(key);
    }

    public static String translate(String key, Object... args) {
        return I18n.func_135052_a(key, args);
    }

    public static String translateWithFallback(String key, String fallback) {
        return I18n.func_188566_a(key) ? I18n.func_135052_a(key) : fallback;
    }

    public static String translateWithFallback(String key, String fallback, Object... args) {
        return I18n.func_188566_a(key) ? I18n.func_135052_a(key, args) : fallback;
    }

    public static LanguageManager getLanguageManager() {
        return ClientUtil.getClient().func_135016_M();
    }

    public static String getLanguage() {
        return getLanguageManager().func_135041_c().getCode();
    }

    public static void setLanguage(String language) {
        getLanguageManager().func_135045_a(getLanguageManager().func_191960_a(language));
    }

    public static void reload(net.minecraft.resources.IResourceManager resourceManager) {
        getLanguageManager().func_195410_a(resourceManager);
    }

    public static void reload(ResourceManager resourceManager) {
        reload(resourceManager.getRaw());
    }
}
