package net.pitan76.mcpitanlib.api.util;

import net.minecraft.nbt.CompoundNBT;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.World;
import net.minecraft.world.server.ServerWorld;
import net.minecraft.world.storage.DimensionSavedDataManager;
import net.minecraft.world.storage.WorldSavedData;
import java.util.function.Function;
import java.util.function.Supplier;

public class PersistentStateUtil {
    public static <T extends WorldSavedData> T getOrCreate(DimensionSavedDataManager manager, String id, Supplier<T> supplier, Function<CompoundNBT, T> function) {
        return manager.func_215752_a(supplier, id);
    }

    public static DimensionSavedDataManager getManagerFromServer(MinecraftServer server) {
        return server.func_71218_a(World.field_234918_g_).func_217481_x();
    }

    public static DimensionSavedDataManager getManagerFromWorld(ServerWorld world) {
        return world.func_217481_x();
    }

    public static void markDirty(WorldSavedData state) {
        state.func_76185_a();
    }
}