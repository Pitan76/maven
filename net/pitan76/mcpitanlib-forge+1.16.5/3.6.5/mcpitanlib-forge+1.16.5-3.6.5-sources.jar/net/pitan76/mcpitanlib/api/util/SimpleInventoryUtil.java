package net.pitan76.mcpitanlib.api.util;

import net.minecraft.inventory.Inventory;
import net.minecraft.item.ItemStack;
import net.minecraft.util.NonNullList;

public class SimpleInventoryUtil {
    public static NonNullList<ItemStack> getHeldStacks(Inventory inventory) {
        NonNullList<ItemStack> stacks = NonNullList.func_191197_a(inventory.func_70302_i_(), ItemStack.field_190927_a);
        for (int i = 0; i < inventory.func_70302_i_(); i++) {
            stacks.add(i, inventory.func_70301_a(i));
        }
        return stacks;
    }

    public static Inventory create(int size) {
        return InventoryUtil.createSimpleInventory(size);
    }

    public static ItemStack getStack(Inventory inventory, int slot) {
        return inventory.func_70301_a(slot);
    }

    public static void setStack(Inventory inventory, int slot, ItemStack stack) {
        inventory.func_70299_a(slot, stack);
    }

    public static void clear(Inventory inventory) {
        inventory.func_174888_l();
    }

    public static int size(Inventory inventory) {
        return inventory.func_70302_i_();
    }

    public static boolean isEmpty(Inventory inventory) {
        return inventory.func_191420_l();
    }
}
