package net.pitan76.mcpitanlib.api.tile;

import net.minecraft.block.BlockState;
import net.minecraft.nbt.CompoundNBT;
import net.minecraft.network.play.server.SUpdateTileEntityPacket;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.tileentity.TileEntityType;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraft.world.server.ServerWorld;
import net.pitan76.mcpitanlib.api.event.block.TileCreateEvent;
import net.pitan76.mcpitanlib.api.event.nbt.ReadNbtArgs;
import net.pitan76.mcpitanlib.api.event.nbt.WriteNbtArgs;
import net.pitan76.mcpitanlib.api.packet.UpdatePacketType;
import net.pitan76.mcpitanlib.api.registry.CompatRegistryLookup;
import net.pitan76.mcpitanlib.api.util.BlockEntityUtil;
import net.pitan76.mcpitanlib.api.util.WorldUtil;
import org.jetbrains.annotations.Nullable;

public class CompatBlockEntity extends TileEntity {
    public CompatBlockEntity(TileEntityType<?> type) {
        super(type);
    }

    public CompatBlockEntity(TileEntityType<?> type, TileCreateEvent event) {
        this(type);
    }

    @Override
    @Deprecated
    public SUpdateTileEntityPacket func_189518_D_() {
        switch (getUpdatePacketType().name) {
            case "BLOCK_ENTITY_UPDATE_S2C":
                CompoundNBT nbt = new CompoundNBT();
                writeNbtOverride(nbt);
                return new SUpdateTileEntityPacket(func_174877_v(), 1, nbt);
        }
        return super.func_189518_D_();
    }

    public UpdatePacketType getUpdatePacketType() {
        return UpdatePacketType.NONE;
    }

    public void writeNbt(WriteNbtArgs args) {

    }

    public void readNbt(ReadNbtArgs args) {

    }

    public CompoundNBT toInitialChunkDataNbt(CompatRegistryLookup registryLookup) {
        return super.func_189517_E_();
    }

    @Deprecated
    @Override
    public CompoundNBT func_189517_E_() {
        return toInitialChunkDataNbt(new CompatRegistryLookup());
    }

    // deprecated

    /**
     * @deprecated Use {@link #writeNbt(WriteNbtArgs)} instead
     */
    @Deprecated
    public void writeNbtOverride(CompoundNBT nbt) {
        super.func_189515_b(nbt);
    }

    /**
     * @deprecated Use {@link #readNbt(ReadNbtArgs)} instead
     */
    @Deprecated
    public void readNbtOverride(CompoundNBT nbt) {
        super.func_230337_a_(func_195044_w(), nbt);
    }

    // ----

    @Deprecated
    @Override
    public CompoundNBT func_189515_b(CompoundNBT nbt) {
        // deprecated
        writeNbtOverride(nbt);
        // ----

        writeNbt(new WriteNbtArgs(nbt));
        return nbt;
    }

    @Deprecated
    @Override
    public void func_230337_a_(BlockState state, CompoundNBT nbt) {
        // deprecated
        readNbtOverride(nbt);
        // ----

        readNbt(new ReadNbtArgs(nbt));
    }

    public boolean isClient() {
        if (func_145831_w() == null)
            return false;

        return WorldUtil.isClient(func_145831_w());
    }

    @Deprecated
    @Override
    public @Nullable World func_145831_w() {
        return callGetWorld();
    }

    @Deprecated
    @Override
    public BlockPos func_174877_v() {
        return callGetPos();
    }

    public World callGetWorld() {
        return super.func_145831_w();
    }

    public BlockPos callGetPos() {
        return super.func_174877_v();
    }

    public BlockState callGetBlockState() {
        return BlockEntityUtil.getBlockState(this);
    }

    public BlockState callGetCachedState() {
        return BlockEntityUtil.getCachedState(this);
    }

    public boolean hasServerWorld() {
        return callGetWorld() instanceof ServerWorld;
    }

    public ServerWorld getServerWorld() {
        return BlockEntityUtil.getServerWorld(this);
    }

    public void callMarkDirty() {
        BlockEntityUtil.markDirty(this);
    }

    @Deprecated
    @Override
    public void func_145843_s() {
        markRemovedOverride();
    }

    public void markRemovedOverride() {
        super.func_145843_s();
    }

    public net.pitan76.mcpitanlib.midohra.world.World getMidohraWorld() {
        return net.pitan76.mcpitanlib.midohra.world.World.of(callGetWorld());
    }

    public net.pitan76.mcpitanlib.midohra.util.math.BlockPos getMidohraPos() {
        return net.pitan76.mcpitanlib.midohra.util.math.BlockPos.of(callGetPos());
    }

    public net.pitan76.mcpitanlib.midohra.block.BlockState getMidohraBlockState() {
        return net.pitan76.mcpitanlib.midohra.block.BlockState.of(callGetBlockState());
    }

    public net.pitan76.mcpitanlib.midohra.block.BlockState getMidohraCachedState() {
        return net.pitan76.mcpitanlib.midohra.block.BlockState.of(callGetCachedState());
    }
}
