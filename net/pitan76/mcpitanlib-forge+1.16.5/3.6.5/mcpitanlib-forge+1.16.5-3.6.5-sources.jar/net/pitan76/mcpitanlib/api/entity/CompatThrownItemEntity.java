package net.pitan76.mcpitanlib.api.entity;

import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.projectile.ProjectileItemEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.CompoundNBT;
import net.minecraft.util.math.EntityRayTraceResult;
import net.minecraft.util.math.RayTraceResult;
import net.minecraft.world.World;
import net.pitan76.mcpitanlib.api.event.entity.CollisionEvent;
import net.pitan76.mcpitanlib.api.event.entity.EntityHitEvent;
import net.pitan76.mcpitanlib.api.event.entity.InitDataTrackerArgs;
import net.pitan76.mcpitanlib.api.event.nbt.ReadNbtArgs;
import net.pitan76.mcpitanlib.api.event.nbt.WriteNbtArgs;
import net.pitan76.mcpitanlib.midohra.entity.IEntityM;

public abstract class CompatThrownItemEntity extends ProjectileItemEntity implements IEntityM {

    public CompatThrownItemEntity(EntityType<? extends ProjectileItemEntity> entityType, World world) {
        super(entityType, world);
    }

    public CompatThrownItemEntity(EntityType<? extends ProjectileItemEntity> entityType, double d, double e, double f, World world) {
        super(entityType, d, e, f, world);
    }

    public CompatThrownItemEntity(EntityType<? extends ProjectileItemEntity> entityType, LivingEntity livingEntity, World world) {
        super(entityType, livingEntity, world);
    }

    public abstract Item getDefaultItemOverride();

    @Deprecated
    @Override
    protected Item func_213885_i() {
        return getDefaultItemOverride();
    }

    public ItemStack callGetItem() {
        return super.func_184543_l();
    }

    @Deprecated
    @Override
    public ItemStack func_184543_l() {
        return callGetItem();
    }

    public void callSetItem(ItemStack stack) {
        super.func_213884_b(stack);
    }

    @Deprecated
    @Override
    public void func_213884_b(ItemStack stack) {
        callSetItem(stack);
    }

    public void callHandleStatus(byte status) {
        super.func_70103_a(status);
    }

    @Deprecated
    @Override
    public void func_70103_a(byte status) {
        callHandleStatus(status);
    }

    public void onEntityHit(EntityHitEvent event) {
        super.func_213868_a(event.entityHitResult);
    }

    @Deprecated
    @Override
    protected void func_213868_a(EntityRayTraceResult entityHitResult) {
        onEntityHit(new EntityHitEvent(entityHitResult));
    }

    public void onCollision(CollisionEvent event) {
        super.func_70227_a(event.hitResult);
    }

    @Deprecated
    @Override
    protected void func_70227_a(RayTraceResult hitResult) {
        onCollision(new CollisionEvent(hitResult));
    }

    // ------------------ ExtendEntity ------------------

    @Deprecated
    @Override
    public void func_70088_a() {
        initDataTracker(new InitDataTrackerArgs(field_70180_af));
    }

    public void initDataTracker(InitDataTrackerArgs args) {
        super.func_70088_a();
    }

    public void readCustomDataFromNbt(ReadNbtArgs nbt) {
        super.func_70037_a(nbt.getNbt());
    }

    public void writeCustomDataToNbt(WriteNbtArgs nbt) {
        super.func_213281_b(nbt.getNbt());
    }

    @Deprecated
    @Override
    public void func_70037_a(CompoundNBT nbt) {
        readCustomDataFromNbt(new ReadNbtArgs(nbt));
    }

    @Deprecated
    @Override
    public void func_213281_b(CompoundNBT nbt) {
        writeCustomDataToNbt(new WriteNbtArgs(nbt));
    }

    public void writeNbt(WriteNbtArgs args) {
        super.func_189511_e(args.getNbt());
    }

    public void readNbt(ReadNbtArgs args) {
        super.func_70020_e(args.getNbt());
    }

    @Deprecated
    @Override
    public CompoundNBT func_189511_e(CompoundNBT nbt) {
        writeNbt(new WriteNbtArgs(nbt));
        return nbt;
    }

    @Deprecated
    @Override
    public void func_70020_e(CompoundNBT nbt) {
        readNbt(new ReadNbtArgs(nbt));
    }

    public World getWorld() {
        return field_70170_p;
    }

    public void setStack(net.pitan76.mcpitanlib.midohra.item.ItemStack stack) {
        callSetItem(stack.toMinecraft());
    }

    public net.pitan76.mcpitanlib.midohra.item.ItemStack getStackM() {
        return net.pitan76.mcpitanlib.midohra.item.ItemStack.of(callGetItem());
    }
}
