package net.pitan76.mcpitanlib.api.item.tool;

import net.minecraft.item.IItemTier;
import net.minecraft.item.Item;
import net.minecraft.item.crafting.Ingredient;
import net.minecraft.tags.ItemTags;
import net.pitan76.mcpitanlib.api.tag.TagKey;

public interface CompatibleToolMaterial {

    int getCompatMiningLevel();

    float getCompatAttackDamage();

    float getCompatMiningSpeedMultiplier();

    default Ingredient getCompatRepairIngredient() {
        return Ingredient.func_199805_a(getRepairTag().getTagKey());
    }

    int getCompatDurability();

    int getCompatEnchantability();

    @Deprecated
    default float getAttackDamage() {
        return getCompatAttackDamage();
    }

    @Deprecated
    default float getMiningSpeedMultiplier() {
        return getCompatMiningSpeedMultiplier();
    }

    @Deprecated
    default Ingredient getRepairIngredient() {
        return getCompatRepairIngredient();
    }

    @Deprecated
    default int getDurability() {
        return getCompatDurability();
    }

    @Deprecated
    default int getEnchantability() {
        return getCompatEnchantability();
    }

    default TagKey<Item> getRepairTag() {
        return (TagKey<Item>) TagKey.create(TagKey.Type.ITEM, ItemTags.field_232909_aa_.func_230234_a_());
    }

    default IItemTier build() {
        return new IItemTier() {
            @Override
            public int func_200926_a() {
                return getCompatDurability();
            }

            @Override
            public float func_200928_b() {
                return getCompatMiningSpeedMultiplier();
            }

            @Override
            public float func_200929_c() {
                return getCompatAttackDamage();
            }

            @Override
            public int func_200925_d() {
                return getCompatMiningLevel();
            }

            @Override
            public int func_200927_e() {
                return getCompatEnchantability();
            }

            @Override
            public Ingredient func_200924_f() {
                return getCompatRepairIngredient();
            }
        };
    }
}