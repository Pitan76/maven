package net.pitan76.mcpitanlib.api.gui.inventory;

import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.inventory.ItemStackHelper;
import net.minecraft.item.ItemStack;
import net.minecraft.util.NonNullList;

public interface IInventory extends net.minecraft.inventory.IInventory {

    NonNullList<ItemStack> getItems();

    static IInventory of(NonNullList<ItemStack> items) {
        return () -> items;
    }

    static IInventory ofSize(int size) {
        return of(NonNullList.func_191197_a(size, ItemStack.field_190927_a));
    }

    @Override
    default int func_70302_i_() {
        return getItems().size();
    }

    @Override
    default boolean func_191420_l() {
        for (int i = 0; i < func_70302_i_(); i++) {
            ItemStack stack = func_70301_a(i);
            if (!stack.func_190926_b()) {
                return false;
            }
        }
        return true;
    }

    @Override
    default ItemStack func_70301_a(int slot) {
        return getItems().get(slot);
    }

    @Override
    default ItemStack func_70298_a(int slot, int count) {
        ItemStack result = ItemStackHelper.func_188382_a(getItems(), slot, count);
        if (!result.func_190926_b()) {
            func_70296_d();
        }
        return result;
    }

    @Override
    default ItemStack func_70304_b(int slot) {
        return ItemStackHelper.func_188383_a(getItems(), slot);
    }

    @Override
    default void func_70299_a(int slot, ItemStack stack) {
        getItems().set(slot, stack);
        if (stack.func_190916_E() > func_70297_j_()) {
            stack.func_190920_e(func_70297_j_());
        }
    }

    @Override
    default void func_174888_l() {
        getItems().clear();
    }

    @Override
    default void func_70296_d() {
    }

    @Override
    default boolean func_70300_a(PlayerEntity player) {
        return true;
    }
}