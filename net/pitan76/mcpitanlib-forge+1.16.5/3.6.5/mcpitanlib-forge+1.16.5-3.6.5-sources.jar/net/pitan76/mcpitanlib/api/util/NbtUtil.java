package net.pitan76.mcpitanlib.api.util;

import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.*;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.vector.Vector3d;
import net.minecraft.util.math.vector.Vector3i;
import net.pitan76.mcpitanlib.api.registry.CompatRegistryLookup;
import net.pitan76.mcpitanlib.api.util.math.PosUtil;
import net.pitan76.mcpitanlib.api.util.math.Vec3dUtil;
import net.pitan76.mcpitanlib.api.util.math.Vec3iUtil;

import java.util.Optional;
import java.util.Set;
import java.util.UUID;

public class NbtUtil {

    /**
     * 新しいNbtCompoundを作成する。
     * @return NbtCompound
     */
    public static CompoundNBT create() {
        return new CompoundNBT();
    }

    /**
     * 値を設定する。
     * @param nbt NbtCompound
     * @param key キー
     * @param value 値
     */
    public static void put(CompoundNBT nbt, String key, CompoundNBT value) {
        nbt.func_218657_a(key, value);
    }

    /**
     * 値を設定する。
     * @param nbt NbtCompound
     * @param key キー
     * @param value 値
     */
    public static void put(CompoundNBT nbt, String key, INBT value) {
        nbt.func_218657_a(key, value);
    }

    /**
     * 値を取得する。
     * @param nbt NbtCompound
     * @param key キー
     * @return 値
     */
    public static CompoundNBT get(CompoundNBT nbt, String key) {
        return nbt.func_74775_l(key);
    }

    /**
     * 値を削除する。
     * @param nbt NbtCompound
     * @param key キー
     */
    public static void remove(CompoundNBT nbt, String key) {
        nbt.func_82580_o(key);
    }

    /**
     * 値が存在するかどうかを取得する。
     * @param nbt NbtCompound
     * @param key キー
     * @return 値が存在するかどうか
     */
    public static boolean has(CompoundNBT nbt, String key) {
        return nbt.func_74764_b(key);
    }

    /**
     * 指定した型の値を取得する
     * @param nbt NbtCompound
     * @param key キー
     * @param clazz クラス
     * @param <T> 値
     */
    public static <T> T get(CompoundNBT nbt, String key, Class<T> clazz) {
        if (clazz == Integer.class) {
            return (T) Integer.valueOf(nbt.func_74762_e(key));
        }
        if (clazz == String.class) {
            return (T) nbt.func_74779_i(key);
        }
        if (clazz == Boolean.class) {
            return (T) Boolean.valueOf(nbt.func_74767_n(key));
        }
        if (clazz == Float.class) {
            return (T) Float.valueOf(nbt.func_74760_g(key));
        }
        if (clazz == Double.class) {
            return (T) Double.valueOf(nbt.func_74769_h(key));
        }
        if (clazz == Long.class) {
            return (T) Long.valueOf(nbt.func_74763_f(key));
        }
        if (clazz == CompoundNBT.class) {
            return (T) nbt.func_74775_l(key);
        }
        if (clazz == ListNBT.class) {
            return (T) nbt.func_74781_a(key);
        }
        if (clazz == Byte.class) {
            return (T) Byte.valueOf(nbt.func_74771_c(key));
        }
        if (clazz == Short.class) {
            return (T) Short.valueOf(nbt.func_74765_d(key));
        }
        if (clazz == UUID.class) {
            return (T) nbt.func_186857_a(key);
        }
        return null;
    }

    /**
     * 値を設定する。
     * @param nbt NbtCompound
     * @param key キー
     * @param value 値
     */
    public static <T> void set(CompoundNBT nbt, String key, T value) {
        if (value instanceof Integer) {
            nbt.func_74768_a(key, (Integer) value);
            return;
        }
        if (value instanceof String) {
            nbt.func_74778_a(key, (String) value);
            return;
        }
        if (value instanceof Boolean) {
            nbt.func_74757_a(key, (Boolean) value);
            return;
        }
        if (value instanceof Float) {
            nbt.func_74776_a(key, (Float) value);
            return;
        }
        if (value instanceof Double) {
            nbt.func_74780_a(key, (Double) value);
            return;
        }
        if (value instanceof Long) {
            nbt.func_74772_a(key, (Long) value);
            return;
        }
        if (value instanceof CompoundNBT) {
            nbt.func_218657_a(key, (CompoundNBT) value);
            return;
        }
        if (value instanceof ListNBT) {
            nbt.func_218657_a(key, (ListNBT) value);
            return;
        }
        if (value instanceof Byte) {
            nbt.func_74774_a(key, (Byte) value);
            return;
        }
        if (value instanceof Short) {
            nbt.func_74777_a(key, (Short) value);
            return;
        }
        if (value instanceof UUID) {
            nbt.func_186854_a(key, (UUID) value);
            return;
        }
    }

    /**
     * キーの一覧を取得する。
     * @param nbt NbtCompound
     * @return キーの一覧
     */
    public static Set<String> getKeys(CompoundNBT nbt) {
        return nbt.func_150296_c();
    }

    /**
     * NbtListを取得する。
     * @return NbtList
     */
    public static ListNBT getList(CompoundNBT nbt, String key) {
        return (ListNBT) nbt.func_74781_a(key);
    }

    /**
     * NbtListを取得する。
     * @return NbtList
     */
    public static ListNBT getList(CompoundNBT nbt, String key, int type) {
        return nbt.func_150295_c(key, type);
    }

    /**
     * NbtCompoundのリストを取得する。
     * @return NbtList
     */
    public static ListNBT getNbtCompoundList(CompoundNBT nbt, String key) {
        return nbt.func_150295_c(key, 10);
    }

    /**
     * NbtCompoundをコピーする。
     * @return NbtCompound
     */
    public static CompoundNBT copy(CompoundNBT nbt) {
        return nbt.func_74737_b();
    }

    // Helper methods

    public static void putInt(CompoundNBT nbt, String key, int value) {
        set(nbt, key, value);
    }

    public static int getInt(CompoundNBT nbt, String key) {
        if (has(nbt, key))
            return get(nbt, key, Integer.class);
        return 0;
    }

    public static void putString(CompoundNBT nbt, String key, String value) {
        set(nbt, key, value);
    }

    public static String getString(CompoundNBT nbt, String key) {
        if (has(nbt, key))
            return get(nbt, key, String.class);
        return "";
    }

    public static void putBoolean(CompoundNBT nbt, String key, boolean value) {
        set(nbt, key, value);
    }

    public static boolean getBoolean(CompoundNBT nbt, String key) {
        if (has(nbt, key))
            return get(nbt, key, Boolean.class);
        return false;
    }

    public static void putFloat(CompoundNBT nbt, String key, float value) {
        set(nbt, key, value);
    }

    public static float getFloat(CompoundNBT nbt, String key) {
        if (has(nbt, key))
            return get(nbt, key, Float.class);
        return 0;
    }

    public static void putDouble(CompoundNBT nbt, String key, double value) {
        set(nbt, key, value);
    }

    public static double getDouble(CompoundNBT nbt, String key) {
        if (has(nbt, key))
            return get(nbt, key, Double.class);
        return 0;
    }

    public static void putLong(CompoundNBT nbt, String key, long value) {
        set(nbt, key, value);
    }

    public static long getLong(CompoundNBT nbt, String key) {
        if (has(nbt, key))
            return get(nbt, key, Long.class);
        return 0;
    }

    public static void putByte(CompoundNBT nbt, String key, byte value) {
        set(nbt, key, value);
    }

    public static byte getByte(CompoundNBT nbt, String key) {
        if (has(nbt, key))
            return get(nbt, key, Byte.class);
        return 0;
    }

    public static void putShort(CompoundNBT nbt, String key, short value) {
        set(nbt, key, value);
    }

    public static short getShort(CompoundNBT nbt, String key) {
        if (has(nbt, key))
            return get(nbt, key, Short.class);
        return 0;
    }

    public static void putUuid(CompoundNBT nbt, String key, UUID value) {
        set(nbt, key, value);
    }

    public static UUID getUuid(CompoundNBT nbt, String key) {
        if (has(nbt, key))
            return get(nbt, key, UUID.class);
        return null;
    }

    /**
     * BlockPosを設定する。
     * key: {
     *   "x": pos.getX(),
     *   "y": pos.getY(),
     *   "z": pos.getZ()
     * }
     *
     * @param nbt NbtCompound
     * @param key キー
     * @param pos BlockPos
     */
    public static void setBlockPos(CompoundNBT nbt, String key, BlockPos pos) {
        CompoundNBT posNbt = create();
        putInt(posNbt, "x", pos.func_177958_n());
        putInt(posNbt, "y", pos.func_177956_o());
        putInt(posNbt, "z", pos.func_177952_p());
        put(nbt, key, posNbt);
    }

    /**
     * BlockPosを取得する。
     *
     * @param nbt NbtCompound
     * @param key キー
     * @return BlockPos
     */
    public static BlockPos getBlockPos(CompoundNBT nbt, String key) {
        CompoundNBT posNbt = get(nbt, key);
        return PosUtil.flooredBlockPos(getInt(posNbt, "x"), getInt(posNbt, "y"), getInt(posNbt, "z"));
    }

    public static void putVec3i(CompoundNBT nbt, String key, Vector3i vec3i) {
        CompoundNBT vec3iNbt = create();
        putInt(vec3iNbt, "x", vec3i.func_177958_n());
        putInt(vec3iNbt, "y", vec3i.func_177956_o());
        putInt(vec3iNbt, "z", vec3i.func_177952_p());
        put(nbt, key, vec3iNbt);
    }

    public static Vector3i getVec3i(CompoundNBT nbt, String key) {
        CompoundNBT vec3iNbt = get(nbt, key);
        return Vec3iUtil.create(getInt(vec3iNbt, "x"), getInt(vec3iNbt, "y"), getInt(vec3iNbt, "z"));
    }

    public static void putVec3d(CompoundNBT nbt, String key, Vector3d vec3d) {
        CompoundNBT vec3dNbt = create();
        putDouble(vec3dNbt, "x", vec3d.func_82615_a());
        putDouble(vec3dNbt, "y", vec3d.func_82617_b());
        putDouble(vec3dNbt, "z", vec3d.func_82616_c());
        put(nbt, key, vec3dNbt);
    }

    public static Vector3d getVec3d(CompoundNBT nbt, String key) {
        CompoundNBT vec3dNbt = get(nbt, key);
        return Vec3dUtil.create(getDouble(vec3dNbt, "x"), getDouble(vec3dNbt, "y"), getDouble(vec3dNbt, "z"));
    }

    public static void putItemStack(CompoundNBT nbt, String key, ItemStack stack, CompatRegistryLookup registryLookup) {
        CompoundNBT stackNbt = create();
        stack.func_77955_b(stackNbt);
        put(nbt, key, stackNbt);
    }

    public static Optional<ItemStack> getItemStack(CompoundNBT nbt, String key, CompatRegistryLookup registryLookup) {
        CompoundNBT stackNbt = get(nbt, key);
        return Optional.ofNullable(ItemStack.func_199557_a(stackNbt));
    }

    public static void putSimpleItemStack(CompoundNBT nbt, String key, ItemStack stack) {
        CompoundNBT stackNbt = create();
        putString(stackNbt, "id", ItemUtil.toID(stack.func_77973_b()).toString());
        putByte(stackNbt, "Count", (byte) ItemStackUtil.getCount(stack));

        CompoundNBT tagNbt = create();
        CompoundNBT componentsNbt = create();
        put(componentsNbt, "minecraft:custom_data", CustomDataUtil.getOrCreateNbt(stack));
        put(tagNbt, "components", componentsNbt);
        put(stackNbt, "tag", tagNbt);
        put(nbt, key, stackNbt);
    }

    public static Optional<ItemStack> getSimpleItemStack(CompoundNBT nbt, String key) {
        if (!has(nbt, key)) return Optional.empty();
        CompoundNBT stackNbt = get(nbt, key);

        if (!has(stackNbt, "id") || !has(stackNbt, "Count")) return Optional.empty();
        Item item = ItemUtil.fromId(CompatIdentifier.of(getString(stackNbt, "id")));
        int count = getByte(stackNbt, "Count");

        ItemStack stack = ItemStackUtil.create(item, count);

        if (has(stackNbt, "tag")) {
            CompoundNBT tagNbt = get(stackNbt, "tag");
            if (has(tagNbt, "components")) {
                CompoundNBT componentsNbt = get(tagNbt, "components");
                if (has(componentsNbt, "minecraft:custom_data")) {
                    CustomDataUtil.setNbt(stack, get(componentsNbt, "minecraft:custom_data"));
                }
            }
        }

        return Optional.of(stack);
    }

    public static ListNBT createNbtList() {
        return new ListNBT();
    }

    public static int getIntOrDefault(CompoundNBT nbt, String key, int defaultValue) {
        if (has(nbt, key))
            return getInt(nbt, key);
        return defaultValue;
    }

    public static String getStringOrDefault(CompoundNBT nbt, String key, String defaultValue) {
        if (has(nbt, key))
            return getString(nbt, key);
        return defaultValue;
    }

    public static boolean getBooleanOrDefault(CompoundNBT nbt, String key, boolean defaultValue) {
        if (has(nbt, key))
            return getBoolean(nbt, key);
        return defaultValue;
    }

    public static float getFloatOrDefault(CompoundNBT nbt, String key, float defaultValue) {
        if (has(nbt, key))
            return getFloat(nbt, key);
        return defaultValue;
    }

    public static double getDoubleOrDefault(CompoundNBT nbt, String key, double defaultValue) {
        if (has(nbt, key))
            return getDouble(nbt, key);
        return defaultValue;
    }

    public static long getLongOrDefault(CompoundNBT nbt, String key, long defaultValue) {
        if (has(nbt, key))
            return getLong(nbt, key);
        return defaultValue;
    }

    public static byte getByteOrDefault(CompoundNBT nbt, String key, byte defaultValue) {
        if (has(nbt, key))
            return getByte(nbt, key);
        return defaultValue;
    }

    public static short getShortOrDefault(CompoundNBT nbt, String key, short defaultValue) {
        if (has(nbt, key))
            return getShort(nbt, key);
        return defaultValue;
    }

    public static UUID getUuidOrDefault(CompoundNBT nbt, String key, UUID defaultValue) {
        if (has(nbt, key))
            return getUuid(nbt, key);
        return defaultValue;
    }

    public static INBT getElement(CompoundNBT nbt, String key) {
        return nbt.func_74781_a(key);
    }

    public static void putElement(CompoundNBT nbt, String key, INBT element) {
        nbt.func_218657_a(key, element);
    }

    public static void setBlockPosDirect(CompoundNBT nbt, BlockPos pos) {
        putInt(nbt, "x", pos.func_177958_n());
        putInt(nbt, "y", pos.func_177956_o());
        putInt(nbt, "z", pos.func_177952_p());
    }

    public static BlockPos getBlockPosDirect(CompoundNBT nbt) {
        return PosUtil.flooredBlockPos(getInt(nbt, "x"), getInt(nbt, "y"), getInt(nbt, "z"));
    }

    public static void setVec3iDirect(CompoundNBT nbt, Vector3i vec3i) {
        putInt(nbt, "x", vec3i.func_177958_n());
        putInt(nbt, "y", vec3i.func_177956_o());
        putInt(nbt, "z", vec3i.func_177952_p());
    }

    public static Vector3i getVec3iDirect(CompoundNBT nbt) {
        return Vec3iUtil.create(getInt(nbt, "x"), getInt(nbt, "y"), getInt(nbt, "z"));
    }

    public static void setVec3dDirect(CompoundNBT nbt, Vector3d vec3d) {
        putDouble(nbt, "x", vec3d.func_82615_a());
        putDouble(nbt, "y", vec3d.func_82617_b());
        putDouble(nbt, "z", vec3d.func_82616_c());
    }

    public static Vector3d getVec3dDirect(CompoundNBT nbt) {
        return Vec3dUtil.create(getDouble(nbt, "x"), getDouble(nbt, "y"), getDouble(nbt, "z"));
    }

    public static void setVec3iDirect(CompoundNBT nbt, int x, int y, int z) {
        putInt(nbt, "x", x);
        putInt(nbt, "y", y);
        putInt(nbt, "z", z);
    }

    public static void setVec3dDirect(CompoundNBT nbt, double x, double y, double z) {
        putDouble(nbt, "x", x);
        putDouble(nbt, "y", y);
        putDouble(nbt, "z", z);
    }

    public static String asString(INBT nbt) {
        return nbt.func_150285_a_();
    }

    public static StringNBT createString(String string) {
        return StringNBT.func_229705_a_(string);
    }

    public static IntNBT createInt(int value) {
        return IntNBT.func_229692_a_(value);
    }

    public static FloatNBT createFloat(float value) {
        return FloatNBT.func_229689_a_(value);
    }

    public static DoubleNBT createDouble(double value) {
        return DoubleNBT.func_229684_a_(value);
    }

    public static LongNBT createLong(long value) {
        return LongNBT.func_229698_a_(value);
    }

    public static ByteNBT createByte(byte value) {
        return ByteNBT.func_229671_a_(value);
    }

    public static ShortNBT createShort(short value) {
        return ShortNBT.func_229701_a_(value);
    }

    public static void copyFrom(CompoundNBT target, CompoundNBT source) {
        target.func_197643_a(source);
    }
}
