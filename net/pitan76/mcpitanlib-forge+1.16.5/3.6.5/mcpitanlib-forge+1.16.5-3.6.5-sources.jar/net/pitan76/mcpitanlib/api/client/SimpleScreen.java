package net.pitan76.mcpitanlib.api.client;

import com.mojang.blaze3d.matrix.MatrixStack;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.gui.IGuiEventListener;
import net.minecraft.client.gui.IRenderable;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.Widget;
import net.minecraft.client.renderer.ItemRenderer;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.text.ITextComponent;
import net.pitan76.mcpitanlib.api.client.gui.widget.CompatibleTexturedButtonWidget;
import net.pitan76.mcpitanlib.api.client.render.DrawObjectDM;
import net.pitan76.mcpitanlib.api.util.client.RenderUtil;
import net.pitan76.mcpitanlib.api.util.client.ScreenUtil;
import net.pitan76.mcpitanlib.api.client.render.handledscreen.KeyEventArgs;
import net.pitan76.mcpitanlib.api.client.render.handledscreen.RenderArgs;
import net.pitan76.mcpitanlib.api.client.render.screen.RenderBackgroundTextureArgs;
import net.pitan76.mcpitanlib.api.util.CompatIdentifier;
import net.pitan76.mcpitanlib.api.util.IdentifierUtil;
import net.pitan76.mcpitanlib.api.util.client.RenderUtil;

public abstract class SimpleScreen extends Screen {

    public int field_230708_k_, field_230709_l_;
    public FontRenderer field_230712_o_;
    public ItemRenderer field_230707_j_;

    public ITextComponent field_230704_d_;
    public Minecraft field_230706_i_;

    public SimpleScreen(ITextComponent title) {
        super(title);
        fixScreen();
        this.field_230704_d_ = title;
    }

    public <T extends IGuiEventListener & IRenderable> T addDrawableChild_compatibility(T drawableElement) {
        if (drawableElement instanceof Widget)
            return (T) super.func_230480_a_((Widget) drawableElement);
        else
            return super.func_230481_d_(drawableElement);
    }

    public <T extends IGuiEventListener> T addSelectableChild_compatibility(T selectableElement) {
        if (selectableElement instanceof Widget)
            return (T) super.func_230480_a_((Widget) selectableElement);
        else
            return super.func_230481_d_(selectableElement);
    }

    public CompatibleTexturedButtonWidget addDrawableCTBW(CompatibleTexturedButtonWidget widget) {
        return addDrawableChild_compatibility(widget);
    }

    public void callDrawTexture(DrawObjectDM drawObjectDM, ResourceLocation texture, int x, int y, int u, int v, int width, int height) {
        ScreenUtil.setBackground(texture);
        func_238474_b_(drawObjectDM.getStack(), x, y, u, v, width, height);
    }

    public void callDrawTexture(DrawObjectDM drawObjectDM, CompatIdentifier texture, int x, int y, int u, int v, int width, int height) {
        callDrawTexture(drawObjectDM, texture.toMinecraft(), x, y, u, v, width, height);
    }

    @Deprecated
    @Override
    public void func_230446_a_(MatrixStack matrices) {
        renderBackground(new RenderArgs(new DrawObjectDM(matrices, this), 0, 0, 0));
    }

    public void renderBackground(RenderArgs args) {
        super.func_230446_a_(args.drawObjectDM.getStack());
    }

    public void render(RenderArgs args) {
        super.func_230430_a_(args.drawObjectDM.getStack(), args.mouseX, args.mouseY, args.delta);
    }

    public void resizeOverride(Minecraft client, int width, int height) {
    }

    public void initOverride() {
    }

    @Deprecated
    @Override
    protected void func_231160_c_() {
        super.func_231160_c_();
        fixScreen();
        initOverride();
    }

    @Deprecated
    @Override
    public void func_231152_a_(Minecraft client, int width, int height) {
        super.func_231152_a_(client, width, height);
        fixScreen();
        resizeOverride(client, width, height);
    }

    public void fixScreen() {
        this.field_230712_o_ = super.field_230712_o_;
        this.field_230707_j_ = Minecraft.func_71410_x().func_175599_af();
        this.field_230708_k_ = super.field_230708_k_;
        this.field_230709_l_ = super.field_230709_l_;
        if (super.field_230706_i_ == null)
            this.field_230706_i_ = Minecraft.func_71410_x();
        else
            this.field_230706_i_ = super.field_230706_i_;
    }

    public void setTextRenderer(FontRenderer textRenderer) {
        this.field_230712_o_ = textRenderer;
        super.field_230712_o_ = textRenderer;
    }

    public void setItemRenderer(ItemRenderer itemRenderer) {
        this.field_230707_j_ = itemRenderer;
    }

    public void setWidth(int width) {
        this.field_230708_k_ = width;
        super.field_230708_k_ = width;
    }

    public void setHeight(int height) {
        this.field_230709_l_ = height;
        super.field_230709_l_ = height;
    }

    @Deprecated
    @Override
    public void func_230430_a_(MatrixStack stack, int mouseX, int mouseY, float delta) {
        DrawObjectDM drawObjectDM = new DrawObjectDM(stack, this);
        render(new RenderArgs(drawObjectDM, mouseX, mouseY, delta));
    }

    public boolean keyReleased(KeyEventArgs args) {
        return super.func_223281_a_(args.keyCode, args.scanCode, args.modifiers);
    }

    public boolean keyPressed(KeyEventArgs args) {
        return super.func_231046_a_(args.keyCode, args.scanCode, args.modifiers);
    }

    public void renderBackgroundTexture(RenderBackgroundTextureArgs args) {
        if (getBackgroundTexture() == null) {
            super.func_231165_f_(args.getvOffset());
            return;
        }

        RenderUtil.setShaderToPositionTexProgram();
        RenderUtil.setShaderTexture(0, getBackgroundTexture());
        RenderUtil.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);

        callDrawTexture(args.drawObjectDM, getBackgroundTexture(), 0, 0, 0, 0, this.field_230708_k_, this.field_230709_l_);
    }

    @Deprecated
    @Override
    public boolean func_223281_a_(int keyCode, int scanCode, int modifiers) {
        return this.keyReleased(new KeyEventArgs(keyCode, scanCode, modifiers));
    }

    @Deprecated
    @Override
    public boolean func_231046_a_(int keyCode, int scanCode, int modifiers) {
        return this.keyPressed(new KeyEventArgs(keyCode, scanCode, modifiers));
    }

    @Deprecated
    @Override
    public void func_231165_f_(int vOffset) {
        this.renderBackgroundTexture(new RenderBackgroundTextureArgs(new DrawObjectDM(null, this), vOffset));
    }

    public void closeOverride() {
        super.func_231175_as__();
    }

    public void removedOverride() {
        super.func_231164_f_();
    }

    @Override
    public void func_231175_as__() {
        closeOverride();
    }

    @Override
    public void func_231164_f_() {
        removedOverride();
    }

    public ResourceLocation getBackgroundTexture() {
        return IdentifierUtil.from(getCompatBackgroundTexture());
    }

    public CompatIdentifier getCompatBackgroundTexture() {
        return null;
    }
}
