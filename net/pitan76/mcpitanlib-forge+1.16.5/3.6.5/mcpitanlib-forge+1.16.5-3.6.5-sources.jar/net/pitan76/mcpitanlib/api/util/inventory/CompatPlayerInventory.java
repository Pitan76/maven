package net.pitan76.mcpitanlib.api.util.inventory;

import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.ItemStack;
import net.pitan76.mcpitanlib.api.entity.Player;

public class CompatPlayerInventory implements ICompatInventory {
    public PlayerInventory inv;

    public CompatPlayerInventory(PlayerInventory inv) {
        this.inv = inv;
    }

    public Player getPlayer() {
        return PlayerInventoryUtil.getPlayer(inv);
    }

    public int getSelectedSlot() {
        return PlayerInventoryUtil.getSelectedSlot(inv);
    }

    public void setSelectedSlot(int slot) {
        PlayerInventoryUtil.setSelectedSlot(inv, slot);
    }

    public void dropAllItems() {
        PlayerInventoryUtil.dropAllItems(inv);
    }

    public void offerOrDrop(ItemStack stack) {
        inv.func_191975_a(inv.field_70458_d.field_70170_p, stack);
    }

    public void offerOrDrop(net.pitan76.mcpitanlib.midohra.item.ItemStack stack) {
        offerOrDrop(stack.toMinecraft());
    }

    public PlayerInventory getRaw() {
        return inv;
    }

    @Override
    public int func_70302_i_() {
        return inv.func_70302_i_();
    }

    @Override
    public boolean func_191420_l() {
        return inv.func_191420_l();
    }

    @Override
    public ItemStack func_70301_a(int slot) {
        return inv.func_70301_a(slot);
    }

    @Override
    public ItemStack func_70298_a(int slot, int count) {
        return inv.func_70298_a(slot, count);
    }

    @Override
    public ItemStack func_70304_b(int slot) {
        return inv.func_70304_b(slot);
    }

    @Override
    public void func_70299_a(int slot, ItemStack itemStack) {
        inv.func_70299_a(slot, itemStack);
    }

    @Override
    public void func_70296_d() {
        inv.func_70296_d();
    }

    @Override
    public boolean func_70300_a(PlayerEntity player) {
        return inv.func_70300_a(player);
    }

    @Override
    public void func_174888_l() {
        inv.func_174888_l();
    }
}

