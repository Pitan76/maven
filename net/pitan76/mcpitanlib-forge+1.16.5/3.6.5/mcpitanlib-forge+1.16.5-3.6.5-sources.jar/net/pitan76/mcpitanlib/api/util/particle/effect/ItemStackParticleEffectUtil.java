package net.pitan76.mcpitanlib.api.util.particle.effect;

import net.minecraft.item.ItemStack;
import net.minecraft.particles.ItemParticleData;
import net.minecraft.particles.ParticleType;
import net.minecraft.particles.ParticleTypes;

// Use: ParticleEffectUtil
public class ItemStackParticleEffectUtil {

    public ItemStackParticleEffectUtil() {
        // Empty constructor
    }

    public ItemParticleData create(ParticleType<ItemParticleData> type, ItemStack stack) {
        return new ItemParticleData(type, stack);
    }

    public ItemParticleData createTypedItem(ItemStack stack) {
        return new ItemParticleData(ParticleTypes.field_197591_B, stack);
    }
}
