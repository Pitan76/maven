package net.pitan76.mcpitanlib.api.entity.effect;

import net.minecraft.potion.Effect;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.registry.Registry;
import net.minecraft.world.World;
import net.pitan76.mcpitanlib.api.util.StatusEffectUtil;
import org.jetbrains.annotations.Nullable;

public class CompatStatusEffect {
    private final Effect statusEffect;

    @Deprecated
    public CompatStatusEffect(Effect statusEffect) {
        this.statusEffect = statusEffect;
    }

    public CompatStatusEffect of(ResourceLocation identifier) {
        return StatusEffectUtil.getStatusEffect(identifier);
    }

    public ResourceLocation getId() {
        return Registry.field_212631_t.func_177774_c(statusEffect);
    }

    public String toString() {
        return getId().toString();
    }

    public boolean equals(Object obj) {
        if (obj instanceof CompatStatusEffect) {
            return ((CompatStatusEffect) obj).getId().equals(getId());
        }
        return false;
    }

    public Effect getStatusEffect(@Nullable World world) {
        return statusEffect;
    }
}
