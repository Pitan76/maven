package net.pitan76.mcpitanlib.api.util;

import net.minecraft.util.ResourceLocation;

public class IdentifierUtil {
    public static ResourceLocation id(String id) {
        return new ResourceLocation(id);
    }

    public static ResourceLocation id(String namespace, String path) {
        return new ResourceLocation(namespace, path);
    }

    public static String toString(ResourceLocation identifier) {
        return identifier.toString();
    }

    public static String getNamespace(ResourceLocation identifier) {
        return identifier.func_110624_b();
    }

    public static String getPath(ResourceLocation identifier) {
        return identifier.func_110623_a();
    }

    public static ResourceLocation from(CompatIdentifier id) {
        if (id == null)
            return null;

        return id.toMinecraft();
    }
}
