package net.pitan76.mcpitanlib.api.client.event.listener;

import net.minecraft.client.util.ITooltipFlag;
import net.minecraft.item.ItemStack;
import net.minecraft.util.text.ITextComponent;
import net.pitan76.mcpitanlib.api.text.TextComponent;
import net.pitan76.mcpitanlib.api.util.TextUtil;

import java.util.List;

public class ItemTooltipContext {

    public ItemStack stack;
    public List<ITextComponent> texts;
    public ITooltipFlag tooltipContext;

    public ItemTooltipContext(ItemStack stack, List<ITextComponent> texts, ITooltipFlag tooltipContext) {
        this.stack = stack;
        this.texts = texts;
        this.tooltipContext = tooltipContext;
    }

    public ItemStack getStack() {
        return stack;
    }

    public List<ITextComponent> getTexts() {
        return texts;
    }

    public ITooltipFlag getTooltipContext() {
        return tooltipContext;
    }

    public void addTooltip(ITextComponent text) {
        texts.add(text);
    }

    public void addTooltip(List<ITextComponent> texts) {
        this.texts.addAll(texts);
    }

    public boolean isAdvanced() {
        return tooltipContext.func_194127_a();
    }

    public boolean isCreative() {
        return !tooltipContext.func_194127_a();
    }

    public void addTooltip(TextComponent textComponent) {
        addTooltip(textComponent.getText());
    }

    public void addTooltip(String text) {
        addTooltip(TextUtil.literal(text));
    }
}
