package net.pitan76.mcpitanlib.api.block;

import net.minecraft.block.material.Material;
import net.minecraft.block.material.MaterialColor;
import net.minecraft.block.material.PushReaction;

public final class CompatibleMaterial {
    public static final CompatibleMaterial AIR;
    public static final CompatibleMaterial STRUCTURE_VOID;
    public static final CompatibleMaterial PORTAL;
    public static final CompatibleMaterial CARPET;
    public static final CompatibleMaterial PLANT;
    public static final CompatibleMaterial UNDERWATER_PLANT;
    public static final CompatibleMaterial REPLACEABLE_PLANT;
    public static final CompatibleMaterial NETHER_SHOOTS;
    public static final CompatibleMaterial REPLACEABLE_UNDERWATER_PLANT;
    public static final CompatibleMaterial WATER;
    public static final CompatibleMaterial BUBBLE_COLUMN;
    public static final CompatibleMaterial LAVA;
    public static final CompatibleMaterial SNOW_LAYER;
    public static final CompatibleMaterial FIRE;
    public static final CompatibleMaterial DECORATION;
    public static final CompatibleMaterial COBWEB;
    public static final CompatibleMaterial SCULK;
    public static final CompatibleMaterial REDSTONE_LAMP;
    public static final CompatibleMaterial ORGANIC_PRODUCT;
    public static final CompatibleMaterial SOIL;
    public static final CompatibleMaterial SOLID_ORGANIC;
    public static final CompatibleMaterial DENSE_ICE;
    public static final CompatibleMaterial AGGREGATE;
    public static final CompatibleMaterial SPONGE;
    public static final CompatibleMaterial SHULKER_BOX;
    public static final CompatibleMaterial WOOD;
    public static final CompatibleMaterial NETHER_WOOD;
    public static final CompatibleMaterial BAMBOO_SAPLING;
    public static final CompatibleMaterial BAMBOO;
    public static final CompatibleMaterial WOOL;
    public static final CompatibleMaterial TNT;
    public static final CompatibleMaterial LEAVES;
    public static final CompatibleMaterial GLASS;
    public static final CompatibleMaterial ICE;
    public static final CompatibleMaterial CACTUS;
    public static final CompatibleMaterial STONE;
    public static final CompatibleMaterial METAL;
    public static final CompatibleMaterial SNOW_BLOCK;
    public static final CompatibleMaterial REPAIR_STATION;
    public static final CompatibleMaterial BARRIER;
    public static final CompatibleMaterial PISTON;
    public static final CompatibleMaterial MOSS_BLOCK;
    public static final CompatibleMaterial GOURD;
    public static final CompatibleMaterial EGG;
    public static final CompatibleMaterial CAKE;
    public static final CompatibleMaterial AMETHYST;
    public static final CompatibleMaterial POWDER_SNOW;
    private final MaterialColor color;
    private final PushReaction pistonBehavior;
    private final boolean burnable;
    private final boolean liquid;
    private final boolean replaceable;
    private final boolean solid;
    private Material material;

    public CompatibleMaterial(MaterialColor color, boolean liquid, boolean solid, boolean burnable, boolean replaceable, PushReaction pistonBehavior) {
        this.color = color;
        this.liquid = liquid;
        this.solid = solid;
        this.burnable = burnable;
        this.replaceable = replaceable;
        this.pistonBehavior = pistonBehavior;
        this.material = Material.field_151576_e;
    }

    private CompatibleMaterial(Material material, MaterialColor color, boolean liquid, boolean solid, boolean burnable, boolean replaceable, PushReaction pistonBehavior) {
        this(material.func_151565_r(), material.func_76224_d(), material.func_76220_a(), material.func_76217_h(), material.func_76222_j(), material.func_186274_m());
        this.material = material;
    }

    @Deprecated
    public Material getMaterial() {
        return material;
    }

    public boolean isLiquid() {
        return this.liquid;
    }

    public boolean isSolid() {
        return this.solid;
    }

    public boolean isBurnable() {
        return this.burnable;
    }

    public boolean isReplaceable() {
        return this.replaceable;
    }

    public PushReaction getPistonBehavior() {
        return this.pistonBehavior;
    }

    public MaterialColor getColor() {
        return this.color;
    }

    static {
        AIR = (new Builder(MaterialColor.field_151660_b)).allowsMovement().lightPassesThrough().notSolid().replaceable().material(Material.field_151579_a).build();
        STRUCTURE_VOID = (new Builder(MaterialColor.field_151660_b)).allowsMovement().lightPassesThrough().notSolid().replaceable().material(Material.field_189963_J).build();
        PORTAL = (new Builder(MaterialColor.field_151660_b)).allowsMovement().lightPassesThrough().notSolid().blocksPistons().material(Material.field_151567_E).build();
        CARPET = (new Builder(MaterialColor.field_151659_e)).allowsMovement().lightPassesThrough().notSolid().burnable().material(Material.field_151593_r).build();
        PLANT = (new Builder(MaterialColor.field_151669_i)).allowsMovement().lightPassesThrough().notSolid().destroyedByPiston().material(Material.field_151585_k).build();
        UNDERWATER_PLANT = (new Builder(MaterialColor.field_151662_n)).allowsMovement().lightPassesThrough().notSolid().destroyedByPiston().material(Material.field_203243_f).build();
        REPLACEABLE_PLANT = (new Builder(MaterialColor.field_151669_i)).allowsMovement().lightPassesThrough().notSolid().destroyedByPiston().replaceable().burnable().material(Material.field_151582_l).build();
        NETHER_SHOOTS = (new Builder(MaterialColor.field_151669_i)).allowsMovement().lightPassesThrough().notSolid().destroyedByPiston().replaceable().material(Material.field_242934_h).build();
        REPLACEABLE_UNDERWATER_PLANT = (new Builder(MaterialColor.field_151662_n)).allowsMovement().lightPassesThrough().notSolid().destroyedByPiston().replaceable().material(Material.field_204868_h).build();
        WATER = (new Builder(MaterialColor.field_151662_n)).allowsMovement().lightPassesThrough().notSolid().destroyedByPiston().replaceable().liquid().material(Material.field_151586_h).build();
        BUBBLE_COLUMN = (new Builder(MaterialColor.field_151662_n)).allowsMovement().lightPassesThrough().notSolid().destroyedByPiston().replaceable().liquid().material(Material.field_203244_i).build();
        LAVA = (new Builder(MaterialColor.field_151656_f)).allowsMovement().lightPassesThrough().notSolid().destroyedByPiston().replaceable().liquid().material(Material.field_151587_i).build();
        SNOW_LAYER = (new Builder(MaterialColor.field_151666_j)).allowsMovement().lightPassesThrough().notSolid().destroyedByPiston().replaceable().material(Material.field_151597_y).build();
        FIRE = (new Builder(MaterialColor.field_151660_b)).allowsMovement().lightPassesThrough().notSolid().destroyedByPiston().replaceable().material(Material.field_151581_o).build();
        DECORATION = (new Builder(MaterialColor.field_151660_b)).allowsMovement().lightPassesThrough().notSolid().destroyedByPiston().material(Material.field_151594_q).build();
        COBWEB = (new Builder(MaterialColor.field_151659_e)).allowsMovement().lightPassesThrough().destroyedByPiston().material(Material.field_151569_G).build();
        SCULK = (new Builder(MaterialColor.field_151646_E)).build();
        REDSTONE_LAMP = (new Builder(MaterialColor.field_151660_b)).material(Material.field_151591_t).build();
        ORGANIC_PRODUCT = (new Builder(MaterialColor.field_151667_k)).material(Material.field_151571_B).build();
        SOIL = (new Builder(MaterialColor.field_151664_l)).material(Material.field_151578_c).build();
        SOLID_ORGANIC = (new Builder(MaterialColor.field_151661_c)).material(Material.field_151577_b).build();
        DENSE_ICE = (new Builder(MaterialColor.field_151657_g)).material(Material.field_151598_x).build();
        AGGREGATE = (new Builder(MaterialColor.field_151658_d)).material(Material.field_151595_p).build();
        SPONGE = (new Builder(MaterialColor.field_151673_t)).material(Material.field_151583_m).build();
        SHULKER_BOX = (new Builder(MaterialColor.field_151678_z)).material(Material.field_215711_w).build();
        WOOD = (new Builder(MaterialColor.field_151663_o)).burnable().material(Material.field_151575_d).build();
        NETHER_WOOD = (new Builder(MaterialColor.field_151663_o)).material(Material.field_237214_y_).build();
        BAMBOO_SAPLING = (new Builder(MaterialColor.field_151663_o)).burnable().destroyedByPiston().allowsMovement().material(Material.field_215712_y).build();
        BAMBOO = (new Builder(MaterialColor.field_151663_o)).burnable().destroyedByPiston().material(Material.field_215713_z).build();
        WOOL = (new Builder(MaterialColor.field_151659_e)).burnable().material(Material.field_151580_n).build();
        TNT = (new Builder(MaterialColor.field_151656_f)).burnable().lightPassesThrough().material(Material.field_151590_u).build();
        LEAVES = (new Builder(MaterialColor.field_151669_i)).burnable().lightPassesThrough().destroyedByPiston().material(Material.field_151584_j).build();
        GLASS = (new Builder(MaterialColor.field_151660_b)).lightPassesThrough().material(Material.field_151592_s).build();
        ICE = (new Builder(MaterialColor.field_151657_g)).lightPassesThrough().material(Material.field_151588_w).build();
        CACTUS = (new Builder(MaterialColor.field_151669_i)).lightPassesThrough().destroyedByPiston().material(Material.field_151570_A).build();
        STONE = (new Builder(MaterialColor.field_151665_m)).material(Material.field_151576_e).build();
        METAL = (new Builder(MaterialColor.field_151668_h)).material(Material.field_151573_f).build();
        SNOW_BLOCK = (new Builder(MaterialColor.field_151666_j)).material(Material.field_151596_z).build();
        REPAIR_STATION = (new Builder(MaterialColor.field_151668_h)).blocksPistons().material(Material.field_151574_g).build();
        BARRIER = (new Builder(MaterialColor.field_151660_b)).blocksPistons().material(Material.field_175972_I).build();
        PISTON = (new Builder(MaterialColor.field_151665_m)).blocksPistons().material(Material.field_76233_E).build();
        MOSS_BLOCK = (new Builder(MaterialColor.field_151669_i)).destroyedByPiston().material(Material.field_151589_v).build();
        GOURD = (new Builder(MaterialColor.field_151669_i)).destroyedByPiston().material(Material.field_151572_C).build();
        EGG = (new Builder(MaterialColor.field_151669_i)).destroyedByPiston().material(Material.field_151566_D).build();
        CAKE = (new Builder(MaterialColor.field_151660_b)).destroyedByPiston().material(Material.field_151568_F).build();
        AMETHYST = (new Builder(MaterialColor.field_151678_z)).build();
        POWDER_SNOW = (new Builder(MaterialColor.field_151666_j)).notSolid().allowsMovement().build();
    }

    public static class Builder {
        private PushReaction pistonBehavior;
        private boolean blocksMovement;
        private boolean burnable;
        private boolean liquid;
        private boolean replaceable;
        private boolean solid;
        private final MaterialColor color;
        private boolean blocksLight;
        private Material material = Material.field_151576_e;

        public Builder(MaterialColor color) {
            this.pistonBehavior = PushReaction.NORMAL;
            this.blocksMovement = true;
            this.solid = true;
            this.blocksLight = true;
            this.color = color;
        }

        public Builder liquid() {
            this.liquid = true;
            return this;
        }

        public Builder notSolid() {
            this.solid = false;
            return this;
        }

        public Builder allowsMovement() {
            this.blocksMovement = false;
            return this;
        }

        Builder lightPassesThrough() {
            this.blocksLight = false;
            return this;
        }

        protected Builder burnable() {
            this.burnable = true;
            return this;
        }

        public Builder replaceable() {
            this.replaceable = true;
            return this;
        }

        protected Builder destroyedByPiston() {
            this.pistonBehavior = PushReaction.DESTROY;
            return this;
        }

        protected Builder blocksPistons() {
            this.pistonBehavior = PushReaction.BLOCK;
            return this;
        }

        protected Builder material(Material material) {
            this.material = material;
            return this;
        }

        public CompatibleMaterial build() {
            return new CompatibleMaterial(material, this.color, this.liquid, this.solid, this.burnable, this.replaceable, this.pistonBehavior);
        }
    }
}
