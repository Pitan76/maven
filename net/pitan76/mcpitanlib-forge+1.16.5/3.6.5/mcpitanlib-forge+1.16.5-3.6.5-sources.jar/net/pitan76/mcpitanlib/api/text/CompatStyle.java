package net.pitan76.mcpitanlib.api.text;

import net.minecraft.util.text.Color;
import net.minecraft.util.text.Style;

public class CompatStyle {
    private final Style style;

    public CompatStyle(Style style) {
        this.style = style;
    }

    public CompatStyle() {
        this(Style.field_240709_b_);
    }

    public static CompatStyle of(Style style) {
        return new CompatStyle(style);
    }

    public static CompatStyle of() {
        return new CompatStyle();
    }

    public CompatStyle withColor(CompatTextColor color) {
        return new CompatStyle(style.func_240718_a_(color.getRaw()));
    }

    public CompatStyle withColor(CompatFormatting formatting) {
        return new CompatStyle(style.func_240712_a_(formatting.getRaw()));
    }

    public CompatStyle withColor(int rgbColor) {
        return new CompatStyle(style.func_240718_a_(Color.func_240743_a_(rgbColor)));
    }

    public CompatStyle withBold(boolean bold) {
        return new CompatStyle(style.func_240713_a_(bold));
    }

    public CompatStyle withItalic(boolean italic) {
        return new CompatStyle(style.func_240722_b_(italic));
    }

    public CompatStyle withUnderline(boolean underline) {
        return new CompatStyle(style.func_244282_c(underline));
    }

    public CompatStyle withStrikethrough(boolean strikethrough) {
        return withFormatting(CompatFormatting.STRIKETHROUGH);
    }

    public CompatStyle withObfuscated(boolean obfuscated) {
        return withFormatting(CompatFormatting.OBFUSCATED);
    }

    public CompatTextColor getColor() {
        if (style.func_240711_a_() == null) return null;
        return new CompatTextColor(style.func_240711_a_());
    }

    public boolean isBold() {
        return style.func_150223_b();
    }

    public boolean isItalic() {
        return style.func_150242_c();
    }

    public boolean isUnderlined() {
        return style.func_150234_e();
    }

    public boolean isStrikethrough() {
        return style.func_150236_d();
    }

    public boolean isObfuscated() {
        return style.func_150233_f();
    }

    public boolean isEmpty() {
        return style.func_150229_g();
    }

    public CompatStyle withFormatting(CompatFormatting formatting) {
        return withColor(formatting);
    }

    public Style getRaw() {
        return style;
    }

    @Override
    public int hashCode() {
        return style.hashCode();
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        CompatStyle that = (CompatStyle) obj;
        return style.equals(that.style);
    }
}
