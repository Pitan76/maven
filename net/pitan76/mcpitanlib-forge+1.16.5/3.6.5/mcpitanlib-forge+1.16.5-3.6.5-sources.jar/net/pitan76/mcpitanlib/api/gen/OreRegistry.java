package net.pitan76.mcpitanlib.api.gen;

import net.minecraft.block.Block;
import net.minecraft.util.ResourceLocation;
import net.minecraft.world.gen.GenerationStage;
import net.minecraft.world.gen.feature.ConfiguredFeature;
import net.pitan76.mcpitanlib.api.registry.WorldGenRegistry;
import net.pitan76.mcpitanlib.api.util.BlockUtil;
import net.pitan76.mcpitanlib.api.util.FeatureConfigUtil;

@Deprecated
public class OreRegistry {
    /**
     * Generating custom ore in stone
     * @param registry WorldGenRegistry
     * @param block Block
     * @param size Ore size
     * @param height generating height
     * @param count generating count per chunk
     * @return Identifier of feature
     */
    public static ResourceLocation registerStoneOre(WorldGenRegistry registry, Block block, int size, int height, int count) {
        ResourceLocation blockId = BlockUtil.toID(block);
        ResourceLocation identifier = new ResourceLocation(blockId.func_110624_b(), blockId.func_110623_a() + "_ore_feature");
        ConfiguredFeature<?, ?> configuredFuture = registry.registerFeature(identifier,
                () -> FeatureConfigUtil.createConfiguredFeature(
                        FeatureConfigUtil.createStoneOreFeatureConfig(block.func_176223_P(), size)
                )
        );

        WorldGenRegistry.addProperties(GenerationStage.Decoration.UNDERGROUND_ORES, configuredFuture);
        return identifier;
    }
}
