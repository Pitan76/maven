package net.pitan76.mcpitanlib.api.block.args;

import net.minecraft.block.BlockState;
import net.minecraft.util.Direction;
import net.minecraft.util.Rotation;
import net.pitan76.mcpitanlib.midohra.holder.BlockStatePropertyHolder;

public class RotateArgs implements BlockStatePropertyHolder {

    public BlockState state;
    public Rotation rotation;

    public RotateArgs(BlockState state, Rotation rotation) {
        this.state = state;
        this.rotation = rotation;
    }

    public BlockState getRawBlockState() {
        return state;
    }

    public Rotation getRawRotation() {
        return rotation;
    }

    @Override
    public net.pitan76.mcpitanlib.midohra.block.BlockState getBlockState() {
        return net.pitan76.mcpitanlib.midohra.block.BlockState.of(state);
    }

    public Direction rotate(Direction direction) {
        return rotation.func_185831_a(direction);
    }

    public net.pitan76.mcpitanlib.midohra.util.math.Direction rotate(net.pitan76.mcpitanlib.midohra.util.math.Direction direction) {
        return net.pitan76.mcpitanlib.midohra.util.math.Direction.of(rotation.func_185831_a(direction.toMinecraft()));
    }
}
