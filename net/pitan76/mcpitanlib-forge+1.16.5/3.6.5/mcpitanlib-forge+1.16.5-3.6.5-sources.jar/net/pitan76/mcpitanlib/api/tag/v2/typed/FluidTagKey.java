package net.pitan76.mcpitanlib.api.tag.v2.typed;

import me.shedaniel.architectury.hooks.TagHooks;
import net.minecraft.fluid.Fluid;
import net.minecraft.tags.ITag;
import net.pitan76.mcpitanlib.api.tag.v2.CompatTagKey;
import net.pitan76.mcpitanlib.api.tag.v2.CompatTagKeyType;
import net.pitan76.mcpitanlib.api.util.CompatIdentifier;

public class FluidTagKey extends CompatTagKey<Fluid> {
    @Deprecated
    public FluidTagKey(ITag.INamedTag<Fluid> tagKey) {
        super(tagKey);
    }

    public static FluidTagKey of(CompatIdentifier identifier) {
        return new FluidTagKey(TagHooks.getOptional(identifier.toMinecraft(), CompatTagKeyType.FLUID::getTagGroup));
    }
}
