package net.pitan76.mcpitanlib.api.gui;

import me.shedaniel.architectury.registry.menu.ExtendedMenuProvider;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.inventory.container.Container;
import net.minecraft.inventory.container.IContainerProvider;
import net.minecraft.network.PacketBuffer;
import net.minecraft.util.text.ITextComponent;
import org.jetbrains.annotations.Nullable;

@Deprecated
public class ExtendedNamedScreenHandlerFactory implements ExtendedMenuProvider {

    private final ITextComponent name;
    private final IContainerProvider baseFactory;
    private final PacketByteBufFactory bufFactory;

    public ExtendedNamedScreenHandlerFactory(ITextComponent name, IContainerProvider baseFactory, PacketByteBufFactory bufFactory) {
        this.name = name;
        this.baseFactory = baseFactory;
        this.bufFactory = bufFactory;
    }

    @Override
    public void saveExtraData(PacketBuffer buf) {
        bufFactory.saveExtraData(buf);
    }

    @Override
    public ITextComponent func_145748_c_() {
        return name;
    }

    @Nullable
    @Override
    public Container createMenu(int syncId, PlayerInventory inv, PlayerEntity player) {
        return baseFactory.createMenu(syncId, inv, player);

    }

    @FunctionalInterface
    public interface PacketByteBufFactory {
        void saveExtraData(PacketBuffer buf);
    }
}
