package net.pitan76.mcpitanlib.api.event;

import com.mojang.brigadier.Command;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.context.StringRange;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import net.minecraft.command.CommandSource;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.text.ITextComponent;
import net.minecraft.world.World;
import net.pitan76.mcpitanlib.api.entity.Player;
import net.pitan76.mcpitanlib.api.text.TextComponent;
import net.pitan76.mcpitanlib.api.util.TextUtil;
import net.pitan76.mcpitanlib.api.util.WorldUtil;

public class ServerCommandEvent extends CommandEvent<CommandSource> {

    public CommandContext<CommandSource> getContext() {
        return context;
    }

    public void setContext(CommandContext<CommandSource> context) {
        this.context = context;
    }

    public CommandSource getSource() {
        return getContext().getSource();
    }

    public PlayerEntity getPlayerEntity() throws CommandSyntaxException {
        return getSource().func_197035_h();
    }

    public Player getPlayer() throws CommandSyntaxException {
        return new Player(getPlayerEntity());
    }

    public World getWorld() {
        return getSource().func_197023_e();
    }

    public Entity getEntity() {
        return getSource().func_197022_f();
    }

    public String getInput() {
        return getContext().getInput();
    }

    public Command<CommandSource> getContextCommand() {
        return getContext().getCommand();
    }

    public CommandContext<CommandSource> getChild() {
        return getContext().getChild();
    }

    public CommandContext<CommandSource> getLastChild() {
        return getContext().getLastChild();
    }

    public StringRange getRange() {
        return getContext().getRange();
    }

    // Text
    public void sendSuccess(ITextComponent message, boolean broadcastToOps) {
        getSource().func_197030_a(message, broadcastToOps);
    }

    public void sendFailure(ITextComponent message) {
        getSource().func_197021_a(message);
    }

    public void sendSuccess(ITextComponent message) {
        sendSuccess(message, false);
    }

    // String (Formatted)
    public void sendSuccess(String message, boolean broadcastToOps) {
        sendSuccess(TextUtil.convert(message), broadcastToOps);
    }

    public void sendSuccess(String message) {
        sendSuccess(message, false);
    }

    public void sendFailure(String message) {
        sendFailure(TextUtil.convert(message));
    }

    // Translatable
    public void sendSuccessWithTranslatable(String message, boolean broadcastToOps) {
        sendSuccess(TextUtil.convertWithTranslatable(message), broadcastToOps);
    }

    public void sendSuccessWithTranslatable(String message) {
        sendSuccessWithTranslatable(message, false);
    }

    public void sendFailureWithTranslatable(String message) {
        sendFailure(TextUtil.convertWithTranslatable(message));
    }

    // Raw
    public void sendSuccessRaw(String message, boolean broadcastToOps) {
        sendSuccess(TextUtil.literal(message), broadcastToOps);
    }

    public void sendSuccessRaw(String message) {
        sendSuccessRaw(message, false);
    }

    public void sendFailureRaw(String message) {
        sendFailure(TextUtil.literal(message));
    }

    public boolean isClient() {
        return WorldUtil.isClient(getWorld());
    }

    public void sendSuccess(TextComponent message, boolean broadcastToOps) {
        sendSuccess(message.getText(), broadcastToOps);
    }

    public void sendSuccess(TextComponent message) {
        sendSuccess(message.getText());
    }

    public void sendFailure(TextComponent message) {
        sendFailure(message.getText());
    }
}
