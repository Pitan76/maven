package net.pitan76.mcpitanlib.api.util.client.widget;

import net.minecraft.client.gui.widget.Widget;
import net.pitan76.mcpitanlib.api.client.render.handledscreen.RenderArgs;

public class ClickableWidgetUtil {
    public static void render(Widget widget, RenderArgs args) {
        widget.func_230430_a_(args.drawObjectDM.getStack(), args.mouseX, args.mouseY, args.delta);
    }
}
