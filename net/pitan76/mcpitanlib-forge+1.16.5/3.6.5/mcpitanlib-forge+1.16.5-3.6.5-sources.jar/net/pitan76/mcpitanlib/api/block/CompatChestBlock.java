package net.pitan76.mcpitanlib.api.block;

import net.minecraft.block.BlockState;
import net.minecraft.block.ChestBlock;
import net.minecraft.tileentity.ChestTileEntity;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.tileentity.TileEntityType;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.IBlockReader;
import net.pitan76.mcpitanlib.api.block.v2.CompatBlockProvider;
import net.pitan76.mcpitanlib.api.block.v2.CompatibleBlockSettings;
import net.pitan76.mcpitanlib.api.event.block.TileCreateEvent;

import java.util.function.Supplier;

public class CompatChestBlock extends ChestBlock implements CompatBlockProvider {
    public CompatChestBlock(Properties settings, Supplier<TileEntityType<? extends ChestTileEntity>> supplier) {
        super(settings, supplier);
    }

    public CompatibleBlockSettings compatSettings;

    public CompatChestBlock(CompatibleBlockSettings settings, Supplier<TileEntityType<? extends ChestTileEntity>> supplier) {
        this(settings.build(), supplier);
    }

    /**
     * @deprecated Use {@link #createBlockEntity(TileCreateEvent)} instead.
     */
    @Deprecated
    public TileEntity createBlockEntity(BlockPos pos, BlockState state) {
        return createBlockEntity(new TileCreateEvent(pos, state));
    }

    /**
     * @deprecated Use {@link #createBlockEntity(TileCreateEvent)} instead.
     */
    @Deprecated
    @Override
    public TileEntity func_196283_a_(IBlockReader world) {
        return createBlockEntity(new TileCreateEvent(world));
    }

    /**
     * @see ExtendBlockEntityProvider#createBlockEntity(TileCreateEvent)
     */
    public TileEntity createBlockEntity(TileCreateEvent event) {
        return super.func_196283_a_(event.getBlockView());
    }

    @Override
    public CompatibleBlockSettings getCompatSettings() {
        return compatSettings;
    }
}
