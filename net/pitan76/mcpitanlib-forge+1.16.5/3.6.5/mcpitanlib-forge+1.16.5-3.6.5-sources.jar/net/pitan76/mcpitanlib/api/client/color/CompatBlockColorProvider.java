package net.pitan76.mcpitanlib.api.client.color;

import net.minecraft.block.BlockState;
import net.minecraft.client.renderer.color.IBlockColor;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.IBlockDisplayReader;
import org.jetbrains.annotations.Nullable;

public interface CompatBlockColorProvider extends IBlockColor {
    default int getColor(BlockState state, @Nullable IBlockDisplayReader world, @Nullable BlockPos pos, int tintIndex) {
        return getColor(new BlockColorEvent(state, world, pos, tintIndex));
    }

    int getColor(BlockColorEvent e);
}
