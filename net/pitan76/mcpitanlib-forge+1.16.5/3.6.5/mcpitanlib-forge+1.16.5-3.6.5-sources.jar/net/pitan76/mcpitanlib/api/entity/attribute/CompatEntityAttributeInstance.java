package net.pitan76.mcpitanlib.api.entity.attribute;

import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.ai.attributes.ModifiableAttributeInstance;
import net.pitan76.mcpitanlib.api.entity.Player;
import net.pitan76.mcpitanlib.api.util.CompatIdentifier;

import java.util.function.Consumer;

public class CompatEntityAttributeInstance {
    private final net.minecraft.entity.ai.attributes.ModifiableAttributeInstance raw;

    @Deprecated
    public CompatEntityAttributeInstance(net.minecraft.entity.ai.attributes.ModifiableAttributeInstance instance) {
        this.raw = instance;
    }

    @Deprecated
    public net.minecraft.entity.ai.attributes.ModifiableAttributeInstance raw() {
        return raw;
    }

    @Deprecated
    public static CompatEntityAttributeInstance of(net.minecraft.entity.ai.attributes.ModifiableAttributeInstance instance) {
        return new CompatEntityAttributeInstance(instance);
    }

    public static CompatEntityAttributeInstance create(CompatEntityAttribute type, Consumer<CompatEntityAttributeInstance> updateCallback) {
        return of(new ModifiableAttributeInstance(type.raw(), modifier -> {
            if (updateCallback != null)
                updateCallback.accept(of(modifier));
        }));
    }

    public static CompatEntityAttributeInstance get(LivingEntity entity, CompatEntityAttribute attribute) {
        return new CompatEntityAttributeInstance(entity.func_110148_a(attribute.raw()));
    }

    public static CompatEntityAttributeInstance get(Player player, CompatEntityAttribute attribute) {
        return get(player.getEntity(), attribute);
    }

    // TODO: Implement this method properly
    public boolean hasModifier(CompatIdentifier id) {
        return false; //raw().hasModifier();
    }

    public double getValue() {
        return raw().func_111126_e();
    }

    public void setBaseValue(double value) {
        raw().func_111128_a(value);
    }

    public void addPersistentModifier(CompatEntityAttributeModifier modifier) {
        raw().func_233769_c_(modifier.raw());
    }

    // TODO: Implement this method properly
    public void removeModifier(CompatIdentifier id) {

    }

    public CompatEntityAttribute getAttribute() {
        return CompatEntityAttribute.of(raw().func_111123_a());
    }

    public boolean isNull() {
        return raw() == null;
    }
}
