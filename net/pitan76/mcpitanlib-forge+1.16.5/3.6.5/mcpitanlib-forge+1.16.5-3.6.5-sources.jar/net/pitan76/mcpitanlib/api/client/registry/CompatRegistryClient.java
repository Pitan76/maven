package net.pitan76.mcpitanlib.api.client.registry;

import dev.architectury.injectables.annotations.ExpectPlatform;
import dev.architectury.registry.menu.MenuRegistry;
import me.shedaniel.architectury.registry.BlockEntityRenderers;
import me.shedaniel.architectury.registry.ParticleProviderRegistry;
import me.shedaniel.architectury.registry.RenderTypes;
import me.shedaniel.architectury.registry.entity.EntityRenderers;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.block.Block;
import net.minecraft.client.gui.IHasContainer;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.particle.IAnimatedSprite;
import net.minecraft.client.particle.IParticleFactory;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.color.IBlockColor;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererManager;
import net.minecraft.client.renderer.texture.AtlasTexture;
import net.minecraft.client.renderer.texture.TextureAtlasSprite;
import net.minecraft.client.renderer.tileentity.TileEntityRenderer;
import net.minecraft.client.renderer.tileentity.TileEntityRendererDispatcher;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.fluid.Fluid;
import net.minecraft.inventory.container.Container;
import net.minecraft.inventory.container.ContainerType;
import net.minecraft.particles.IParticleData;
import net.minecraft.particles.ParticleType;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.tileentity.TileEntityType;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.text.ITextComponent;
import net.pitan76.mcpitanlib.MCPitanLib;
import net.pitan76.mcpitanlib.api.client.color.CompatBlockColorProvider;
import net.pitan76.mcpitanlib.api.client.render.CompatRenderLayer;

import java.util.List;
import java.util.Random;
import java.util.function.Function;
import java.util.function.Supplier;

@Environment(EnvType.CLIENT)
public class CompatRegistryClient {
    public static <H extends Container, S extends Screen & IHasContainer<H>> void registerScreen(ContainerType<? extends H> type, ScreenFactory<H, S> factory) {
        registerScreen(MCPitanLib.MOD_ID, type, factory);
    }

    public static <H extends Container, S extends Screen & IHasContainer<H>> void registerScreen(String modId, ContainerType<? extends H> type, ScreenFactory<H, S> factory) {
        MenuRegistry.registerScreenFactory(type, factory::create);
    }

    public interface ScreenFactory<H extends Container, S extends Screen & IHasContainer<H>> {
        S create(H handler, PlayerInventory inventory, ITextComponent text);
    }

    public static <T extends IParticleData> void registerParticle(ParticleType<T> type, IParticleFactory<T> factory) {
        ParticleProviderRegistry.register(type, factory);
    }

    public static <T extends IParticleData> void registerParticle(ParticleType<T> type, ArchRegistryClient.DeferredParticleProvider<T> provider) {
        ParticleProviderRegistry.register(type, spriteSet -> provider.create(new ArchRegistryClient.ExtendedSpriteSet() {
            @Override
            public AtlasTexture getAtlas() {
                return spriteSet.getAtlas();
            }

            @Override
            public List<TextureAtlasSprite> getSprites() {
                return spriteSet.getSprites();
            }

            @Override
            public TextureAtlasSprite func_217591_a(int age, int maxAge) {
                return spriteSet.func_217591_a(age, maxAge);
            }

            @Override
            public TextureAtlasSprite func_217590_a(Random random) {
                return spriteSet.func_217590_a(random);
            }
        }));
    }

    public static <T extends Entity> void registerEntityRenderer(Supplier<? extends EntityType<? extends T>> type, Function<EntityRendererManager, EntityRenderer<T>> factory) {
        EntityRenderers.register((EntityType<T>) type.get(), factory);
    }

    @FunctionalInterface
    public interface DeferredParticleProvider<T extends IParticleData> {
        IParticleFactory<T> create(ExtendedSpriteSet spriteSet);
    }

    public interface ExtendedSpriteSet extends IAnimatedSprite {
        AtlasTexture getAtlas();

        List<TextureAtlasSprite> getSprites();
    }

    public static void registryClientSpriteAtlasTexture(ResourceLocation identifier) {
        //registryClientSprite(PlayerScreenHandler.BLOCK_ATLAS_TEXTURE, identifier);
    }

    public static void registryClientSpriteAtlasTexture(TextureAtlasSprite sprite) {
        //registryClientSprite(PlayerScreenHandler.BLOCK_ATLAS_TEXTURE, sprite);
    }

    public static void registryClientSprite(ResourceLocation atlasId, ResourceLocation identifier) {
        // ～1.19.2
    }

    public static void registryClientSprite(ResourceLocation atlasId, TextureAtlasSprite sprite) {
        // ～1.19.2
    }

    public static <T extends TileEntity> void registerBlockEntityRenderer(TileEntityType<T> type, BlockEntityRendererFactory<T> provider) {
        BlockEntityRenderers.registerRenderer(type, dispatcher -> provider.create(new BlockEntityRendererFactory.Context(dispatcher)));
    }

    @FunctionalInterface
    public interface BlockEntityRendererFactory<T extends TileEntity> {
        TileEntityRenderer<T> create(BlockEntityRendererFactory.Context ctx);

        class Context {
            private final TileEntityRendererDispatcher renderDispatcher;

            public Context(TileEntityRendererDispatcher renderDispatcher) {
                this.renderDispatcher = renderDispatcher;
            }

            public TileEntityRendererDispatcher getRenderDispatcher() {
                return this.renderDispatcher;
            }
        }
    }

    public static void registerRenderTypeBlock(RenderType layer, Block block) {
        RenderTypes.register(layer, block);
    }

    public static void registerRenderTypeFluid(RenderType layer, Fluid fluid) {
        RenderTypes.register(layer, fluid);
    }

    public static void registerCutoutBlock(Block block) {
        registerRenderTypeBlock(RenderType.func_228643_e_(), block);
    }

    public static <T extends TileEntity> void registerCompatBlockEntityRenderer(TileEntityType<T> type, BlockEntityRendererFactory<T> provider) {
        BlockEntityRenderers.registerRenderer(type, dispatcher -> provider.create(new BlockEntityRendererFactory.Context(dispatcher)));
    }

    public static void registerRenderTypeBlock(CompatRenderLayer layer, Block block) {
        registerRenderTypeBlock(layer.layer, block);
    }

    public static void registerRenderTypeFluid(CompatRenderLayer layer, Fluid fluid) {
        registerRenderTypeFluid(layer.layer, fluid);
    }

    @ExpectPlatform
    public static void registerColorProviderBlock(IBlockColor provider, Block... blocks) {
        throw new AssertionError("This method should be replaced by the platform implementation");
    }

    public static void registerColorProviderBlock(CompatBlockColorProvider provider, Block... blocks) {
        registerColorProviderBlock((IBlockColor) provider, blocks);
    }
}
