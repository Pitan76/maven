package net.pitan76.mcpitanlib.api.block.args.v2;

import net.minecraft.item.Item;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.math.shapes.ISelectionContext;
import net.pitan76.mcpitanlib.api.event.BaseEvent;
import net.pitan76.mcpitanlib.midohra.block.entity.BlockEntityWrapper;
import net.pitan76.mcpitanlib.midohra.holder.BlockStatePropertyHolder;
import net.pitan76.mcpitanlib.midohra.block.BlockState;
import net.pitan76.mcpitanlib.midohra.item.ItemWrapper;
import net.pitan76.mcpitanlib.midohra.util.math.BlockPos;
import net.pitan76.mcpitanlib.midohra.world.BlockView;
import net.pitan76.mcpitanlib.midohra.world.IWorldView;

public class OutlineShapeEvent extends BaseEvent implements BlockStatePropertyHolder {
    public BlockState state;
    public BlockView world;
    public BlockPos pos;
    public ISelectionContext context;

    public OutlineShapeEvent(BlockState state, BlockView world, BlockPos pos, ISelectionContext context) {
        this.state = state;
        this.world = world;
        this.pos = pos;
        this.context = context;
    }

    public OutlineShapeEvent(net.minecraft.block.BlockState state, net.minecraft.world.IBlockReader world, net.minecraft.util.math.BlockPos pos, net.minecraft.util.math.shapes.ISelectionContext context) {
        this(BlockState.of(state), BlockView.of(world), BlockPos.of(pos), context);
    }

    @Override
    public BlockState getBlockState() {
        return state;
    }

    public BlockEntityWrapper getBlockEntity() {
        return world.getBlockEntity(pos);
    }

    public TileEntity getRawBlockEntity() {
        return getBlockEntity().get();
    }

    public IWorldView getWorldView() {
        return world;
    }

    public BlockPos getPos() {
        return pos;
    }

    public ISelectionContext getContext() {
        return context;
    }

    public boolean isHolding(Item item) {
        return getContext().func_216375_a(item);
    }

    public boolean isHolding(ItemWrapper item) {
        return isHolding(item.get());
    }
}
