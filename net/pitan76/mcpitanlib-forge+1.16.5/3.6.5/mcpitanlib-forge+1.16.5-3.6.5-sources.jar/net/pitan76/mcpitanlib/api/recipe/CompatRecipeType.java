package net.pitan76.mcpitanlib.api.recipe;

import net.minecraft.item.crafting.BlastingRecipe;
import net.minecraft.item.crafting.CampfireCookingRecipe;
import net.minecraft.item.crafting.FurnaceRecipe;
import net.minecraft.item.crafting.ICraftingRecipe;
import net.minecraft.item.crafting.IRecipe;
import net.minecraft.item.crafting.IRecipeType;
import net.minecraft.item.crafting.SmithingRecipe;
import net.minecraft.item.crafting.SmokingRecipe;
import net.minecraft.item.crafting.StonecuttingRecipe;
import net.minecraft.recipe.*;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.registry.Registry;
import net.pitan76.mcpitanlib.api.util.CompatIdentifier;

@Deprecated
public class CompatRecipeType<T extends IRecipe<?>> {
    public static final CompatRecipeType<ICraftingRecipe> CRAFTING = new CompatRecipeType<>(IRecipeType.field_222149_a);
    public static final CompatRecipeType<FurnaceRecipe> SMELTING = new CompatRecipeType<>(IRecipeType.field_222150_b);
    public static final CompatRecipeType<BlastingRecipe> BLASTING = new CompatRecipeType<>(IRecipeType.field_222151_c);
    public static final CompatRecipeType<SmokingRecipe> SMOKING = new CompatRecipeType<>(IRecipeType.field_222152_d);
    public static final CompatRecipeType<CampfireCookingRecipe> CAMPFIRE_COOKING = new CompatRecipeType<>(IRecipeType.field_222153_e);
    public static final CompatRecipeType<StonecuttingRecipe> STONECUTTING = new CompatRecipeType<>(IRecipeType.field_222154_f);
    public static final CompatRecipeType<SmithingRecipe> SMITHING = new CompatRecipeType<>(IRecipeType.field_234827_g_);

    private final IRecipeType<T> type;

    public CompatRecipeType(String id) {
        this(IRecipeType.func_222147_a(id));
    }

    public CompatRecipeType(IRecipeType<T> type) {
        this.type = type;
    }

    public IRecipeType<T> getType() {
        return type;
    }

    public CompatIdentifier getName() {
        ResourceLocation id = Registry.field_218367_H.func_177774_c(type);
        if (id == null) return CompatIdentifier.empty();

        return CompatIdentifier.fromMinecraft(id);
    }

    public static CompatRecipeType<?> of(CompatIdentifier id) {
        IRecipeType<?> type = Registry.field_218367_H.func_82594_a(id.toMinecraft());
        if (type == null) return null;

        return new CompatRecipeType<>(type);
    }

    public static <T extends IRecipe<?>> CompatRecipeType<T> of(CompatIdentifier id, Class<T> clazz) {
        return (CompatRecipeType<T>) of(id);
    }

    public static <T extends IRecipe<?>> CompatRecipeType<T> of(IRecipeType<T> type) {
        return new CompatRecipeType<>(type);
    }

    public net.pitan76.mcpitanlib.midohra.recipe.RecipeType toMidohra() {
        return net.pitan76.mcpitanlib.midohra.recipe.RecipeType.of(type);
    }
}
