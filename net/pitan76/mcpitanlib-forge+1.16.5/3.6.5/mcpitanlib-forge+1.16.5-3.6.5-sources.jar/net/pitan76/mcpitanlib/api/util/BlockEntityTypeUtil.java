package net.pitan76.mcpitanlib.api.util;

import net.minecraft.tileentity.TileEntityType;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.registry.Registry;

public class BlockEntityTypeUtil {
    public static ResourceLocation toID(TileEntityType<?> entityType) {
        return Registry.field_212626_o.func_177774_c(entityType);
    }

    public static TileEntityType<?> fromId(ResourceLocation identifier) {
        return Registry.field_212626_o.func_82594_a(identifier);
    }

    public static boolean isExist(ResourceLocation identifier) {
        return Registry.field_212626_o.func_212607_c(identifier);
    }

    public static CompatIdentifier toCompatID(TileEntityType<?> entityType) {
        return CompatIdentifier.fromMinecraft(toID(entityType));
    }

    public static TileEntityType<?> fromId(CompatIdentifier identifier) {
        return fromId(identifier.toMinecraft());
    }

    public static boolean isExist(CompatIdentifier identifier) {
        return isExist(identifier.toMinecraft());
    }

    public static int getRawId(TileEntityType<?> type) {
        return Registry.field_212626_o.func_148757_b(type);
    }

    public static TileEntityType<?> fromIndex(int index) {
        return Registry.field_212626_o.func_148745_a(index);
    }
}
