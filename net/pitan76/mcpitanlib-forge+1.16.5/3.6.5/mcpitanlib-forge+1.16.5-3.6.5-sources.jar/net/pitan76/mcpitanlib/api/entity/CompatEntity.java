package net.pitan76.mcpitanlib.api.entity;

import net.minecraft.client.network.play.IClientPlayNetHandler;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.nbt.CompoundNBT;
import net.minecraft.network.IPacket;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraft.world.server.ServerWorld;
import net.pitan76.mcpitanlib.api.event.entity.InitDataTrackerArgs;
import net.pitan76.mcpitanlib.api.event.nbt.ReadNbtArgs;
import net.pitan76.mcpitanlib.api.event.nbt.WriteNbtArgs;
import net.pitan76.mcpitanlib.midohra.util.math.Vector3d;

public class CompatEntity extends Entity {
    public CompatEntity(EntityType<?> type, World world) {
        super(type, world);
    }

    @Deprecated
    @Override
    public void func_70088_a() {
        initDataTracker(new InitDataTrackerArgs(field_70180_af));
    }

    public void initDataTracker(InitDataTrackerArgs args) {

    }

    public void readCustomDataFromNbt(ReadNbtArgs nbt) {

    }

    public void writeCustomDataToNbt(WriteNbtArgs nbt) {

    }

    @Deprecated
    @Override
    public void func_70037_a(CompoundNBT nbt) {
        readCustomDataFromNbt(new ReadNbtArgs(nbt));
    }

    @Deprecated
    @Override
    public void func_213281_b(CompoundNBT nbt) {
        writeCustomDataToNbt(new WriteNbtArgs(nbt));
    }

    public IPacket<IClientPlayNetHandler> func_213297_N() {
        return null;
    }

    public void writeNbt(WriteNbtArgs args) {
        super.func_189511_e(args.getNbt());
    }

    public void readNbt(ReadNbtArgs args) {
        super.func_70020_e(args.getNbt());
    }

    @Deprecated
    @Override
    public CompoundNBT func_189511_e(CompoundNBT nbt) {
        writeNbt(new WriteNbtArgs(nbt));
        return nbt;
    }

    @Deprecated
    @Override
    public void func_70020_e(CompoundNBT nbt) {
        readNbt(new ReadNbtArgs(nbt));
    }

    public World callGetWorld() {
        return super.field_70170_p;
    }

    public BlockPos callGetBlockPos() {
        return func_233580_cy_();
    }

    public net.minecraft.util.math.vector.Vector3d callGetPos() {
        return func_213303_ch();
    }

    public boolean hasServerWorld() {
        return callGetWorld() instanceof ServerWorld;
    }

    public ServerWorld getServerWorld() {
        return (ServerWorld) super.field_70170_p;
    }

    public net.pitan76.mcpitanlib.midohra.world.World getMidohraWorld() {
        return net.pitan76.mcpitanlib.midohra.world.World.of(callGetWorld());
    }

    public net.pitan76.mcpitanlib.midohra.util.math.BlockPos getMidohraBlockPos() {
        return net.pitan76.mcpitanlib.midohra.util.math.BlockPos.of(callGetBlockPos());
    }

     public Vector3d getMidohraPos() {
        return Vector3d.of(callGetPos());
     }

     public net.pitan76.mcpitanlib.midohra.world.ServerWorld getMidohraServerWorld() {
         return net.pitan76.mcpitanlib.midohra.world.ServerWorld.of(getServerWorld());
     }
}