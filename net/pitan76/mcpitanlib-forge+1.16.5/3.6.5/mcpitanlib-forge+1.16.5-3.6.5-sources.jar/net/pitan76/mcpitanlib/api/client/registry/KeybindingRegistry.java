package net.pitan76.mcpitanlib.api.client.registry;

import me.shedaniel.architectury.registry.KeyBindings;
import net.minecraft.client.settings.KeyBinding;
import net.minecraft.util.ResourceLocation;
import net.pitan76.mcpitanlib.api.event.v0.ClientTickEventRegistry;
import net.pitan76.mcpitanlib.api.network.ClientNetworking;
import net.pitan76.mcpitanlib.api.network.PacketByteUtil;

public class KeybindingRegistry {
    public static void register(KeyBinding keyBinding) {
        KeyBindings.registerKeyBinding(keyBinding);
    }

    public static void register(KeyBinding keyBinding, ClientTickEventRegistry.Client client) {
        register(keyBinding);
        ClientTickEventRegistry.registerPost(client);
    }

    public static void registerOnLevel(KeyBinding keyBinding, ClientTickEventRegistry.ClientLevel level) {
        register(keyBinding);
        ClientTickEventRegistry.registerLevelPost(level);
    }

    public static void registerWithNetwork(KeyBinding keyBinding, ResourceLocation identifier) {
        register(keyBinding, client -> {
            if (keyBinding.func_151468_f())
                ClientNetworking.send(identifier, PacketByteUtil.create());
        });
    }

    public static void registerOnLevelWithNetwork(KeyBinding keyBinding, ResourceLocation identifier) {
        registerOnLevel(keyBinding, client -> {
            if (keyBinding.func_151468_f())
                ClientNetworking.send(identifier, PacketByteUtil.create());
        });
    }
}
