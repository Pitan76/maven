package net.pitan76.mcpitanlib.api.registry;

import java.util.HashMap;
import java.util.Map;
import java.util.function.Supplier;
import net.minecraft.util.IItemProvider;

public class FuelRegistry {

    private static final Map<String, Map<Supplier<IItemProvider>, Integer>> FUEL_MAP = new HashMap<>();

    public static void register(Supplier<IItemProvider> itemSupplier, int time, String namespace) {
        Map<Supplier<IItemProvider>, Integer> map = new HashMap<>();
        map.put(itemSupplier, time);

        FUEL_MAP.put(namespace, map);
    }

    @Deprecated
    public static void allRegister(String namespace) {
        if (!FUEL_MAP.containsKey(namespace)) return;

        Map<Supplier<IItemProvider>, Integer> map = FUEL_MAP.get(namespace);
        for (Map.Entry<Supplier<IItemProvider>, Integer> entry : map.entrySet()) {
            net.pitan76.mcpitanlib.core.registry.FuelRegistry.register(entry.getValue(), entry.getKey().get());
        }

        FUEL_MAP.remove(namespace);
    }
}
