package net.pitan76.mcpitanlib.api.event.entity;

import net.minecraft.util.math.RayTraceResult;
import net.minecraft.util.math.vector.Vector3d;
import net.pitan76.mcpitanlib.midohra.util.hit.HitResultType;

public class CollisionEvent {

    public RayTraceResult hitResult;

    public CollisionEvent(RayTraceResult hitResult) {
        this.hitResult = hitResult;
    }

    public RayTraceResult getHitResult() {
        return hitResult;
    }

    public RayTraceResult.Type getType() {
        return hitResult.func_216346_c();
    }

    public Vector3d getPos() {
        return hitResult.func_216347_e();
    }

    public net.pitan76.mcpitanlib.midohra.util.hit.HitResult getHitResultM() {
        return net.pitan76.mcpitanlib.midohra.util.hit.HitResult.of(getHitResult());
    }

    public HitResultType getHitResultTypeM() {
        return HitResultType.from(getType());
    }
}
