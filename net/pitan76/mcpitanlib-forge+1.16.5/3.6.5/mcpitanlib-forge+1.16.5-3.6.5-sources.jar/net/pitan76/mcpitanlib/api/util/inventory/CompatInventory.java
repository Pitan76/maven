package net.pitan76.mcpitanlib.api.util.inventory;

import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.inventory.IInventory;
import net.minecraft.inventory.Inventory;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.NonNullList;
import net.pitan76.mcpitanlib.api.entity.CompatContainerUser;
import net.pitan76.mcpitanlib.api.entity.Player;
import net.pitan76.mcpitanlib.api.registry.CompatRegistryLookup;
import net.pitan76.mcpitanlib.api.util.collection.ItemStackList;
import net.pitan76.mcpitanlib.api.util.inventory.args.CanInsertArgs;
import net.pitan76.mcpitanlib.midohra.nbt.NbtList;

import java.util.List;

public class CompatInventory extends Inventory implements ICompatInventory {
    public CompatInventory(int size) {
        super(size);
    }

    @Override
    public void func_70299_a(int slot, ItemStack stack) {
        super.func_70299_a(slot, stack);
    }

    /**
     * super method of setStack(slot, stack)
     */
    public final void superSetStack(int slot, ItemStack stack) {
        super.func_70299_a(slot, stack);
    }

    /**
     * super method of removeStack(slot, amount)
     */
    public final ItemStack superRemoveStack(int slot, int amount) {
        return super.func_70298_a(slot, amount);
    }

    @Override
    public ItemStack func_70298_a(int slot, int amount) {
        return callRemoveStack(slot, amount);
    }

    public ItemStack callRemoveStack(int slot, int amount) {
        return super.func_70298_a(slot, amount);
    }

    @Override
    public ItemStack func_70304_b(int slot) {
        return super.func_70304_b(slot);
    }

    @Override
    public ItemStack func_223374_a(Item item, int count) {
        return super.func_223374_a(item, count);
    }

    @Deprecated
    @Override
    public void func_174889_b(PlayerEntity player) {
        onOpen(new Player(player));
    }

    @Deprecated
    @Override
    public void func_174886_c(PlayerEntity player) {
        onClose(new Player(player));
    }

    @Deprecated
    @Override
    public net.minecraft.nbt.ListNBT func_70487_g() {
        return toNbtList(new CompatRegistryLookup()).toMinecraft();
    }

    @Deprecated
    @Override
    public void func_70486_a(net.minecraft.nbt.ListNBT list) {
        readNbtList(NbtList.of(list), new CompatRegistryLookup());
    }

    @Deprecated
    @Override
    public boolean func_70300_a(PlayerEntity player) {
        return canPlayerUse(new Player(player));
    }

    @Deprecated
    @Override
    public boolean func_233541_b_(ItemStack stack) {
        return canInsert(new CanInsertArgs(stack));
    }

    public void onOpen(Player player) {
        this.onOpen(new CompatContainerUser(player.getEntity()));
    }

    public void onClose(Player player) {
        this.onClose(new CompatContainerUser(player.getEntity()));
    }

    public void onOpen(CompatContainerUser user) {
        super.func_174889_b(user.getRaw());
    }

    public void onClose(CompatContainerUser user) {
        super.func_174886_c(user.getRaw());
    }

    public NbtList toNbtList(CompatRegistryLookup registries) {
        return NbtList.of(super.func_70487_g());
    }

    public void readNbtList(NbtList list, CompatRegistryLookup registries) {
        super.func_70486_a(list.toMinecraft());
    }

    public boolean canPlayerUse(Player player) {
        return true;
    }

    public boolean canInsert(CanInsertArgs args) {
        return super.func_233541_b_(args.getMcStack());
    }

    @Deprecated
    @Override
    public List<ItemStack> func_233543_f_() {
        return callClearToList();
    }

    public List<ItemStack> callClearToList() {
        return super.func_233543_f_();
    }

    public NonNullList<ItemStack> callGetHeldStacks() {
        ItemStackList list = ItemStackList.ofSize(func_70302_i_());
        for (int i = 0; i < func_70302_i_(); i++) {
            list.add(callGetStack(i));
        }

        return list;
    }

    public ItemStackList callGetHeldStacksAsItemStackList() {
        return ItemStackList.of(callGetHeldStacks());
    }

    @Deprecated
    @Override
    public ItemStack func_70301_a(int slot) {
        return callGetStack(slot);
    }

    public ItemStack callGetStack(int slot) {
        return super.func_70301_a(slot);
    }

    @Deprecated
    @Override
    public int func_70302_i_() {
        return getSize();
    }

    public int getSize() {
        return super.func_70302_i_();
    }

    @Deprecated
    @Override
    public boolean func_191420_l() {
        return callIsEmpty();
    }

    public boolean callIsEmpty() {
        return super.func_191420_l();
    }

    public boolean callCanTransferTo(IInventory hopperInventory, int slot, ItemStack stack) {
        return hopperInventory.func_94041_b(slot, stack);
    }

    @Deprecated
    @Override
    public ItemStack func_174894_a(ItemStack stack) {
        return callAddStack(stack);
    }

    public ItemStack callAddStack(ItemStack stack) {
        return super.func_174894_a(stack);
    }

    @Deprecated
    @Override
    public int func_70297_j_() {
        return callGetMaxCountPerStack();
    }

    public int callGetMaxCountPerStack() {
        return super.func_70297_j_();
    }
}
