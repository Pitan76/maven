package net.pitan76.mcpitanlib.api.gui;

import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.inventory.IInventory;
import net.minecraft.inventory.container.ClickType;
import net.minecraft.inventory.container.Container;
import net.minecraft.inventory.container.ContainerType;
import net.minecraft.inventory.container.Slot;
import net.minecraft.item.ItemStack;
import net.pitan76.mcpitanlib.api.entity.Player;
import net.pitan76.mcpitanlib.api.gui.args.CreateMenuEvent;
import net.pitan76.mcpitanlib.api.gui.args.SlotClickEvent;
import net.pitan76.mcpitanlib.api.util.ItemStackUtil;
import net.pitan76.mcpitanlib.api.util.ScreenHandlerUtil;
import net.pitan76.mcpitanlib.api.util.SlotUtil;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.List;

public class SimpleScreenHandler extends Container {
    protected SimpleScreenHandler(@Nullable ContainerType<?> type, int syncId) {
        super(type, syncId);
    }

    protected SimpleScreenHandler(@Nullable ContainerType<?> type, CreateMenuEvent e) {
        this(type, e.getSyncId());
    }

    public boolean hasMainInventory = false;
    public boolean hasHotbar = false;

    @Deprecated
    @Override
    public boolean func_75145_c(PlayerEntity player) {
        return canUse(new Player(player));
    }

    public boolean canUse(Player player) {
        return true;
    }

    public Slot addNormalSlot(IInventory inventory, int index, int x, int y) {
        Slot slot = new Slot(inventory, index, x, y);
        return this.func_75146_a(slot);
    }

    public <T extends Slot> Slot addSlot(IInventory inventory, int index, int x, int y, SlotFactory<T> factory) {
        Slot slot = factory.create(inventory, index, x, y);
        return this.func_75146_a(slot);
    }

    public interface SlotFactory<T extends Slot> {
        T create(IInventory inventory, int index, int x, int y);
    }

    public Slot callAddSlot(Slot slot) {
        return this.func_75146_a(slot);
    }

    @Deprecated
    @Override
    protected Slot func_75146_a(Slot slot) {
        return super.func_75146_a(slot);
    }

    @Deprecated
    @Override
    public void func_75134_a(PlayerEntity player) {
        this.close(new Player(player));
    }

    public void close(Player player) {
        super.func_75134_a(player.getPlayerEntity());
    }


    public static final int DEFAULT_SLOT_SIZE = 18;

    /**
     * Add player main inventory slots
     * @param inventory target player inventory
     * @param x start x
     * @param y start y
     */
    protected List<Slot> addPlayerMainInventorySlots(PlayerInventory inventory, int x, int y) {
        hasMainInventory = true;
        return this.addSlots(inventory, 9, x, y, DEFAULT_SLOT_SIZE, 9, 3);
    }

    /**
     * Add player hotbar slots
     * @param inventory target player inventory
     * @param x start x
     * @param y start y
     */
    protected List<Slot> addPlayerHotbarSlots(PlayerInventory inventory, int x, int y) {
        hasHotbar = true;
        return this.addSlotsX(inventory, 0, x, y, DEFAULT_SLOT_SIZE, 9);
    }

    /**
     * 一括でスロットを設置する
     * @param inventory target inventory
     * @param firstIndex fisrt index
     * @param firstX first x
     * @param firstY first y
     * @param size a slot size (if this is -1, set 18 to this)
     * @param maxAmountX x line slot max amount
     * @param maxAmountY y line slot max amount
     * @return Slot list
     */
    protected List<Slot> addSlots(IInventory inventory, int firstIndex, int firstX, int firstY, int size, int maxAmountX, int maxAmountY) {
        if (size < 0) size = DEFAULT_SLOT_SIZE;
        List<Slot> slots = new ArrayList<>();
        for (int y = 0; y < maxAmountY; ++y) {
            List<Slot> xSlots = this.addSlotsX(inventory, firstIndex + (y * maxAmountX), firstX, firstY + (y * size), size, maxAmountX);
            slots.addAll(xSlots);
        }
        return slots;
    }

    /**
     * 一括で横にスロットを設置する
     * @param inventory target inventory
     * @param firstIndex first index
     * @param firstX first x
     * @param y y
     * @param size a slot size (if this is -1, set 18 to this)
     * @param amount slot amount
     * @return Slot list
     */
    protected List<Slot> addSlotsX(IInventory inventory, int firstIndex, int firstX, int y, int size, int amount) {
        if (size < 0) size = DEFAULT_SLOT_SIZE;
        List<Slot> slots = new ArrayList<>();
        for (int x = 0; x < amount; ++x) {
            Slot slot = this.addNormalSlot(inventory, firstIndex + x, firstX + (x * size), y);
            slots.add(slot);
        }
        return slots;
    }

    /**
     * 一括で縦にスロットを設置する
     * @param inventory target inventory
     * @param firstIndex first index
     * @param x x
     * @param firstY first y
     * @param size a slot size (if this is -1, set 18 to this)
     * @param amount slot amount
     * @return Slot list
     */
    protected List<Slot> addSlotsY(IInventory inventory, int firstIndex, int x, int firstY, int size, int amount) {
        if (size < 0) size = DEFAULT_SLOT_SIZE;
        List<Slot> slots = new ArrayList<>();
        for (int y = 0; y < amount; ++y) {
            Slot slot = this.addNormalSlot(inventory, firstIndex + x, x, firstY + (y * size));
            slots.add(slot);
        }
        return slots;
    }

    @Deprecated
    public ItemStack quickMoveOverride(PlayerEntity player, int index) {
        return quickMoveOverride(new Player(player), index);
    }

    public boolean callInsertItem(ItemStack stack, int startIndex, int endIndex, boolean fromLast) {
        return this.func_75135_a(stack, startIndex, endIndex, fromLast);
    }

    @Deprecated
    @Override
    protected boolean func_75135_a(ItemStack stack, int startIndex, int endIndex, boolean fromLast) {
        return super.func_75135_a(stack, startIndex, endIndex, fromLast);
    }

    public ItemStack quickMoveOverride(Player player, int index) {
        ItemStack itemStack = ItemStackUtil.empty();
        Slot slot = ScreenHandlerUtil.getSlot(this, index);
        int size = ScreenHandlerUtil.getSlots(this).size();

        if (SlotUtil.hasStack(slot)) {
            ItemStack itemStack2 = SlotUtil.getStack(slot);
            itemStack = itemStack2.func_77946_l();

            if (hasMainInventory && hasHotbar) {
                if (index > 35) {
                    if (!this.callInsertItem(itemStack2, 0, 9, false)) {
                        if (!this.callInsertItem(itemStack2, 9, 36, true)) {
                            return ItemStackUtil.empty();
                        }
                    }
                } else if (size > 36 && !this.callInsertItem(itemStack2, 36, size, false)) {
                    return ItemStackUtil.empty();
                }
            }

            if (itemStack2.func_190926_b()) {
                SlotUtil.setStack(slot, ItemStackUtil.empty());
            } else {
                SlotUtil.markDirty(slot);
            }

            if (itemStack2.func_190916_E() == itemStack.func_190916_E()) {
                return ItemStackUtil.empty();
            }

            SlotUtil.onTakeItem(slot, player, itemStack2);
        }

        return itemStack;
    }


    @Deprecated
    @Override
    public ItemStack func_82846_b(PlayerEntity player, int slot) {
        return quickMoveOverride(player, slot);
    }

    @Deprecated
    @Override
    public Slot func_75139_a(int index) {
        return callGetSlot(index);
    }

    public Slot callGetSlot(int index) {
        return super.func_75139_a(index);
    }

    @Deprecated
    @Override
    public ItemStack func_184996_a(int slotIndex, int button, ClickType actionType, PlayerEntity player) {
        overrideOnSlotClick(slotIndex, button, actionType, new Player(player));
        return super.func_184996_a(slotIndex, button, actionType, player);
    }

    public void overrideOnSlotClick(int slotIndex, int button, ClickType actionType, Player player) {
        onSlotClick(new SlotClickEvent(slotIndex, button, actionType, player));
    }

    public void onSlotClick(SlotClickEvent e) {
        super.func_184996_a(e.slot, e.button, e.actionType, e.player.getEntity());
    }

    public void callSetCursorStack(ItemStack stack) {
        if (stack.func_234694_A_() instanceof PlayerEntity) {
            Player player = new Player((PlayerEntity) stack.func_234694_A_());
            player.getInventory().func_70437_b(stack);
        }
    }

    @Override
    @Deprecated
    public void func_75141_a(int slot, ItemStack stack) {
        callSetStackInSlot(slot, -1, stack);
    }

    public void callSetStackInSlot(int slot, int revision, ItemStack stack) {
        super.func_75141_a(slot, stack);
    }

    public int callGetRevision() {
        return -1;
    }

    public net.pitan76.mcpitanlib.midohra.item.ItemStack getCursorStackM() {
        return ScreenHandlerUtil.getCursorStackM(this);
    }

    public ItemStack callGetCursorStack() {
        return ScreenHandlerUtil.getCursorStack(this);
    }

    public void setCursorStack(net.pitan76.mcpitanlib.midohra.item.ItemStack stack) {
        ScreenHandlerUtil.setCursorStackM(this, stack);
    }

    @Deprecated
    @Override
    public boolean func_94530_a(ItemStack carried, Slot target) {
        return canInsertIntoSlotOverride(net.pitan76.mcpitanlib.midohra.item.ItemStack.of(carried), target);
    }

    @Deprecated
    @Override
    public boolean func_94531_b(Slot slot) {
        return canInsertIntoSlotOverride(slot);
    }

    public boolean canInsertIntoSlotOverride(net.pitan76.mcpitanlib.midohra.item.ItemStack carried, Slot target) {
        return super.func_94530_a(carried.toMinecraft(), target);
    }

    public boolean canInsertIntoSlotOverride(Slot slot) {
        return super.func_94531_b(slot);
    }
}
