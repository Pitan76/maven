package net.pitan76.mcpitanlib.api.tile;

import com.mojang.datafixers.types.Type;
import dev.architectury.injectables.annotations.ExpectPlatform;
import net.minecraft.block.Block;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.tileentity.TileEntityType;
import net.pitan76.mcpitanlib.api.event.block.TileCreateEvent;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class BlockEntityTypeBuilder<T extends TileEntity> {
    private final Factory<? extends T> factory;
    private final List<Block> blocks;

    public BlockEntityTypeBuilder(Factory<? extends T> factory, List<Block> blocks) {
        this.factory = factory;
        this.blocks = blocks;
    }

    public static <T extends TileEntity> BlockEntityTypeBuilder<T> create(Factory<? extends T> factory, Block... blocks) {
        List<Block> blocksList = new ArrayList<>(blocks.length);
        Collections.addAll(blocksList, blocks);

        return new BlockEntityTypeBuilder<>(factory, blocksList);
    }

    public BlockEntityTypeBuilder<T> addBlock(Block block) {
        this.blocks.add(block);
        return this;
    }

    public BlockEntityTypeBuilder<T> addBlocks(Block... blocks) {
        Collections.addAll(this.blocks, blocks);
        return this;
    }

    public TileEntityType<T> build() {
        return build(null);
    }

    public TileEntityType<T> build(Type<?> type) {
        return TileEntityType.Builder.<T>func_223042_a(factory::create, blocks.toArray(new Block[0])).func_206865_a(type);

    }

    @FunctionalInterface
    public interface Factory<T extends TileEntity> {
        T create(TileCreateEvent event);

        @Deprecated
        default T create() {
            return create(new TileCreateEvent(null));
        }
    }
}
