package net.pitan76.mcpitanlib.api.util.client.v2;

import net.minecraft.client.gui.IGuiEventListener;
import net.minecraft.client.gui.screen.Screen;

public class ScreenUtil extends net.pitan76.mcpitanlib.api.util.client.ScreenUtil {

    public static void setFocus(Screen screen, boolean focus) {
    }

    public static void setFocus(Screen screen, IGuiEventListener element) {
        screen.func_231035_a_(element);
    }

    public static boolean isFocused(Screen screen) {
        return false;
    }

    public static void setDragging(Screen screen, boolean dragging) {
        screen.func_231037_b__(dragging);
    }

    public static boolean isDragging(Screen screen) {
        return screen.func_231041_ay__();
    }

    public static int getWidth(Screen screen) {
        return screen.field_230708_k_;
    }

    public static int getHeight(Screen screen) {
        return screen.field_230709_l_;
    }
}
