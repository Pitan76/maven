package net.pitan76.mcpitanlib.api.item;

import net.minecraft.block.BlockState;
import net.minecraft.client.util.ITooltipFlag;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemUseContext;
import net.minecraft.item.Rarity;
import net.minecraft.item.UseAction;
import net.minecraft.util.*;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.text.ITextComponent;
import net.minecraft.world.World;
import net.pitan76.mcpitanlib.api.event.item.*;
import net.pitan76.mcpitanlib.api.util.CompatActionResult;
import net.pitan76.mcpitanlib.api.util.StackActionResult;
import net.pitan76.mcpitanlib.core.Dummy;
import net.pitan76.mcpitanlib.mixin.ItemUsageContextMixin;
import org.jetbrains.annotations.Nullable;

import java.util.List;

public class ExtendItem extends Item {

    public ExtendItem(Properties settings) {
        super(settings);
    }

    public ExtendItem(CompatibleItemSettings settings) {
        super(settings.build());
    }

    @Deprecated
    @Override
    public ActionResult<ItemStack> func_77659_a(World world, PlayerEntity user, Hand hand) {
        return onRightClick(new ItemUseEvent(world, user, hand)).toTypedActionResult();
    }

    @Deprecated
    @Override
    public ActionResultType func_195939_a(ItemUseContext context) {
        ItemUsageContextMixin contextAccessor = (ItemUsageContextMixin) context;
        return onRightClickOnBlock(new ItemUseOnBlockEvent(context.func_195999_j(), context.func_221531_n(), contextAccessor.getHit())).toActionResult();
    }

    @Deprecated
    @Override
    public ItemStack func_77654_b(ItemStack stack, World world, LivingEntity user) {
        return onFinishUsing(new ItemFinishUsingEvent(stack, world, user));
    }

    @Deprecated
    @Override
    public ActionResultType func_111207_a(ItemStack stack, PlayerEntity user, LivingEntity entity, Hand hand) {
        return onRightClickOnEntity(new ItemUseOnEntityEvent(stack, user, entity, hand)).toActionResult();
    }

    @Override
    public UseAction func_77661_b(ItemStack stack) {
        return super.func_77661_b(stack);
    }

    @Deprecated
    @Override
    public boolean func_77634_r() {
        return hasRecipeRemainder(new Dummy());
    }

    @Deprecated
    @Override
    public void func_77624_a(ItemStack stack, @Nullable World world, List<ITextComponent> tooltip, ITooltipFlag context) {
        appendTooltip(new ItemAppendTooltipEvent(stack, world, tooltip, context));
    }

    @Deprecated
    @Override
    public void func_77622_d(ItemStack stack, World world, PlayerEntity player) {
        onCraft(new CraftEvent(stack, world, player));
    }

    @Deprecated
    @Override
    public boolean func_77644_a(ItemStack stack, LivingEntity target, LivingEntity attacker) {
        return postHit(new PostHitEvent(stack, target, attacker));
    }

    @Deprecated
    @Override
    public boolean func_179218_a(ItemStack stack, World world, BlockState state, BlockPos pos, LivingEntity miner) {
        return postMine(new PostMineEvent(stack, world, state, pos, miner));
    }

    /**
     * item right click event
     *
     * @param event ItemUseEvent
     * @return ActionResultType
     */
    public StackActionResult onRightClick(ItemUseEvent event) {
        return StackActionResult.create(CompatActionResult.create(super.func_77659_a(event.world, event.user.getPlayerEntity(), event.hand).func_188397_a()), event.stack);
    }

    /**
     * item right click event on block
     * @param event ItemUseOnBlockEvent
     * @return ActionResultType
     */
    public CompatActionResult onRightClickOnBlock(ItemUseOnBlockEvent event) {
        return CompatActionResult.create(super.func_195939_a(event.toIUC()));
    }

    /**
     * item finish using event
     * @param event ItemFinishUsingEvent
     * @return ItemStack
     */
    public ItemStack onFinishUsing(ItemFinishUsingEvent event) {
        return super.func_77654_b(event.stack, event.world, event.user);
    }

    /**
     * item right click event on entity
     * @param event ItemUseOnEntityEvent
     * @return ActionResultType
     */
    public CompatActionResult onRightClickOnEntity(ItemUseOnEntityEvent event) {
        return CompatActionResult.create(super.func_111207_a(event.stack, event.user.getEntity(), event.entity, event.hand));
    }

    /**
     * check if item has recipe remainder
     * @param dummy Dummy
     * @return boolean
     */
    public boolean hasRecipeRemainder(Dummy dummy) {
        return false;
    }

    /**
     * append tooltip to item
     * @param event ItemAppendTooltipEvent
     */
    public void appendTooltip(ItemAppendTooltipEvent event) {
        super.func_77624_a(event.stack, event.world, event.tooltip, event.context);
    }

    /**
     * on craft event
     * @param event CraftEvent
     */
    public void onCraft(CraftEvent event) {
        super.func_77622_d(event.stack, event.world, null);
    }

    /**
     * post hit event
     * @param event PostHitEvent
     * @return boolean
     */
    public boolean postHit(PostHitEvent event) {
        return super.func_77644_a(event.stack, event.target, event.attacker);
    }

    /**
     * post mine event
     * @param event PostMineEvent
     * @return boolean
     */
    public boolean postMine(PostMineEvent event) {
        return super.func_179218_a(event.stack, event.world, event.state, event.pos, event.miner);
    }

    // -1.20.6
    public Rarity func_77613_e(ItemStack stack) {
        return Rarity.COMMON;
    }

    @Deprecated
    @Override
    public boolean func_77616_k(ItemStack stack) {
        return isEnchantable(new EnchantableArgs(stack));
    }

    public boolean isEnchantable(EnchantableArgs args) {
        return super.func_77616_k(args.stack);
    }

    @Deprecated
    @Override
    public int func_77619_b() {
        return getEnchantability(new EnchantabilityArgs());
    }

    public int getEnchantability(EnchantabilityArgs args) {
        return super.func_77619_b();
    }

    public int getItemBarColor(ItemBarColorArgs args) {
        return 0;
    }

    public boolean isItemBarVisible(ItemBarVisibleArgs args) {
        return false;
    }

    public int getItemBarStep(ItemBarStepArgs args) {
        return 0;
    }

    public float getBonusAttackDamage(BonusAttackDamageArgs args) {
        return 0;
    }

    @Deprecated
    @Override
    public boolean func_82789_a(ItemStack stack, ItemStack ingredient) {
        return canRepair(new CanRepairArgs(stack, ingredient));
    }

    public boolean canRepair(CanRepairArgs args) {
        return false;
    }

    @Deprecated
    @Override
    public boolean func_195938_a(BlockState state, World world, BlockPos pos, PlayerEntity miner) {
        return canMine(new CanMineArgs(state, world, pos, miner));
    }

    public boolean canMine(CanMineArgs args) {
        return super.func_195938_a(args.state, args.world, args.pos, args.miner.getEntity());
    }
}
