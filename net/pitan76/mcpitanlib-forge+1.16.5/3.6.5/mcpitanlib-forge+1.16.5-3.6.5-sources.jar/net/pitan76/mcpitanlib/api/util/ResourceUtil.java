package net.pitan76.mcpitanlib.api.util;

import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;
import net.minecraft.resources.IResource;
import net.minecraft.resources.IResourceManager;
import net.minecraft.util.ResourceLocation;

public class ResourceUtil {
    public static IResource getResource(IResourceManager resourceManager, ResourceLocation identifier) throws IOException {
        return resourceManager.func_199002_a(identifier);
    }

    public static InputStream getInputStream(IResource resource) {
        return resource.func_199027_b();
    }

    public static Map<ResourceLocation, IResource> findResources(IResourceManager resourceManager, String startingPath, String endingPath) throws IOException {
        Map<ResourceLocation, IResource> map = new HashMap<>();
        for (ResourceLocation identifier : resourceManager.func_199003_a(startingPath, s -> s.endsWith(endingPath))) {
            map.put(identifier, resourceManager.func_199002_a(identifier));
        }
        return map;
    }

    public static void close(IResource resource) throws IOException {
        resource.close();
    }
}
