package net.pitan76.mcpitanlib.api.util.client;

import net.minecraft.client.MouseHelper;

public class MouseUtil {

    public static MouseHelper getMouse() {
        return ClientUtil.getMouse();
    }

    public static double getMouseX() {
        return getMouse().func_198024_e();
    }

    public static double getMouseY() {
        return getMouse().func_198026_f();
    }

    public static boolean isCursorLocked() {
        return getMouse().func_198035_h();
    }

    public static void lockCursor() {
        getMouse().func_198034_i();
    }

    public static void unlockCursor() {
        getMouse().func_198032_j();
    }

    public static void tick() {
        getMouse().func_198028_a();
    }

    public static boolean wasLeftButtonClicked() {
        return getMouse().func_198030_b();
    }

    public static boolean wasRightButtonClicked() {
        return getMouse().func_198031_d();
    }

    public static boolean wasMiddleButtonClicked() {
        return getMouse().field_198038_c;
    }
}
