package net.pitan76.mcpitanlib.api.entity;

import me.shedaniel.architectury.registry.menu.ExtendedMenuProvider;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.block.BlockState;
import net.minecraft.client.entity.player.ClientPlayerEntity;
import net.minecraft.entity.player.PlayerAbilities;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.entity.player.ServerPlayerEntity;
import net.minecraft.inventory.EquipmentSlotType;
import net.minecraft.inventory.container.Container;
import net.minecraft.inventory.container.INamedContainerProvider;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.CompoundNBT;
import net.minecraft.network.PacketBuffer;
import net.minecraft.network.play.ServerPlayNetHandler;
import net.minecraft.potion.EffectInstance;
import net.minecraft.stats.Stat;
import net.minecraft.stats.StatType;
import net.minecraft.util.CooldownTracker;
import net.minecraft.util.Direction;
import net.minecraft.util.Hand;
import net.minecraft.util.NonNullList;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.SoundEvent;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.text.ITextComponent;
import net.minecraft.world.World;
import net.pitan76.mcpitanlib.api.entity.effect.CompatStatusEffect;
import net.pitan76.mcpitanlib.api.entity.effect.CompatStatusEffectInstance;
import net.pitan76.mcpitanlib.api.gui.ExtendedNamedScreenHandlerFactory;
import net.pitan76.mcpitanlib.api.gui.v2.ExtendedScreenHandlerFactory;
import net.pitan76.mcpitanlib.api.item.ArmorEquipmentType;
import net.pitan76.mcpitanlib.api.item.CompatFoodComponent;
import net.pitan76.mcpitanlib.api.sound.CompatSoundCategory;
import net.pitan76.mcpitanlib.api.sound.CompatSoundEvent;
import net.pitan76.mcpitanlib.api.text.TextComponent;
import net.pitan76.mcpitanlib.api.util.CompatIdentifier;
import net.pitan76.mcpitanlib.api.util.ScreenHandlerUtil;
import net.pitan76.mcpitanlib.api.util.TextUtil;
import net.pitan76.mcpitanlib.api.util.entity.LivingEntityUtil;
import net.pitan76.mcpitanlib.core.player.ItemCooldown;
import net.pitan76.mcpitanlib.midohra.util.math.Vector3d;

import java.util.*;
import java.util.function.Consumer;

/*
PlayerEntity helper
 */
public class Player {
    private final PlayerEntity entity;

    public PlayerEntity getEntity() {
        return entity;
    }

    public PlayerEntity getPlayerEntity() {
        return getEntity();
    }

    public Player(PlayerEntity playerEntity) {
        this.entity = playerEntity;
    }

    /**
     * Get player inventory
     * @return PlayerInventory
     */
    public PlayerInventory getInv() {
        return getEntity().field_71071_by;
    }

    /**
     * Alias of getInv()
     * @return PlayerInventory
     */
    public PlayerInventory getInventory() {
        return getInv();
    }

    /**
     * Get armor's item stack list
     * @return DefaultedList<ItemStack>
     */
    public NonNullList<ItemStack> getArmor() {
        return getInv().field_70460_b;
    }

    /**
     * Get main's item stack list
     * @return DefaultedList<ItemStack>
     */
    public NonNullList<ItemStack> getMain() {
        return getInv().field_70462_a;
    }

    /**
     * Get off hand's item stack list
     * @return DefaultedList<ItemStack>
     */
    public NonNullList<ItemStack> getOffHand() {
        return getInv().field_184439_c;
    }

    /**
     * Get select slot integer
     * @return int
     */
    public int getSelectSlot() {
        return getInv().field_70461_c;
    }

    /**
     * Get player inventory size
     * @return player inventory size
     */
    public int getInvSize() {
        return getInv().func_70302_i_();
    }

    public OptionalInt openGuiScreen(INamedContainerProvider factory) {
        return getEntity().func_213829_a(factory);
    }

    public OptionalInt openGuiScreen(World world, BlockState state, BlockPos pos) {
        return openGuiScreen(state.func_215699_b(world, pos));
    }

    public boolean isServerPlayerEntity() {
        return this.getEntity() instanceof ServerPlayerEntity;
    }

    public void openExtendedMenu(INamedContainerProvider provider, Consumer<PacketBuffer> bufWriter) {
        if (isServerPlayerEntity())
            ScreenHandlerUtil.openExtendedMenu((ServerPlayerEntity) this.getPlayerEntity(), provider, bufWriter);
    }

    public void openExtendedMenu(ExtendedMenuProvider provider) {
        if (isServerPlayerEntity())
            ScreenHandlerUtil.openExtendedMenu((ServerPlayerEntity) this.getPlayerEntity(), provider);
    }

    public void openExtendedMenu(ExtendedNamedScreenHandlerFactory provider) {
        this.openExtendedMenu((ExtendedMenuProvider) provider);
    }

    public void openMenu(INamedContainerProvider provider) {
        if (isServerPlayerEntity())
            ScreenHandlerUtil.openMenu((ServerPlayerEntity) this.getPlayerEntity(), provider);
    }

    public void insertStack(ItemStack stack) {
        getInv().func_70441_a(stack);
    }

    public void insertStack(int slot, ItemStack stack) {
        getInv().func_191971_c(slot, stack);
    }

    public void offerOrDrop(ItemStack itemStack) {
        getInv().func_191975_a(getWorld(), itemStack);
    }

    public void giveStack(ItemStack stack) {
        getEntity().func_191521_c(stack);
    }

    public String getName() {
        return getEntity().func_200200_C_().getString();
    }

    public UUID getUUID() {
        return getEntity().func_110124_au();
    }

    public PlayerAbilities getAbilities() {
        return getEntity().field_71075_bZ;
    }

    /**
     * Returns whether this player is in creative mode.
     */
    public boolean isCreative() {
        return getAbilities().field_75098_d;
    }

    public boolean isFlying() {
        return getAbilities().field_75100_b;
    }

    public boolean isInvulnerable() {
        return getAbilities().field_75102_a;
    }

    public World getWorld() {
        return getEntity().field_70170_p;
    }

    public Container getCurrentScreenHandler() {
        return getEntity().field_71070_bA;
    }

    public boolean isSneaking() {
        return getEntity().func_225608_bj_();
    }

    public ItemStack getCursorStack() {
        return getInv().func_70445_o();
    }

    public boolean isClient() {
        return getWorld().func_201670_d();
    }
    public boolean isServer() {
        return !isClient();
    }

    public void readCustomDataFromNbt(CompoundNBT nbt) {
        getEntity().func_70037_a(nbt);
    }

    public void writeCustomDataToNbt(CompoundNBT nbt) {
        getEntity().func_213281_b(nbt);
    }

    public void sendMessage(ITextComponent text) {
        getEntity().func_146105_b(text, false);
    }

    public void sendActionBar(ITextComponent text) {
        getEntity().func_146105_b(text, true);
    }

    public void equipStack(EquipmentSlotType slot, ItemStack stack) {
        getEntity().func_184201_a(slot, stack);
    }

    public void dropStack(ItemStack stack, boolean throwRandomly, boolean retainOwnership) {
        getEntity().func_146097_a(stack, throwRandomly, retainOwnership);
    }

    public void dropStack(ItemStack stack, boolean retainOwnership) {
        dropStack(stack, false, retainOwnership);
    }

    public void dropStack(ItemStack stack) {
        dropStack(stack, false, false);
    }

    public BlockPos getBlockPos() {
        return getEntity().func_233580_cy_();
    }

    public net.minecraft.util.math.vector.Vector3d getPos() {
        return getEntity().func_213303_ch();
    }

    public ItemStack getStackInHand(Hand hand) {
        return this.getEntity().func_184586_b(hand);
    }

    public void heal(float amount) {
        this.getEntity().func_70691_i(amount);
    }

    public float getYaw() {
        return this.getEntity().func_195046_g(1.0f);
    }

    public float getPitch() {
        return this.getEntity().func_195050_f(1.0f);
    }

    public void playSound(SoundEvent event, SoundCategory category, float volume, float pitch) {
        if (isServerPlayerEntity()) {
            Optional<ServerPlayerEntity> player = getServerPlayer();
            if (player.isPresent()) {
                player.get().func_213823_a(event, category, volume, pitch);
                return;
            }
        }

        playSound(event, volume, pitch);
    }

    public void playSound(SoundEvent event, float volume, float pitch) {
        if (isServerPlayerEntity()) {
            Optional<ServerPlayerEntity> player = getServerPlayer();
            if (player.isPresent()) {
                player.get().func_184185_a(event, volume, pitch);
                return;
            }
        }

        getEntity().func_184185_a(event, volume, pitch);
    }

    public void playSound(CompatSoundEvent event, CompatSoundCategory category, float volume, float pitch) {
        playSound(event.get(), category.get(), volume, pitch);
    }

    public void playSound(CompatSoundEvent event, float volume, float pitch) {
        playSound(event.get(), volume, pitch);
    }

    public ItemCooldown itemCooldown = new ItemCooldown(this);

    public ItemCooldown getItemCooldown() {
        return itemCooldown;
    }

    public CooldownTracker getItemCooldownManager() {
        return getEntity().func_184811_cZ();
    }

    public void incrementStat(Stat<?> stat) {
        getEntity().func_71029_a(stat);
    }

    public <T> void incrementStat(StatType<T> type, T object) {
        getEntity().func_71029_a(type.func_199076_b(object));
    }

    public void incrementStat(ResourceLocation id) {
        getEntity().func_195066_a(id);
    }

    public void incrementStat(CompatIdentifier id) {
        getEntity().func_195066_a(id.toMinecraft());
    }

    public void teleport(double x, double y, double z) {
        getEntity().func_213373_a(x, y, z, false);
    }

    public ItemStack getMainHandStack() {
        return getStackInHand(Hand.MAIN_HAND);
    }

    public ItemStack getOffHandStack() {
        return getStackInHand(Hand.OFF_HAND);
    }

    public Direction getHorizontalFacing() {
        return getEntity().func_174811_aO();
    }

    public double getX() {
        return getEntity().func_226277_ct_();
    }

    public double getY() {
        return getEntity().func_226278_cu_();
    }

    public double getZ() {
        return getEntity().func_226281_cx_();
    }

    public boolean isServerPlayer() {
        return getEntity() instanceof ServerPlayerEntity;
    }

    public Optional<ServerPlayerEntity> getServerPlayer() {
        if (isServerPlayer())
            return Optional.of((ServerPlayerEntity) getEntity());

        return Optional.empty();
    }

    @Environment(EnvType.CLIENT)
    public Optional<ClientPlayerEntity> getClientPlayer() {
        if (getEntity() instanceof ClientPlayerEntity)
            return Optional.of((ClientPlayerEntity) getEntity());

        return Optional.empty();
    }

    public void setVelocity(double x, double y, double z) {
        getEntity().func_213293_j(x, y, z);
    }

    public void setVelocity(net.minecraft.util.math.vector.Vector3d velocity) {
        getEntity().func_213317_d(velocity);
    }

    public net.minecraft.util.math.vector.Vector3d getVelocity() {
        return getEntity().func_213322_ci();
    }

    public Optional<ServerPlayNetHandler> getNetworkHandler() {
        Optional<ServerPlayerEntity> player = getServerPlayer();
        return player.map(sp -> sp.field_71135_a);
    }

    public boolean hasNetworkHandler() {
        return getNetworkHandler().isPresent();
    }

    public boolean isSpectator() {
        return getEntity().func_175149_v();
    }

    /**
     * Returns the current {@link ItemStack} in the {@link Player}'s hand, or offhand if the
     * main hand is empty.
     *
     * @return {@code ItemStack} that the {@link Player} is holding. Can be {@link null}.
     */
    public Optional<ItemStack> getCurrentHandItem() {
        boolean playerIsHoldingInMainHand = !getMainHandStack().func_190926_b();
        if (playerIsHoldingInMainHand)
            return Optional.ofNullable(getMainHandStack());

        boolean playerIsHoldingInOffHand = !getOffHandStack().func_190926_b();

        if (playerIsHoldingInOffHand)
            return Optional.ofNullable(getOffHandStack());

        return Optional.empty();
    }

    public void addStatusEffect(CompatStatusEffectInstance effect) {
        getEntity().func_195064_c(effect.getInstance());
    }

    public void removeStatusEffect(CompatStatusEffect effect) {
        getEntity().func_195063_d(effect.getStatusEffect(getWorld()));
    }

    public List<CompatStatusEffectInstance> getStatusEffects() {
        List<CompatStatusEffectInstance> compatEffects = new ArrayList<>();

        for (EffectInstance effect : getEntity().func_70651_bq()) {
            compatEffects.add(new CompatStatusEffectInstance(effect));
        }

        return compatEffects;
    }

    public void addExperience(int experience) {
        getEntity().func_195068_e(experience);
    }

    public int getExperienceLevel() {
        return getEntity().field_71068_ca;
    }

    public void addExperienceLevels(int levels) {
        getEntity().func_82242_a(levels);
    }

    public void setExperienceLevel(int level) {
        getEntity().field_71068_ca = level;
    }

    public void addScore(int score) {
        getEntity().func_85039_t(score);
    }

    public int getScore() {
        return getEntity().func_71037_bA();
    }

    public void setScore(int score) {
        getEntity().func_85040_s(score);
    }

    public int getTotalExperience() {
        return getEntity().field_71067_cb;
    }

    public void setTotalExperience(int experience) {
        getEntity().field_71067_cb = experience;
    }

    public boolean isSwimming() {
        return getEntity().func_203007_ba();
    }

    public void setStackInHand(Hand hand, ItemStack stack) {
        getEntity().func_184611_a(hand, stack);
    }

    public void setStackInHand(Hand hand, net.pitan76.mcpitanlib.midohra.item.ItemStack stack) {
        setStackInHand(hand, stack.toMinecraft());
    }

    public net.pitan76.mcpitanlib.midohra.item.ItemStack getMidohraStackInHand(Hand hand) {
        return net.pitan76.mcpitanlib.midohra.item.ItemStack.of(getStackInHand(hand));
    }

    public Hand getActiveHand() {
        return getEntity().func_184600_cs();
    }

    public float getBlockBreakingSpeed(BlockState state) {
        return getEntity().func_184813_a(state);
    }

    public boolean canHarvest(BlockState state) {
        return getEntity().func_234569_d_(state);
    }

    public net.pitan76.mcpitanlib.midohra.world.World getMidohraWorld() {
        return net.pitan76.mcpitanlib.midohra.world.World.of(getWorld());
    }

    public void eatFood(ItemStack stack, CompatFoodComponent foodComponent) {
        getEntity().func_213357_a(getWorld(), stack);
    }

    public void sendMessage(String message) {
        sendMessage(TextUtil.of(message));
    }

    public void sendActionBar(String message) {
        sendActionBar(TextUtil.of(message));
    }

    public void sendMessagef(String format, Object... args) {
        sendMessage(TextUtil.of(String.format(format, args)));
    }

    public void sendMessage(TextComponent textComponent) {
        sendMessage(textComponent.getText());
    }

    public void sendActionBar(TextComponent textComponent) {
        sendActionBar(textComponent.getText());
    }


    public void openExtendedMenu(ExtendedScreenHandlerFactory provider) {
        this.openExtendedMenu((ExtendedMenuProvider) provider);
    }

    public void offerOrDrop(net.pitan76.mcpitanlib.midohra.item.ItemStack stack) {
        offerOrDrop(stack.toMinecraft());
    }

    public void insertStack(net.pitan76.mcpitanlib.midohra.item.ItemStack stack) {
        insertStack(stack.toMinecraft());
    }

    public void insertStack(int slot, net.pitan76.mcpitanlib.midohra.item.ItemStack stack) {
        insertStack(slot, stack.toMinecraft());
    }

    public void giveStack(net.pitan76.mcpitanlib.midohra.item.ItemStack stack) {
        giveStack(stack.toMinecraft());
    }

    public Vector3d getPosM() {
        return Vector3d.of(getPos());
    }

    public net.pitan76.mcpitanlib.midohra.util.math.BlockPos getBlockPosM() {
        return net.pitan76.mcpitanlib.midohra.util.math.BlockPos.of(getBlockPos());
    }

    public ItemStack getEquippedStack(ArmorEquipmentType type) {
        return LivingEntityUtil.getEquippedStack(getEntity(), type.getSlot());
    }

    public net.pitan76.mcpitanlib.midohra.item.ItemStack getEquippedStackM(ArmorEquipmentType type) {
        return net.pitan76.mcpitanlib.midohra.item.ItemStack.of(getEquippedStack(type));
    }
}