package net.pitan76.mcpitanlib.api.util.block.entity;

import net.minecraft.inventory.IInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.item.crafting.AbstractCookingRecipe;
import net.minecraft.tileentity.AbstractFurnaceTileEntity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.pitan76.mcpitanlib.api.recipe.MatchGetter;
import net.pitan76.mcpitanlib.api.recipe.input.CompatRecipeInput;
import net.pitan76.mcpitanlib.api.util.recipe.input.SingleStackRecipeInputUtil;

public class FurnaceUtil {
    public static int getDefaultCookTime() {
        return 200;
    }

    public static boolean canUseAsFuel(net.pitan76.mcpitanlib.midohra.item.ItemStack stack, World world) {
        return canUseAsFuel(stack.toMinecraft(), world);
    }

    public static boolean canUseAsFuel(ItemStack stack, World world) {
        return AbstractFurnaceTileEntity.func_213991_b(stack);
    }

    public static void tick(World world, BlockPos pos, AbstractFurnaceTileEntity blockEntity) {
        blockEntity.func_73660_a();
    }

    public static int getCookTime(World world, AbstractFurnaceTileEntity furnace, MatchGetter<IInventory, ? extends AbstractCookingRecipe> matchGetter) {
        return getCookTime(world, furnace.func_70301_a(0), matchGetter);
    }

    public static int getCookTime(World world, ItemStack stack, MatchGetter<IInventory, ? extends AbstractCookingRecipe> matchGetter) {
        CompatRecipeInput<IInventory> input = (CompatRecipeInput<IInventory>) SingleStackRecipeInputUtil.create(stack);

        matchGetter.getFirstMatch(input, world);

        return matchGetter.getFirstMatch(input, world).map((entry) -> ((AbstractCookingRecipe)entry.getRecipe()).func_222137_e()).orElse(200);
    }
}
