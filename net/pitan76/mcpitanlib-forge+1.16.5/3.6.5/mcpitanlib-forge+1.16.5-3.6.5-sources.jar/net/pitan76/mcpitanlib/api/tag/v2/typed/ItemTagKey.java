package net.pitan76.mcpitanlib.api.tag.v2.typed;

import me.shedaniel.architectury.hooks.TagHooks;
import net.minecraft.item.Item;
import net.minecraft.item.crafting.Ingredient;
import net.minecraft.tags.ITag;
import net.pitan76.mcpitanlib.api.tag.v2.CompatTagKey;
import net.pitan76.mcpitanlib.api.tag.v2.CompatTagKeyType;
import net.pitan76.mcpitanlib.api.util.CompatIdentifier;
import net.pitan76.mcpitanlib.api.util.IngredientUtil;

import java.util.List;

public class ItemTagKey extends CompatTagKey<Item> {
    @Deprecated
    public ItemTagKey(ITag.INamedTag<Item> tagKey) {
        super(tagKey);
    }

    public static ItemTagKey of(CompatIdentifier identifier) {
        return new ItemTagKey(TagHooks.getOptional(identifier.toMinecraft(), CompatTagKeyType.ITEM::getTagGroup));
    }

    public Ingredient asIngredient() {
        return IngredientUtil.fromTagByIdentifier(getTagKey().func_230234_a_());
    }

    public List<Item> values() {
        return getTagKey().func_230236_b_();
    }
}
