package net.pitan76.mcpitanlib.api.event.item;

import net.minecraft.client.util.ITooltipFlag;
import net.minecraft.item.ItemStack;
import net.minecraft.util.text.ITextComponent;
import net.minecraft.world.IBlockReader;
import net.minecraft.world.World;
import net.pitan76.mcpitanlib.api.event.BaseEvent;
import net.pitan76.mcpitanlib.api.registry.CompatRegistryLookup;
import net.pitan76.mcpitanlib.api.text.TextComponent;
import net.pitan76.mcpitanlib.api.util.TextUtil;
import org.jetbrains.annotations.Nullable;

import java.util.List;

public class ItemAppendTooltipEvent extends BaseEvent {
    public ItemStack stack;
    public World world;
    public IBlockReader blockView;
    public List<ITextComponent> tooltip;
    public ITooltipFlag context;

    public ItemAppendTooltipEvent(ItemStack stack, @Nullable World world, List<ITextComponent> tooltip, ITooltipFlag context) {
        this.stack = stack;
        this.world = world;
        this.tooltip = tooltip;
        this.context = context;
    }

    public ItemAppendTooltipEvent(ItemStack stack, @Nullable IBlockReader world, List<ITextComponent> tooltip, ITooltipFlag context) {
        this.stack = stack;
        this.blockView = world;
        this.tooltip = tooltip;
        this.context = context;
    }

    public ItemStack getStack() {
        return stack;
    }

    public World getWorld() {
        return world;
    }

    public List<ITextComponent> getTooltip() {
        return tooltip;
    }

    public ITooltipFlag getContext() {
        return context;
    }

    public void addTooltip(ITextComponent text) {
        tooltip.add(text);
    }

    public void addTooltip(List<ITextComponent> texts) {
        tooltip.addAll(texts);
    }

    public boolean removeTooltip(ITextComponent text) {
        return tooltip.remove(text);
    }

    public boolean isCreative() {
        return context.func_194127_a();
    }

    public boolean isAdvanced() {
        return context.func_194127_a();
    }

    public CompatRegistryLookup getRegistryLookup() {
        return new CompatRegistryLookup();
    }

    public void addTooltip(TextComponent textComponent) {
        addTooltip(textComponent.getText());
    }

    public void addTooltip(String text) {
        addTooltip(TextUtil.literal(text));
    }
}
