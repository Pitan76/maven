package net.pitan76.mcpitanlib.api.tile.v2;

import com.mojang.datafixers.types.Type;
import net.minecraft.block.Block;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.tileentity.TileEntityType;
import net.pitan76.mcpitanlib.midohra.block.SupplierBlockWrapper;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Supplier;

public class BlockEntityTypeBuilder<T extends TileEntity> extends net.pitan76.mcpitanlib.api.tile.BlockEntityTypeBuilder<T> {
    private final Factory<? extends T> factory;
    private final Consumer<List<Block>> consumer;

    public BlockEntityTypeBuilder(Factory<? extends T> factory, Consumer<List<Block>> blocks) {
        super(null, null);

        this.factory = factory;
        this.consumer = blocks;
    }

    @Deprecated
    public static <T extends TileEntity> BlockEntityTypeBuilder<T> create(Factory<? extends T> factory, Block... blocks) {
        throw new IllegalStateException("Use create(Factory, Consumer<List<Block>>) instead");
    }

    public static <T extends TileEntity> BlockEntityTypeBuilder<T> create(BlockEntityTypeBuilder.Factory<? extends T> factory, Consumer<List<Block>> blocks) {
        return new BlockEntityTypeBuilder<>(factory, blocks);
    }

    public static <T extends TileEntity> BlockEntityTypeBuilder<T> createA(BlockEntityTypeBuilder.Factory<? extends T> factory, Supplier<Block> block) {
        return new BlockEntityTypeBuilder<>(factory, blocks -> {
            blocks.add(block.get());
        });
    }

    public static <T extends TileEntity> BlockEntityTypeBuilder<T> create(BlockEntityTypeBuilder.Factory<? extends T> factory, SupplierBlockWrapper wrapper) {
        return new BlockEntityTypeBuilder<>(factory, blocks -> {
            blocks.add(wrapper.get());
        });
    }

    @Override
    @Deprecated
    public BlockEntityTypeBuilder<T> addBlock(Block block) {
        return this;
    }

    @Override
    @Deprecated
    public BlockEntityTypeBuilder<T> addBlocks(Block... blocks) {
        return this;
    }

    public TileEntityType<T> build() {
        return build(null);
    }

    public TileEntityType<T> build(Type<?> type) {
        List<Block> blocks = new ArrayList<>();
        if (consumer != null)
            consumer.accept(blocks);

        return TileEntityType.Builder.<T>func_223042_a(factory::create, blocks.toArray(new Block[0])).func_206865_a(type);
    }
}
