package net.pitan76.mcpitanlib.api.util.client.widget;

import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.util.text.ITextComponent;
import net.pitan76.mcpitanlib.api.client.render.handledscreen.RenderArgs;
import net.pitan76.mcpitanlib.api.util.TextUtil;

public class TextFieldUtil {
    public static void setFocused(TextFieldWidget widget, boolean focused) {
        widget.func_146195_b(focused);
    }

    public static void render(TextFieldWidget widget, RenderArgs args) {
        widget.func_230430_a_(args.drawObjectDM.getStack(), args.mouseX, args.mouseY, args.delta);
    }

    public static void setEditable(TextFieldWidget widget, boolean editable) {
        widget.func_146184_c(editable);
    }

    public static void setMaxLength(TextFieldWidget widget, int maxLength) {
        widget.func_146203_f(maxLength);
    }

    public static void setSuggestion(TextFieldWidget widget, String suggestion) {
        widget.func_195612_c(suggestion);
    }

    public static void setText(TextFieldWidget widget, String text) {
        widget.func_146180_a(text);
    }

    public static String getText(TextFieldWidget widget) {
        return widget.func_146179_b();
    }

    public static void setDrawsBackground(TextFieldWidget widget, boolean drawsBackground) {
        widget.func_146185_a(drawsBackground);
    }

    public static void setFocusUnlocked(TextFieldWidget widget, boolean focusUnlocked) {
        widget.func_146205_d(focusUnlocked);
    }

    public static boolean isFocused(TextFieldWidget widget) {
        return widget.func_230999_j_();
    }

    public static boolean keyPressed(TextFieldWidget widget, int keyCode, int scanCode, int modifiers) {
        return widget.func_231046_a_(keyCode, scanCode, modifiers);
    }

    public static boolean keyReleased(TextFieldWidget widget, int keyCode, int scanCode, int modifiers) {
        return widget.func_223281_a_(keyCode, scanCode, modifiers);
    }

    public static boolean charTyped(TextFieldWidget widget, char chr, int modifiers) {
        return widget.func_231042_a_(chr, modifiers);
    }

    public static TextFieldWidget create(FontRenderer renderer, int x, int y, int width, int height, ITextComponent text) {
        return new TextFieldWidget(renderer, x, y, width, height, text);
    }

    public static TextFieldWidget create(FontRenderer renderer, int width, int height, ITextComponent text) {
        return create(renderer, 0, 0, width, height, text);
    }

    public static TextFieldWidget create(FontRenderer renderer, int x, int y, int width, int height) {
        return new TextFieldWidget(renderer, x, y, width, height, TextUtil.empty());
    }

    public static TextFieldWidget create(FontRenderer renderer, int width, int height) {
        return create(renderer, width, height, TextUtil.empty());
    }
}
