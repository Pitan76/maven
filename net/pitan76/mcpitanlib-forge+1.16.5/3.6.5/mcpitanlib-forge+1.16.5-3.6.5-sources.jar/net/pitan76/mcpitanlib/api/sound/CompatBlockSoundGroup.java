package net.pitan76.mcpitanlib.api.sound;

import net.minecraft.block.SoundType;
import net.minecraft.util.SoundEvent;

public class CompatBlockSoundGroup {
    public static final CompatBlockSoundGroup INTENTIONALLY_EMPTY = of(SoundType.field_185851_d);
    public static final CompatBlockSoundGroup WOOD = of(SoundType.field_185848_a);
    public static final CompatBlockSoundGroup GRAVEL = of(SoundType.field_185849_b);
    public static final CompatBlockSoundGroup GRASS = of(SoundType.field_185850_c);
    public static final CompatBlockSoundGroup LILY_PAD = of(SoundType.field_235600_d_);
    public static final CompatBlockSoundGroup STONE = of(SoundType.field_185851_d);
    public static final CompatBlockSoundGroup METAL = of(SoundType.field_185852_e);
    public static final CompatBlockSoundGroup GLASS = of(SoundType.field_185853_f);
    public static final CompatBlockSoundGroup WOOL = of(SoundType.field_185854_g);
    public static final CompatBlockSoundGroup SAND = of(SoundType.field_185855_h);
    public static final CompatBlockSoundGroup SNOW = of(SoundType.field_185856_i);
    public static final CompatBlockSoundGroup POWDER_SNOW = of(SoundType.field_185856_i);
    public static final CompatBlockSoundGroup LADDER = of(SoundType.field_185857_j);
    public static final CompatBlockSoundGroup ANVIL = of(SoundType.field_185858_k);
    public static final CompatBlockSoundGroup SLIME = of(SoundType.field_185859_l);
    public static final CompatBlockSoundGroup HONEY = of(SoundType.field_226947_m_);
    public static final CompatBlockSoundGroup WET_GRASS = of(SoundType.field_211382_m);
    public static final CompatBlockSoundGroup CORAL = of(SoundType.field_211383_n);
    public static final CompatBlockSoundGroup BAMBOO = of(SoundType.field_222468_o);
    public static final CompatBlockSoundGroup BAMBOO_SAPLING = of(SoundType.field_222469_p);
    public static final CompatBlockSoundGroup SCAFFOLDING = of(SoundType.field_222470_q);
    public static final CompatBlockSoundGroup SWEET_BERRY_BUSH = of(SoundType.field_222471_r);
    public static final CompatBlockSoundGroup CROP = of(SoundType.field_222472_s);
    public static final CompatBlockSoundGroup STEM = of(SoundType.field_222473_t);
    public static final CompatBlockSoundGroup VINE = of(SoundType.field_235601_w_);
    public static final CompatBlockSoundGroup NETHER_WART = of(SoundType.field_222474_u);
    public static final CompatBlockSoundGroup LANTERN = of(SoundType.field_222475_v);
    public static final CompatBlockSoundGroup NETHER_STEM = of(SoundType.field_235602_z_);
    public static final CompatBlockSoundGroup NYLIUM = of(SoundType.field_235579_A_);
    public static final CompatBlockSoundGroup FUNGUS = of(SoundType.field_235580_B_);
    public static final CompatBlockSoundGroup ROOTS = of(SoundType.field_235581_C_);
    public static final CompatBlockSoundGroup SHROOMLIGHT = of(SoundType.field_235582_D_);
    public static final CompatBlockSoundGroup WEEPING_VINES = of(SoundType.field_235583_E_);
    public static final CompatBlockSoundGroup WEEPING_VINES_LOW_PITCH = of(SoundType.field_235584_F_);
    public static final CompatBlockSoundGroup SOUL_SAND = of(SoundType.field_235585_G_);
    public static final CompatBlockSoundGroup SOUL_SOIL = of(SoundType.field_235586_H_);
    public static final CompatBlockSoundGroup BASALT = of(SoundType.field_235587_I_);
    public static final CompatBlockSoundGroup WART_BLOCK = of(SoundType.field_235588_J_);
    public static final CompatBlockSoundGroup NETHERRACK = of(SoundType.field_235589_K_);
    public static final CompatBlockSoundGroup NETHER_BRICKS = of(SoundType.field_235590_L_);
    public static final CompatBlockSoundGroup NETHER_SPROUTS = of(SoundType.field_235591_M_);
    public static final CompatBlockSoundGroup NETHER_ORE = of(SoundType.field_235592_N_);
    public static final CompatBlockSoundGroup BONE = of(SoundType.field_235593_O_);
    public static final CompatBlockSoundGroup NETHERITE = of(SoundType.field_235594_P_);
    public static final CompatBlockSoundGroup ANCIENT_DEBRIS = of(SoundType.field_235595_Q_);
    public static final CompatBlockSoundGroup LODESTONE = of(SoundType.field_235596_R_);
    public static final CompatBlockSoundGroup CHAIN = of(SoundType.field_235597_S_);
    public static final CompatBlockSoundGroup NETHER_GOLD_ORE = of(SoundType.field_235598_T_);
    public static final CompatBlockSoundGroup GILDED_BLACKSTONE = of(SoundType.field_235599_U_);
    public static final CompatBlockSoundGroup CANDLE = of(SoundType.field_185851_d);
    public static final CompatBlockSoundGroup AMETHYST_BLOCK = of(SoundType.field_185851_d);
    public static final CompatBlockSoundGroup AMETHYST_CLUSTER = of(SoundType.field_185851_d);
    public static final CompatBlockSoundGroup SMALL_AMETHYST_BUD = of(SoundType.field_185851_d);
    public static final CompatBlockSoundGroup MEDIUM_AMETHYST_BUD = of(SoundType.field_185851_d);
    public static final CompatBlockSoundGroup LARGE_AMETHYST_BUD = of(SoundType.field_185851_d);
    public static final CompatBlockSoundGroup TUFF = of(SoundType.field_185851_d);
    public static final CompatBlockSoundGroup TUFF_BRICKS = of(SoundType.field_185851_d);
    public static final CompatBlockSoundGroup POLISHED_TUFF = of(SoundType.field_185851_d);
    public static final CompatBlockSoundGroup CALCITE = of(SoundType.field_185851_d);
    public static final CompatBlockSoundGroup DRIPSTONE_BLOCK = of(SoundType.field_185851_d);
    public static final CompatBlockSoundGroup POINTED_DRIPSTONE = of(SoundType.field_185851_d);
    public static final CompatBlockSoundGroup COPPER = of(SoundType.field_185852_e);
    public static final CompatBlockSoundGroup COPPER_BULB = of(SoundType.field_185851_d);
    public static final CompatBlockSoundGroup COPPER_GRATE = of(SoundType.field_185851_d);
    public static final CompatBlockSoundGroup CAVE_VINES = of(SoundType.field_185851_d);
    public static final CompatBlockSoundGroup SPORE_BLOSSOM = of(SoundType.field_185851_d);
    public static final CompatBlockSoundGroup AZALEA = of(SoundType.field_185851_d);
    public static final CompatBlockSoundGroup FLOWERING_AZALEA = of(SoundType.field_185851_d);
    public static final CompatBlockSoundGroup MOSS_CARPET = of(SoundType.field_185848_a);
    public static final CompatBlockSoundGroup PINK_PETALS = of(SoundType.field_185851_d);
    public static final CompatBlockSoundGroup MOSS_BLOCK = of(SoundType.field_185851_d);
    public static final CompatBlockSoundGroup BIG_DRIPLEAF = of(SoundType.field_185850_c);
    public static final CompatBlockSoundGroup SMALL_DRIPLEAF = of(SoundType.field_185850_c);
    public static final CompatBlockSoundGroup ROOTED_DIRT = of(SoundType.field_185851_d);
    public static final CompatBlockSoundGroup HANGING_ROOTS = of(SoundType.field_185851_d);
    public static final CompatBlockSoundGroup AZALEA_LEAVES = of(SoundType.field_185850_c);
    public static final CompatBlockSoundGroup SCULK_SENSOR = of(SoundType.field_185851_d);
    public static final CompatBlockSoundGroup SCULK_CATALYST = of(SoundType.field_185851_d);
    public static final CompatBlockSoundGroup SCULK = of(SoundType.field_185851_d);
    public static final CompatBlockSoundGroup SCULK_VEIN = of(SoundType.field_185851_d);
    public static final CompatBlockSoundGroup SCULK_SHRIEKER = of(SoundType.field_185851_d);
    public static final CompatBlockSoundGroup GLOW_LICHEN = of(SoundType.field_185851_d);
    public static final CompatBlockSoundGroup DEEPSLATE = of(SoundType.field_185851_d);
    public static final CompatBlockSoundGroup DEEPSLATE_BRICKS = of(SoundType.field_185851_d);
    public static final CompatBlockSoundGroup DEEPSLATE_TILES = of(SoundType.field_185851_d);
    public static final CompatBlockSoundGroup POLISHED_DEEPSLATE = of(SoundType.field_185851_d);
    public static final CompatBlockSoundGroup FROGLIGHT = of(SoundType.field_185851_d);
    public static final CompatBlockSoundGroup FROGSPAWN = of(SoundType.field_185851_d);
    public static final CompatBlockSoundGroup MANGROVE_ROOTS = of(SoundType.field_185851_d);
    public static final CompatBlockSoundGroup MUDDY_MANGROVE_ROOTS = of(SoundType.field_185851_d);
    public static final CompatBlockSoundGroup MUD = of(SoundType.field_185851_d);
    public static final CompatBlockSoundGroup MUD_BRICKS = of(SoundType.field_185851_d);
    public static final CompatBlockSoundGroup PACKED_MUD = of(SoundType.field_185851_d);
    public static final CompatBlockSoundGroup HANGING_SIGN = of(SoundType.field_185848_a);
    public static final CompatBlockSoundGroup NETHER_WOOD_HANGING_SIGN = of(SoundType.field_185848_a);
    public static final CompatBlockSoundGroup BAMBOO_WOOD_HANGING_SIGN = of(SoundType.field_185848_a);
    public static final CompatBlockSoundGroup BAMBOO_WOOD = of(SoundType.field_185848_a);
    public static final CompatBlockSoundGroup NETHER_WOOD = of(SoundType.field_185848_a);
    public static final CompatBlockSoundGroup CHERRY_WOOD = of(SoundType.field_185848_a);
    public static final CompatBlockSoundGroup CHERRY_SAPLING = of(SoundType.field_185850_c);
    public static final CompatBlockSoundGroup CHERRY_LEAVES = of(SoundType.field_185850_c);
    public static final CompatBlockSoundGroup CHERRY_WOOD_HANGING_SIGN = of(SoundType.field_185848_a);
    public static final CompatBlockSoundGroup CHISELED_BOOKSHELF = of(SoundType.field_185848_a);
    public static final CompatBlockSoundGroup SUSPICIOUS_SAND = of(SoundType.field_185855_h);
    public static final CompatBlockSoundGroup SUSPICIOUS_GRAVEL = of(SoundType.field_185849_b);
    public static final CompatBlockSoundGroup DECORATED_POT = of(SoundType.field_185851_d);
    public static final CompatBlockSoundGroup DECORATED_POT_SHATTER = of(SoundType.field_185851_d);
    public static final CompatBlockSoundGroup TRIAL_SPAWNER = of(SoundType.field_185851_d);
    public static final CompatBlockSoundGroup SPONGE = of(SoundType.field_185850_c);
    public static final CompatBlockSoundGroup WET_SPONGE = of(SoundType.field_211382_m);
    public static final CompatBlockSoundGroup VAULT = of(SoundType.field_185851_d);
    public static final CompatBlockSoundGroup HEAVY_CORE = of(SoundType.field_185851_d);
    public static final CompatBlockSoundGroup COBWEB = of(SoundType.field_185851_d);

    public SoundType blockSoundGroup;

    private final float volume;
    private final float pitch;
    private final SoundEvent breakSound;
    private final SoundEvent stepSound;
    private final SoundEvent placeSound;
    private final SoundEvent hitSound;
    private final SoundEvent fallSound;

    public CompatBlockSoundGroup(SoundType blockSoundGroup) {
        this.blockSoundGroup = blockSoundGroup;

        this.volume = blockSoundGroup.func_185843_a();
        this.pitch = blockSoundGroup.func_185847_b();
        this.breakSound = blockSoundGroup.func_185845_c();
        this.stepSound = blockSoundGroup.func_185844_d();
        this.placeSound = blockSoundGroup.func_185841_e();
        this.hitSound = blockSoundGroup.func_185846_f();
        this.fallSound = blockSoundGroup.func_185842_g();
    }

    public CompatBlockSoundGroup(float volume, float pitch, SoundEvent breakSound, SoundEvent stepSound, SoundEvent placeSound, SoundEvent hitSound, SoundEvent fallSound) {
        this.blockSoundGroup = new SoundType(volume, pitch, breakSound, stepSound, placeSound, hitSound, fallSound);

        this.volume = volume;
        this.pitch = pitch;
        this.breakSound = breakSound;
        this.stepSound = stepSound;
        this.placeSound = placeSound;
        this.hitSound = hitSound;
        this.fallSound = fallSound;
    }

    public SoundType get() {
        if (blockSoundGroup == null) {
            return new SoundType(volume, pitch, breakSound, stepSound, placeSound, hitSound, fallSound);
        }
        return blockSoundGroup;
    }

    public static CompatBlockSoundGroup of(SoundType blockSoundGroup) {
        return new CompatBlockSoundGroup(blockSoundGroup);
    }

    public static CompatBlockSoundGroup of(float volume, float pitch, SoundEvent breakSound, SoundEvent stepSound, SoundEvent placeSound, SoundEvent hitSound, SoundEvent fallSound) {
        return new CompatBlockSoundGroup(volume, pitch, breakSound, stepSound, placeSound, hitSound, fallSound);
    }

    public static CompatBlockSoundGroup of(float volume, float pitch, CompatSoundEvent breakSound, CompatSoundEvent stepSound, CompatSoundEvent placeSound, CompatSoundEvent hitSound, CompatSoundEvent fallSound) {
        return new CompatBlockSoundGroup(volume, pitch, breakSound.get(), stepSound.get(), placeSound.get(), hitSound.get(), fallSound.get());
    }

    public float getVolume() {
        return volume;
    }

    public float getPitch() {
        return pitch;
    }

    public SoundEvent getRawBreakSound() {
        return breakSound;
    }

    public SoundEvent getRawStepSound() {
        return stepSound;
    }

    public SoundEvent getRawPlaceSound() {
        return placeSound;
    }

    public SoundEvent getRawHitSound() {
        return hitSound;
    }

    public SoundEvent getRawFallSound() {
        return fallSound;
    }

    public CompatSoundEvent getBreakSound() {
        return CompatSoundEvent.of(breakSound);
    }

    public CompatSoundEvent getStepSound() {
        return CompatSoundEvent.of(stepSound);
    }

    public CompatSoundEvent getPlaceSound() {
        return CompatSoundEvent.of(placeSound);
    }

    public CompatSoundEvent getHitSound() {
        return CompatSoundEvent.of(hitSound);
    }

    public CompatSoundEvent getFallSound() {
        return CompatSoundEvent.of(fallSound);
    }
}
