package net.pitan76.mcpitanlib.api.event;

import com.mojang.brigadier.exceptions.CommandSyntaxException;
import net.minecraft.command.arguments.EntityArgument;
import net.minecraft.entity.Entity;
import net.pitan76.mcpitanlib.api.command.argument.EntitiesCommand;

public class EntitiesCommandEvent extends RequiredCommandEvent {
    public Entity getValue() {
        try {
            return EntityArgument.func_197088_a(context, ((EntitiesCommand) getCommand()).getArgumentName());
        } catch (CommandSyntaxException e) {
            throw new RuntimeException(e);
        }
    }
}
