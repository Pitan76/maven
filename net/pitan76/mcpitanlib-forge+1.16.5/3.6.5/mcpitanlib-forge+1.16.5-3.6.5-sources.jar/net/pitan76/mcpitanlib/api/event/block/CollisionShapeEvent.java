package net.pitan76.mcpitanlib.api.event.block;

import net.minecraft.block.BlockState;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.shapes.ISelectionContext;
import net.minecraft.world.IBlockReader;

public class CollisionShapeEvent extends OutlineShapeEvent {

    public CollisionShapeEvent(BlockState state, IBlockReader world, BlockPos pos, ISelectionContext context) {
        super(state, world, pos, context);
    }
}
