package net.pitan76.mcpitanlib.api.recipe.v3;

import net.minecraft.item.crafting.IRecipe;
import net.minecraft.item.crafting.IRecipeType;
import net.minecraft.util.ResourceLocation;
import net.pitan76.mcpitanlib.api.recipe.CompatibleRecipeEntry;
import net.pitan76.mcpitanlib.api.recipe.v2.CompatRecipeEntry;
import net.pitan76.mcpitanlib.api.util.CompatIdentifier;
import net.pitan76.mcpitanlib.midohra.recipe.entry.RecipeEntry;

public class CompatRecipe {
    public IRecipe<?> recipe;
    public ResourceLocation id;

    public CompatRecipe(IRecipe<?> recipe, ResourceLocation id) {
        this.recipe = recipe;
        this.id = id;
    }

    @Deprecated
    public CompatRecipe(IRecipe<?> recipe) {
        this.recipe = recipe;
        this.id = recipe.func_199560_c();
    }

    public boolean isNull() {
        return recipe == null;
    }

    public IRecipe<?> getRecipe() {
        return recipe;
    }

    public ResourceLocation getId() {
        return id;
    }

    public CompatIdentifier getCompatId() {
        return CompatIdentifier.fromMinecraft(getId());
    }

    public IRecipeType<?> getType() {
        IRecipe<?> recipe = getRecipe();
        if (recipe == null) return null;

        return recipe.func_222127_g();
    }

    @Deprecated
    public CompatRecipeEntry<?> getRecipeEntry() {
        return new CompatRecipeEntry<>(getId(), "", null, getRecipe());
    }

    @Deprecated
    public CompatibleRecipeEntry getCompatibleRecipeEntry() {
        return new CompatibleRecipeEntry(getRecipe());
    }

    // MidohraAPI
    public net.pitan76.mcpitanlib.midohra.recipe.Recipe getMidohraRecipe() {
        if (getMidohraType() == net.pitan76.mcpitanlib.midohra.recipe.RecipeType.CRAFTING) {
            return net.pitan76.mcpitanlib.midohra.recipe.CraftingRecipe.of((net.minecraft.item.crafting.ICraftingRecipe) getRecipe());
        }

        return net.pitan76.mcpitanlib.midohra.recipe.Recipe.of(getRecipe());
    }

    public net.pitan76.mcpitanlib.midohra.recipe.entry.RecipeEntry getMidohraRecipeEntry() {
        if (getMidohraType() == net.pitan76.mcpitanlib.midohra.recipe.RecipeType.CRAFTING) {
            return net.pitan76.mcpitanlib.midohra.recipe.entry.CraftingRecipeEntry.of((net.minecraft.item.crafting.ICraftingRecipe) getRecipe(), getCompatId());
        }

        return RecipeEntry.of(getRecipe(), getCompatId());
    }

    public net.pitan76.mcpitanlib.midohra.recipe.RecipeType getMidohraType() {
        return net.pitan76.mcpitanlib.midohra.recipe.RecipeType.of(getType());
    }
}
