package net.pitan76.mcpitanlib.api.event.v0;

import dev.architectury.injectables.annotations.ExpectPlatform;
import me.shedaniel.architectury.event.EventResult;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.Hand;
import net.minecraft.util.math.EntityRayTraceResult;
import net.minecraft.world.World;
import net.pitan76.mcpitanlib.api.entity.Player;
import org.jetbrains.annotations.Nullable;

@Deprecated
public class AttackEntityEventRegistry {
    @ExpectPlatform
    public static void register(AttackEntity attackEntity) {

    }

    public interface AttackEntity {
        default EventResult attack(PlayerEntity player, World level, Entity target, Hand hand, @Nullable EntityRayTraceResult result) {
            return attack(new Player(player), level, target, hand, result);
        }

        EventResult attack(Player player, World level, Entity target, Hand hand, @Nullable EntityRayTraceResult result);
    }
}
