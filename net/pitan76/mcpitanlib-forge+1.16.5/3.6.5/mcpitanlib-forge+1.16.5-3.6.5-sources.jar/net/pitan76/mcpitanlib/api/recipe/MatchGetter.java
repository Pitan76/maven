package net.pitan76.mcpitanlib.api.recipe;

import net.minecraft.inventory.IInventory;
import net.minecraft.item.crafting.IRecipe;
import net.minecraft.world.World;
import net.pitan76.mcpitanlib.api.recipe.input.CompatRecipeInput;
import net.pitan76.mcpitanlib.api.recipe.v2.CompatRecipeEntry;

import java.util.Optional;

@Deprecated
public interface MatchGetter<I extends IInventory, T extends IRecipe<I>> {
    Optional<CompatRecipeEntry<I>> getFirstMatch(CompatRecipeInput<I> input, World world);
}
