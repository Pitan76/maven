package net.pitan76.mcpitanlib.api.client.gui.widget;

import com.google.common.collect.ImmutableList;
import com.mojang.blaze3d.matrix.MatrixStack;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.IGuiEventListener;
import net.minecraft.client.gui.widget.Widget;
import net.minecraft.client.gui.widget.list.AbstractOptionList;
import net.pitan76.mcpitanlib.api.client.render.DrawObjectDM;
import net.pitan76.mcpitanlib.api.client.render.handledscreen.RenderArgs;
import org.jetbrains.annotations.Nullable;

import java.util.List;
import java.util.Optional;

@Environment(EnvType.CLIENT)
public class SimpleListWidget extends AbstractOptionList<SimpleListWidget.WidgetEntry> {

    public SimpleListWidget(Minecraft client, int width, int height, int top, int bottom, int itemHeight) {
        super(client, width, height, top, bottom, itemHeight);
        this.field_230676_m_ = false;
    }

    public SimpleListWidget(Minecraft client, int width, int height, int y, int itemHeight) {
        this(client, width, height, y, height - y, itemHeight);
    }

    public void add(Widget widget) {
        super.func_230513_b_(WidgetEntry.create(widget));
    }

    @Override
    public int func_230949_c_() {
        return 400;
    }

    public int getWidth() {
        return this.field_230670_d_;
    }

    public int getHeight() {
        return this.field_230671_e_;
    }

    @Override
    protected int func_230952_d_() {
        return super.func_230952_d_() + 32;
    }

    @Nullable
    public Widget getWidget(int index) {
        if (index < 0 || index >= this.func_231039_at__().size()) {
            return null;
        }
        return this.func_231039_at__().get(index).getWidget();
    }

    public Optional<Widget> getHoveredWidget(double mouseX, double mouseY) {
        for (WidgetEntry entry : this.func_231039_at__()) {
            if (entry.getWidget().func_231047_b_(mouseX, mouseY)) {
                return Optional.of(entry.getWidget());
            }
        }
        return Optional.empty();
    }

    @Deprecated
    @Override
    public void func_230430_a_(MatrixStack matrices, int mouseX, int mouseY, float delta) {
        this.render(new RenderArgs(new DrawObjectDM(matrices), mouseX, mouseY, delta));
    }

    public void render(RenderArgs args) {
        super.func_230430_a_(args.drawObjectDM.getStack(), args.mouseX, args.mouseY, args.delta);
    }

    @Environment(EnvType.CLIENT)
    public static class WidgetEntry extends Entry<WidgetEntry> {
        protected final Widget widget;

        public WidgetEntry(Widget widget) {
            this.widget = widget;
        }

        public static WidgetEntry create(Widget widget) {
            return new WidgetEntry(widget);
        }

        @Deprecated
        @Override
        public void render(MatrixStack matrices, int index, int y, int x, int entryWidth, int entryHeight, int mouseX, int mouseY, boolean hovered, float tickDelta) {
            widget.field_230691_m_ = y;
            widget.func_230430_a_(matrices, mouseX, mouseY, tickDelta);
        }

        @Deprecated
        @Override
        public List<? extends IGuiEventListener> children() {
            return ImmutableList.of(widget);
        }

        public Widget getWidget() {
            return widget;
        }
    }
}
