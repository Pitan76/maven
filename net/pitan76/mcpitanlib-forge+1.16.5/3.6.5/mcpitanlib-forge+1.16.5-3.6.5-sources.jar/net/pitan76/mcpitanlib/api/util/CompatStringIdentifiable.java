package net.pitan76.mcpitanlib.api.util;

import net.minecraft.util.IStringSerializable;

public interface CompatStringIdentifiable extends IStringSerializable {
    @Deprecated
    @Override
    default String func_176610_l() {
        return asString_compat();
    }

    String asString_compat();

    default IStringSerializable get() {
        return this;
    }
}
