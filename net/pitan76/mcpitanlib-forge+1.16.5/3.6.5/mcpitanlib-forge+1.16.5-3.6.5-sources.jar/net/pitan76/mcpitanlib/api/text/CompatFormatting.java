package net.pitan76.mcpitanlib.api.text;

import net.minecraft.util.text.TextFormatting;
import net.pitan76.mcpitanlib.api.util.CompatStringIdentifiable;

public class CompatFormatting implements CompatStringIdentifiable {
    private final TextFormatting formatting;

    public static final CompatFormatting BLACK = of(TextFormatting.BLACK);
    public static final CompatFormatting DARK_BLUE = of(TextFormatting.DARK_BLUE);
    public static final CompatFormatting DARK_GREEN = of(TextFormatting.DARK_GREEN);
    public static final CompatFormatting DARK_AQUA = of(TextFormatting.DARK_AQUA);
    public static final CompatFormatting DARK_RED = of(TextFormatting.DARK_RED);
    public static final CompatFormatting DARK_PURPLE = of(TextFormatting.DARK_PURPLE);
    public static final CompatFormatting GOLD = of(TextFormatting.GOLD);
    public static final CompatFormatting GRAY = of(TextFormatting.GRAY);
    public static final CompatFormatting DARK_GRAY = of(TextFormatting.DARK_GRAY);
    public static final CompatFormatting BLUE = of(TextFormatting.BLUE);
    public static final CompatFormatting GREEN = of(TextFormatting.GREEN);
    public static final CompatFormatting AQUA = of(TextFormatting.AQUA);
    public static final CompatFormatting RED = of(TextFormatting.RED);
    public static final CompatFormatting LIGHT_PURPLE = of(TextFormatting.LIGHT_PURPLE);
    public static final CompatFormatting YELLOW = of(TextFormatting.YELLOW);
    public static final CompatFormatting WHITE = of(TextFormatting.WHITE);
    public static final CompatFormatting OBFUSCATED = of(TextFormatting.OBFUSCATED);
    public static final CompatFormatting BOLD = of(TextFormatting.BOLD);
    public static final CompatFormatting STRIKETHROUGH = of(TextFormatting.STRIKETHROUGH);
    public static final CompatFormatting UNDERLINE = of(TextFormatting.UNDERLINE);
    public static final CompatFormatting ITALIC = of(TextFormatting.ITALIC);
    public static final CompatFormatting RESET = of(TextFormatting.RESET);

    public CompatFormatting(TextFormatting formatting) {
        this.formatting = formatting;
    }

    public static CompatFormatting of(TextFormatting formatting) {
        return new CompatFormatting(formatting);
    }

    public TextFormatting getRaw() {
        return formatting;
    }

    @Override
    public String asString_compat() {
        return formatting.toString();
    }

    public boolean isColor() {
        return formatting.func_96302_c();
    }

    public boolean isModifier() {
        return formatting.func_96301_b();
    }

    public char getCode() {
        return formatting.toString().charAt(1);
    }

    public Integer getColorValue() {
        return formatting.func_211163_e();
    }

    public int getColorIndex() {
        return formatting.func_175746_b();
    }

    @Override
    public String toString() {
        return formatting.toString();
    }

    @Override
    public int hashCode() {
        return formatting.hashCode();
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        CompatFormatting other = (CompatFormatting) obj;
        return formatting.equals(other.formatting);
    }
}
