package net.pitan76.mcpitanlib.api.util;

import net.minecraft.inventory.IInventory;
import net.minecraft.inventory.container.Slot;
import net.minecraft.item.ItemStack;
import net.pitan76.mcpitanlib.api.entity.Player;

public class SlotUtil {
    public static void setStack(Slot slot, ItemStack stack) {
        slot.func_75215_d(stack);
    }

    public static ItemStack getStack(Slot slot) {
        return slot.func_75211_c();
    }

    public static void takeStack(Slot slot, int amount) {
        slot.func_75209_a(amount);
    }

    public static boolean hasStack(Slot slot) {
        return slot.func_75216_d();
    }

    public static void markDirty(Slot slot) {
        slot.func_75218_e();
    }

    public static boolean canInsert(Slot slot, ItemStack stack) {
        return slot.func_75214_a(stack);
    }

    public static boolean canTakeItems(Slot slot) {
        return slot.func_82869_a(null);
    }

    public static void onTakeItem(Slot slot, Player player, ItemStack stack) {
        slot.func_190901_a(player.getEntity(), stack);
    }

    public static IInventory getInventory(Slot slot) {
        return slot.field_75224_c;
    }
}
