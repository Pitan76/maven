package net.pitan76.mcpitanlib.api.item.tool;

import com.google.common.collect.Sets;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.IItemTier;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ToolItem;
import net.minecraft.util.ActionResultType;
import net.minecraft.util.Hand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.pitan76.mcpitanlib.api.event.item.ItemUseOnEntityEvent;
import net.pitan76.mcpitanlib.api.event.item.PostHitEvent;
import net.pitan76.mcpitanlib.api.event.item.PostMineEvent;
import net.pitan76.mcpitanlib.api.item.v2.CompatItemProvider;
import net.pitan76.mcpitanlib.api.item.v2.CompatibleItemSettings;
import net.pitan76.mcpitanlib.api.tag.TagKey;
import net.pitan76.mcpitanlib.api.tag.v2.CompatTagKey;
import net.pitan76.mcpitanlib.api.tag.v2.typed.BlockTagKey;
import net.pitan76.mcpitanlib.api.util.CompatActionResult;
import net.pitan76.mcpitanlib.api.util.block.BlockUtil;

import java.util.Set;

public class CompatibleMiningToolItem extends ToolItem implements CompatItemProvider {

    public CompatibleItemSettings settings;

    @Deprecated
    protected CompatibleMiningToolItem(float attackDamage, float attackSpeed, IItemTier material, Set<Block> effectiveBlocks, Properties settings) {
        super(attackDamage, attackSpeed, material, effectiveBlocks, settings);
    }

    public CompatibleMiningToolItem(CompatibleToolMaterial material, int attackDamage, float attackSpeed, TagKey<Block> tagKey, CompatibleItemSettings settings) {
        this(attackDamage, attackSpeed, material.build(), Sets.newHashSet(BlockUtil.getInTag(tagKey)), settings.build());
        this.settings = settings;
    }

    public CompatibleMiningToolItem(CompatibleToolMaterial material, int attackDamage, float attackSpeed, CompatTagKey<Block> tagKey, CompatibleItemSettings settings) {
        this(attackDamage, attackSpeed, material.build(), Sets.newHashSet(BlockUtil.getInTag(tagKey)), settings.build());
        this.settings = settings;
    }

    public CompatibleMiningToolItem(CompatibleToolMaterial material, int attackDamage, float attackSpeed, BlockTagKey tagKey, CompatibleItemSettings settings) {
        this(attackDamage, attackSpeed, material.build(), Sets.newHashSet(BlockUtil.getInTag(tagKey)), settings.build());
        this.settings = settings;
    }

    @Override
    public CompatibleItemSettings getCompatSettings() {
        return settings;
    }

    public boolean overrideIsSuitableFor(BlockState state) {
        return super.func_150897_b(state);
    }

    public float overrideGetMiningSpeedMultiplier(ItemStack stack, BlockState state) {
        return super.func_150893_a(stack, state);
    }

    /**
     * post hit event
     * @param event PostHitEvent
     * @return boolean
     */
    public boolean postHit(PostHitEvent event) {
        return super.func_77644_a(event.stack, event.target, event.attacker);
    }

    /**
     * post mine event
     * @param event PostMineEvent
     * @return boolean
     */
    public boolean postMine(PostMineEvent event) {
        return super.func_179218_a(event.stack, event.world, event.state, event.pos, event.miner);
    }

    @Deprecated
    @Override
    public boolean func_150897_b(BlockState state) {
        return overrideIsSuitableFor(state);
    }

    @Deprecated
    @Override
    public float func_150893_a(ItemStack stack, BlockState state) {
        return overrideGetMiningSpeedMultiplier(stack, state);
    }

    @Deprecated
    @Override
    public boolean func_77644_a(ItemStack stack, LivingEntity target, LivingEntity attacker) {
        return postHit(new PostHitEvent(stack, target, attacker));
    }

    @Deprecated
    @Override
    public boolean func_179218_a(ItemStack stack, World world, BlockState state, BlockPos pos, LivingEntity miner) {
        return postMine(new PostMineEvent(stack, world, state, pos, miner));
    }

    @Deprecated
    public boolean func_77645_m() {
        return isDamageableOnDefault();
    }

    // -1.20.6
    public boolean isDamageableOnDefault() {
        return super.func_77645_m();
    }

    @Deprecated
    @Override
    public ActionResultType func_111207_a(ItemStack stack, PlayerEntity user, LivingEntity entity, Hand hand) {
        return onRightClickOnEntity(new ItemUseOnEntityEvent(stack, user, entity, hand)).toActionResult();
    }

    @Deprecated
    @Override
    public CompatActionResult onRightClickOnEntity(ItemUseOnEntityEvent event, Options options) {
        return CompatItemProvider.super.onRightClickOnEntity(event, options);
    }

    public CompatActionResult onRightClickOnEntity(ItemUseOnEntityEvent e) {
        return CompatActionResult.of(super.func_111207_a(e.stack, e.user.getEntity(), e.entity, e.hand));
    }
}