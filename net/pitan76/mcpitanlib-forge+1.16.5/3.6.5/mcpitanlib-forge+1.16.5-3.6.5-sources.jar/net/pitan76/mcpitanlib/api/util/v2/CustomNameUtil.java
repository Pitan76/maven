package net.pitan76.mcpitanlib.api.util.v2;

import net.minecraft.item.ItemStack;
import net.minecraft.util.text.ITextComponent;
import net.pitan76.mcpitanlib.api.text.TextComponent;
import net.pitan76.mcpitanlib.api.util.TextUtil;

public class CustomNameUtil {

    public static void setCustomName(ItemStack stack, ITextComponent name) {
        stack.func_200302_a(name);
    }

    public static void setCustomName(ItemStack stack, String name) {
        setCustomNameFromString(stack, name);
    }

    public static void setCustomNameFromString(ItemStack stack, String name) {
        setCustomName(stack, TextUtil.literal(name));
    }

    public static void setCustomNameFromTranslatable(ItemStack stack, String key) {
        setCustomName(stack, TextUtil.translatable(key));
    }

    public static void setCustomName(ItemStack stack, TextComponent name) {
        setCustomName(stack, name.getText());
    }

    public static ITextComponent getCustomName(ItemStack stack) {
        return stack.func_200301_q();
    }

    public static String getCustomNameAsString(ItemStack stack) {
        return getCustomName(stack).getString();
    }

    public static TextComponent getCustomNameAsTextComponent(ItemStack stack) {
        return new TextComponent(getCustomName(stack));
    }

    public static boolean hasCustomName(ItemStack stack) {
        return stack.func_82837_s();
    }

    public static void removeCustomName(ItemStack stack) {
        stack.func_135074_t();
    }
}
