package net.pitan76.mcpitanlib.api.util;

import it.unimi.dsi.fastutil.ints.IntList;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.crafting.Ingredient;
import net.minecraft.tags.ItemTags;
import net.minecraft.util.IItemProvider;
import net.minecraft.util.NonNullList;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.registry.Registry;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class IngredientUtil {
    public static Ingredient fromTagByIdentifier(ResourceLocation id) {
        return Ingredient.func_199805_a(ItemTags.func_199903_a().func_241834_b(id));
    }

    public static Ingredient fromTagByString(String id) {
        return fromTagByIdentifier(new ResourceLocation(id));
    }

    public static Ingredient fromTagByIdentifier(CompatIdentifier id) {
        return fromTagByIdentifier(id.toMinecraft());
    }

    public static List<Item> getItems(Ingredient ingredient) {
        List<Item> items = new ArrayList<>();
        for (int rawId : ingredient.func_194139_b()) {
            try {
                items.add(ItemUtil.fromIndex(rawId));
            } catch (Exception ignored) {}
        }
        return items;
    }

    public static IntList getMatchingStacksIds(Ingredient ingredient) {
        return ingredient.func_194139_b();
    }

    public static List<ItemStack> getMatchingStacksAsList(Ingredient ingredient) {
        List<ItemStack> stacks = new ArrayList<>();

        for (Item item : getItems(ingredient)) {
            stacks.add(new ItemStack(item));
        }

        return stacks;
    }

    public static ItemStack[] getMatchingStacks(Ingredient ingredient) {
        return getMatchingStacksAsList(ingredient).toArray(new ItemStack[0]);
    }

    public static Ingredient empty() {
        return Ingredient.field_193370_a;
    }

    public static Ingredient ofItems(IItemProvider... items) {
        return Ingredient.func_199804_a(items);
    }

    public static NonNullList<Ingredient> buildInput(Object[] input) {
        NonNullList<Ingredient> list = NonNullList.func_191196_a();
        for (Object obj : input) {
            if (obj instanceof Ingredient) {
                list.add((Ingredient) obj);
                continue;
            }

            if (obj instanceof IItemProvider) {
                list.add(ofItems((IItemProvider) obj));
            }
        }
        return list;
    }
}
