package net.pitan76.mcpitanlib.api.util.client;

import net.pitan76.mcpitanlib.api.util.MathUtil;

import static net.pitan76.mcpitanlib.api.util.MathUtil.getRotationDegrees;

import com.mojang.blaze3d.matrix.MatrixStack;

public class MatrixStackUtil {
    public static void multiply(MatrixStack matrixStack, MathUtil.RotationAxisType type, float deg) {
        matrixStack.func_227863_a_(getRotationDegrees(type, deg));
    }

    public static void push(MatrixStack matrices) {
        matrices.func_227860_a_();
    }

    public static void pop(MatrixStack matrices) {
        matrices.func_227865_b_();
    }

    public static void translate(MatrixStack matrices, double x, double y, double z) {
        matrices.func_227861_a_(x, y, z);
    }

    public static void scale(MatrixStack matrices, float x, float y, float z) {
        matrices.func_227862_a_(x, y, z);
    }

    public static MatrixStack.Entry peek(MatrixStack matrices) {
        return matrices.func_227866_c_();
    }
}
