package net.pitan76.mcpitanlib.api.recipe.v2;

import net.minecraft.inventory.IInventory;
import net.minecraft.item.crafting.IRecipe;
import net.minecraft.item.crafting.IRecipeSerializer;
import net.minecraft.item.crafting.IRecipeType;
import net.minecraft.recipe.*;
import net.minecraft.util.ResourceLocation;
import net.pitan76.mcpitanlib.api.util.CompatIdentifier;
import net.pitan76.mcpitanlib.api.util.RecipeUtil;
import org.jetbrains.annotations.Nullable;

@Deprecated
public class CompatRecipeEntry<T extends IInventory> {
    private final IRecipe<T> recipe;

    private ResourceLocation id;

    public String group = "";
    public RecipeUtil.CompatibilityCraftingRecipeCategory category = null;

    @Deprecated
    public CompatRecipeEntry(IRecipe<T> recipe) {
        this.recipe = recipe;
    }

    public CompatRecipeEntry(ResourceLocation id, String group, RecipeUtil.CompatibilityCraftingRecipeCategory category, IRecipe<T> recipe) {
        this.recipe = recipe;
        this.id = id;
        this.group = group;
        this.category = category;
    }

    public CompatRecipeEntry(CompatIdentifier id, String group, RecipeUtil.CompatibilityCraftingRecipeCategory category, IRecipe<T> recipe) {
        this(id.toMinecraft(), group, category, recipe);
    }

    public boolean isNull() {
        return recipe == null;
    }

    public IRecipe<T> getRecipe() {
        return recipe;
    }

    public ResourceLocation getId() {
        return id;
    }

    public CompatIdentifier getCompatId() {
        return CompatIdentifier.fromMinecraft(getId());
    }

    public IRecipeType<?> getType() {
        IRecipe<T> recipe = getRecipe();
        if (recipe == null) return null;

        return recipe.func_222127_g();
    }

    public IRecipeSerializer<?> getSerializer() {
        IRecipe<?> recipe = getRecipe();
        if (recipe == null) return null;

        return recipe.func_199559_b();
    }

    @Nullable
    public RecipeUtil.CompatibilityCraftingRecipeCategory getCategory() {
        return category;
    }

    public String getGroup() {
        return group;
    }
}
