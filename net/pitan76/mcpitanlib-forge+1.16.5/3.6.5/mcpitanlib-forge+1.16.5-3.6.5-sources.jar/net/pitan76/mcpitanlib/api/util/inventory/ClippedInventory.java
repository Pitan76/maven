package net.pitan76.mcpitanlib.api.util.inventory;

import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.inventory.IInventory;
import net.minecraft.item.ItemStack;
import net.pitan76.mcpitanlib.api.util.ItemStackUtil;

public class ClippedInventory implements IInventory, ICompatInventory {

    private final IInventory inventory;
    private final int start;
    private final int end;

    public static ClippedInventory of(IInventory inventory, int start, int end) {
        if (start < 0 || end > inventory.func_70302_i_() || start >= end) {
            throw new IllegalArgumentException("Invalid start or end indices for clipping inventory.");
        }
        return new ClippedInventory(inventory, start, end);
    }

    public static ClippedInventory of(IInventory inventory) {
        return of(inventory, 0, inventory.func_70302_i_());
    }

    public static ClippedInventory of(IInventory inventory, int start) {
        return of(inventory, start, inventory.func_70302_i_());
    }

    public ClippedInventory(IInventory inventory, int start, int end) {
        this.inventory = inventory;
        this.start = start;
        this.end = end;
    }

    @Override
    public int func_70302_i_() {
        return end - start;
    }

    @Override
    public boolean func_191420_l() {
        for (int i = start; i < end; i++) {
            if (!inventory.func_70301_a(i).func_190926_b()) {
                return false;
            }
        }
        return true;
    }

    @Override
    public ItemStack func_70301_a(int slot) {
        return inventory.func_70301_a(start + slot);
    }

    @Override
    public ItemStack func_70298_a(int slot, int amount) {
        return inventory.func_70298_a(start + slot, amount);
    }

    @Override
    public ItemStack func_70304_b(int slot) {
        return inventory.func_70304_b(start + slot);
    }

    @Override
    public void func_70299_a(int slot, ItemStack stack) {
        inventory.func_70299_a(start + slot, stack);
    }

    @Override
    public void func_70296_d() {
        inventory.func_70296_d();
    }

    @Override
    public boolean func_70300_a(PlayerEntity player) {
        return inventory.func_70300_a(player);
    }

    @Override
    public void func_174888_l() {
        for (int i = start; i < end; i++) {
            inventory.func_70299_a(i, ItemStackUtil.empty());
        }
    }

    @Override
    public int func_70297_j_() {
        return inventory.func_70297_j_();
    }
}
