package net.pitan76.mcpitanlib.api.client.gui.widget;

import com.mojang.blaze3d.matrix.MatrixStack;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.text.ITextComponent;
import net.pitan76.mcpitanlib.api.util.client.RenderUtil;

public class RedrawableTexturedButtonWidget extends CompatibleTexturedButtonWidget {
    public ResourceLocation texture;
    public int u;
    public int v;
    public int hoveredVOffset;
    public int textureWidth;
    public int textureHeight;

    public RedrawableTexturedButtonWidget(int x, int y, int width, int height, int u, int v, int hoveredVOffset, ResourceLocation texture, int textureWidth, int textureHeight, IPressable pressAction, ITextComponent message) {
        super(x, y, width, height, u, v, hoveredVOffset, texture, textureWidth, textureHeight, pressAction, message);
        this.textureWidth = textureWidth;
        this.textureHeight = textureHeight;
        this.u = u;
        this.v = v;
        this.hoveredVOffset = hoveredVOffset;
        this.texture = texture;
    }

    public void func_230431_b_(MatrixStack matrices, int mouseX, int mouseY, float delta) {
        RenderUtil.setShaderToPositionTexProgram();
        RenderUtil.setShaderTexture(0, this.texture);
        int i = this.v;
        if (this.func_230449_g_()) {
            i += this.hoveredVOffset;
        }

        RenderUtil.enableDepthTest();
        func_238463_a_(matrices, this.field_230690_l_, this.field_230691_m_, (float)this.u, (float)i, this.field_230688_j_, this.field_230689_k_, this.textureWidth, this.textureHeight);
        if (this.func_230449_g_()) {
            this.func_230443_a_(matrices, mouseX, mouseY);
        }
    }

    public void setTexture(ResourceLocation texture) {
        this.texture = texture;
    }

    public void setU(int u) {
        this.u = u;
    }

    public void setV(int v) {
        this.v = v;
    }

    public void setHoveredVOffset(int hoveredVOffset) {
        this.hoveredVOffset = hoveredVOffset;
    }

    public void setTextureWidth(int textureWidth) {
        this.textureWidth = textureWidth;
    }

    public void setTextureHeight(int textureHeight) {
        this.textureHeight = textureHeight;
    }
}
