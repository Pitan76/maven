package net.pitan76.mcpitanlib.api.command.argument;

import net.minecraft.command.arguments.ItemArgument;
import net.minecraft.item.Item;
import net.pitan76.mcpitanlib.api.event.ItemCommandEvent;
import net.pitan76.mcpitanlib.api.event.ServerCommandEvent;

public abstract class ItemCommand extends RequiredCommand<Item> {
    @Override
    public ItemArgument getArgumentType() {
        return ItemArgument.func_197317_a();
    }

    public abstract void execute(ItemCommandEvent event);

    @Override
    public void execute(ServerCommandEvent event) {
        execute((ItemCommandEvent) event);
    }
}
