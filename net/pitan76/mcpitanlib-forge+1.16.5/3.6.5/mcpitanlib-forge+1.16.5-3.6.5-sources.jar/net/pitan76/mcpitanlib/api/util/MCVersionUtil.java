package net.pitan76.mcpitanlib.api.util;

import net.minecraft.util.SharedConstants;
import net.pitan76.mcpitanlib.api.util.client.ClientUtil;

public class MCVersionUtil {

    public static int getProtocolVersion() {
        return SharedConstants.func_215069_a().getProtocolVersion();
    }

    public static String getGameVersion() {
        return ClientUtil.getClient().func_175600_c();
    }

    public static boolean isSupportedComponent() {
        return getProtocolVersion() >= 766;
    }
}
