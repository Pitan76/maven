package net.pitan76.mcpitanlib.api.block;

import net.minecraft.block.BlockState;
import net.minecraft.block.ITileEntityProvider;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.tileentity.TileEntityType;
import net.minecraft.world.IBlockReader;
import net.minecraft.world.World;
import net.pitan76.mcpitanlib.api.event.block.TileCreateEvent;
import net.pitan76.mcpitanlib.api.tile.ExtendBlockEntityTicker;
import org.jetbrains.annotations.Nullable;

public interface ExtendBlockEntityProvider extends ITileEntityProvider {

    /**
     * @deprecated Use {@link #createBlockEntity(TileCreateEvent)} instead.
     */
    @Deprecated
    @Nullable
    @Override
    default TileEntity func_196283_a_(IBlockReader world) {
        return createBlockEntity(new TileCreateEvent(world));
    }

    /**
     * create instance of BlockEntity
     * @param event TileCreateEvent
     * @return BlockEntity
     *
     * <pre>{@code
     * public BlockEntity createBlockEntity(TileCreateEvent e) {
     *    return new ExampleBlockEntity(e); // ExampleBlockEntity extends CompatBlockEntity
     * }</pre>
     */
    @Nullable
    default TileEntity createBlockEntity(TileCreateEvent event) {
        if (getBlockEntityType() == null) return null;

        // return new ...BlockEntity(world)
        return getBlockEntityType().func_200968_a();
    }

    @Nullable
    default <T extends TileEntity> TileEntityType<T> getBlockEntityType() {
        return null;
    }

    @Nullable
    default <T extends TileEntity> ExtendBlockEntityTicker<T> getCompatibleTicker(World world, BlockState state, TileEntityType<T> type) {

        return null;
    }

    default boolean isTick() {
        return false;
    }
}
