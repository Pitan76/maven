package net.pitan76.mcpitanlib.api.util.entity;

import net.minecraft.entity.Entity;
import net.minecraft.entity.player.ServerPlayerEntity;
import net.minecraft.world.server.ServerWorld;
import net.pitan76.mcpitanlib.api.entity.Player;
import net.pitan76.mcpitanlib.api.sound.CompatSoundCategory;
import net.pitan76.mcpitanlib.api.sound.CompatSoundEvent;

import java.util.Optional;

public class ServerPlayerUtil {
    public static boolean teleport(ServerPlayerEntity serverPlayerEntity, ServerWorld serverWorld, double x, double y, double z, float yaw, float pitch, boolean resetCamera) {
        if (!resetCamera) {
            Entity cameraEntity = serverPlayerEntity.func_175398_C();
            teleport(serverPlayerEntity, serverWorld, x, y, z, yaw, pitch);
            serverPlayerEntity.func_175399_e(cameraEntity);
        }

        teleport(serverPlayerEntity, serverWorld, x, y, z, yaw, pitch);
        return true;
    }

    public static boolean teleport(ServerPlayerEntity serverPlayerEntity, ServerWorld serverWorld, double x, double y, double z, float yaw, float pitch) {
        serverPlayerEntity.func_200619_a(serverWorld, x, y, z, yaw, pitch);
        return true;
    }

    public static boolean teleport(ServerPlayerEntity serverPlayerEntity, ServerWorld serverWorld, double x, double y, double z) {
        return teleport(serverPlayerEntity, serverWorld, x, y, z, serverPlayerEntity.func_195046_g(1.0F), serverPlayerEntity.func_195050_f(1.0F));
    }

    public static boolean teleport(ServerPlayerEntity serverPlayerEntity, net.pitan76.mcpitanlib.midohra.world.ServerWorld serverWorld, double x, double y, double z, float yaw, float pitch, boolean resetCamera) {
        return teleport(serverPlayerEntity, serverWorld.getRaw(), x, y, z, yaw, pitch, resetCamera);
    }

    public static boolean teleport(ServerPlayerEntity serverPlayerEntity, net.pitan76.mcpitanlib.midohra.world.ServerWorld serverWorld, double x, double y, double z, float yaw, float pitch) {
        return teleport(serverPlayerEntity, serverWorld, x, y, z, yaw, pitch, false);
    }

    public static boolean teleport(ServerPlayerEntity serverPlayerEntity, net.pitan76.mcpitanlib.midohra.world.ServerWorld serverWorld, double x, double y, double z) {
        return teleport(serverPlayerEntity, serverWorld, x, y, z, serverPlayerEntity.func_195046_g(1.0F), serverPlayerEntity.func_195050_f(1.0F));
    }

    public static boolean teleport(Player player, net.pitan76.mcpitanlib.midohra.world.ServerWorld serverWorld, double x, double y, double z, float yaw, float pitch, boolean resetCamera) {
        Optional<ServerPlayerEntity> optionalServerPlayer = player.getServerPlayer();
        if (!optionalServerPlayer.isPresent()) return false;

        return teleport(optionalServerPlayer.get(), serverWorld, x, y, z, yaw, pitch, resetCamera);
    }

    public static boolean teleport(Player player, net.pitan76.mcpitanlib.midohra.world.ServerWorld serverWorld, double x, double y, double z, float yaw, float pitch) {
        return teleport(player, serverWorld, x, y, z, yaw, pitch, false);
    }

    public static boolean teleport(Player player, net.pitan76.mcpitanlib.midohra.world.ServerWorld serverWorld, double x, double y, double z) {
        return teleport(player, serverWorld, x, y, z, player.getYaw(), player.getPitch());
    }

    public static boolean teleport(ServerPlayerEntity serverPlayerEntity, double x, double y, double z, boolean particleEffects) {
        return serverPlayerEntity.func_213373_a(x, y, z, particleEffects);
    }

    public static boolean teleport(ServerPlayerEntity serverPlayerEntity, double x, double y, double z) {
        return teleport(serverPlayerEntity, x, y, z, false);
    }

    public static boolean teleport(Player player, double x, double y, double z, boolean particleEffects) {
        Optional<ServerPlayerEntity> optionalServerPlayer = player.getServerPlayer();
        if (!optionalServerPlayer.isPresent()) return false;

        return teleport(optionalServerPlayer.get(), x, y, z, particleEffects);
    }

    public static boolean teleport(Player player, double x, double y, double z) {
        return teleport(player, x, y, z, false);
    }

    public static void playSound(ServerPlayerEntity serverPlayerEntity, CompatSoundEvent soundEvent, CompatSoundCategory category, float volume, float pitch) {
        serverPlayerEntity.func_213823_a(soundEvent.get(), category.get(), volume, pitch);
    }

    public static void playSound(ServerPlayerEntity serverPlayerEntity, CompatSoundEvent soundEvent, float volume, float pitch) {
        serverPlayerEntity.func_184185_a(soundEvent.get(), volume, pitch);
    }

    public static void playSound(ServerPlayerEntity serverPlayerEntity, CompatSoundEvent soundEvent) {
        serverPlayerEntity.func_184185_a(soundEvent.get(), 1.0F, 1.0F);
    }

    public static void playSound(Player player, CompatSoundEvent soundEvent, CompatSoundCategory category, float volume, float pitch) {
        Optional<ServerPlayerEntity> optionalServerPlayer = player.getServerPlayer();
        if (!optionalServerPlayer.isPresent()) return;

        playSound(optionalServerPlayer.get(), soundEvent, category, volume, pitch);
    }

    public static void playSound(Player player, CompatSoundEvent soundEvent, float volume, float pitch) {
        Optional<ServerPlayerEntity> optionalServerPlayer = player.getServerPlayer();
        if (!optionalServerPlayer.isPresent()) return;

        playSound(optionalServerPlayer.get(), soundEvent, volume, pitch);
    }

    public static void playSound(Player player, CompatSoundEvent soundEvent) {
        Optional<ServerPlayerEntity> optionalServerPlayer = player.getServerPlayer();
        if (!optionalServerPlayer.isPresent()) return;

        playSound(optionalServerPlayer.get(), soundEvent);
    }
}
