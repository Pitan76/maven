package net.pitan76.mcpitanlib.api.client.gui.screen;

import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.inventory.container.Container;
import net.minecraft.inventory.container.Slot;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.text.ITextComponent;
import net.pitan76.mcpitanlib.api.client.render.DrawObjectDM;
import net.pitan76.mcpitanlib.api.util.CompatIdentifier;
import net.pitan76.mcpitanlib.guilib.api.render.SlotRenderer;

public abstract class CompatInventoryScreen<S extends Container> extends SimpleInventoryScreen<S> {

    public CompatInventoryScreen(S handler, PlayerInventory inventory, ITextComponent title) {
        super(handler, inventory, title);
    }

    public abstract CompatIdentifier getCompatTexture();

    @Deprecated
    @Override
    public ResourceLocation getTexture() {
        return getCompatTexture().toMinecraft();
    }

    public void drawSlot(DrawObjectDM drawObjectDM, Slot slot) {
        SlotRenderer.drawSlot(drawObjectDM, slot, field_147003_i, field_147009_r);
    }

    public void drawSlots(DrawObjectDM drawObjectDM) {
        SlotRenderer.drawSlots(drawObjectDM, field_147002_h, field_147003_i, field_147009_r);
    }
}
