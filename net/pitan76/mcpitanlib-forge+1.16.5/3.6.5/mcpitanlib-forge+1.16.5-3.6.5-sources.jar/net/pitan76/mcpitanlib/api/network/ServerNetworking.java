package net.pitan76.mcpitanlib.api.network;

import dev.architectury.networking.NetworkManager;
import net.minecraft.entity.player.ServerPlayerEntity;
import net.minecraft.network.PacketBuffer;
import net.minecraft.server.MinecraftServer;
import net.minecraft.util.ResourceLocation;

import static dev.architectury.networking.NetworkManager.Side.C2S;

public class ServerNetworking {
    public static void send(ServerPlayerEntity player, ResourceLocation identifier, PacketBuffer buf) {
        NetworkManager.sendToPlayer(player, identifier, buf);
    }

    public static void send(Iterable<ServerPlayerEntity> players, ResourceLocation identifier, PacketBuffer buf) {
        NetworkManager.sendToPlayers(players, identifier, buf);
    }


    public static void sendAll(MinecraftServer server, ResourceLocation identifier, PacketBuffer buf) {
        send(server.func_184103_al().func_181057_v(), identifier, buf);
    }

    public static void registerReceiver(ResourceLocation identifier, ServerNetworkHandler handler) {
        NetworkManager.registerReceiver(C2S, identifier, ((buf, context) -> handler.receive(context.getPlayer().func_184102_h(), (ServerPlayerEntity) context.getPlayer(), buf)));
    }

    @FunctionalInterface
    public interface ServerNetworkHandler {
        void receive(MinecraftServer server, ServerPlayerEntity player, PacketBuffer buf);
    }

    public static void registerS2CPayloadType(ResourceLocation identifier) {
        // ignore
    }
}
