package net.pitan76.mcpitanlib.api.recipe.input;

import net.minecraft.inventory.IInventory;
import net.minecraft.item.ItemStack;

public class CompatRecipeInput<I extends IInventory> {
    protected I input;

    public CompatRecipeInput(I input) {
        this.input = input;
    }

    public I getInput() {
        return input;
    }

    public ItemStack getStack(int slot) {
        return input.func_70301_a(slot);
    }

    public net.pitan76.mcpitanlib.midohra.item.ItemStack getMidohraStack(int slot) {
        return net.pitan76.mcpitanlib.midohra.item.ItemStack.of(getStack(slot));
    }

    public int getSize() {
        return input.func_70302_i_();
    }

    public boolean isEmpty() {
        return input.func_191420_l();
    }
}
