package net.pitan76.mcpitanlib.api.event;

import net.minecraft.command.arguments.ItemArgument;
import net.minecraft.item.Item;
import net.pitan76.mcpitanlib.api.command.argument.ItemCommand;

public class ItemCommandEvent extends RequiredCommandEvent {
    public Item getValue() {
        return ItemArgument.func_197316_a(context, ((ItemCommand) getCommand()).getArgumentName()).func_197319_a();
    }
}
