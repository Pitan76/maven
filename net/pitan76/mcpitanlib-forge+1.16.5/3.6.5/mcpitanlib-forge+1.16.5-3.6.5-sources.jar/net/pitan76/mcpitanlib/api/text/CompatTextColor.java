package net.pitan76.mcpitanlib.api.text;

import net.minecraft.util.text.Color;
import net.minecraft.util.text.TextFormatting;

public class CompatTextColor {
    private final Color textColor;

    public static final CompatTextColor BLACK = of(Color.func_240744_a_(TextFormatting.BLACK));
    public static final CompatTextColor DARK_BLUE = of(Color.func_240744_a_(TextFormatting.DARK_BLUE));
    public static final CompatTextColor DARK_GREEN = of(Color.func_240744_a_(TextFormatting.DARK_GREEN));
    public static final CompatTextColor DARK_AQUA = of(Color.func_240744_a_(TextFormatting.DARK_AQUA));
    public static final CompatTextColor DARK_RED = of(Color.func_240744_a_(TextFormatting.DARK_RED));
    public static final CompatTextColor DARK_PURPLE = of(Color.func_240744_a_(TextFormatting.DARK_PURPLE));
    public static final CompatTextColor GOLD = of(Color.func_240744_a_(TextFormatting.GOLD));
    public static final CompatTextColor GRAY = of(Color.func_240744_a_(TextFormatting.GRAY));
    public static final CompatTextColor DARK_GRAY = of(Color.func_240744_a_(TextFormatting.DARK_GRAY));
    public static final CompatTextColor BLUE = of(Color.func_240744_a_(TextFormatting.BLUE));
    public static final CompatTextColor GREEN = of(Color.func_240744_a_(TextFormatting.GREEN));
    public static final CompatTextColor AQUA = of(Color.func_240744_a_(TextFormatting.AQUA));
    public static final CompatTextColor RED = of(Color.func_240744_a_(TextFormatting.RED));
    public static final CompatTextColor LIGHT_PURPLE = of(Color.func_240744_a_(TextFormatting.LIGHT_PURPLE));
    public static final CompatTextColor YELLOW = of(Color.func_240744_a_(TextFormatting.YELLOW));
    public static final CompatTextColor WHITE = of(Color.func_240744_a_(TextFormatting.WHITE));

    public CompatTextColor(Color textColor) {
        this.textColor = textColor;
    }

    public Color getRaw() {
        return textColor;
    }

    public static CompatTextColor of(Color textColor) {
        return new CompatTextColor(textColor);
    }

    public static CompatTextColor fromFormatting(TextFormatting formatting) {
        return new CompatTextColor(Color.func_240744_a_(formatting));
    }

    public static CompatTextColor fromFormatting(CompatFormatting formatting) {
        return fromFormatting(formatting.getRaw());
    }

    public static CompatTextColor fromRgb(int rgb) {
        return new CompatTextColor(Color.func_240743_a_(rgb));
    }

    public static CompatTextColor fromRgb(int r, int g, int b) {
        int rgb = (r << 16) | (g << 8) | b;
        return fromRgb(rgb);
    }

    public static CompatTextColor parse(String string) {
        try {
            return parseOrThrow(string);
        } catch (Exception e) {
            return null;
        }
    }

    public static CompatTextColor parseOrThrow(String string) {
        return new CompatTextColor(Color.func_240745_a_(string));
    }

    @Override
    public int hashCode() {
        return textColor.hashCode();
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        CompatTextColor other = (CompatTextColor) obj;
        return textColor.equals(other.textColor);
    }
}
