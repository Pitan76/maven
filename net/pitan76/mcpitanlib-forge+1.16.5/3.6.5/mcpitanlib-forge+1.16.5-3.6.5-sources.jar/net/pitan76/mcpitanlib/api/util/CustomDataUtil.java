package net.pitan76.mcpitanlib.api.util;

import net.minecraft.item.ItemStack;
import net.minecraft.nbt.CompoundNBT;
import java.util.Set;

/**
 * カスタムデータのユーティリティクラス
 */
public class CustomDataUtil {
    /**
     * NBTを取得する。存在しない場合は新しいNBTを作成する。
     * @param stack ItemStack
     * @return NBT
     */
    public static CompoundNBT getOrCreateNbt(ItemStack stack) {
        if (!hasNbt(stack)) {
            return NbtUtil.create();
        }

        return getNbt(stack);
    }

    /**
     * NBTを設定する。
     * @param stack ItemStack
     * @param nbt NBT
     */
    public static void setNbt(ItemStack stack, CompoundNBT nbt) {
        CompoundNBT components = NbtUtil.create();
        if (hasNbt(stack)) {
            components = stack.func_77978_p().func_74775_l("components");
        }
        components.func_218657_a("minecraft:custom_data", nbt);
        stack.func_196082_o().func_218657_a("components", components);
    }

    /**
     * NBTが存在するかどうかを取得する。
     * @param stack ItemStack
     * @return NBTが存在するかどうか
     */
    public static boolean hasNbt(ItemStack stack) {
        if (stack.func_77978_p() == null) return false;

        return stack.func_77978_p().func_74764_b("components") &&
                stack.func_77978_p().func_74775_l("components").func_74764_b("minecraft:custom_data");
    }

    /**
     * NBTを取得する。
     * @param stack ItemStack
     * @return NBT
     */
    public static CompoundNBT getNbt(ItemStack stack) {
        CompoundNBT customData = NbtUtil.create();
        if (!hasNbt(stack))
            return customData;

        if (stack.func_77978_p().func_74764_b("components")) {
            CompoundNBT components = stack.func_77978_p().func_74775_l("components");
            if (components.func_74764_b("minecraft:custom_data")) {
                customData = components.func_74775_l("minecraft:custom_data").func_74737_b();
            }
        }
        return customData;
    }

    /**
     * 値を設定する。
     * @param stack ItemStack
     * @param key キー
     * @param value 値
     */
    public static void put(ItemStack stack, String key, CompoundNBT value) {
        CompoundNBT nbt = getOrCreateNbt(stack);
        NbtUtil.put(nbt, key, value);
        setNbt(stack, nbt);
    }

    /**
     * 値を取得する。
     * @param stack ItemStack
     * @param key キー
     * @return 値
     */
    public static CompoundNBT get(ItemStack stack, String key) {
        CompoundNBT nbt = getNbt(stack);
        return nbt.func_74775_l(key);
    }

    /**
     * 値を削除する。
     * @param stack ItemStack
     * @param key キー
     */
    public static void remove(ItemStack stack, String key) {
        CompoundNBT nbt = getNbt(stack);
        nbt.func_82580_o(key);
        setNbt(stack, nbt);
    }

    /**
     * 値が存在するかどうかを取得する。
     * @param stack ItemStack
     * @param key キー
     * @return 値が存在するかどうか
     */
    public static boolean has(ItemStack stack, String key) {
        if (!hasNbt(stack))
            return false;

        CompoundNBT nbt = getNbt(stack);
        return nbt.func_74764_b(key);
    }

    /**
     * 指定した型の値を取得する
     * @param stack ItemStack
     * @param key キー
     * @param clazz クラス
     * @param <T> 値
     */
    public static <T> T get(ItemStack stack, String key, Class<T> clazz) {
        CompoundNBT nbt = getNbt(stack);
        return NbtUtil.get(nbt, key, clazz);
    }

    /**
     * 値を設定する。
     * @param stack ItemStack
     * @param key キー
     * @param value 値
     */
    public static <T> void set(ItemStack stack, String key, T value) {
        CompoundNBT nbt = getOrCreateNbt(stack);
        NbtUtil.set(nbt, key, value);
        setNbt(stack, nbt);
    }

    /**
     * キーの一覧を取得する。
     * @param stack ItemStack
     * @return キーの一覧
     */
    public static Set<String> getKeys(ItemStack stack) {
        CompoundNBT nbt = getNbt(stack);
        return NbtUtil.getKeys(nbt);
    }

    /**
     * set(stack, key, value) のエイリアス
     * @param stack ItemStack
     * @param key キー
     * @param value 値
     */
    public static <T> void put(ItemStack stack, String key, T value) {
        set(stack, key, value);
    }

    /**
     * has(stack, key) のエイリアス
     * @param stack ItemStack
     * @param key キー
     * @return 値が存在するかどうか
     */
    public static boolean contains(ItemStack stack, String key) {
        return has(stack, key);
    }

    /**
     * 1.20.3以前下位互換のための修正用
     * @param stack ItemStack
     * @param keys 移植するキー
     */
    public static void fix_oldNbt(ItemStack stack, String[] keys) {
        CompoundNBT customData = getOrCreateNbt(stack);

        for (String key : keys) {
            if (stack.func_77978_p().func_74764_b(key)) {
                customData.func_218657_a(key, stack.func_77978_p().func_74781_a(key));
                stack.func_77978_p().func_82580_o(key);
            }
        }

        setNbt(stack, customData);
    }

    /**
     * カスタムNBTを削除する
     * @param stack ItemStack
     */
    public static void remove(ItemStack stack) {
        CompoundNBT nbt = stack.func_196082_o();
        if (nbt.func_74764_b("components")) {
            CompoundNBT components = nbt.func_74775_l("components");
            components.func_82580_o("minecraft:custom_data");
            nbt.func_218657_a("components", components);
        }
    }
}
