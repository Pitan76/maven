package net.pitan76.mcpitanlib.api.item.v2;

import net.minecraft.block.Block;
import net.minecraft.client.util.ITooltipFlag;
import net.minecraft.item.BlockItem;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemUseContext;
import net.minecraft.util.ActionResultType;
import net.minecraft.util.text.ITextComponent;
import net.minecraft.world.World;
import net.pitan76.mcpitanlib.api.event.item.ItemAppendTooltipEvent;
import net.pitan76.mcpitanlib.api.event.item.ItemUseOnBlockEvent;
import net.pitan76.mcpitanlib.api.item.CompatibleItemSettings;
import net.pitan76.mcpitanlib.api.item.ExtendItemProvider;
import net.pitan76.mcpitanlib.api.util.CompatActionResult;
import net.pitan76.mcpitanlib.mixin.ItemUsageContextMixin;
import org.jetbrains.annotations.Nullable;

import java.util.List;

public class ExtendBlockItem extends BlockItem implements ExtendItemProvider {
    public ExtendBlockItem(Block block, Properties settings) {
        super(block, settings);
    }

    public ExtendBlockItem(Block block, CompatibleItemSettings settings) {
        this(block, settings.build());
    }

    @Deprecated
    @Override
    public ActionResultType func_195939_a(ItemUseContext context) {
        ItemUsageContextMixin contextAccessor = (ItemUsageContextMixin) context;
        return onRightClickOnBlock(new ItemUseOnBlockEvent(context.func_195999_j(), context.func_221531_n(), contextAccessor.getHit())).toActionResult();
    }

    @Deprecated
    @Override
    public CompatActionResult onRightClickOnBlock(ItemUseOnBlockEvent event, Options options) {
        return ExtendItemProvider.super.onRightClickOnBlock(event, options);
    }

    public CompatActionResult onRightClickOnBlock(ItemUseOnBlockEvent event) {
        return CompatActionResult.create(super.func_195939_a(event.toIUC()));
    }

    @Deprecated
    @Override
    public void func_77624_a(ItemStack stack, @Nullable World world, List<ITextComponent> tooltip, ITooltipFlag context) {
        appendTooltip(new ItemAppendTooltipEvent(stack, world, tooltip, context));
    }

    @Deprecated
    @Override
    public void appendTooltip(ItemAppendTooltipEvent event, Options options) {
        ExtendItemProvider.super.appendTooltip(event, options);
    }

    public void appendTooltip(ItemAppendTooltipEvent event) {
        super.func_77624_a(event.getStack(), event.getWorld(), event.getTooltip(), event.getContext());
    }

    @Override
    public Block func_179223_d() {
        return super.func_179223_d();
    }
}
