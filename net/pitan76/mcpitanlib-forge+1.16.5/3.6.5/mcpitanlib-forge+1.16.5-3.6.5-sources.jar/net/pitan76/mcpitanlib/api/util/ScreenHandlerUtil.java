package net.pitan76.mcpitanlib.api.util;

import me.shedaniel.architectury.registry.MenuRegistry;
import me.shedaniel.architectury.registry.menu.ExtendedMenuProvider;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.entity.player.ServerPlayerEntity;
import net.minecraft.inventory.container.Container;
import net.minecraft.inventory.container.ContainerType;
import net.minecraft.inventory.container.INamedContainerProvider;
import net.minecraft.inventory.container.Slot;
import net.minecraft.item.ItemStack;
import net.minecraft.network.PacketBuffer;
import net.minecraft.util.NonNullList;
import net.minecraft.util.registry.Registry;
import net.pitan76.mcpitanlib.api.util.client.ClientUtil;
import net.pitan76.mcpitanlib.midohra.server.MCServer;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;

public class ScreenHandlerUtil {
    public static NonNullList<Slot> getSlots(Container screenHandler) {
        NonNullList<Slot> slots = NonNullList.func_191196_a();
        slots.addAll(screenHandler.field_75151_b);
        return slots;
    }

    public static Slot getSlot(Container screenHandler, int index) {
        return screenHandler.func_75139_a(index);
    }

    public static List<ContainerType<?>> getAllScreenHandlerTypes() {
        List<ContainerType<?>> screenHandlerTypes = new ArrayList<>();
        for (ContainerType<?> screenHandler : Registry.field_218366_G) {
            screenHandlerTypes.add(screenHandler);
        }
        return screenHandlerTypes;
    }

    public static void openExtendedMenu(ServerPlayerEntity player, INamedContainerProvider provider, Consumer<PacketBuffer> bufWriter) {
        MenuRegistry.openExtendedMenu(player, provider, bufWriter);
    }

    public static void openExtendedMenu(ServerPlayerEntity player, ExtendedMenuProvider provider) {
        MenuRegistry.openExtendedMenu(player, provider);
    }

    public static void openMenu(ServerPlayerEntity player, INamedContainerProvider provider) {
        MenuRegistry.openMenu(player, provider);
    }

    public static int getRawId(ContainerType<?> type) {
        return Registry.field_218366_G.func_148757_b(type);
    }

    public static ContainerType<?> fromIndex(int index) {
        return Registry.field_218366_G.func_148745_a(index);
    }

    public static ItemStack getCursorStack(Container screenHandler) {
        if (PlatformUtil.isClient()) {
            return ClientUtil.getClientPlayer().field_71071_by.func_70445_o();
        }
        for (Slot slot : screenHandler.field_75151_b) {
            if (slot.field_75224_c instanceof PlayerInventory) {
                PlayerInventory inventory = (PlayerInventory) slot.field_75224_c;
                return inventory.func_70445_o();
            }
        }
        for (ItemStack tmp : screenHandler.func_75138_a()) {
            if (tmp.func_234694_A_() instanceof ServerPlayerEntity) {
                ServerPlayerEntity player = (ServerPlayerEntity) tmp.func_234694_A_();
                return player.field_71071_by.func_70445_o();
            }
        }
        return ItemStack.field_190927_a;
    }

    public static net.pitan76.mcpitanlib.midohra.item.ItemStack getCursorStackM(Container screenHandler) {
        return net.pitan76.mcpitanlib.midohra.item.ItemStack.of(getCursorStack(screenHandler));
    }

    public static void setCursorStack(Container screenHandler, ItemStack stack) {
        if (PlatformUtil.isClient()) {
            ClientUtil.getClientPlayer().field_71071_by.func_70437_b(stack);
            return;
        }
        for (Slot slot : screenHandler.field_75151_b) {
            if (slot.field_75224_c instanceof PlayerInventory) {
                PlayerInventory inventory = (PlayerInventory) slot.field_75224_c;
                inventory.func_70437_b(stack);
                return;
            }
        }
        for (ItemStack tmp : screenHandler.func_75138_a()) {
            if (tmp.func_234694_A_() instanceof ServerPlayerEntity) {
                ServerPlayerEntity player = (ServerPlayerEntity) tmp.func_234694_A_();
                player.field_71071_by.func_70437_b(stack);
                return;
            }
        }
    }

    public static void setCursorStackM(Container screenHandler, net.pitan76.mcpitanlib.midohra.item.ItemStack stack) {
        setCursorStack(screenHandler, stack.toMinecraft());
    }
}
