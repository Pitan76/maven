package net.pitan76.mcpitanlib.api.util;

import net.minecraft.server.MinecraftServer;
import net.minecraft.server.management.PlayerList;
import net.minecraft.world.World;
import net.pitan76.mcpitanlib.api.entity.Player;

public class ServerUtil {
    public static MinecraftServer getServer(World world) {
        return world.func_73046_m();
    }

    public static String getIP(MinecraftServer server) {
        return server.func_71211_k();
    }

    public static int getPort(MinecraftServer server) {
        return server.func_71215_F();
    }

    public static String getMotd(MinecraftServer server) {
        return server.func_71273_Y();
    }

    public static String getServerModName(MinecraftServer server) {
        return server.getServerModName();
    }

    public static int getMaxPlayerCount(MinecraftServer server) {
        return server.func_71275_y();
    }

    public static int getCurrentPlayerCount(MinecraftServer server) {
        return server.func_71233_x();
    }

    public static boolean isOnlineMode(MinecraftServer server) {
        return server.func_71266_T();
    }

    public static boolean isServerRunning(MinecraftServer server) {
        return server.func_71278_l();
    }

    public static boolean isServerDedicated(MinecraftServer server) {
        return server.func_71262_S();
    }

    public static boolean isSingleplayer(MinecraftServer server) {
        return server.func_71264_H();
    }

    public static PlayerList getPlayerManager(MinecraftServer server) {
        return server.func_184103_al();
    }

    public static MinecraftServer getServer(Player player) {
        return getServer(player.getWorld());
    }

    public static void execute(MinecraftServer server, Runnable runnable) {
        server.execute(runnable);
    }
}
