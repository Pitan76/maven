package net.pitan76.mcpitanlib.api.recipe.v2;

import net.minecraft.inventory.IInventory;
import net.minecraft.item.crafting.IRecipe;
import net.pitan76.mcpitanlib.api.util.CompatIdentifier;
import net.pitan76.mcpitanlib.api.util.RecipeUtil;

@Deprecated
public class CompatRecipeNonEntry<T extends IInventory> extends CompatRecipeEntry<T> {
    public CompatRecipeNonEntry(IRecipe<T> recipe) {
        super(CompatIdentifier.EMPTY, "", RecipeUtil.CompatibilityCraftingRecipeCategory.MISC, recipe);
    }

    public static CompatRecipeNonEntry<?> create(IRecipe<?> recipe) {
        return new CompatRecipeNonEntry<>(recipe);
    }

    @Override
    public IRecipe<T> getRecipe() {
        return super.getRecipe();
    }

    public IRecipe<?> getRawRecipe() {
        return super.getRecipe();
    }
}
