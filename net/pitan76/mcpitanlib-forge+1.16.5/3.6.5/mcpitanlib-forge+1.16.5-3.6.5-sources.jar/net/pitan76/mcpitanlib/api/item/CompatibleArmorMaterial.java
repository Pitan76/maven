package net.pitan76.mcpitanlib.api.item;

import net.minecraft.inventory.EquipmentSlotType;
import net.minecraft.item.IArmorMaterial;
import net.minecraft.item.crafting.Ingredient;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.SoundEvent;

public interface CompatibleArmorMaterial {
    int getDurability(ArmorEquipmentType type);

    int getProtection(ArmorEquipmentType type);

    int getEnchantability();

    SoundEvent getEquipSound();

    Ingredient getRepairIngredient();

    /**
     * @return the name of the material
     */
    default String getName() {
        return getId().func_110623_a();
    }

    /**
     * @return the id of the material
     */
    ResourceLocation getId();

    float getToughness();

    float getKnockbackResistance();

    @Deprecated
    default IArmorMaterial build() {
        return new IArmorMaterial() {
            @Override
            public int func_200896_a(EquipmentSlotType slot) {
                return CompatibleArmorMaterial.this.getDurability(ArmorEquipmentType.of(slot));
            }

            @Override
            public int func_200902_b(EquipmentSlotType slot) {
                return CompatibleArmorMaterial.this.getProtection(ArmorEquipmentType.of(slot));
            }

            @Override
            public int func_200900_a() {
                return CompatibleArmorMaterial.this.getEnchantability();
            }

            @Override
            public SoundEvent func_200899_b() {
                return CompatibleArmorMaterial.this.getEquipSound();
            }

            @Override
            public Ingredient func_200898_c() {
                return CompatibleArmorMaterial.this.getRepairIngredient();
            }

            @Override
            public String func_200897_d() {
                return CompatibleArmorMaterial.this.getName();
            }

            @Override
            public float func_200901_e() {
                return CompatibleArmorMaterial.this.getToughness();
            }

            @Override
            public float func_230304_f_() {
                return CompatibleArmorMaterial.this.getKnockbackResistance();
            }
        };
    }
}
