package net.pitan76.mcpitanlib.api.state.property;

import java.util.function.Predicate;
import net.minecraft.util.IStringSerializable;

public class EnumProperty<T extends Enum<T> & IStringSerializable> implements IProperty<T> {

    private final net.minecraft.state.EnumProperty<T> property;

    public EnumProperty(String name, Class<T> type) {
        this(net.minecraft.state.EnumProperty.func_177709_a(name, type));
    }

    public EnumProperty(String name, Class<T> type, Predicate<T> filter) {
        this(net.minecraft.state.EnumProperty.func_177708_a(name, type, filter));
    }

    public EnumProperty(net.minecraft.state.EnumProperty<T> property) {
        this.property = property;
    }

    public static <T extends Enum<T> & IStringSerializable> EnumProperty<T> of(String name, Class<T> type) {
        return new EnumProperty<>(name, type);
    }

    public static <T extends Enum<T> & IStringSerializable> EnumProperty<T> of(String name, Class<T> type, Predicate<T> filter) {
        return new EnumProperty<>(name, type, filter);
    }


    public static <T extends Enum<T> & IStringSerializable> EnumProperty<T> of(net.minecraft.state.EnumProperty<T> property) {
        return new EnumProperty<>(property);
    }

    @Override
    public net.minecraft.state.EnumProperty<T> getProperty() {
        return property;
    }
}
