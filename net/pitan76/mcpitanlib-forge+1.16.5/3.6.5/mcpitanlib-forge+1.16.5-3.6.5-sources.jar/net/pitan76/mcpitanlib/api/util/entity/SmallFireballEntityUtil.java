package net.pitan76.mcpitanlib.api.util.entity;

import net.minecraft.entity.projectile.SmallFireballEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.util.math.vector.Vector3d;
import net.minecraft.world.World;

public class SmallFireballEntityUtil {
    public static SmallFireballEntity create(World world, double x, double y, double z, double velocityX, double velocityY, double velocityZ) {
        return new SmallFireballEntity(world, x, y, z, velocityX, velocityY, velocityZ);
    }

    public static SmallFireballEntity create(World world, double x, double y, double z, Vector3d velocity) {
        return create(world, x, y, z, velocity.field_72450_a, velocity.field_72448_b, velocity.field_72449_c);
    }

    public static void setVelocity(SmallFireballEntity entity, double x, double y, double z, float velocity, float divergence) {
        entity.func_70186_c(x, y, z, velocity, divergence);
    }

    public static void setItem(SmallFireballEntity entity, ItemStack stack) {
        entity.func_213898_b(stack);
    }

    public static ItemStack getItem(SmallFireballEntity entity) {
        return entity.func_184543_l();
    }
}
