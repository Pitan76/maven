package net.pitan76.mcpitanlib.api.block.v2;

import net.minecraft.block.StairsBlock;
import net.minecraft.state.properties.Half;
import net.minecraft.state.properties.StairsShape;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.shapes.ISelectionContext;
import net.minecraft.util.math.shapes.VoxelShape;
import net.minecraft.world.IBlockReader;
import net.pitan76.mcpitanlib.api.block.args.v2.CollisionShapeEvent;
import net.pitan76.mcpitanlib.api.block.args.v2.OutlineShapeEvent;
import net.pitan76.mcpitanlib.api.state.property.*;
import net.pitan76.mcpitanlib.midohra.block.BlockState;

public class CompatStairsBlock extends net.pitan76.mcpitanlib.api.block.CompatStairsBlock {

    public static final DirectionProperty FACING = CompatProperties.ofDir(StairsBlock.field_176309_a);
    public static final EnumProperty<Half> HALF = CompatProperties.of(StairsBlock.field_176308_b);
    public static final EnumProperty<StairsShape> SHAPE = CompatProperties.of(StairsBlock.field_176310_M);
    public static final BooleanProperty WATERLOGGED = CompatProperties.of(StairsBlock.field_204513_t);

    public static final BlockHalfProperty COMPAT_HALF = BlockHalfProperty.ofRaw(StairsBlock.field_176308_b);
    public static final StairShapeProperty COMPAT_SHAPE = StairShapeProperty.ofRaw(StairsBlock.field_176310_M);

    public CompatStairsBlock(net.minecraft.block.BlockState baseBlockState, CompatibleBlockSettings settings) {
        super(baseBlockState, settings);
    }

    public CompatStairsBlock(BlockState baseBlockState, CompatibleBlockSettings settings) {
        this(baseBlockState.toMinecraft(), settings);
    }

    public VoxelShape getOutlineShape(OutlineShapeEvent e) {
        return super.func_220053_a(e.state.toMinecraft(), e.world.getRaw(), e.pos.toMinecraft(), e.context);
    }

    public VoxelShape getCollisionShape(CollisionShapeEvent e) {
        return super.func_220071_b(e.state.toMinecraft(), e.world.getRaw(), e.pos.toMinecraft(), e.context);
    }

    @Deprecated
    @Override
    public VoxelShape getOutlineShape(net.pitan76.mcpitanlib.api.event.block.OutlineShapeEvent e) {
        return getOutlineShape(new OutlineShapeEvent(e.state, e.world, e.pos, e.context));
    }

    @Deprecated
    @Override
    public VoxelShape func_220053_a(net.minecraft.block.BlockState state, IBlockReader world, BlockPos pos, ISelectionContext context) {
        return getOutlineShape(new OutlineShapeEvent(state, world, pos, context));
    }

    @Deprecated
    @Override
    public VoxelShape getOutlineShape(OutlineShapeEvent e, Options options) {
        return super.getOutlineShape(e, options);
    }

    @Override
    public VoxelShape func_220071_b(net.minecraft.block.BlockState state, IBlockReader world, BlockPos pos, ISelectionContext context) {
        return getCollisionShape(new CollisionShapeEvent(state, world, pos, context));
    }

    @Deprecated
    @Override
    public VoxelShape getCollisionShape(CollisionShapeEvent event, Options options) {
        return super.getCollisionShape(event, options);
    }
}
