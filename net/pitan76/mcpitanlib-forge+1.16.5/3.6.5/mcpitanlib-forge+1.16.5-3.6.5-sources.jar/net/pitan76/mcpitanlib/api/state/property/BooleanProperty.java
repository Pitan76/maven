package net.pitan76.mcpitanlib.api.state.property;

public class BooleanProperty implements IProperty<Boolean> {

    private final net.minecraft.state.BooleanProperty property;

    public BooleanProperty(String name) {
        this(net.minecraft.state.BooleanProperty.func_177716_a(name));
    }

    public BooleanProperty(net.minecraft.state.BooleanProperty property) {
        this.property = property;
    }

    public static BooleanProperty of(String name) {
        return new BooleanProperty(name);
    }

    public static BooleanProperty of(net.minecraft.state.BooleanProperty property) {
        return new BooleanProperty(property);
    }

    @Override
    public net.minecraft.state.BooleanProperty getProperty() {
        return property;
    }
}
