package net.pitan76.mcpitanlib.api.event;

import com.mojang.brigadier.exceptions.CommandSyntaxException;
import net.minecraft.command.arguments.EntityArgument;
import net.minecraft.entity.Entity;
import net.pitan76.mcpitanlib.api.command.argument.PlayersCommand;

public class PlayersCommandEvent extends RequiredCommandEvent {
    public Entity getValue() {
        try {
            return EntityArgument.func_197089_d(context, ((PlayersCommand) getCommand()).getArgumentName());
        } catch (CommandSyntaxException e) {
            throw new RuntimeException(e);
        }
    }
}
