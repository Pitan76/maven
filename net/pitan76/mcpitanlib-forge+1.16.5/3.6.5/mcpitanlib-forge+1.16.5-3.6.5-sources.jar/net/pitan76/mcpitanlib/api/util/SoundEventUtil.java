package net.pitan76.mcpitanlib.api.util;

import net.minecraft.util.ResourceLocation;
import net.minecraft.util.SoundEvent;
import net.minecraft.util.registry.Registry;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class SoundEventUtil {
    public static ResourceLocation getId(SoundEvent soundEvent) {
        return soundEvent.func_187503_a();
    }

    public static SoundEvent getSoundEvent(ResourceLocation id) {
        return new SoundEvent(id);
    }

    public static CompatIdentifier getCompatId(SoundEvent soundEvent) {
        return CompatIdentifier.fromMinecraft(getId(soundEvent));
    }

    public static SoundEvent getSoundEvent(CompatIdentifier id) {
        return getSoundEvent(id.toMinecraft());
    }

    public static List<SoundEvent> getAllSoundEvents() {
        return Registry.field_212633_v.func_201756_e().collect(Collectors.toList());
    }

    public static List<ResourceLocation> getAllSoundEventIds() {
        return new ArrayList<>(Registry.field_212633_v.func_148742_b());
    }
}
