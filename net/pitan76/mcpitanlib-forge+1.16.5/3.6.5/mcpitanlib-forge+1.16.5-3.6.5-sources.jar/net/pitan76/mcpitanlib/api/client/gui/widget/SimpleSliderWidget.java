package net.pitan76.mcpitanlib.api.client.gui.widget;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.gui.widget.AbstractSlider;
import net.minecraft.util.text.ITextComponent;
import net.pitan76.mcpitanlib.api.client.render.DrawObjectDM;
import net.pitan76.mcpitanlib.api.client.render.handledscreen.RenderArgs;
import net.pitan76.mcpitanlib.api.util.TextUtil;
import com.mojang.blaze3d.matrix.MatrixStack;
import java.util.function.Consumer;
import java.util.function.Function;

@Environment(EnvType.CLIENT)
public class SimpleSliderWidget extends AbstractSlider {
    protected final Function<Double, ITextComponent> textGetter;
    protected final Consumer<Double> changeCallback;
    public SimpleListWidget listWidget = null;

    public SimpleSliderWidget(int x, int y, int width, int height, ITextComponent text, double defaultValue, ValueTextGetter<Double> valueTextGetter, Consumer<Double> changeCallback) {
        super(x, y, width, height, text, defaultValue);
        this.textGetter = (Double value) -> valueTextGetter.get(text, value);
        this.changeCallback = changeCallback;
        this.func_230979_b_();
    }
    public SimpleSliderWidget(int x, int y, int width, int height, double defaultValue, ValueTextGetter<Double> valueTextGetter, Consumer<Double> changeCallback) {
        this(x, y, width, height, TextUtil.empty(), defaultValue, valueTextGetter, changeCallback);
    }

    public SimpleSliderWidget(int x, int y, int width, ITextComponent text, double defaultValue, ValueTextGetter<Double> valueTextGetter, Consumer<Double> changeCallback) {
        this(x, y, width, 20, text, defaultValue, valueTextGetter, changeCallback);
    }

    public SimpleSliderWidget(int x, int y, int width, double defaultValue, ValueTextGetter<Double> valueTextGetter, Consumer<Double> changeCallback) {
        this(x, y, width, 20, defaultValue, valueTextGetter, changeCallback);
    }

    public SimpleSliderWidget(SimpleListWidget listWidget, int width, ITextComponent text, double defaultValue, ValueTextGetter<Double> valueTextGetter, Consumer<Double> changeCallback) {
        this(listWidget.getWidth() / 2 - 155, 0, width, 20, text, defaultValue, valueTextGetter, changeCallback);
        this.listWidget = listWidget;
    }

    public SimpleSliderWidget(SimpleListWidget listWidget, int width, double defaultValue, ValueTextGetter<Double> valueTextGetter, Consumer<Double> changeCallback) {
        this(listWidget, width, TextUtil.empty(), defaultValue, valueTextGetter, changeCallback);
    }

    @Override
    public void func_230430_a_(MatrixStack matrices, int mouseX, int mouseY, float delta) {
        this.render(new RenderArgs(new DrawObjectDM(matrices), mouseX, mouseY, delta));
    }

    public void render(RenderArgs args) {
        super.func_230430_a_(args.drawObjectDM.getStack(), args.mouseX, args.mouseY, args.delta);
    }
    
    public void func_230980_b_(double value) {
        super.field_230683_b_ = value;
    }
    
    public double getValue() {
        return super.field_230683_b_;
    }

    @Override
    protected void func_230979_b_() {
        this.func_238482_a_(this.textGetter.apply(this.getValue()));
    }

    @Override
    protected void func_230972_a_() {
        this.changeCallback.accept(this.getValue());
    }

    @Environment(EnvType.CLIENT)
    @FunctionalInterface
    public interface ValueTextGetter<Double> {
        ITextComponent get(ITextComponent optionText, Double value);
    }
}
