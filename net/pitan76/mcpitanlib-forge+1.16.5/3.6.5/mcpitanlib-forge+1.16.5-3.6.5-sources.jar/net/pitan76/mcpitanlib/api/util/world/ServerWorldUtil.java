package net.pitan76.mcpitanlib.api.util.world;

import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.entity.Entity;
import net.minecraft.item.ItemStack;
import net.minecraft.particles.IParticleData;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.server.ServerChunkProvider;
import net.minecraft.world.server.ServerWorld;
import net.pitan76.mcpitanlib.api.entity.Player;
import net.pitan76.mcpitanlib.midohra.block.entity.BlockEntityWrapper;
import org.jetbrains.annotations.Nullable;

import java.util.List;

public class ServerWorldUtil {
    public static void spawnParticles(ServerWorld world, IParticleData particle, double x, double y, double z, int count, double velocityX, double velocityY, double velocityZ, double speed) {
        world.func_195598_a(particle, x, y, z, count, velocityX, velocityY, velocityZ, speed);
    }

    public static void spawnParticles(ServerWorld world, Player player, IParticleData particle, boolean force, double x, double y, double z, int count, double velocityX, double velocityY, double velocityZ, double speed) {
        if (player.isServer()) {
            world.func_195600_a(player.getServerPlayer().get(), particle, force, x, y, z, count, velocityX, velocityY, velocityZ, speed);
        }
    }

    public static List<ItemStack> getDroppedStacksOnBlock(BlockState state, ServerWorld world, BlockPos pos, @Nullable TileEntity blockEntity) {
        return Block.func_220070_a(state, world, pos, blockEntity);
    }

    public static List<ItemStack> getDroppedStacksOnBlock(BlockState state, ServerWorld world, BlockPos pos, @Nullable BlockEntityWrapper blockEntity) {
        return getDroppedStacksOnBlock(state, world, pos, blockEntity.get());
    }

    public static List<ItemStack> getDroppedStacksOnBlock(BlockState state, ServerWorld world, BlockPos pos, @Nullable TileEntity blockEntity, @Nullable Entity entity, ItemStack stack) {
        return Block.func_220077_a(state, world, pos, blockEntity, entity, stack);
    }

    public static ServerChunkProvider getChunkManager(ServerWorld world) {
        return world.func_72863_F();
    }
}
