package net.pitan76.mcpitanlib.api.event.v0.event;

import com.google.common.collect.ImmutableMap;
import com.google.gson.JsonElement;
import net.minecraft.item.crafting.IRecipe;
import net.minecraft.item.crafting.IRecipeType;
import net.minecraft.profiler.IProfiler;
import net.minecraft.resources.IResourceManager;
import net.minecraft.util.ResourceLocation;
import net.pitan76.mcpitanlib.api.recipe.CompatibleRecipeEntry;
import net.pitan76.mcpitanlib.api.recipe.v2.CompatRecipeEntry;
import net.pitan76.mcpitanlib.api.recipe.v3.CompatRecipe;

import java.util.Map;

public class RecipeManagerEvent {
    public Map<ResourceLocation, JsonElement> jsonMap;
    public IResourceManager resourceManager;
    public IProfiler profiler;

    @Deprecated
    public Map<IRecipeType<?>, ImmutableMap.Builder<ResourceLocation, IRecipe<?>>> map;

    public RecipeManagerEvent(Map<ResourceLocation, JsonElement> map, IResourceManager resourceManager, IProfiler profiler, Map<IRecipeType<?>, ImmutableMap.Builder<ResourceLocation, IRecipe<?>>> map2) {
        this.jsonMap = map;
        this.resourceManager = resourceManager;
        this.profiler = profiler;
        this.map = map2;
    }

    public Map<ResourceLocation, JsonElement> getJsonMap() {
        return jsonMap;
    }

    @Deprecated
    public Map<IRecipeType<?>, ImmutableMap.Builder<ResourceLocation, IRecipe<?>>> getMap() {
        return map;
    }

    public IProfiler getProfiler() {
        return profiler;
    }

    public IResourceManager getResourceManager() {
        return resourceManager;
    }

    public net.pitan76.mcpitanlib.midohra.resource.ResourceManager getResourceManagerM() {
        return net.pitan76.mcpitanlib.midohra.resource.ResourceManager.of(resourceManager);
    }

    public void putCompatibleRecipeEntry(ResourceLocation id, CompatibleRecipeEntry entry) {
        map.get(entry.getType()).put(id, entry.getRecipe());
    }

    public void putCompatibleRecipeEntry(CompatibleRecipeEntry entry) {
        map.get(entry.getType()).put(entry.getId(), entry.getRecipe());
    }

    public void putCompatibleRecipeEntry(CompatRecipeEntry<?> entry) {
        map.get(entry.getType()).put(entry.getId(), entry.getRecipe());
    }

    public void putRecipeEntry(net.pitan76.mcpitanlib.midohra.recipe.entry.RecipeEntry entry) {
        map.get(entry.getRawRecipeType()).put(entry.getId().toMinecraft(), entry.toMinecraft());
    }

    public void putRecipe(CompatRecipe recipe) {
        map.get(recipe.getType()).put(recipe.getId(), recipe.getRecipeEntry().getRecipe());
    }
}
