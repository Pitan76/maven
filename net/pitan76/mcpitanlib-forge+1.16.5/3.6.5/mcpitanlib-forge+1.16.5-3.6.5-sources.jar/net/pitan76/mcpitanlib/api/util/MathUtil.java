package net.pitan76.mcpitanlib.api.util;

import net.minecraft.util.math.vector.Quaternion;
import net.minecraft.util.math.vector.Vector3f;
import net.pitan76.mcpitanlib.api.util.math.random.CompatRandom;

public class MathUtil {

    public static CompatRandom createRandom(long seed) {
        return CompatRandom.of(seed);
    }

    public static CompatRandom createRandom() {
        return CompatRandom.of();
    }

    @Deprecated
    public static Quaternion getRotationDegrees(RotationAxisType type, float deg) {
        return type.axis.func_229187_a_(deg);
    }

    public static class RotationAxisType {

        public static RotationAxisType POSITIVE_X = new RotationAxisType(Vector3f.field_229179_b_);
        public static RotationAxisType POSITIVE_Y = new RotationAxisType(Vector3f.field_229181_d_);
        public static RotationAxisType POSITIVE_Z = new RotationAxisType(Vector3f.field_229183_f_);

        protected final Vector3f axis;
        protected RotationAxisType(Vector3f axis) {
            this.axis = axis;
        }
    }
}
