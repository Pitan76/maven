package net.pitan76.mcpitanlib.api.event.entity;

import net.minecraft.network.datasync.DataParameter;
import net.minecraft.network.datasync.EntityDataManager;

public class InitDataTrackerArgs {
    public EntityDataManager tracker;

    public InitDataTrackerArgs(EntityDataManager tracker) {
        this.tracker = tracker;
    }

    public <T> void set(DataParameter<T> data, T value) {
        tracker.func_187227_b(data, value);
    }

    public <T> void addTracking(DataParameter<T> data, T value) {
        if (tracker != null) {
            set(data, value);
            return;
        }
    }
}
