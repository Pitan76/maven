package net.pitan76.mcpitanlib.api.event.item;

import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.inventory.EquipmentSlotType;
import net.minecraft.item.ItemStack;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.pitan76.mcpitanlib.api.entity.Player;
import net.pitan76.mcpitanlib.api.event.BaseEvent;
import net.pitan76.mcpitanlib.api.item.ArmorEquipmentType;
import net.pitan76.mcpitanlib.api.tag.TagKey;
import net.pitan76.mcpitanlib.api.util.BlockUtil;
import net.pitan76.mcpitanlib.api.util.WorldUtil;

public class PostMineEvent extends BaseEvent {
    public ItemStack stack;
    public World world;
    public BlockState state;
    public BlockPos pos;
    public LivingEntity miner;

    public PostMineEvent(ItemStack stack, World world, BlockState state, BlockPos pos, LivingEntity miner) {
        this.stack = stack;
        this.world = world;
        this.state = state;
        this.pos = pos;
        this.miner = miner;
    }

    public BlockState getState() {
        return state;
    }

    public BlockPos getPos() {
        return pos;
    }

    public World getWorld() {
        return world;
    }

    public ItemStack getStack() {
        return stack;
    }

    public LivingEntity getMiner() {
        return miner;
    }

    public TileEntity getBlockEntity() {
        return WorldUtil.getBlockEntity(world, pos);
    }

    public boolean isClient() {
        return world.field_72995_K;
    }

    public boolean stateIsIn(TagKey<Block> tagKey) {
        return BlockUtil.isIn(state.func_177230_c(), tagKey);
    }

    public boolean stateIsOf(Block block) {
        return BlockUtil.isEqual(state.func_177230_c(), block);
    }

    /**
     * Damages the stack in the given slot
     * @param amount the amount of damage to deal
     * @param slot the slot to damage
     */
    public void damageStack(int amount, EquipmentSlotType slot) {
        stack.func_222118_a(amount, miner, (entity) -> {
            entity.func_213361_c(slot);
        });
    }

    /**
     * Damages the stack in the given slot
     * @param amount the amount of damage to deal
     * @param type the type of armor equipment
     */
    public void damageStack(int amount, ArmorEquipmentType type) {
        stack.func_222118_a(amount, miner, (entity) -> {
            entity.func_213361_c(type.getSlot());
        });
    }

    /**
     * Damages the stack in the main hand
     * @param amount the amount of damage to deal
     */
    public void damageStack(int amount) {
        stack.func_222118_a(amount, miner, (entity) -> {
            entity.func_213361_c(EquipmentSlotType.MAINHAND);
        });
    }

    public boolean isPlayer() {
        return miner instanceof PlayerEntity;
    }

    public Player getPlayer() {
        if (isPlayer())
            return new Player((PlayerEntity) miner);

        return null;
    }

    public boolean isCreative() {
        return isPlayer() && getPlayer().isCreative();
    }

    public boolean isSneaking() {
        return miner.func_225608_bj_();
    }

    public ItemStack getMainHandStack() {
        return miner.func_184614_ca();
    }
}
