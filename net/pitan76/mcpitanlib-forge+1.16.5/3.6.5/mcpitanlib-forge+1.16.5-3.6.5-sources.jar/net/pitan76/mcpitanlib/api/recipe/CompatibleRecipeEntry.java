package net.pitan76.mcpitanlib.api.recipe;

import net.minecraft.item.crafting.IRecipe;
import net.minecraft.item.crafting.IRecipeSerializer;
import net.minecraft.item.crafting.IRecipeType;
import net.minecraft.item.crafting.ShapelessRecipe;
import net.minecraft.util.ResourceLocation;
import net.pitan76.mcpitanlib.api.util.CompatIdentifier;
import net.pitan76.mcpitanlib.api.util.RecipeUtil;
import org.jetbrains.annotations.Nullable;

@Deprecated
public class CompatibleRecipeEntry {
    private final IRecipe<?> recipe;

    private ResourceLocation id;

    public String group = "";
    public RecipeUtil.CompatibilityCraftingRecipeCategory category = null;

    @Deprecated
    public CompatibleRecipeEntry(IRecipe<?> recipe) {
        this.recipe = recipe;
    }

    public CompatibleRecipeEntry(ResourceLocation id, String group, RecipeUtil.CompatibilityCraftingRecipeCategory category, ShapelessRecipe shapelessRecipe) {
        this.recipe = shapelessRecipe;
        this.id = id;
        this.group = group;
        this.category = category;
    }

    public CompatibleRecipeEntry(CompatIdentifier id, String group, RecipeUtil.CompatibilityCraftingRecipeCategory category, ShapelessRecipe shapelessRecipe) {
        this(id.toMinecraft(), group, category, shapelessRecipe);
    }

    public IRecipe<?> getRecipe() {
        return recipe;
    }

    public ResourceLocation getId() {
        return id;
    }

    public CompatIdentifier getCompatId() {
        return CompatIdentifier.fromMinecraft(getId());
    }

    public IRecipeType<?> getType() {
        IRecipe<?> recipe = getRecipe();
        if (recipe == null) return null;

        return recipe.func_222127_g();
    }

    public IRecipeSerializer<?> getSerializer() {
        IRecipe<?> recipe = getRecipe();
        if (recipe == null) return null;

        return recipe.func_199559_b();
    }

    @Nullable
    public RecipeUtil.CompatibilityCraftingRecipeCategory getCategory() {
        return category;
    }

    public String getGroup() {
        return group;
    }
}
