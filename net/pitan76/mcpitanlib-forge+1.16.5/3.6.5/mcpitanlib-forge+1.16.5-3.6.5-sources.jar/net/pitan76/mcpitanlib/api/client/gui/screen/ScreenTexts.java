package net.pitan76.mcpitanlib.api.client.gui.screen;

import net.minecraft.util.text.ITextComponent;
import net.pitan76.mcpitanlib.api.util.TextUtil;

public class ScreenTexts {
    public static final ITextComponent ON = TextUtil.translatable("options.on");
    public static final ITextComponent OFF = TextUtil.translatable("options.off");
    public static final ITextComponent DONE = TextUtil.translatable("gui.done");
    public static final ITextComponent CANCEL = TextUtil.translatable("gui.cancel");
    public static final ITextComponent YES = TextUtil.translatable("gui.yes");
    public static final ITextComponent NO = TextUtil.translatable("gui.no");
    public static final ITextComponent PROCEED = TextUtil.translatable("gui.proceed");
    public static final ITextComponent BACK = TextUtil.translatable("gui.back");
    public static final ITextComponent CONNECT_FAILED = TextUtil.translatable("connect.failed");
    public static final ITextComponent LINE_BREAK = TextUtil.literal("\n");
    public static final ITextComponent SENTENCE_SEPARATOR = TextUtil.literal(". ");

    public ScreenTexts() {
    }
}
