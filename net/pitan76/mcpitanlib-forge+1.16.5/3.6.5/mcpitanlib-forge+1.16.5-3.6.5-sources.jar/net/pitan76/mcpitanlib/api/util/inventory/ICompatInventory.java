package net.pitan76.mcpitanlib.api.util.inventory;

import net.minecraft.inventory.IInventory;
import net.minecraft.item.ItemStack;
import net.pitan76.mcpitanlib.api.entity.Player;

public interface ICompatInventory extends IInventory {
    default void callSetStack(int slot, ItemStack stack) {
        func_70299_a(slot, stack);
    }

    default ItemStack callGetStack(int slot) {
        return func_70301_a(slot);
    }

    default int callSize() {
        return func_70302_i_();
    }

    default boolean callIsEmpty() {
        return func_191420_l();
    }

    default ItemStack callRemoveStack(int slot, int amount) {
        return func_70298_a(slot, amount);
    }

    default ItemStack callRemoveStack(int slot) {
        return func_70304_b(slot);
    }

    default void callClear() {
        func_174888_l();
    }

    default void callMarkDirty() {
        func_70296_d();
    }

    default boolean callCanPlayerUse(net.minecraft.entity.player.PlayerEntity player) {
        return func_70300_a(player);
    }

    default boolean canPlayerUse(Player player) {
        return func_70300_a(player.getEntity());
    }


    default void callSetStack(int slot, net.pitan76.mcpitanlib.midohra.item.ItemStack stack) {
        func_70299_a(slot, stack.toMinecraft());
    }

    default net.pitan76.mcpitanlib.midohra.item.ItemStack callGetStackAsMidohra(int slot) {
        return net.pitan76.mcpitanlib.midohra.item.ItemStack.of(func_70301_a(slot));
    }

    default int callGetMaxCountPerStack() {
        return func_70297_j_();
    }
}
