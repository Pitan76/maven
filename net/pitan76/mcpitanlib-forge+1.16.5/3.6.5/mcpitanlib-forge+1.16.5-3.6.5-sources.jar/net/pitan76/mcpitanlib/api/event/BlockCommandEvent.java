package net.pitan76.mcpitanlib.api.event;

import net.minecraft.block.Block;
import net.minecraft.command.arguments.BlockStateArgument;
import net.pitan76.mcpitanlib.api.command.argument.BlockCommand;

public class BlockCommandEvent extends RequiredCommandEvent {
    public Block getValue() {
        return BlockStateArgument.func_197238_a(context, ((BlockCommand) getCommand()).getArgumentName()).func_197231_a().func_177230_c();
    }
}
