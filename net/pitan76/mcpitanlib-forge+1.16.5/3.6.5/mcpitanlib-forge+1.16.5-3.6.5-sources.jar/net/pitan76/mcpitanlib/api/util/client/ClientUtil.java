package net.pitan76.mcpitanlib.api.util.client;

import com.mojang.authlib.GameProfile;
import net.minecraft.client.MainWindow;
import net.minecraft.client.Minecraft;
import net.minecraft.client.MouseHelper;
import net.minecraft.client.entity.player.ClientPlayerEntity;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.renderer.GameRenderer;
import net.minecraft.client.renderer.ItemRenderer;
import net.minecraft.client.renderer.WorldRenderer;
import net.minecraft.client.renderer.texture.TextureManager;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.profiler.IProfiler;
import net.minecraft.resources.IResourceManager;
import net.minecraft.util.math.RayTraceResult;
import net.pitan76.mcpitanlib.api.client.option.GameOptionsWrapper;
import net.pitan76.mcpitanlib.api.entity.Player;

import java.io.File;
import java.util.Optional;

public class ClientUtil {
    public static void setScreen(Screen screen) {
        getClient().func_147108_a(screen);
    }

    public static Screen getScreen() {
        return getClient().field_71462_r;
    }

    public static Player getPlayer() {
        return new Player(getClientPlayer());
    }

    public static ClientPlayerEntity getClientPlayer() {
        return getClient().field_71439_g;
    }

    public static Minecraft getClient() {
        return Minecraft.func_71410_x();
    }

    public static FontRenderer getTextRenderer() {
        return getClient().field_71466_p;
    }

    public static ItemRenderer getItemRenderer() {
        return getClient().func_175599_af();
    }

    public static IResourceManager getResourceManager() {
        return getClient().func_195551_G();
    }

    public static TextureManager getTextureManager() {
        return getClient().func_110434_K();
    }

    public static ClientWorld getWorld() {
        return getClient().field_71441_e;
    }

    public static GameRenderer getGameRenderer() {
        return getClient().field_71460_t;
    }

    public static Optional<Long> getTime() {
        if (getClient().field_71441_e == null) return Optional.empty();
        return Optional.of(getClient().field_71441_e.func_82737_E());
    }

    public static long getRenderTime() {
        return (long) getClient().func_184121_ak();
    }

    public static RayTraceResult getTarget() {
        return getClient().field_71476_x;
    }

    public static WorldRenderer getWorldRenderer() {
        return getClient().field_71438_f;
    }

    public static File getRunDirectory() {
        return getClient().field_71412_D;
    }

    public static IProfiler getProfiler() {
        return getClient().func_213239_aq();
    }

    public static GameProfile getGameProfile() {
        if (getClient().field_71439_g == null) return null;
        return getClient().field_71439_g.func_146103_bH();
    }

    public static MainWindow getWindow() {
        return getClient().func_228018_at_();
    }

    public static MouseHelper getMouse() {
        return getClient().field_71417_B;
    }

    public static boolean isInSingleplayer() {
        return getClient().func_71387_A();
    }

    public static boolean isPaused() {
        return getClient().func_147113_T();
    }

    public static GameOptionsWrapper getOptions() {
        return new GameOptionsWrapper(getClient().field_71474_y);
    }
}
