package net.pitan76.mcpitanlib.api.client.gui.screen;

import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.inventory.container.Container;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.text.ITextComponent;
import net.pitan76.mcpitanlib.api.client.render.handledscreen.DrawBackgroundArgs;
import net.pitan76.mcpitanlib.api.client.render.handledscreen.DrawMouseoverTooltipArgs;
import net.pitan76.mcpitanlib.api.client.render.handledscreen.RenderArgs;
import net.pitan76.mcpitanlib.api.util.client.RenderUtil;

public abstract class SimpleInventoryScreen<S extends Container> extends SimpleHandledScreen<S> {

    public SimpleInventoryScreen(S handler, PlayerInventory inventory, ITextComponent title) {
        super(handler, inventory, title);
    }

    public abstract ResourceLocation getTexture();

    @Override
    public ResourceLocation getBackgroundTexture() {
        return getTexture();
    }

    @Override
    public void drawBackgroundOverride(DrawBackgroundArgs args) {
        RenderUtil.setShaderToPositionTexProgram();
        RenderUtil.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
        callDrawTexture(args.drawObjectDM, getTexture(), field_147003_i, field_147009_r, 0, 0, field_146999_f, field_147000_g);
    }

    @Override
    public void renderOverride(RenderArgs args) {
        this.callRenderBackground(args);
        super.renderOverride(args);
        this.callDrawMouseoverTooltip(new DrawMouseoverTooltipArgs(args.drawObjectDM, args.mouseX, args.mouseY));
    }
}
