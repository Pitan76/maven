package net.pitan76.mcpitanlib.api.util.block;

import net.minecraft.util.Direction;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.BlockRayTraceResult;
import net.minecraft.util.math.vector.Vector3d;

public class BlockHitResultUtil {

    public static BlockRayTraceResult create(Vector3d pos, Direction direction, BlockPos blockPos, boolean insideBlock) {
        return new BlockRayTraceResult(pos, direction, blockPos, insideBlock);
    }

    public static BlockRayTraceResult create(Vector3d pos, Direction direction, BlockPos blockPos) {
        return new BlockRayTraceResult(pos, direction, blockPos, false);
    }

    public static Vector3d getPos(BlockRayTraceResult blockHitResult) {
        return blockHitResult.func_216347_e();
    }

    public static Direction getSide(BlockRayTraceResult blockHitResult) {
        return blockHitResult.func_216354_b();
    }

    public static BlockPos getBlockPos(BlockRayTraceResult blockHitResult) {
        return blockHitResult.func_216350_a();
    }

    public static boolean isInsideBlock(BlockRayTraceResult blockHitResult) {
        return blockHitResult.func_216353_d();
    }
}
