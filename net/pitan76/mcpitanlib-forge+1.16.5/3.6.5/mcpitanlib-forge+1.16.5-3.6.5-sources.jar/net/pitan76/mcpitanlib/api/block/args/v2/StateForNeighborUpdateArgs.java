package net.pitan76.mcpitanlib.api.block.args.v2;

import net.minecraft.block.BlockState;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.Direction;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.IWorld;
import net.minecraft.world.IWorldReader;
import net.pitan76.mcpitanlib.api.util.math.random.CompatRandom;
import net.pitan76.mcpitanlib.midohra.block.entity.BlockEntityWrapper;
import net.pitan76.mcpitanlib.midohra.holder.BlockStatePropertyHolder;
import net.pitan76.mcpitanlib.midohra.world.IWorldView;

public class StateForNeighborUpdateArgs implements BlockStatePropertyHolder {
    public BlockState state;
    public Direction direction;
    public BlockState neighborState;
    public IWorld world;
    public BlockPos pos;
    public BlockPos neighborPos;
    public CompatRandom random;

    public StateForNeighborUpdateArgs(BlockState state, Direction direction, BlockState neighborState, IWorld world, BlockPos pos, BlockPos neighborPos) {
        this.state = state;
        this.direction = direction;
        this.neighborState = neighborState;
        this.world = world;
        this.pos = pos;
        this.neighborPos = neighborPos;
        this.random = new CompatRandom(world.func_201674_k());
    }

    public Direction getDirection() {
        return direction;
    }

    public BlockState getRawNeighborState() {
        return neighborState;
    }

    public IWorldReader getRawWorld() {
        return world;
    }

    public BlockPos getRawPos() {
        return pos;
    }

    public BlockPos getRawNeighborPos() {
        return neighborPos;
    }

    public net.pitan76.mcpitanlib.midohra.block.BlockState getNeighborState() {
        return net.pitan76.mcpitanlib.midohra.block.BlockState.of(getRawNeighborState());
    }

    public net.pitan76.mcpitanlib.midohra.world.WorldView getWorld() {
        return net.pitan76.mcpitanlib.midohra.world.WorldView.of(getRawWorld());
    }

    public IWorldView getWorldView() {
        return getWorld();
    }

    public net.pitan76.mcpitanlib.midohra.util.math.BlockPos getPos() {
        return net.pitan76.mcpitanlib.midohra.util.math.BlockPos.of(getRawPos());
    }

    public net.pitan76.mcpitanlib.midohra.util.math.BlockPos getNeighborPos() {
        return net.pitan76.mcpitanlib.midohra.util.math.BlockPos.of(getRawNeighborPos());
    }

    public CompatRandom getRandom() {
        return random;
    }

    public net.pitan76.mcpitanlib.midohra.world.tick.ScheduledTickView getTickView() {
        return net.pitan76.mcpitanlib.midohra.world.tick.ScheduledTickView.of(world);
    }

    @Override
    public net.pitan76.mcpitanlib.midohra.block.BlockState getBlockState() {
        return net.pitan76.mcpitanlib.midohra.block.BlockState.of(state);
    }

    public BlockEntityWrapper getBlockEntity() {
        return getWorld().getBlockEntity(getPos());
    }

    public TileEntity getRawBlockEntity() {
        return world.func_175625_s(pos);
    }

    public boolean isClient() {
        return world.func_201670_d();
    }
}
