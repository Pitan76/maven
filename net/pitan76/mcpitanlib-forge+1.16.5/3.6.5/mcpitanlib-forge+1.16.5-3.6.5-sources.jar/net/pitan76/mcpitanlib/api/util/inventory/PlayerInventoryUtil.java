package net.pitan76.mcpitanlib.api.util.inventory;

import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.util.NonNullList;
import net.pitan76.mcpitanlib.api.entity.Player;

public class PlayerInventoryUtil {
    public static Player getPlayer(PlayerInventory playerInventory) {
        return new Player(playerInventory.field_70458_d);
    }

    public static int getSelectedSlot(PlayerInventory playerInventory) {
        return playerInventory.field_70461_c;
    }

    public static void setSelectedSlot(PlayerInventory playerInventory, int slot) {
        playerInventory.field_70461_c = slot;
    }

    public static void dropAllItems(PlayerInventory inv) {
        inv.func_70436_m();
    }

    public static NonNullList<ItemStack> getMain(PlayerInventory inv) {
        return inv.field_70462_a;
    }

    public static NonNullList<ItemStack> getArmor(PlayerInventory inv) {
        return inv.field_70460_b;
    }

    public static NonNullList<ItemStack> getOffHand(PlayerInventory inv) {
        return inv.field_184439_c;
    }

    public static ItemStack getMainHandStack(PlayerInventory inv) {
        return inv.func_70448_g();
    }
}
