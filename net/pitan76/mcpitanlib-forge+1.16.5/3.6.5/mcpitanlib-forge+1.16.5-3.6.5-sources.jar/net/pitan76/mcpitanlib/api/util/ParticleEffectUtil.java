package net.pitan76.mcpitanlib.api.util;

import net.minecraft.particles.IParticleData;
import net.minecraft.particles.ParticleType;
import net.pitan76.mcpitanlib.api.util.particle.effect.ItemStackParticleEffectUtil;

public class ParticleEffectUtil {
    public static ItemStackParticleEffectUtil itemStack = new ItemStackParticleEffectUtil();

    public static ParticleType<?> getType(IParticleData effect) {
        return effect.func_197554_b();
    }
}
