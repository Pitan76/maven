package net.pitan76.mcpitanlib.api.event.block;

import net.minecraft.block.BlockState;
import net.minecraft.loot.LootContext;
import net.minecraft.loot.LootParameters;
import net.minecraft.tileentity.TileEntity;
import net.pitan76.mcpitanlib.api.event.BaseEvent;

public class DroppedStacksArgs extends BaseEvent {
    public BlockState state;
    public LootContext.Builder builder;

    public DroppedStacksArgs(BlockState state, LootContext.Builder builder) {
        this.state = state;
        this.builder = builder;
    }

    public BlockState getState() {
        return state;
    }

    @Deprecated
    public LootContext.Builder getBuilder() {
        return builder;
    }

    public TileEntity getBlockEntity() {
        return builder.func_216024_a(LootParameters.field_216288_h);
    }
}
