package net.pitan76.mcpitanlib.api.util.world;

import net.minecraft.world.World;
import net.minecraft.world.server.ServerChunkProvider;
import net.minecraft.world.server.ServerWorld;
import net.pitan76.mcpitanlib.midohra.util.math.BlockPos;

public class ChunkManagerUtil {

    public static void markForUpdate(ServerChunkProvider manager, BlockPos pos) {
        markForUpdate(manager, pos.toRaw());
    }

    public static void markForUpdate(ServerChunkProvider manager, net.minecraft.util.math.BlockPos pos) {
        manager.func_217217_a(pos);
    }

    public static void markForUpdate(ServerWorld world, net.minecraft.util.math.BlockPos pos) {
       markForUpdate(ServerWorldUtil.getChunkManager(world), pos);
    }

    public static void markForUpdate(World world, net.minecraft.util.math.BlockPos pos) {
        if (!(world instanceof ServerWorld)) return;
        markForUpdate((ServerWorld) world, pos);
    }
}
