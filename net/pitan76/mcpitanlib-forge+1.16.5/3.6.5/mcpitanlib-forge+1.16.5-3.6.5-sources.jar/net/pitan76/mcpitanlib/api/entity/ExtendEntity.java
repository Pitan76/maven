package net.pitan76.mcpitanlib.api.entity;

import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.nbt.CompoundNBT;
import net.minecraft.network.IPacket;
import net.minecraft.world.World;
import net.pitan76.mcpitanlib.api.nbt.NbtTag;

public class ExtendEntity extends Entity {
    public ExtendEntity(EntityType<?> type, World world) {
        super(type, world);
    }

    public void func_70088_a() {
    }

    public void func_70037_a(CompoundNBT nbt) {

    }

    public void func_213281_b(CompoundNBT nbt) {

    }

    public IPacket<?> func_213297_N() {
        return null;
    }

    // 互換性用 (NbtTag型をOverrideすること)
    public void writeNbt(NbtTag nbt) {
        super.func_189511_e(nbt);
    }

    public void readNbt(NbtTag nbt) {
        super.func_70020_e(nbt);
    }

    // 1.18
    @Override
    public CompoundNBT func_189511_e(CompoundNBT nbt) {
        this.writeNbt(NbtTag.from(nbt));
        return nbt;
    }

    @Override
    public void func_70020_e(CompoundNBT nbt) {
        this.readNbt(NbtTag.from(nbt));
    }

    // 1.14
    public CompoundNBT toTag(CompoundNBT nbt) {
        this.writeNbt(NbtTag.from(nbt));
        return nbt;
    }

    public CompoundNBT fromTag(CompoundNBT nbt) {
        this.readNbt(NbtTag.from(nbt));
        return nbt;
    }

    public World getWorld() {
        return super.field_70170_p;
    }
}