package net.pitan76.mcpitanlib.api.util.debug;

import net.minecraft.inventory.IInventory;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.pitan76.mcpitanlib.api.util.ItemUtil;
import net.pitan76.mcpitanlib.api.util.PlatformUtil;

public class OutputUtil {

    public static boolean dev = PlatformUtil.isDevelopmentEnvironment();

    public static void print(Item item) {
        if (!dev) return;
        System.out.println(getString(item));
    }

    public static void print(ItemStack stack) {
        if (!dev) return;
        System.out.println(getString(stack));
    }

    public static void print(IInventory inventory) {
        if (!dev) return;
        System.out.println(getString(inventory));
    }

    public static String getString(Item item) {
        StringBuilder sb = new StringBuilder();
        sb.append("Item: {").append("\n");

        sb.append("  Name: ").append(item.func_77658_a()).append("\n");
        sb.append("  Id: ").append(ItemUtil.toCompatID(item)).append("\n");
        sb.append("}\n");

        return sb.toString();
    }

    public static String getString(ItemStack stack) {
        Item item = stack.func_77973_b();

        StringBuilder sb = new StringBuilder();
        sb.append("ItemStack: {").append("\n");

        sb.append(getString(item));
        sb.append("  Count: ").append(stack.func_190916_E()).append("\n");
        sb.append("}\n");

        return sb.toString();
    }

    public static String getString(IInventory inventory) {
        StringBuilder sb = new StringBuilder();
        sb.append("Inventory: {").append("\n");

        for (int i = 0; i < inventory.func_70302_i_(); i++) {
            ItemStack stack = inventory.func_70301_a(i);
            if (stack.func_190926_b()) continue;

            sb.append("  Slot ").append(i).append(": {").append("\n");
            sb.append(getString(stack));
            sb.append("  }\n");
        }

        sb.append("}\n");

        return sb.toString();
    }
}
