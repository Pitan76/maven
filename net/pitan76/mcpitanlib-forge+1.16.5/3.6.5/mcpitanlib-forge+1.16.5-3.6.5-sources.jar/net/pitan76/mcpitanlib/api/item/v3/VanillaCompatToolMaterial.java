package net.pitan76.mcpitanlib.api.item.v3;

import net.minecraft.item.IItemTier;
import net.minecraft.item.ItemTier;
import net.pitan76.mcpitanlib.api.tag.item.RepairIngredientTag;

public class VanillaCompatToolMaterial implements CompatToolMaterial {
    private final IItemTier material;

    public static final VanillaCompatToolMaterial WOOD = of(ItemTier.WOOD);
    public static final VanillaCompatToolMaterial STONE = of(ItemTier.STONE);
    public static final VanillaCompatToolMaterial IRON = of(ItemTier.IRON);
    public static final VanillaCompatToolMaterial GOLD = of(ItemTier.GOLD);
    public static final VanillaCompatToolMaterial DIAMOND = of(ItemTier.DIAMOND);
    public static final VanillaCompatToolMaterial NETHERITE = of(ItemTier.NETHERITE);

    protected VanillaCompatToolMaterial(IItemTier material) {
        this.material = material;
    }

    private static VanillaCompatToolMaterial of(IItemTier material) {
        return new VanillaCompatToolMaterial(material);
    }

    @Override
    public RepairIngredientTag getRepairIngredientTag() {
        if (material == ItemTier.STONE) return RepairIngredientTag.STONE_TOOL_MATERIALS;
        if (material == ItemTier.IRON) return RepairIngredientTag.IRON_TOOL_MATERIALS;
        if (material == ItemTier.GOLD) return RepairIngredientTag.GOLDEN_TOOL_MATERIALS;
        if (material == ItemTier.DIAMOND) return RepairIngredientTag.DIAMOND_TOOL_MATERIALS;
        if (material == ItemTier.NETHERITE) return RepairIngredientTag.NETHERITE_TOOL_MATERIALS;
        return RepairIngredientTag.WOODEN_TOOL_MATERIALS;
    }

    @Override
    public int getCompatDurability() {
        return material.func_200926_a();
    }

    @Override
    public float getCompatMiningSpeedMultiplier() {
        return material.func_200928_b();
    }

    @Override
    public float getCompatAttackDamage() {
        return material.func_200929_c();
    }

    @Override
    public int getCompatMiningLevel() {
        return material.func_200925_d();
    }

    @Override
    public int getCompatEnchantability() {
        return material.func_200927_e();
    }

    @Deprecated
    public IItemTier toMinecraft() {
        return material;
    }

    @Override
    public IItemTier build() {
        return material;
    }
}
