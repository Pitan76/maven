package net.pitan76.mcpitanlib.api.client.option;

import net.minecraft.client.GameSettings;

public class GameOptionsWrapper {
    public final GameSettings raw;

    public GameOptionsWrapper(GameSettings options) {
        this.raw = options;
    }

    public GameSettings getRaw() {
        return raw;
    }

    public void write() {
        raw.func_74303_b();
    }
}
