package net.pitan76.mcpitanlib.api.util;

import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.shapes.VoxelShape;
import net.minecraft.util.math.shapes.VoxelShapes;

public class VoxelShapeUtil {
    public static VoxelShape union(VoxelShape shape,VoxelShape... shapes) {
        return VoxelShapes.func_216384_a(shape, shapes);
    }

    public static VoxelShape cuboid(double x1, double y1, double z1, double x2, double y2, double z2) {
        return VoxelShapes.func_197873_a(x1, y1, z1, x2, y2, z2);
    }

    public static VoxelShape cuboid(double x, double y, double z, double size) {
        return VoxelShapes.func_197873_a(x, y, z, x + size, y + size, z + size);
    }

    public static VoxelShape cuboid(double size) {
        return VoxelShapes.func_197873_a(0, 0, 0, size, size, size);
    }

    public static VoxelShape centeredCuboid(double x, double y, double z, double size) {
        return VoxelShapes.func_197873_a(x - size / 2, y - size / 2, z - size / 2, x + size / 2, y + size / 2, z + size / 2);
    }

    public static VoxelShape empty() {
        return VoxelShapes.func_197880_a();
    }

    public static VoxelShape fullCube() {
        return VoxelShapes.func_197868_b();
    }

    public static VoxelShape blockCuboid(double minX, double minY, double minZ, double maxX, double maxY, double maxZ) {
        return VoxelShapes.func_197873_a(minX / 16.0, minY / 16.0, minZ / 16.0, maxX / 16.0, maxY / 16.0, maxZ / 16.0);
    }

    public static AxisAlignedBB getBoundingBox(VoxelShape shape) {
        return shape.func_197752_a();
    }
}
