package net.pitan76.mcpitanlib.api.client.event.listener;

import net.minecraft.block.BlockState;
import net.minecraft.client.renderer.ActiveRenderInfo;
import net.minecraft.client.renderer.WorldRenderer;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.BlockRayTraceResult;
import net.minecraft.util.math.RayTraceResult;
import net.minecraft.util.math.shapes.VoxelShape;
import net.minecraft.world.World;
import net.pitan76.mcpitanlib.midohra.client.render.CameraWrapper;
import net.pitan76.mcpitanlib.midohra.util.hit.HitResultType;
import com.mojang.blaze3d.matrix.MatrixStack;
import com.mojang.blaze3d.vertex.IVertexBuilder;
import java.util.Optional;

public class BeforeBlockOutlineEvent {
    public WorldRenderContext context;
    public RayTraceResult hitResult;

    public BeforeBlockOutlineEvent(WorldRenderContext context, RayTraceResult hitResult) {
        this.context = context;
        this.hitResult = hitResult;
    }

    public RayTraceResult getHitResult() {
        return hitResult;
    }

    public WorldRenderContext getContext() {
        return context;
    }

    public WorldRenderer getWorldRenderer() {
        return context.getWorldRenderer();
    }

    public Optional<BlockState> getBlockState() {
        return Optional.ofNullable(getWorld().func_180495_p(getBlockPos().orElse(null)));
    }

    public World getWorld() {
        return context.getWorld();
    }

    public Optional<BlockPos> getBlockPos() {
        return Optional.ofNullable(((BlockRayTraceResult) hitResult).func_216350_a());
    }

    public boolean isBlockType() {
        return getHitResultType() == RayTraceResult.Type.BLOCK;
    }

    public RayTraceResult.Type getHitResultType() {
        return hitResult.func_216346_c();
    }

    @Deprecated
    public ActiveRenderInfo getCamera() {
        return context.getCamera();
    }

    public CameraWrapper getCameraWrapper() {
        return CameraWrapper.of(getCamera());
    }

    public Optional<VoxelShape> getOutlineShape() {
        return context.getOutlineShape();
    }

    public MatrixStack getMatrixStack() {
        return context.getMatrixStack();
    }

    public void push() {
        context.push();
    }

    public void translate(double x, double y, double z) {
        context.translate(x, y, z);
    }

    public void pop() {
        context.pop();
    }

    public Optional<IVertexBuilder> getVertexConsumer() {
        return context.getVertexConsumer();
    }

    public void drawBox(float red, float green, float blue, float alpha) {
        context.drawBox(red, green, blue, alpha);
    }

    public void drawBox(AxisAlignedBB box, float red, float green, float blue, float alpha) {
        context.drawBox(box, red, green, blue, alpha);
    }

    public net.pitan76.mcpitanlib.midohra.util.hit.HitResult getHitResultM() {
        return net.pitan76.mcpitanlib.midohra.util.hit.HitResult.of(hitResult);
    }

    public HitResultType getHitResultTypeM() {
        return HitResultType.from(hitResult.func_216346_c());
    }

    public BlockState getBlockState2() {
        return getWorld().func_180495_p(getHitResultM().asBlockHitResult().get().getBlockPos());
    }

    public net.pitan76.mcpitanlib.midohra.block.BlockState getBlockStateM() {
        return net.pitan76.mcpitanlib.midohra.block.BlockState.of(getBlockState2());
    }
}
