package net.pitan76.mcpitanlib.api.entity.attribute;

import net.minecraft.entity.ai.attributes.Attribute;
import net.minecraft.entity.ai.attributes.Attributes;

public class CompatEntityAttributes {

    public static final CompatEntityAttribute ARMOR = of(Attributes.field_233826_i_);
    public static final CompatEntityAttribute ARMOR_TOUGHNESS = of(Attributes.field_233827_j_);
    public static final CompatEntityAttribute ATTACK_DAMAGE = of(Attributes.field_233823_f_);
    public static final CompatEntityAttribute ATTACK_KNOCKBACK = of(Attributes.field_233824_g_);
    public static final CompatEntityAttribute ATTACK_SPEED = of(Attributes.field_233825_h_);
    public static final CompatEntityAttribute FOLLOW_RANGE = of(Attributes.field_233819_b_);
    public static final CompatEntityAttribute KNOCKBACK_RESISTANCE = of(Attributes.field_233820_c_);
    public static final CompatEntityAttribute LUCK = of(Attributes.field_233828_k_);
    public static final CompatEntityAttribute MOVEMENT_SPEED = of(Attributes.field_233821_d_);
    public static final CompatEntityAttribute MAX_HEALTH = of(Attributes.field_233818_a_);
    public static final CompatEntityAttribute JUMP_STRENGTH = of(Attributes.field_233830_m_);
    public static final CompatEntityAttribute GRAVITY = of(null);
    public static final CompatEntityAttribute FLYING_SPEED = of(Attributes.field_233822_e_);
    public static final CompatEntityAttribute BLOCK_BREAK_SPEED = of(null);
    public static final CompatEntityAttribute BLOCK_INTERACTION_RANGE = of(null);

    public static CompatEntityAttribute of(Attribute attribute) {
        return CompatEntityAttribute.of(attribute);
    }
}
