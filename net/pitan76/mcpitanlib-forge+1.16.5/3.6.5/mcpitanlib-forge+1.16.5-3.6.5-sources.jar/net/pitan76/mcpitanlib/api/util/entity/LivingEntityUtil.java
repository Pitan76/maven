package net.pitan76.mcpitanlib.api.util.entity;

import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.inventory.EquipmentSlotType;
import net.minecraft.item.ItemStack;
import net.minecraft.potion.EffectInstance;
import net.minecraft.world.World;
import net.pitan76.mcpitanlib.api.entity.effect.CompatStatusEffect;
import net.pitan76.mcpitanlib.api.entity.effect.CompatStatusEffectInstance;
import net.pitan76.mcpitanlib.api.item.ArmorEquipmentType;
import net.pitan76.mcpitanlib.api.util.EntityUtil;
import net.pitan76.mcpitanlib.midohra.entity.EntityWrapper;

import java.util.ArrayList;
import java.util.List;

public class LivingEntityUtil extends EntityUtil {
    public static void addStatusEffect(LivingEntity entity, CompatStatusEffectInstance effect) {
        entity.func_195064_c(effect.getInstance());
    }

    public static void removeStatusEffect(LivingEntity entity, CompatStatusEffectInstance effect) {
        entity.func_195063_d(effect.getInstance().func_188419_a());
    }

    public static void removeStatusEffect(LivingEntity entity, CompatStatusEffect effect, World world) {
        entity.func_195063_d(effect.getStatusEffect(world));
    }

    public static List<CompatStatusEffectInstance> getStatusEffects(LivingEntity entity) {
        List<CompatStatusEffectInstance> compatEffects = new ArrayList<>();

        for (EffectInstance effect : entity.func_70651_bq()) {
            compatEffects.add(new CompatStatusEffectInstance(effect));
        }

        return compatEffects;
    }

    public static float getHealth(LivingEntity entity) {
        return entity.func_110143_aJ();
    }

    public static void setHealth(LivingEntity entity, float health) {
        entity.func_70606_j(health);
    }

    public static float getMaxHealth(LivingEntity entity) {
        return entity.func_110138_aP();
    }

    public static ItemStack getEquippedStack(LivingEntity entity, EquipmentSlotType slot) {
        return entity.func_184582_a(slot);
    }

    public static void setEquippedStack(LivingEntity entity, EquipmentSlotType slot, ItemStack stack) {
        entity.func_184201_a(slot, stack);
    }

    public static ItemStack getEquippedStack(LivingEntity entity, ArmorEquipmentType type) {
        return getEquippedStack(entity, type.getSlot());
    }

    public static void setEquippedStack(LivingEntity entity, ArmorEquipmentType type, ItemStack stack) {
        entity.func_184201_a(type.getSlot(), stack);
    }

    public static net.pitan76.mcpitanlib.midohra.item.ItemStack getEquippedStack(EntityWrapper entity, ArmorEquipmentType slot) {
        Entity e = entity.get();
        if (e instanceof LivingEntity) {
            return net.pitan76.mcpitanlib.midohra.item.ItemStack.of(getEquippedStack((LivingEntity) e, slot));
        }

        return net.pitan76.mcpitanlib.midohra.item.ItemStack.empty();
    }

    public static void setEquippedStack(EntityWrapper entity, ArmorEquipmentType slot, net.pitan76.mcpitanlib.midohra.item.ItemStack stack) {
        Entity e = entity.get();
        if (e instanceof LivingEntity) {
            setEquippedStack((LivingEntity) e, slot, stack.toMinecraft());
        }
    }
}
