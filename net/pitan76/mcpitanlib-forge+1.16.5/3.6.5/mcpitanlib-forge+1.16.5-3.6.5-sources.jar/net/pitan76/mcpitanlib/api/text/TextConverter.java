package net.pitan76.mcpitanlib.api.text;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import net.minecraft.util.text.IFormattableTextComponent;
import net.minecraft.util.text.StringTextComponent;
import net.minecraft.util.text.TextFormatting;
import net.minecraft.util.text.TranslationTextComponent;

public class TextConverter {

    public static IFormattableTextComponent convert(String string) {
        return convert(string, false);
    }

    /**
     * Convert string to MutableText with formatting
     *
     * @param text String
     * @param translatable boolean
     * @return MutableText
     */
    public static IFormattableTextComponent convert(String text, boolean translatable) {
        String[] splits = split(text);
        IFormattableTextComponent result = new StringTextComponent("");
        TextFormatting[] currentFormatting = {};

        for (String part : splits) {
            // Section
            if (part.startsWith("§") && part.length() == 2) {
                char code = part.charAt(1);
                // Reset
                if (code == 'r') {
                    currentFormatting = new TextFormatting[]{};
                    continue;
                }

                TextFormatting format = TextFormatting.func_211165_a(code);
                if (format == null)
                    continue;

                // Bold, Italic, Underline, Strikethrough, Obfuscated
                if (code >= 'k' && code <= 'o') {
                    ArrayList<TextFormatting> list = new ArrayList<>(Arrays.asList(currentFormatting));
                    list.add(format);
                    currentFormatting = list.toArray(new TextFormatting[0]);
                    continue;
                }

                // Color
                currentFormatting = new TextFormatting[]{format};
                continue;
            }

            // Translatable
            if (translatable) {
                Pattern pattern = Pattern.compile("\\{(.+?)\\}");
                Matcher matcher = pattern.matcher(part);
                IFormattableTextComponent tempText = new StringTextComponent("");
                int lastIndex = 0;

                while (matcher.find()) {
                    // {translatable key} より前の文字列を追加
                    if (matcher.start() > lastIndex) {
                        tempText.func_230529_a_(new StringTextComponent(part.substring(lastIndex, matcher.start())).func_240701_a_(currentFormatting));
                    }

                    // {translatable key} を追加
                    String key = matcher.group(1);
                    tempText.func_230529_a_(new TranslationTextComponent(key).func_240701_a_(currentFormatting));

                    lastIndex = matcher.end();
                }

                // 最後の文字列を追加
                if (lastIndex < part.length()) {
                    tempText.func_230529_a_(new StringTextComponent(part.substring(lastIndex)).func_240701_a_(currentFormatting));
                }

                result.func_230529_a_(tempText);
                continue;
            }

            result.func_230529_a_(new StringTextComponent(part).func_240701_a_(currentFormatting));
        }

        return result;
    }

    public static String[] split(String text) {
        Matcher matcher = Pattern.compile("(?i)§[0-9a-fk-or]|[^§]+").matcher(text);
        List<String> parts = new ArrayList<>();

        while (matcher.find())
            parts.add(matcher.group());

        return parts.toArray(new String[0]);
    }
}
