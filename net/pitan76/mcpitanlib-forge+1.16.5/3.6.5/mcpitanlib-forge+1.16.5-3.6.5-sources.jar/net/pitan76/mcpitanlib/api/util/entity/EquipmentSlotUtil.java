package net.pitan76.mcpitanlib.api.util.entity;

import net.minecraft.inventory.EquipmentSlotType;
import net.pitan76.mcpitanlib.api.item.ArmorEquipmentType;

public class EquipmentSlotUtil {
    public static boolean isArmor(EquipmentSlotType slot) {
        return slot == EquipmentSlotType.HEAD || slot == EquipmentSlotType.CHEST || slot == EquipmentSlotType.LEGS || slot == EquipmentSlotType.FEET;
    }

    public static boolean isMainHand(EquipmentSlotType slot) {
        return slot == EquipmentSlotType.MAINHAND;
    }

    public static boolean isOffHand(EquipmentSlotType slot) {
        return slot == EquipmentSlotType.OFFHAND;
    }

    public static boolean isWeapon(EquipmentSlotType slot) {
        return slot == EquipmentSlotType.MAINHAND || slot == EquipmentSlotType.OFFHAND;
    }

    public static int getEntitySlotId(EquipmentSlotType slot) {
        if (slot == null)
            return 0;

        return slot.func_188454_b();
    }

    public static EquipmentSlotType fromEntitySlotId(int id) {
        for (EquipmentSlotType slot : EquipmentSlotType.values()) {
            if (slot.func_188454_b() == id) {
                return slot;
            }
        }
        return EquipmentSlotType.MAINHAND;
    }

    public static ArmorEquipmentType getArmorEquipmentType(EquipmentSlotType slot) {
        switch (slot) {
            case HEAD:
                return ArmorEquipmentType.HEAD;
            case CHEST:
                return ArmorEquipmentType.CHEST;
            case LEGS:
                return ArmorEquipmentType.LEGS;
            case FEET:
                return ArmorEquipmentType.FEET;
            default:
                return null;
        }
    }
}
