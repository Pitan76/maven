package net.pitan76.mcpitanlib.api.client.gui.widget;

import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.util.text.ITextComponent;
import net.pitan76.mcpitanlib.api.util.TextUtil;
import org.jetbrains.annotations.Nullable;

public class CompatTextFieldWidget extends TextFieldWidget {
    public CompatTextFieldWidget(FontRenderer textRenderer, int width, int height) {
        this(textRenderer, width, height, TextUtil.empty());
    }

    public CompatTextFieldWidget(FontRenderer textRenderer, int x, int y, int width, int height) {
        this(textRenderer, x, y, width, height, TextUtil.empty());
    }

    // ----

    public CompatTextFieldWidget(FontRenderer textRenderer, int width, int height, ITextComponent text) {
        super(textRenderer, 0, 0, width, height, text);
    }

    public CompatTextFieldWidget(FontRenderer textRenderer, int x, int y, int width, int height, ITextComponent text) {
        super(textRenderer, x, y, width, height, text);
    }

    public CompatTextFieldWidget(FontRenderer textRenderer, int x, int y, int width, int height, @Nullable TextFieldWidget copyFrom, ITextComponent text) {
        super(textRenderer, x, y, width, height, copyFrom, text);
    }

    // ----

    @Deprecated
    @Override
    public void func_146185_a(boolean drawsBackground) {
        callSetDrawsBackground(drawsBackground);
    }

    public void callSetDrawsBackground(boolean drawsBackground) {
        super.func_146185_a(drawsBackground);
    }

    @Deprecated
    @Override
    public void func_230996_d_(boolean focused) {
        callSetFocused(focused);
    }

    public void callSetFocused(boolean focused) {
        super.func_230996_d_(focused);
    }

    @Deprecated
    @Override
    public void func_146205_d(boolean focusUnlocked) {
        callSetFocusUnlocked(focusUnlocked);
    }

    public void callSetFocusUnlocked(boolean focusUnlocked) {
        super.func_146205_d(focusUnlocked);
    }

    @Deprecated
    @Override
    public void func_146203_f(int maxLength) {
        callSetMaxLength(maxLength);
    }

    public void callSetMaxLength(int maxLength) {
        super.func_146203_f(maxLength);
    }

    @Deprecated
    @Override
    public void func_146180_a(String text) {
        callSetText(text);
    }

    public void callSetText(String text) {
        super.func_146180_a(text);
    }

    @Deprecated
    @Override
    public String func_146179_b() {
        return callGetText();
    }

    public String callGetText() {
        return super.func_146179_b();
    }

    @Deprecated
    @Override
    public void func_146184_c(boolean editable) {
        callSetEditable(editable);
    }

    public void callSetEditable(boolean editable) {
        super.func_146184_c(editable);
    }

    @Deprecated
    @Override
    public boolean func_230999_j_() {
        return callIsFocused();
    }

    public boolean callIsFocused() {
        return super.func_230999_j_();
    }

    @Deprecated
    @Override
    public boolean func_231046_a_(int keyCode, int scanCode, int modifiers) {
        return callKeyPressed(keyCode, scanCode, modifiers);
    }

    public boolean callKeyPressed(int keyCode, int scanCode, int modifiers) {
        return super.func_231046_a_(keyCode, scanCode, modifiers);
    }

    @Deprecated
    @Override
    public boolean func_223281_a_(int keyCode, int scanCode, int modifiers) {
        return callKeyReleased(keyCode, scanCode, modifiers);
    }

    public boolean callKeyReleased(int keyCode, int scanCode, int modifiers) {
        return super.func_223281_a_(keyCode, scanCode, modifiers);
    }

    @Deprecated
    @Override
    public boolean func_231042_a_(char chr, int modifiers) {
        return callCharTyped(chr, modifiers);
    }

    public boolean callCharTyped(char chr, int modifiers) {
        return super.func_231042_a_(chr, modifiers);
    }
}
