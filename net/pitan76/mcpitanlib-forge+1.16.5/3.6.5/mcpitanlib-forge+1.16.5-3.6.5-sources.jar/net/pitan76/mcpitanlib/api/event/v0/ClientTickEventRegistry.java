package net.pitan76.mcpitanlib.api.event.v0;

import me.shedaniel.architectury.event.events.client.ClientTickEvent;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.Minecraft;
import net.minecraft.client.world.ClientWorld;

public class ClientTickEventRegistry {
    public static void registerPost(Client client) {
        ClientTickEvent.CLIENT_POST.register(client::tick);
    }

    public static void registerPre(Client client) {
        ClientTickEvent.CLIENT_PRE.register(client::tick);
    }

    public static void registerLevelPost(ClientLevel world) {
        ClientTickEvent.CLIENT_WORLD_POST.register(world::tick);
    }

    public static void registerLevelPre(ClientLevel world) {
        ClientTickEvent.CLIENT_WORLD_PRE.register(world::tick);
    }

    @Environment(EnvType.CLIENT)
    public interface Client {
        void tick(Minecraft instance);
    }

    @Environment(EnvType.CLIENT)
    public interface ClientLevel {
        void tick(ClientWorld instance);
    }
}
