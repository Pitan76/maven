package net.pitan76.mcpitanlib.api.entity.effect;

import org.jetbrains.annotations.Nullable;

import java.util.Optional;
import net.minecraft.potion.Effect;
import net.minecraft.potion.EffectInstance;

public class CompatStatusEffectInstance {
    private final EffectInstance instance;
    
    @Deprecated
    public CompatStatusEffectInstance(EffectInstance instance) {
        this.instance = instance;
    }

    public EffectInstance getInstance() {
        return instance;
    }

    public Optional<CompatStatusEffect> getCompatStatusEffect() {
        return Optional.of(new CompatStatusEffect(instance.func_188419_a()));
    }

    public CompatStatusEffectInstance(CompatStatusEffect effect) {
        this(effect, 0, 0);
    }

    public CompatStatusEffectInstance(CompatStatusEffect effect, int duration) {
        this(effect, duration, 0);
    }

    public CompatStatusEffectInstance(CompatStatusEffect effect, int duration, int amplifier) {
        this(effect, duration, amplifier, false, true);
    }

    public CompatStatusEffectInstance(CompatStatusEffect effect, int duration, int amplifier, boolean ambient, boolean visible) {
        this(effect, duration, amplifier, ambient, visible, visible);
    }

    public CompatStatusEffectInstance(CompatStatusEffect effect, int duration, int amplifier, boolean ambient, boolean showParticles, boolean showIcon) {
        this(effect, duration, amplifier, ambient, showParticles, showIcon, null);
    }
    
    public CompatStatusEffectInstance(CompatStatusEffect effect, int duration, int amplifier, boolean ambient, boolean showParticles, boolean showIcon, @Nullable EffectInstance hiddenEffect) {
        Effect statusEffect = effect.getStatusEffect(null);
        this.instance = new EffectInstance(statusEffect, duration, amplifier, ambient, showParticles, showIcon, hiddenEffect);
    }

    public int getDuration() {
        return instance.func_76459_b();
    }

    public int getAmplifier() {
        return instance.func_76458_c();
    }

    public boolean isAmbient() {
        return instance.func_82720_e();
    }

    public boolean showParticles() {
        return instance.func_188418_e();
    }

    public boolean showIcon() {
        return instance.func_205348_f();
    }

    public boolean isInfinite() {
        return instance.func_100011_g();
    }
}
