package net.pitan76.mcpitanlib.api.client.event.listener;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.block.BlockState;
import net.minecraft.client.Minecraft;
import net.minecraft.client.render.*;
import net.minecraft.client.renderer.ActiveRenderInfo;
import net.minecraft.client.renderer.GameRenderer;
import net.minecraft.client.renderer.IRenderTypeBuffer;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.WorldRenderer;
import net.minecraft.client.renderer.culling.ClippingHelper;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.BlockRayTraceResult;
import net.minecraft.util.math.RayTraceResult;
import net.minecraft.util.math.shapes.VoxelShape;
import net.minecraft.util.math.vector.Matrix4f;
import net.pitan76.mcpitanlib.api.util.VoxelShapeUtil;
import net.pitan76.mcpitanlib.midohra.client.render.CameraWrapper;
import org.jetbrains.annotations.Nullable;
import com.mojang.blaze3d.matrix.MatrixStack;
import com.mojang.blaze3d.vertex.IVertexBuilder;
import java.util.Objects;
import java.util.Optional;

public interface WorldRenderContext {

    WorldRenderer getWorldRenderer();

    MatrixStack getMatrixStack();

    float getTickDelta();

    ActiveRenderInfo getCamera();

    GameRenderer getGameRenderer();

    LightTexture getLightmapTextureManager();

    @Deprecated
    Matrix4f getProjectionMatrix();

    ClientWorld getWorld();

    @Deprecated
    boolean isAdvancedTranslucency();

    @Nullable IRenderTypeBuffer getConsumers();
    @Nullable ClippingHelper getFrustum();

    @Environment(EnvType.CLIENT)
    interface BlockOutlineContext {
        @Deprecated
        IVertexBuilder vertexConsumer();

        Entity entity();

        double cameraX();

        double cameraY();

        double cameraZ();

        BlockPos blockPos();

        BlockState blockState();
    }

    default RayTraceResult getHitResult() {
        return Minecraft.func_71410_x().field_71476_x;
    }

    default Optional<BlockState> getBlockState() {
        return Optional.ofNullable(getWorld().func_180495_p(getBlockPos().orElse(null)));
    }

    default Optional<BlockPos> getBlockPos() {
        return Optional.ofNullable(((BlockRayTraceResult) getHitResult()).func_216350_a());
    }

    default boolean isBlockType() {
        return getHitResultType() == RayTraceResult.Type.BLOCK;
    }

    default RayTraceResult.Type getHitResultType() {
        return getHitResult().func_216346_c();
    }

    default Optional<VoxelShape> getOutlineShape() {
        return getBlockState().map(blockState -> blockState.func_196954_c(getWorld(),
                getBlockPos().orElse(null)));
    }

    default void push() {
        getMatrixStack().func_227860_a_();
    }

    default void translate(double x, double y, double z) {
        getMatrixStack().func_227861_a_(x, y, z);
    }

    default void pop() {
        getMatrixStack().func_227865_b_();
    }

    default Optional<IVertexBuilder> getVertexConsumer() {
        if (getConsumers() == null)
            return Optional.empty();

        return Optional.of(Objects.requireNonNull(getConsumers()).getBuffer(RenderType.func_228659_m_()));
    }

    default void drawBox(float red, float green, float blue, float alpha) {
        Optional<VoxelShape> outlineShape = getOutlineShape();
        if (!outlineShape.isPresent()) return;

        drawBox(VoxelShapeUtil.getBoundingBox(outlineShape.get()), red, green, blue, alpha);
    }

    default void drawBox(AxisAlignedBB box, float red, float green, float blue, float alpha) {
        Optional<IVertexBuilder> vertexConsumer = getVertexConsumer();

        if (!vertexConsumer.isPresent())
            return;

        WorldRenderer.func_228430_a_(getMatrixStack(), vertexConsumer.get(), box, red, green, blue, alpha);
    }

    default CameraWrapper getCameraWrapper() {
        return CameraWrapper.of(getCamera());
    }
}
