package net.pitan76.mcpitanlib.api.event.block;

import net.minecraft.block.BlockState;
import net.minecraft.fluid.FluidState;
import net.minecraft.pathfinding.PathType;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.IBlockReader;
import net.pitan76.mcpitanlib.api.event.BaseEvent;
import net.pitan76.mcpitanlib.api.util.FluidStateUtil;

public class CanPathfindThroughArgs extends BaseEvent {
    public BlockState state;
    private IBlockReader blockView;
    private BlockPos pos;
    public PathType type;

    public CanPathfindThroughArgs(BlockState state, IBlockReader blockView, BlockPos pos, PathType type) {
        this.state = state;
        this.blockView = blockView;
        this.pos = pos;
        this.type = type;
    }

    public BlockState getState() {
        return state;
    }

    public PathType getType() {
        return type;
    }

    public FluidState getFluidState() {
        return state.func_204520_s();
    }

    public boolean isWaterNavigationType() {
        return type == PathType.WATER;
    }

    public boolean isAirNavigationType() {
        return type == PathType.AIR;
    }

    public boolean isLandNavigationType() {
        return type == PathType.LAND;
    }

    public boolean isWaterState() {
        return FluidStateUtil.isWater(getFluidState());
    }

    public boolean isLavaState() {
        return FluidStateUtil.isLava(getFluidState());
    }

    public BlockPos getPos() {
        return pos;
    }

    public IBlockReader getBlockView() {
        return blockView;
    }
}
