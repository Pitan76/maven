package net.pitan76.mcpitanlib.api.util.recipe.input;

import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.inventory.IInventory;
import net.minecraft.item.ItemStack;
import net.pitan76.mcpitanlib.api.recipe.input.CompatRecipeInput;
import net.pitan76.mcpitanlib.api.util.ItemStackUtil;

import java.util.Optional;

public class SingleStackRecipeInputUtil {
    public static Optional<IInventory> get(CompatRecipeInput<?> input) {
        if (input.getInput() instanceof IInventory) {
            return Optional.of( input.getInput());
        }
        return Optional.empty();
    }

    public static CompatRecipeInput<?> create(IInventory input) {
        return new CompatRecipeInput<>(input);
    }

    public static CompatRecipeInput<?> create(ItemStack stack) {
        return new CompatRecipeInput<>(new IInventory() {

            private ItemStack itemStack = stack;

            @Override
            public void func_174888_l() {
                itemStack = ItemStackUtil.empty();
            }

            @Override
            public int func_70302_i_() {
                return 1;
            }

            @Override
            public boolean func_191420_l() {
                return false;
            }

            @Override
            public ItemStack func_70301_a(int slot) {
                if (slot == 0)
                    return itemStack;
                return ItemStackUtil.empty();
            }

            @Override
            public ItemStack func_70298_a(int slot, int amount) {
                if (slot == 0) {
                    ItemStack stack = itemStack;
                    ItemStackUtil.decrementCount(stack, amount);
                    return stack;
                }
                return ItemStackUtil.empty();
            }

            @Override
            public ItemStack func_70304_b(int slot) {
                if (slot == 0) {
                    ItemStack stack = itemStack;
                    itemStack = ItemStackUtil.empty();
                    return stack;
                }
                return ItemStackUtil.empty();
            }

            @Override
            public void func_70299_a(int slot, ItemStack stack) {
                if (slot == 0)
                    itemStack = stack;
            }

            @Override
            public void func_70296_d() {

            }

            @Override
            public boolean func_70300_a(PlayerEntity player) {
                return false;
            }
        });
    }

    public static ItemStack getStack(CompatRecipeInput<?> input) {
        Optional<IInventory> recipeInput = get(input);
        if (!recipeInput.isPresent()) return ItemStackUtil.empty();

        return recipeInput.get().func_70301_a(0);
    }
}
