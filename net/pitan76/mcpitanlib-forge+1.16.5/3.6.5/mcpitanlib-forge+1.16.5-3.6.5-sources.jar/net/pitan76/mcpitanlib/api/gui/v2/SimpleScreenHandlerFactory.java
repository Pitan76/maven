package net.pitan76.mcpitanlib.api.gui.v2;

import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.inventory.container.Container;
import net.minecraft.inventory.container.INamedContainerProvider;
import net.minecraft.util.text.ITextComponent;
import net.pitan76.mcpitanlib.api.event.container.factory.DisplayNameArgs;
import net.pitan76.mcpitanlib.api.gui.args.CreateMenuEvent;

public interface SimpleScreenHandlerFactory extends INamedContainerProvider {
    @Override
    default ITextComponent func_145748_c_() {
        return getDisplayName(new DisplayNameArgs());
    }

    ITextComponent getDisplayName(DisplayNameArgs args);

    @Override
    default Container createMenu(int syncId, PlayerInventory playerInventory, PlayerEntity player) {
        return createMenu(new CreateMenuEvent(syncId, playerInventory, player));
    }

    Container createMenu(CreateMenuEvent event);
}
