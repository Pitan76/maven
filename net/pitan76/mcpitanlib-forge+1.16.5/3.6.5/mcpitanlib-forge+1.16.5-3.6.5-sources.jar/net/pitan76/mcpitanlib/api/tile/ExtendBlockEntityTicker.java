package net.pitan76.mcpitanlib.api.tile;

import net.minecraft.tileentity.TileEntity;
import net.pitan76.mcpitanlib.api.event.tile.TileTickEvent;

public interface ExtendBlockEntityTicker<T extends TileEntity> {
    void tick(TileTickEvent<T> event);
}
