package net.pitan76.mcpitanlib.api.state.property;

import net.minecraft.block.enums.*;
import net.minecraft.state.Property;
import net.minecraft.state.properties.BlockStateProperties;
import net.minecraft.state.properties.ChestType;
import net.minecraft.state.properties.ComparatorMode;
import net.minecraft.state.properties.Half;
import net.minecraft.state.properties.PistonType;
import net.minecraft.state.properties.SlabType;
import net.minecraft.state.properties.StairsShape;
import net.minecraft.util.Direction;
import net.minecraft.util.IStringSerializable;

public class CompatProperties {
    public static final DirectionProperty FACING = new DirectionProperty(BlockStateProperties.field_208155_H);
    public static final DirectionProperty HORIZONTAL_FACING = new DirectionProperty(BlockStateProperties.field_208157_J);
    public static final DirectionProperty HOPPER_FACING = new DirectionProperty(BlockStateProperties.field_208156_I);
    public static final DirectionProperty VERTICAL_DIRECTION = DirectionProperty.of("vertical_direction", (dir) -> dir == Direction.UP || dir == Direction.DOWN);

    public static final BooleanProperty POWERED = new BooleanProperty(BlockStateProperties.field_208194_u);
    public static final BooleanProperty ENABLED = new BooleanProperty(BlockStateProperties.field_208180_g);
    public static final BooleanProperty WATERLOGGED = new BooleanProperty(BlockStateProperties.field_208198_y);
    public static final BooleanProperty LIT = new BooleanProperty(BlockStateProperties.field_208190_q);
    public static final BooleanProperty OCCUPIED = new BooleanProperty(BlockStateProperties.field_208192_s);
    public static final BooleanProperty ATTACHED = new BooleanProperty(BlockStateProperties.field_208174_a);
    public static final BooleanProperty HANGING = new BooleanProperty(BlockStateProperties.field_222514_j);
    public static final BooleanProperty BOTTOM = new BooleanProperty(BlockStateProperties.field_222513_b);
    public static final BooleanProperty OPEN = new BooleanProperty(BlockStateProperties.field_208193_t);
    public static final BooleanProperty UNSTABLE = new BooleanProperty(BlockStateProperties.field_212646_x);
    public static final BooleanProperty UP = new BooleanProperty(BlockStateProperties.field_208149_B);
    public static final BooleanProperty DOWN = new BooleanProperty(BlockStateProperties.field_208150_C);
    public static final BooleanProperty NORTH = new BooleanProperty(BlockStateProperties.field_208151_D);
    public static final BooleanProperty EAST = new BooleanProperty(BlockStateProperties.field_208152_E);
    public static final BooleanProperty SOUTH = new BooleanProperty(BlockStateProperties.field_208153_F);
    public static final BooleanProperty WEST = new BooleanProperty(BlockStateProperties.field_208154_G);

    public static final IntProperty POWER = new IntProperty(BlockStateProperties.field_208136_ak);
    public static final IntProperty LAYERS = new IntProperty(BlockStateProperties.field_208129_ad);
    public static final IntProperty NOTE = new IntProperty(BlockStateProperties.field_208134_ai);
    public static final IntProperty ROTATION = new IntProperty(BlockStateProperties.field_208138_am);
    public static final IntProperty EGGS = new IntProperty(BlockStateProperties.field_208127_ab);
    public static final IntProperty DELAY = new IntProperty(BlockStateProperties.field_208126_aa);

    public static final EnumProperty<Half> BLOCK_HALF = new EnumProperty<>(BlockStateProperties.field_208164_Q);
    public static final EnumProperty<StairsShape> STAIR_SHAPE = new EnumProperty<>(BlockStateProperties.field_208146_au);
    public static final EnumProperty<SlabType> SLAB_TYPE = new EnumProperty<>(BlockStateProperties.field_208145_at);
    public static final EnumProperty<ChestType> CHEST_TYPE = new EnumProperty<>(BlockStateProperties.field_208140_ao);
    public static final EnumProperty<PistonType> PISTON_TYPE = new EnumProperty<>(BlockStateProperties.field_208144_as);
    public static final EnumProperty<Direction.Axis> AXIS = new EnumProperty<>(BlockStateProperties.field_208148_A);
    public static final EnumProperty<Direction.Axis> HORIZONTAL_AXIS = new EnumProperty<>(BlockStateProperties.field_208199_z);
    public static final EnumProperty<ComparatorMode> COMPARATOR_MODE = new EnumProperty<>(BlockStateProperties.field_208141_ap);

    public static IProperty<?> of(Property<?> property) {
        if (property instanceof net.minecraft.state.IntegerProperty) {
            return of((net.minecraft.state.IntegerProperty) property);
        }
        if (property instanceof net.minecraft.state.BooleanProperty) {
            return of((net.minecraft.state.BooleanProperty) property);
        }
        if (property instanceof net.minecraft.state.EnumProperty) {
            return of((net.minecraft.state.EnumProperty<?>) property);
        }
        if (property instanceof net.minecraft.state.DirectionProperty) {
            return ofDir((net.minecraft.state.DirectionProperty) property);
        }
        return UnknownProperty.of(property);
    }

    public static IntProperty of(net.minecraft.state.IntegerProperty property) {
        if (property == BlockStateProperties.field_208136_ak) return POWER;
        if (property == BlockStateProperties.field_208129_ad) return LAYERS;
        if (property == BlockStateProperties.field_208134_ai) return NOTE;
        if (property == BlockStateProperties.field_208138_am) return ROTATION;
        if (property == BlockStateProperties.field_208127_ab) return EGGS;
        if (property == BlockStateProperties.field_208126_aa) return DELAY;

        return new IntProperty(property);
    }

    public static BooleanProperty of(net.minecraft.state.BooleanProperty property) {
        if (property == BlockStateProperties.field_208194_u) return POWERED;
        if (property == BlockStateProperties.field_208180_g) return ENABLED;
        if (property == BlockStateProperties.field_208198_y) return WATERLOGGED;
        if (property == BlockStateProperties.field_208190_q) return LIT;
        if (property == BlockStateProperties.field_208192_s) return OCCUPIED;
        if (property == BlockStateProperties.field_208174_a) return ATTACHED;
        if (property == BlockStateProperties.field_222514_j) return HANGING;
        if (property == BlockStateProperties.field_222513_b) return BOTTOM;
        if (property == BlockStateProperties.field_208193_t) return OPEN;
        if (property == BlockStateProperties.field_212646_x) return UNSTABLE;
        if (property == BlockStateProperties.field_208149_B) return UP;
        if (property == BlockStateProperties.field_208150_C) return DOWN;
        if (property == BlockStateProperties.field_208151_D) return NORTH;
        if (property == BlockStateProperties.field_208152_E) return EAST;
        if (property == BlockStateProperties.field_208153_F) return SOUTH;
        if (property == BlockStateProperties.field_208154_G) return WEST;

        return new BooleanProperty(property);
    }

    public static <T extends Enum<T> & IStringSerializable> EnumProperty<T> of(net.minecraft.state.EnumProperty<T> property) {
        if (property.equals(BlockStateProperties.field_208164_Q)) return (EnumProperty) BLOCK_HALF;
        if (property.equals(BlockStateProperties.field_208146_au)) return (EnumProperty) STAIR_SHAPE;
        if (property.equals(BlockStateProperties.field_208145_at)) return (EnumProperty) SLAB_TYPE;
        if (property.equals(BlockStateProperties.field_208140_ao)) return (EnumProperty) CHEST_TYPE;
        if (property.equals(BlockStateProperties.field_208144_as)) return (EnumProperty) PISTON_TYPE;
        if (property.equals(BlockStateProperties.field_208148_A)) return (EnumProperty) AXIS;
        if (property.equals(BlockStateProperties.field_208199_z)) return (EnumProperty) HORIZONTAL_AXIS;
        if (property.equals(BlockStateProperties.field_208141_ap)) return (EnumProperty) COMPARATOR_MODE;

        return new EnumProperty<>(property);
    }

    public static DirectionProperty ofDir(net.minecraft.state.DirectionProperty property) {
        if (property == BlockStateProperties.field_208155_H) return FACING;
        if (property == BlockStateProperties.field_208157_J) return HORIZONTAL_FACING;
        if (property == BlockStateProperties.field_208156_I) return HOPPER_FACING;

        return new DirectionProperty(property);
    }
}
