package net.pitan76.mcpitanlib.api.util.math;

import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;

public class BoxUtil {
    public static AxisAlignedBB createBox(double x1, double y1, double z1, double x2, double y2, double z2) {
        return new AxisAlignedBB(x1, y1, z1, x2, y2, z2);
    }

    public static AxisAlignedBB createBox(double x, double y, double z, double size) {
        return new AxisAlignedBB(x, y, z, x + size, y + size, z + size);
    }

    public static AxisAlignedBB createBox(double size) {
        return new AxisAlignedBB(0, 0, 0, size, size, size);
    }

    public static AxisAlignedBB createBox(double x1, double y1, double z1, double x2, double y2, double z2, double size) {
        return new AxisAlignedBB(x1, y1, z1, x2 + size, y2 + size, z2 + size);
    }

    public static AxisAlignedBB createBox(BlockPos pos) {
        return new AxisAlignedBB(pos);
    }

    public static AxisAlignedBB createBox(BlockPos pos1, BlockPos pos2) {
        return new AxisAlignedBB(pos1, pos2);
    }

    public static AxisAlignedBB createBox(BlockPos pos, int size) {
        return createBox(pos, pos.func_177982_a(size, size, size));
    }

    public static AxisAlignedBB createBox(BlockPos pos, int sizeX, int sizeY, int sizeZ) {
        return createBox(pos, pos.func_177982_a(sizeX, sizeY, sizeZ));
    }

    public static AxisAlignedBB createBoxCenter(BlockPos pos, int size) {
        return createBox(pos.func_177982_a(-size, -size, -size), pos.func_177982_a(size, size, size));
    }

    public static AxisAlignedBB expand(AxisAlignedBB box, double x, double y, double z) {
        return new AxisAlignedBB(box.field_72340_a - x, box.field_72338_b - y, box.field_72339_c - z, box.field_72336_d + x, box.field_72337_e + y, box.field_72334_f + z);
    }

    public static AxisAlignedBB expand(AxisAlignedBB box, double size) {
        return expand(box, size, size, size);
    }

    public static AxisAlignedBB union(AxisAlignedBB box1, AxisAlignedBB box2) {
        return box1.func_111270_a(box2);
    }
}
