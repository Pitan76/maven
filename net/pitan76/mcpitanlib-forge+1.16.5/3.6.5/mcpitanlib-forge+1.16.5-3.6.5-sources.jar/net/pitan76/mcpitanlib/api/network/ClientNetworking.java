package net.pitan76.mcpitanlib.api.network;

import dev.architectury.networking.NetworkManager;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.player.ClientPlayerEntity;
import net.minecraft.network.PacketBuffer;
import net.minecraft.util.ResourceLocation;

import static dev.architectury.networking.NetworkManager.Side.S2C;

public class ClientNetworking {
    public static void send(ResourceLocation identifier, PacketBuffer buf) {
        NetworkManager.sendToServer(identifier, buf);
    }

    public static void registerReceiver(ResourceLocation identifier, ClientNetworkHandler handler) {
        NetworkManager.registerReceiver(S2C, identifier, ((buf, context) -> handler.receive(Minecraft.func_71410_x(), Minecraft.func_71410_x().field_71439_g, buf)));
    }

    @FunctionalInterface
    public interface ClientNetworkHandler {
        void receive(Minecraft client, ClientPlayerEntity player, PacketBuffer buf);
    }
}
