package net.pitan76.mcpitanlib.api.event.block;

import net.minecraft.block.BlockState;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.Direction;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.IWorld;

public class StateForNeighborUpdateArgs {
    public BlockState state;
    public Direction direction;
    public BlockState neighborState;
    public IWorld world;
    public BlockPos pos;
    public BlockPos neighborPos;

    public StateForNeighborUpdateArgs(BlockState state, Direction direction, BlockState neighborState, IWorld world, BlockPos pos, BlockPos neighborPos) {
        this.state = state;
        this.direction = direction;
        this.neighborState = neighborState;
        this.world = world;
        this.pos = pos;
        this.neighborPos = neighborPos;
    }

    public BlockState getState() {
        return state;
    }

    public TileEntity getBlockEntity() {
        return world.func_175625_s(pos);
    }

    public BlockState getBlockState(BlockPos pos) {
        return world.func_180495_p(pos);
    }

    public TileEntity getBlockEntity(BlockPos pos) {
        return world.func_175625_s(pos);
    }

    public Direction getDirection() {
        return direction;
    }

    public BlockState getNeighborState() {
        return neighborState;
    }

    public IWorld getWorld() {
        return world;
    }

    public BlockPos getPos() {
        return pos;
    }

    public BlockPos getNeighborPos() {
        return neighborPos;
    }
}
