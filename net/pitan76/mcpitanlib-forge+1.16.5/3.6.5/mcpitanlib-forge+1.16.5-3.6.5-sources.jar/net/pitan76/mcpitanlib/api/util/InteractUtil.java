package net.pitan76.mcpitanlib.api.util;

import net.minecraft.block.BlockState;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemUseContext;
import net.minecraft.util.Direction;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.BlockRayTraceResult;
import net.minecraft.world.World;
import net.pitan76.mcpitanlib.api.entity.Player;
import net.pitan76.mcpitanlib.api.event.item.ItemUseEvent;
import net.pitan76.mcpitanlib.api.event.item.ItemUseOnBlockEvent;
import net.pitan76.mcpitanlib.api.event.item.ItemUseOnEntityEvent;
import net.pitan76.mcpitanlib.api.item.args.UseActionArgs;
import net.pitan76.mcpitanlib.api.item.consume.CompatUseAction;

public class InteractUtil {

    public static StackActionResult useItem(Item item, ItemUseEvent event) {
        return StackActionResult.create(item.func_77659_a(event.getWorld(), event.user.getEntity(), event.getHand()));
    }

    public static CompatActionResult useItemOnBlock(Item item, ItemUseContext context) {
        return CompatActionResult.create(item.func_195939_a(context));
    }

    public static CompatActionResult useItemOnBlock(Item item, ItemUseOnBlockEvent event) {
        return useItemOnBlock(item, event.toIUC());
    }

    public static CompatActionResult useItemOnEntity(Item item, ItemUseOnEntityEvent event) {
        return CompatActionResult.create(item.func_111207_a(event.getStack(), event.getUser().getEntity(), event.getEntity(), event.getHand()));
    }

    public static CompatUseAction getUseAction(Item item, UseActionArgs args) {
        return CompatUseAction.of(item.func_77661_b(args.stack));
    }

    public static CompatUseAction getUseAction(Item item, ItemStack stack) {
        return CompatUseAction.of(item.func_77661_b(stack));
    }

    public static CompatActionResult useBlock(BlockState state, World world, Player player, BlockRayTraceResult hitResult) {
        return BlockStateUtil.onUse(state, world, player, hitResult);
    }

    public static CompatActionResult useBlock(BlockState state, World world, Player player, Direction dir, BlockPos blockPos) {
        return BlockStateUtil.onUse(state, world, player, dir, blockPos);
    }

    public static boolean onStoppingUsing(Item item, ItemStack stack, World world, Player player, int remainingUseTicks) {
        item.func_77615_a(stack, world, player.getEntity(), remainingUseTicks);
        return true;
    }
}
