package net.pitan76.mcpitanlib.api.util.entity;

import net.minecraft.entity.EntityType;
import net.minecraft.entity.item.ItemEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.pitan76.mcpitanlib.api.entity.Player;
import net.pitan76.mcpitanlib.api.util.WorldUtil;
import net.pitan76.mcpitanlib.midohra.entity.ItemEntityWrapper;
import net.pitan76.mcpitanlib.midohra.util.math.Vector3d;
import net.pitan76.mcpitanlib.midohra.util.math.Vector3i;

import java.util.List;
import java.util.stream.Collectors;

public class ItemEntityUtil {
    public static ItemEntity create(World world, double x, double y, double z, ItemStack stack) {
        return new ItemEntity(world, x, y, z, stack);
    }

    public static ItemEntity create(World world, BlockPos pos, ItemStack stack) {
        return create(world, pos.func_177958_n(), pos.func_177956_o(), pos.func_177952_p(), stack);
    }

    public static ItemEntity create(World world, net.minecraft.util.math.vector.Vector3d pos, ItemStack stack) {
        return create(world, pos.field_72450_a, pos.field_72448_b, pos.field_72449_c, stack);
    }

    public static ItemEntity create(World world, double x, double y, double z, ItemStack stack, double velocityX, double velocityY, double velocityZ) {
        ItemEntity itemEntity = create(world, x, y, z, stack);
        setVelocity(itemEntity, velocityX, velocityY, velocityZ);
        return itemEntity;
    }

    public static void setVelocity(ItemEntity itemEntity, double velocityX, double velocityY, double velocityZ) {
        itemEntity.func_213293_j(velocityX, velocityY, velocityZ);
    }

    public static void setVelocity(ItemEntity itemEntity, net.minecraft.util.math.vector.Vector3d vec3d) {
        itemEntity.func_213317_d(vec3d);
    }

    public static void setPickupDelay(ItemEntity itemEntity, int pickupDelay) {
        itemEntity.func_174867_a(pickupDelay);
    }

    public static void setToDefaultPickupDelay(ItemEntity itemEntity) {
        itemEntity.func_174869_p();
    }

    public static ItemStack getStack(ItemEntity entity) {
        return entity.func_92059_d();
    }

    public static List<ItemEntity> getEntities(World world, AxisAlignedBB box) {
        return WorldUtil.getEntitiesByType(world, EntityType.field_200765_E, box);
    }

    public static ItemEntity createWithSpawn(World world, ItemStack stack, double x, double y, double z) {
        ItemEntity itemEntity = create(world, x, y, z, stack);
        setToDefaultPickupDelay(itemEntity);
        setVelocity(itemEntity, 0.0D, 0.0D, 0.0D);
        WorldUtil.spawnEntity(world, itemEntity);
        return itemEntity;
    }

    public static ItemEntity createWithSpawn(World world, ItemStack stack, BlockPos pos) {
        return createWithSpawn(world, stack, pos.func_177958_n(), pos.func_177956_o(), pos.func_177952_p());
    }

    public static ItemEntity createWithSpawn(World world, ItemStack stack, Vector3d pos) {
        return createWithSpawn(world, stack, pos.x, pos.y, pos.z);
    }

    public static ItemEntity createWithSpawn(World world, ItemStack stack, Vector3i pos) {
        return createWithSpawn(world, stack, pos.toCenter());
    }

    public static ItemEntity createWithSpawn(net.pitan76.mcpitanlib.midohra.world.World world, ItemStack stack, double x, double y, double z) {
        return createWithSpawn(world.getRaw(), stack, x, y, z);
    }

    public static ItemEntity createWithSpawn(net.pitan76.mcpitanlib.midohra.world.World world, ItemStack stack, BlockPos pos) {
        return createWithSpawn(world, stack, pos.func_177958_n(), pos.func_177956_o(), pos.func_177952_p());
    }

    public static ItemEntity createWithSpawn(net.pitan76.mcpitanlib.midohra.world.World world, ItemStack stack, Vector3i pos) {
        return createWithSpawn(world, stack, pos.toCenter());
    }

    public static ItemEntity createWithSpawn(net.pitan76.mcpitanlib.midohra.world.World world, ItemStack stack, net.pitan76.mcpitanlib.midohra.util.math.Vector3d pos) {
        return createWithSpawn(world.getRaw(), stack, pos.x, pos.y, pos.z);
    }

    public static ItemEntity createWithSpawnAtCenter(net.pitan76.mcpitanlib.midohra.world.World world, ItemStack stack, net.pitan76.mcpitanlib.midohra.util.math.BlockPos pos) {
        return createWithSpawn(world, stack, pos.toCenterVector3d());
    }

    public static ItemEntity createWithSpawn(net.pitan76.mcpitanlib.midohra.world.World world, net.pitan76.mcpitanlib.midohra.item.ItemStack stack, double x, double y, double z) {
        return createWithSpawn(world.getRaw(), stack.toMinecraft(), x, y, z);
    }

    public static ItemEntity createWithSpawn(net.pitan76.mcpitanlib.midohra.world.World world, net.pitan76.mcpitanlib.midohra.item.ItemStack stack, net.pitan76.mcpitanlib.midohra.util.math.BlockPos pos) {
        return createWithSpawn(world.getRaw(), stack.toMinecraft(), pos.toRaw());
    }

    public static ItemEntity createWithSpawn(net.pitan76.mcpitanlib.midohra.world.World world, net.pitan76.mcpitanlib.midohra.item.ItemStack stack, net.pitan76.mcpitanlib.midohra.util.math.Vector3d pos) {
        return createWithSpawn(world.getRaw(), stack.toMinecraft(), pos.x, pos.y, pos.z);
    }

    public static ItemEntity createWithSpawnAtCenter(net.pitan76.mcpitanlib.midohra.world.World world, net.pitan76.mcpitanlib.midohra.item.ItemStack stack, net.pitan76.mcpitanlib.midohra.util.math.BlockPos pos) {
        return createWithSpawn(world, stack, pos.toCenterVector3d());
    }

    public static ItemEntity createWithSpawn(net.pitan76.mcpitanlib.midohra.world.World world, net.pitan76.mcpitanlib.midohra.item.ItemStack stack, net.pitan76.mcpitanlib.midohra.util.math.Vector3i pos) {
        return createWithSpawn(world, stack, pos.toCenter());
    }

    public static List<ItemEntity> getEntities(net.pitan76.mcpitanlib.midohra.world.World world, net.pitan76.mcpitanlib.midohra.util.math.Box box) {
        return getEntities(world.getRaw(), box.toMinecraft());
    }

    public static List<ItemEntityWrapper> getEntityWrappers(net.pitan76.mcpitanlib.midohra.world.World world, net.pitan76.mcpitanlib.midohra.util.math.Box box) {
        return getEntities(world, box).stream().map(ItemEntityWrapper::of).collect(Collectors.toList());
    }

    public static void onPlayerCollision(ItemEntity itemEntity, Player player) {
        itemEntity.func_70100_b_(player.getEntity());
    }

    public static void onPlayerCollision(ItemEntityWrapper itemEntity, Player player) {
        onPlayerCollision(itemEntity.get(), player);
    }
}
