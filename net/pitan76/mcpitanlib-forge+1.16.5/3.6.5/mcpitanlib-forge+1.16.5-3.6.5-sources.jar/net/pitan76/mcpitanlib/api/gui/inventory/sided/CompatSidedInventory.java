package net.pitan76.mcpitanlib.api.gui.inventory.sided;

import net.minecraft.inventory.ISidedInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Direction;
import net.pitan76.mcpitanlib.api.gui.inventory.sided.args.AvailableSlotsArgs;
import net.pitan76.mcpitanlib.api.gui.inventory.sided.args.CanExtractArgs;
import net.pitan76.mcpitanlib.api.gui.inventory.sided.args.CanInsertArgs;
import org.jetbrains.annotations.Nullable;

public interface CompatSidedInventory extends ISidedInventory {
    @Override
    @Deprecated
    default int[] func_180463_a(Direction side) {
        return getAvailableSlots(new AvailableSlotsArgs(side, this));
    }

    int[] getAvailableSlots(AvailableSlotsArgs args);

    @Override
    @Deprecated
    default boolean func_180462_a(int slot, ItemStack stack, @Nullable Direction dir) {
        return canInsert(new CanInsertArgs(slot, stack, dir));
    }

    boolean canInsert(CanInsertArgs args);

    @Override
    @Deprecated
    default boolean func_180461_b(int slot, ItemStack stack, Direction dir) {
        return canExtract(new CanExtractArgs(slot, stack, dir));
    }

    boolean canExtract(CanExtractArgs args);
}
