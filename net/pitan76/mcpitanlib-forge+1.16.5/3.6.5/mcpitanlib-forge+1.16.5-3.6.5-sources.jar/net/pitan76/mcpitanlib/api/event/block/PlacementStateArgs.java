package net.pitan76.mcpitanlib.api.event.block;

import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.item.BlockItemUseContext;
import net.minecraft.state.Property;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.Direction;
import net.minecraft.util.Hand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.BlockRayTraceResult;
import net.minecraft.util.math.vector.Vector3d;
import net.minecraft.world.World;
import net.pitan76.mcpitanlib.api.entity.Player;
import net.pitan76.mcpitanlib.api.event.BaseEvent;
import net.pitan76.mcpitanlib.api.event.item.ItemUseOnBlockEvent;
import net.pitan76.mcpitanlib.api.state.property.IProperty;
import net.pitan76.mcpitanlib.api.util.BlockStateUtil;
import net.pitan76.mcpitanlib.api.util.WorldUtil;
import net.pitan76.mcpitanlib.mixin.ItemUsageContextMixin;
import org.jetbrains.annotations.Nullable;

public class PlacementStateArgs extends BaseEvent {
    public BlockItemUseContext ctx;

    @Nullable
    public Block block;

    public PlacementStateArgs(BlockItemUseContext ctx) {
        this.ctx = ctx;
    }

    public PlacementStateArgs(BlockItemUseContext ctx, @Nullable Block block) {
        this.ctx = ctx;
        this.block = block;
    }

    public boolean canPlace() {
        return ctx.func_196011_b();
    }

    public BlockPos getPos() {
        return ctx.func_195995_a();
    }

    public Player getPlayer() {
        return new Player(ctx.func_195999_j());
    }

    public Direction[] getPlacementDirections() {
        return ctx.func_196009_e();
    }

    public Hand getHand() {
        return ctx.func_221531_n();
    }

    public Direction getSide() {
        return ctx.func_196000_l();
    }

    public Direction getHorizontalPlayerFacing() {
        return ctx.func_195992_f();
    }

    public float getPlayerYaw() {
        return ctx.func_195990_h();
    }

    public World getWorld() {
        return ctx.func_195991_k();
    }

    public boolean isClient() {
        return getWorld().func_201670_d();
    }

    public Vector3d getHitPos() {
        return ctx.func_221532_j();
    }

    public boolean canReplaceExisting() {
        return ctx.func_196012_c();
    }

    @Deprecated
    public ItemUsageContextMixin getIUCAccessor() {
        return (ItemUsageContextMixin) ctx;
    }

    public BlockRayTraceResult getHitResult() {
        return getIUCAccessor().getHit();
    }

    public ItemUseOnBlockEvent toItemUseOnBlockEvent() {
        return new ItemUseOnBlockEvent(getWorld(), getPlayer().getPlayerEntity(), getHand(), ctx.func_195996_i(), getHitResult());
    }

    public BlockItemUseContext getCtx() {
        return ctx;
    }

    public <T extends Comparable<T>, V extends T> BlockState withBlockState(Property<T> property, V value) {
        if (block == null)
            return null;

        return BlockStateUtil.with(BlockStateUtil.getDefaultState(block), property, value);
    }

    public <T extends Comparable<T>, V extends T> net.pitan76.mcpitanlib.midohra.block.BlockState with(IProperty<T> property, V value) {
        return net.pitan76.mcpitanlib.midohra.block.BlockState.of(withBlockState(property.getProperty(), value));
    }

    public BlockState getBlockState() {
        return BlockStateUtil.getDefaultState(block);
    }

    public net.pitan76.mcpitanlib.midohra.block.BlockState getMidohraBlockState() {
        return net.pitan76.mcpitanlib.midohra.block.BlockState.of(getBlockState());
    }

    public TileEntity getBlockEntity() {
        return WorldUtil.getBlockEntity(getWorld(), getPos());
    }
}
