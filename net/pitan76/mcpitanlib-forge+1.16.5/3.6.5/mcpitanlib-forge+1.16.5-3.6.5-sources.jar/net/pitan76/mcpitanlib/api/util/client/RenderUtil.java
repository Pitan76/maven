package net.pitan76.mcpitanlib.api.util.client;

import com.mojang.blaze3d.platform.GlStateManager;
import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.Minecraft;
import net.minecraft.util.ResourceLocation;

public class RenderUtil {
    public static void setShaderToPositionTexProgram() {
        //
    }

    public static void setShaderColor(float red, float green, float blue, float alpha) {
        GlStateManager.func_227702_d_(1.0F, 1.0F, 1.0F, 1.0F);
    }

    public static void setShaderTexture(int texture, ResourceLocation id) {
        Minecraft.func_71410_x().func_110434_K().func_110577_a(id);
    }

    public static void enableDepthTest() {
        RenderSystem.enableDepthTest();
    }

    public static void enableTexture() {
        RenderSystem.enableTexture();
    }

    public static void disableTexture() {
        RenderSystem.disableTexture();
    }

    public static class RendererUtil extends ScreenUtil.RendererUtil {}
}