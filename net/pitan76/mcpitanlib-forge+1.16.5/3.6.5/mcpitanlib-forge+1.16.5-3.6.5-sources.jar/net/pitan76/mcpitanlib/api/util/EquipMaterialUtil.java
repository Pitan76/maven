package net.pitan76.mcpitanlib.api.util;

import net.minecraft.item.IItemTier;
import net.minecraft.item.crafting.Ingredient;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.SoundEvent;
import net.pitan76.mcpitanlib.api.item.ArmorEquipmentType;
import net.pitan76.mcpitanlib.api.item.CompatibleArmorMaterial;
import net.pitan76.mcpitanlib.api.tag.item.RepairIngredientTag;

public class EquipMaterialUtil {
    @Deprecated
    public static IItemTier createToolMaterial(int durability, float miningSpeedMultiplier, float attackDamage, int miningLevel, int enchantability, Ingredient repairIngredient) {
        return new IItemTier() {
            @Override
            public int func_200926_a() {
                return durability;
            }

            @Override
            public float func_200928_b() {
                return miningSpeedMultiplier;
            }

            @Override
            public float func_200929_c() {
                return attackDamage;
            }

            @Override
            public int func_200925_d() {
                return miningLevel;
            }

            @Override
            public int func_200927_e() {
                return enchantability;
            }

            @Override
            public Ingredient func_200924_f() {
                return repairIngredient;
            }
        };
    }

    public static IItemTier createToolMaterial(int durability, float miningSpeedMultiplier, float attackDamage, int miningLevel, int enchantability, RepairIngredientTag ingredientTag) {
        return createToolMaterial(durability, miningSpeedMultiplier, attackDamage, miningLevel, enchantability, ingredientTag.getIngredient());
    }

    public static int toInt(ArmorEquipmentType type) {
        switch (type.getSlot()) {
            case HEAD:
                return 0;
            case CHEST:
                return 1;
            case LEGS:
                return 2;
            case FEET:
                return 3;
            default:
                return 0;
        }
    }

    public static CompatibleArmorMaterial createArmorMaterial(int[] durability, int[] protection, int enchantability, SoundEvent equipSound, Ingredient repairIngredient, String name, float toughness, float knockbackResistance) {
        return ArmorMaterialUtil.create(name, durability, protection, enchantability, equipSound, toughness, knockbackResistance, repairIngredient);
    }

    @Deprecated
    public static CompatibleArmorMaterial createArmorMaterial(int[] durability, int[] protection, int enchantability, SoundEvent equipSound, Ingredient repairIngredient, ResourceLocation id, float toughness, float knockbackResistance) {
        return ArmorMaterialUtil.create(id, durability, protection, enchantability, equipSound, toughness, knockbackResistance, repairIngredient);
    }
}
