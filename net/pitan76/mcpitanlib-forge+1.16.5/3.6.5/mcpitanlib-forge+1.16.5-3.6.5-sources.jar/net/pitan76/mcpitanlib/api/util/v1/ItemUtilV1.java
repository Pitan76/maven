package net.pitan76.mcpitanlib.api.util.v1;

import net.minecraft.block.Block;
import net.minecraft.item.BlockItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.registry.Registry;
import net.pitan76.mcpitanlib.api.item.CompatibleItemSettings;
import net.pitan76.mcpitanlib.api.tag.TagKey;

import java.util.ArrayList;
import java.util.List;

public class ItemUtilV1 {
    public static Item item(ResourceLocation id) {
        return Registry.field_212630_s.func_82594_a(id);
    }

    public static boolean isEqual(Item item, Item item2) {
        return item == item2;
    }

    public static boolean isOf(ItemStack stack, Item item) {
        return stack.func_77973_b().equals(item);
    }

    public static boolean isIn(ItemStack stack, TagKey<Item> tagKey) {
        return isIn(stack.func_77973_b(), tagKey);
    }

    public static boolean isIn(Item item, TagKey<Item> tagKey) {
        return tagKey.isOf(item);
    }

    public static boolean isExist(ResourceLocation identifier) {
        return Registry.field_212630_s.func_212607_c(identifier);
    }
    public static ResourceLocation toID(Item item) {
        return Registry.field_212630_s.func_177774_c(item);
    }

    public static Item fromId(ResourceLocation identifier) {
        return Registry.field_212630_s.func_82594_a(identifier);
    }

    @Deprecated
    public static BlockItem ofBlock(Block block, Item.Properties settings) {
        return new BlockItem(block, settings);
    }

    public static BlockItem ofBlock(Block block, CompatibleItemSettings settings) {
        return ofBlock(block, settings.build());
    }

    @Deprecated
    public static Item of(Item.Properties settings) {
        return new Item(settings);
    }

    public static Item of(CompatibleItemSettings settings) {
        return of(settings.build());
    }

    public static List<Item> getAllItems() {
        List<Item> items = new ArrayList<>();
        for (Item item : Registry.field_212630_s) {
            items.add(item);
        }
        return items;
    }

    public static int getRawId(Item item) {
        return Registry.field_212630_s.func_148757_b(item);
    }

    public static Item fromIndex(int index) {
        return Registry.field_212630_s.func_148745_a(index);
    }
}
