package net.pitan76.mcpitanlib.api.util;

import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.DamageSource;
import net.pitan76.mcpitanlib.api.entity.Player;

public class DamageSourceUtil {
    public static DamageSource thrownProjectile(Entity projectile, Entity attacker, Entity source) {
        return thrownProjectile(projectile, attacker);
    }

    public static DamageSource thrownProjectile(Entity projectile, Entity attacker) {
        return DamageSource.func_76356_a(projectile, attacker);
    }

    public static DamageSource playerAttack(Player attacker, Entity source) {
        return playerAttack(attacker);
    }

    public static DamageSource playerAttack(Player attacker) {
        return DamageSource.func_76365_a(attacker.getPlayerEntity());
    }

    public static DamageSource mobAttack(LivingEntity attacker, Entity source) {
        return mobAttack(attacker);
    }

    public static DamageSource mobAttack(LivingEntity attacker) {
        return DamageSource.func_76358_a(attacker);
    }

    public static DamageSource mobProjectile(Entity projectile, LivingEntity attacker, Entity source) {
        return mobProjectile(projectile, attacker);
    }

    public static DamageSource mobProjectile(Entity projectile, LivingEntity attacker) {
        return DamageSource.func_188403_a(projectile, attacker);
    }

    public static DamageSource fall(Entity source) {
        return DamageSource.field_76379_h;
    }
}
