package net.pitan76.mcpitanlib.api.util;

import net.minecraft.util.text.Color;
import net.minecraft.util.text.Style;
import net.minecraft.util.text.TextFormatting;
import net.minecraft.util.text.event.ClickEvent;
import net.minecraft.util.text.event.HoverEvent;

public class StyleUtil {
    public static Style emptyStyle() {
        return Style.field_240709_b_;
    }

    public static Style withColor(Style style, int color) {
        return style.func_240718_a_(Color.func_240743_a_(color));
    }

    public static Style withBold(Style style, boolean bold) {
        return style.func_240713_a_(bold);
    }

    public static Style withItalic(Style style, boolean italic) {
        return style.func_240722_b_(italic);
    }

    public static Style withUnderline(Style style, boolean underline) {
        return style.func_244282_c(underline);
    }

    public static Style withStrikethrough(Style style, boolean strikethrough) {
        if (strikethrough) return style.func_240721_b_(TextFormatting.STRIKETHROUGH);
        return style;
    }

    public static Style withObfuscated(Style style, boolean obfuscated) {
        if (obfuscated) return style.func_240721_b_(TextFormatting.OBFUSCATED);
        return style;
    }

    public static Style withInsertion(Style style, String insertion) {
        return style.func_240714_a_(insertion);
    }

    public static Style withClickEvent(Style style, ClickEvent clickEvent) {
        return style.func_240715_a_(clickEvent);
    }

    public static Style withHoverEvent(Style style, HoverEvent hoverEvent) {
        return style.func_240716_a_(hoverEvent);
    }

    public static Style withFont(Style style, CompatIdentifier font) {
        return style.func_240719_a_(font.toMinecraft());
    }

    public static Style withFormatting(Style style, TextFormatting formatting) {
        return style.func_240721_b_(formatting);
    }

    public static Style withExclusiveFormatting(Style style, TextFormatting formatting) {
        return style.func_240723_c_(formatting);
    }
}
