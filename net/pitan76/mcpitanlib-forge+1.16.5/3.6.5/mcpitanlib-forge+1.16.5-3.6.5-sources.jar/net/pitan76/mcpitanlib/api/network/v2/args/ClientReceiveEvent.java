package net.pitan76.mcpitanlib.api.network.v2.args;

import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.player.ClientPlayerEntity;
import net.minecraft.network.PacketBuffer;
import net.minecraft.world.World;
import net.pitan76.mcpitanlib.api.entity.Player;
import net.pitan76.mcpitanlib.midohra.network.CompatPacketByteBuf;

public class ClientReceiveEvent {
    public Minecraft client;
    public ClientPlayerEntity clientPlayer;
    public Player player;
    public PacketBuffer buf;

    public ClientReceiveEvent(Minecraft client, ClientPlayerEntity player, PacketBuffer buf) {
        this.client = client;
        this.clientPlayer = player;
        this.player = new Player(player);
        this.buf = buf;
    }

    public ClientPlayerEntity getClientPlayer() {
        return clientPlayer;
    }

    public Player getPlayer() {
        return player;
    }

    public Minecraft getClient() {
        return client;
    }

    public PacketBuffer getBuf() {
        return buf;
    }

    public CompatPacketByteBuf getCompatBuf() {
        return CompatPacketByteBuf.of(buf);
    }

    public World getWorld() {
        return getPlayer().getWorld();
    }

    public net.pitan76.mcpitanlib.midohra.world.World getMidohraWorld() {
        return net.pitan76.mcpitanlib.midohra.world.World.of(getWorld());
    }
}
