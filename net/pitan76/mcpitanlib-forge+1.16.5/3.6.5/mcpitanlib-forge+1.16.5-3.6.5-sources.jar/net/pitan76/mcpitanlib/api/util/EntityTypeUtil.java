package net.pitan76.mcpitanlib.api.util;

import net.minecraft.entity.EntityType;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.registry.Registry;
import net.minecraft.util.text.ITextComponent;

public class EntityTypeUtil {
    public static ResourceLocation toID(EntityType<?> entityType) {
        return Registry.field_212629_r.func_177774_c(entityType);
    }

    public static EntityType<?> fromId(ResourceLocation identifier) {
        return Registry.field_212629_r.func_82594_a(identifier);
    }

    public static boolean isExist(ResourceLocation identifier) {
        return Registry.field_212629_r.func_212607_c(identifier);
    }

    public static CompatIdentifier toCompatID(EntityType<?> entityType) {
        return CompatIdentifier.fromMinecraft(toID(entityType));
    }

    public static EntityType<?> fromId(CompatIdentifier identifier) {
        return fromId(identifier.toMinecraft());
    }

    public static boolean isExist(CompatIdentifier identifier) {
        return isExist(identifier.toMinecraft());
    }

    public static int getRawId(EntityType<?> type) {
        return Registry.field_212629_r.func_148757_b(type);
    }

    public static EntityType<?> fromIndex(int index) {
        return Registry.field_212629_r.func_148745_a(index);
    }

    public static ITextComponent getName(EntityType<?> entityType) {
        return entityType.func_212546_e();
    }

    public static String getTranslationKey(EntityType<?> entityType) {
        return entityType.func_210760_d();
    }
}
