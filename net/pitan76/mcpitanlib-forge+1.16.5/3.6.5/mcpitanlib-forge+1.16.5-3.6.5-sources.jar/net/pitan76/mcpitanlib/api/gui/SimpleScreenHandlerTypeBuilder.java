package net.pitan76.mcpitanlib.api.gui;

import me.shedaniel.architectury.registry.MenuRegistry;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.inventory.container.Container;
import net.minecraft.inventory.container.ContainerType;
import net.pitan76.mcpitanlib.api.gui.args.CreateMenuEvent;

public class SimpleScreenHandlerTypeBuilder<T extends Container> {

    private final Factory<T> factory;

    public SimpleScreenHandlerTypeBuilder(Factory<T> factory) {
        this.factory = factory;
    }

    public SimpleScreenHandlerTypeBuilder(Factory2<T> factory) {
        this.factory = factory;
    }

    public ContainerType<T> build() {
        return MenuRegistry.of(factory::create);
    }

    @FunctionalInterface
    public interface Factory<T extends Container> {
        T create(int syncId, PlayerInventory inventory);
    }

    @FunctionalInterface
    public interface Factory2<T extends Container> extends Factory<T> {
        T create(CreateMenuEvent e);

        @Override
        default T create(int syncId, PlayerInventory inventory) {
            return create(new CreateMenuEvent(syncId, inventory));
        }
    }
}
