package net.pitan76.mcpitanlib.api.item;

import net.minecraft.item.ItemGroup;

public class DefaultItemGroups {
    public static final ItemGroup BUILDING_BLOCKS = ItemGroup.field_78030_b;
    public static final ItemGroup COLORED_BLOCKS = ItemGroup.field_78030_b;
    public static final ItemGroup NATURAL = ItemGroup.field_78031_c;
    public static final ItemGroup FUNCTIONAL = ItemGroup.field_78029_e;
    public static final ItemGroup REDSTONE = ItemGroup.field_78028_d;
    public static final ItemGroup HOTBAR = ItemGroup.field_192395_m;
    public static final ItemGroup SEARCH = ItemGroup.field_78027_g;
    public static final ItemGroup TOOLS = ItemGroup.field_78040_i;
    public static final ItemGroup COMBAT = ItemGroup.field_78037_j;
    public static final ItemGroup FOOD_AND_DRINK = ItemGroup.field_78039_h;
    public static final ItemGroup INGREDIENTS = ItemGroup.field_78026_f;
    public static final ItemGroup SPAWN_EGGS = ItemGroup.field_78026_f;
    public static final ItemGroup OPERATOR = ItemGroup.field_78026_f;
    public static final ItemGroup INVENTORY = ItemGroup.field_78036_m;

    // ～1.19.2 Item Group
    public static final ItemGroup BREWING = ItemGroup.field_78038_k; // if version is 1.19.3, FOOD_AND_DRINK
    public static final ItemGroup TRANSPORTATION = ItemGroup.field_78029_e; // if version is 1.19.3, FUNCTIONAL
    public static final ItemGroup DECORATIONS = ItemGroup.field_78031_c; // if version is 1.19.3, NATURAL
    public static final ItemGroup MISC = ItemGroup.field_78026_f; // if version is 1.19.3, INGREDIENTS
}
