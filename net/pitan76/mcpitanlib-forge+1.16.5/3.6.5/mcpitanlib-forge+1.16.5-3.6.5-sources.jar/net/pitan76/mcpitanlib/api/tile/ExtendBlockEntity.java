package net.pitan76.mcpitanlib.api.tile;

import net.minecraft.tileentity.TileEntityType;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.pitan76.mcpitanlib.api.event.block.TileCreateEvent;
import net.pitan76.mcpitanlib.api.world.ExtendWorld;

public class ExtendBlockEntity extends CompatBlockEntity {
    public ExtendWorld world;

    public ExtendBlockEntity(TileEntityType<?> type) {
        super(type);
    }

    public ExtendBlockEntity(TileEntityType<?> type, TileCreateEvent event) {
        this(type);
    }

    @Override
    public void func_226984_a_(World world, BlockPos pos) {
        super.func_226984_a_(world, pos);
        this.world = new ExtendWorld(world);
    }
}
