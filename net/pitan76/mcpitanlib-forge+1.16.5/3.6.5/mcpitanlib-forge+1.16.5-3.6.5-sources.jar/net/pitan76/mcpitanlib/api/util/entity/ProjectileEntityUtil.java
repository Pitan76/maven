package net.pitan76.mcpitanlib.api.util.entity;

import net.minecraft.entity.Entity;
import net.minecraft.entity.projectile.ProjectileEntity;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.vector.Vector3d;

public class ProjectileEntityUtil {
    public static void setVelocity(ProjectileEntity projectileEntity, Entity shooter, float pitch, float yaw, float roll, float speed, float divergence) {
        float f = -MathHelper.func_76126_a(yaw * ((float)Math.PI / 180F)) * MathHelper.func_76134_b(pitch * ((float)Math.PI / 180F));
        float g = -MathHelper.func_76126_a((pitch + roll) * ((float)Math.PI / 180F));
        float h = MathHelper.func_76134_b(yaw * ((float)Math.PI / 180F)) * MathHelper.func_76134_b(pitch * ((float)Math.PI / 180F));
        projectileEntity.func_70186_c(f, g, h, speed, divergence);
        Vector3d vec3d = shooter.func_213322_ci();
        projectileEntity.func_213317_d(projectileEntity.func_213322_ci().func_72441_c(vec3d.field_72450_a, shooter.func_233570_aj_() ? (double)0.0F : vec3d.field_72448_b, vec3d.field_72449_c));
    }

    public static void setVelocity(ProjectileEntity projectileEntity, double x, double y, double z, float power, float uncertainty) {
        projectileEntity.func_70186_c(x, y, z, power, uncertainty);
    }
}
