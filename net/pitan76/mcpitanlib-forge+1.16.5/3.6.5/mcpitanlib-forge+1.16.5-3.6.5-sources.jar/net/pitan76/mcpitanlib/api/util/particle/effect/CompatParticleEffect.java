package net.pitan76.mcpitanlib.api.util.particle.effect;

import net.minecraft.particles.IParticleData;
import net.pitan76.mcpitanlib.api.network.PacketByteUtil;
import net.pitan76.mcpitanlib.api.util.particle.CompatParticleType;

public class CompatParticleEffect {
    private final IParticleData effect;

    @Deprecated
    public CompatParticleEffect(IParticleData effect) {
        this.effect = effect;
    }

    @Deprecated
    public static CompatParticleEffect of(IParticleData effect) {
        return new CompatParticleEffect(effect);
    }

    public static CompatParticleEffect of(CompatParticleType type) {
        IParticleData.IDeserializer factory = type.getRaw().func_197571_g();
        IParticleData options = factory.func_197543_b(type.getRaw(), PacketByteUtil.create());
        return new CompatParticleEffect(options);
    }

    @Deprecated
    public IParticleData getRaw() {
        return effect;
    }

    public CompatParticleType getType() {
        return CompatParticleType.of(getRaw().func_197554_b());
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        CompatParticleEffect other = (CompatParticleEffect) obj;
        return getRaw().equals(other.getRaw());
    }

    @Override
    public int hashCode() {
        return getRaw().hashCode();
    }
}
