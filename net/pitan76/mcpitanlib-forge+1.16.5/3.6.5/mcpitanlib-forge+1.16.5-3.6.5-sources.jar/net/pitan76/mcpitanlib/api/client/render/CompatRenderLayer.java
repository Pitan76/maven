package net.pitan76.mcpitanlib.api.client.render;

import net.minecraft.client.renderer.RenderType;
import net.pitan76.mcpitanlib.api.util.CompatIdentifier;

public class CompatRenderLayer {
    public static final CompatRenderLayer CUTOUT = new CompatRenderLayer(RenderType.func_228643_e_());
    public static final CompatRenderLayer CUTOUT_MIPPED = new CompatRenderLayer(RenderType.func_228641_d_());
    public static final CompatRenderLayer TRANSLUCENT = new CompatRenderLayer(RenderType.func_228645_f_());
    public static final CompatRenderLayer TRANSLUCENT_MOVING_BLOCK = new CompatRenderLayer(RenderType.func_239269_g_());
    public static final CompatRenderLayer SOLID = new CompatRenderLayer(RenderType.func_228639_c_());
    public static final CompatRenderLayer LINES = new CompatRenderLayer(RenderType.func_228659_m_());
    public static final CompatRenderLayer LINE_STRIP = new CompatRenderLayer(RenderType.func_228659_m_());
    public static final CompatRenderLayer GLINT = new CompatRenderLayer(RenderType.func_228653_j_());

    public final RenderType layer;

    public CompatRenderLayer(RenderType layer) {
        this.layer = layer;
    }

    public RenderType raw() {
        return layer;
    }

    public static CompatRenderLayer getEntityCutout(CompatIdentifier id) {
        return new CompatRenderLayer(RenderType.func_228638_b_(id.toMinecraft()));
    }

    public static CompatRenderLayer getEntityCutoutNoCull(CompatIdentifier id) {
        return new CompatRenderLayer(RenderType.func_228640_c_(id.toMinecraft()));
    }

    public static CompatRenderLayer getEntityTranslucent(CompatIdentifier id) {
        return new CompatRenderLayer(RenderType.func_228644_e_(id.toMinecraft()));
    }

    public static CompatRenderLayer getArmorCutoutNoCull(CompatIdentifier id) {
        return new CompatRenderLayer(RenderType.func_239263_a_(id.toMinecraft()));
    }

    public static CompatRenderLayer getEntitySolid(CompatIdentifier id) {
        return new CompatRenderLayer(RenderType.func_228634_a_(id.toMinecraft()));
    }
}
