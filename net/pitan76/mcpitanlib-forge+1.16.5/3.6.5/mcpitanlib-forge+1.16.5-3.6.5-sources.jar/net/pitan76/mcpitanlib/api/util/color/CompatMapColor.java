package net.pitan76.mcpitanlib.api.util.color;

import net.minecraft.block.material.MaterialColor;

public class CompatMapColor {
    private final MaterialColor color;

    public static final CompatMapColor CLEAR = of(MaterialColor.field_151660_b);
    public static final CompatMapColor PALE_GREEN = of(MaterialColor.field_151661_c);
    public static final CompatMapColor PALE_YELLOW = of(MaterialColor.field_151658_d);
    public static final CompatMapColor WHITE_GRAY = of(MaterialColor.field_151659_e);
    public static final CompatMapColor BRIGHT_RED = of(MaterialColor.field_151656_f);
    public static final CompatMapColor PALE_PURPLE = of(MaterialColor.field_151657_g);
    public static final CompatMapColor IRON_GRAY = of(MaterialColor.field_151668_h);
    public static final CompatMapColor DARK_GREEN = of(MaterialColor.field_151669_i);
    public static final CompatMapColor WHITE = of(MaterialColor.field_151666_j);
    public static final CompatMapColor LIGHT_BLUE_GRAY = of(MaterialColor.field_151667_k);
    public static final CompatMapColor DIRT_BROWN = of(MaterialColor.field_151664_l);
    public static final CompatMapColor STONE_GRAY = of(MaterialColor.field_151665_m);
    public static final CompatMapColor WATER_BLUE = of(MaterialColor.field_151662_n);
    public static final CompatMapColor OAK_TAN = of(MaterialColor.field_151663_o);
    public static final CompatMapColor OFF_WHITE = of(MaterialColor.field_151677_p);
    public static final CompatMapColor ORANGE = of(MaterialColor.field_151676_q);
    public static final CompatMapColor MAGENTA = of(MaterialColor.field_151675_r);
    public static final CompatMapColor LIGHT_BLUE = of(MaterialColor.field_151674_s);
    public static final CompatMapColor YELLOW = of(MaterialColor.field_151673_t);
    public static final CompatMapColor LIME = of(MaterialColor.field_151672_u);
    public static final CompatMapColor PINK = of(MaterialColor.field_151671_v);
    public static final CompatMapColor GRAY = of(MaterialColor.field_151670_w);
    public static final CompatMapColor LIGHT_GRAY = of(MaterialColor.field_197656_x);
    public static final CompatMapColor CYAN = of(MaterialColor.field_151679_y);
    public static final CompatMapColor PURPLE = of(MaterialColor.field_151678_z);
    public static final CompatMapColor BLUE = of(MaterialColor.field_151649_A);
    public static final CompatMapColor BROWN = of(MaterialColor.field_151650_B);
    public static final CompatMapColor GREEN = of(MaterialColor.field_151651_C);
    public static final CompatMapColor RED = of(MaterialColor.field_151645_D);
    public static final CompatMapColor BLACK = of(MaterialColor.field_151646_E);
    public static final CompatMapColor GOLD = of(MaterialColor.field_151647_F);
    public static final CompatMapColor DIAMOND_BLUE = of(MaterialColor.field_151648_G);
    public static final CompatMapColor LAPIS_BLUE = of(MaterialColor.field_151652_H);
    public static final CompatMapColor EMERALD_GREEN = of(MaterialColor.field_151653_I);
    public static final CompatMapColor SPRUCE_BROWN = of(MaterialColor.field_151654_J);
    public static final CompatMapColor DARK_RED = of(MaterialColor.field_151655_K);
    public static final CompatMapColor TERRACOTTA_WHITE = of(MaterialColor.field_193561_M);
    public static final CompatMapColor TERRACOTTA_ORANGE = of(MaterialColor.field_193562_N);
    public static final CompatMapColor TERRACOTTA_MAGENTA = of(MaterialColor.field_193563_O);
    public static final CompatMapColor TERRACOTTA_LIGHT_BLUE = of(MaterialColor.field_193564_P);
    public static final CompatMapColor TERRACOTTA_YELLOW = of(MaterialColor.field_193565_Q);
    public static final CompatMapColor TERRACOTTA_LIME = of(MaterialColor.field_193566_R);
    public static final CompatMapColor TERRACOTTA_PINK = of(MaterialColor.field_193567_S);
    public static final CompatMapColor TERRACOTTA_GRAY = of(MaterialColor.field_193568_T);
    public static final CompatMapColor TERRACOTTA_LIGHT_GRAY = of(MaterialColor.field_197655_T);
    public static final CompatMapColor TERRACOTTA_CYAN = of(MaterialColor.field_193570_V);
    public static final CompatMapColor TERRACOTTA_PURPLE = of(MaterialColor.field_193571_W);
    public static final CompatMapColor TERRACOTTA_BLUE = of(MaterialColor.field_193572_X);
    public static final CompatMapColor TERRACOTTA_BROWN = of(MaterialColor.field_193573_Y);
    public static final CompatMapColor TERRACOTTA_GREEN = of(MaterialColor.field_193574_Z);
    public static final CompatMapColor TERRACOTTA_RED = of(MaterialColor.field_193559_aa);
    public static final CompatMapColor TERRACOTTA_BLACK = of(MaterialColor.field_193560_ab);
    public static final CompatMapColor DULL_RED = of(MaterialColor.field_151645_D);
    public static final CompatMapColor DULL_PINK = of(MaterialColor.field_151671_v);
    public static final CompatMapColor DARK_CRIMSON = of(MaterialColor.field_151655_K);
    public static final CompatMapColor TEAL = of(MaterialColor.field_151645_D);
    public static final CompatMapColor DARK_AQUA = of(MaterialColor.field_151662_n);
    public static final CompatMapColor DARK_DULL_PINK = of(MaterialColor.field_193567_S);
    public static final CompatMapColor BRIGHT_TEAL = of(MaterialColor.field_151656_f);
    public static final CompatMapColor DEEPSLATE_GRAY = of(MaterialColor.field_151665_m);
    public static final CompatMapColor RAW_IRON_PINK = of(MaterialColor.field_151671_v);
    public static final CompatMapColor LICHEN_GREEN = of(MaterialColor.field_151651_C);

    public CompatMapColor(MaterialColor color) {
        this.color = color;
    }

    public static CompatMapColor of(MaterialColor color) {
        return new CompatMapColor(color);
    }

    public MaterialColor getColor() {
        return color;
    }

    public int getId() {
        return color.field_76290_q;
    }

    public int getRgb() {
        return color.field_76291_p;
    }

    public int getRenderColor(CompatBrightness brightness) {
        return color.func_151643_b(brightness.get());
    }

    @Override
    public int hashCode() {
        return color.hashCode();
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        CompatMapColor other = (CompatMapColor) obj;
        return color.equals(other.color);
    }
}
