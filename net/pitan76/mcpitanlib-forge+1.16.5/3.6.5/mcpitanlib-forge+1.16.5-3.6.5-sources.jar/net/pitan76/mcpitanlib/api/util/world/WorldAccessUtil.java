package net.pitan76.mcpitanlib.api.util.world;

import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.entity.Entity;
import net.minecraft.fluid.Fluid;
import net.minecraft.server.MinecraftServer;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.IWorld;
import net.minecraft.world.World;

public class WorldAccessUtil extends WorldViewUtil {

    public static void scheduleBlockTick(IWorld world, BlockPos pos, Block block, int delay) {
        world.func_205220_G_().func_205360_a(pos, block, delay);
    }

    public static void scheduleFluidTick(IWorld world, BlockPos pos, Fluid fluid, int delay) {
        world.func_205219_F_().func_205360_a(pos, fluid, delay);
    }

    public static boolean setBlockState(IWorld world, BlockPos pos, BlockState state, int flags) {
        return world.func_180501_a(pos, state, flags);
    }

    public static boolean setBlockState(IWorld world, BlockPos pos, BlockState state, int flags, int maxUpdateDepth) {
        return world.func_241211_a_(pos, state, flags, maxUpdateDepth);
    }

    public static boolean setBlockState(IWorld world, BlockPos pos, BlockState state) {
        return setBlockState(world, pos, state, 3);
    }

    public static BlockState getBlockState(IWorld world, BlockPos pos) {
        return world.func_180495_p(pos);
    }

    public static boolean breakBlock(IWorld world, BlockPos pos, boolean drop) {
        return world.func_175655_b(pos, drop);
    }

    public static boolean breakBlock(IWorld world, BlockPos pos, boolean drop, Entity entity) {
        return world.func_225521_a_(pos, drop, entity);
    }

    public static boolean removeBlock(IWorld world, BlockPos pos, boolean move) {
        return world.func_217377_a(pos, move);
    }

    public static MinecraftServer getServer(IWorld world) {
        if (world instanceof World) {
            return ((World) world).func_73046_m();
        } else {
            return null;
        }
    }
}
