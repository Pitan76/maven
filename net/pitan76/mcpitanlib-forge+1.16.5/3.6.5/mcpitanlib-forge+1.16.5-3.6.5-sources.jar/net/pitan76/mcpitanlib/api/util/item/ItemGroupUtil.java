package net.pitan76.mcpitanlib.api.util.item;

import net.minecraft.item.ItemGroup;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.text.TranslationTextComponent;
import net.pitan76.mcpitanlib.api.util.CompatIdentifier;

public class ItemGroupUtil {
    public static ResourceLocation toID(ItemGroup itemGroup) {
        if (itemGroup.func_242392_c() instanceof TranslationTextComponent) {
            TranslationTextComponent translatableText = (TranslationTextComponent) itemGroup.func_242392_c();
                String[] strings = translatableText.func_150268_i().split("\\.");

                if (strings.length == 3)
                    return new ResourceLocation(strings[1], strings[2]);
        }

        return CompatIdentifier.empty().toMinecraft();
    }

    public static ItemGroup fromId(ResourceLocation identifier) {
        return null;
    }

    public static boolean isExist(ResourceLocation identifier) {
        return false;
    }

    public static CompatIdentifier toCompatID(ItemGroup itemGroup) {
        return CompatIdentifier.fromMinecraft(toID(itemGroup));
    }

    public static ItemGroup fromId(CompatIdentifier identifier) {
        return fromId(identifier.toMinecraft());
    }

    public static boolean isExist(CompatIdentifier identifier) {
        return isExist(identifier.toMinecraft());
    }

    public static int getRawId(ItemGroup itemGroup) {
        return itemGroup.func_78021_a();
    }

    public static ItemGroup fromIndex(int index) {
        return ItemGroup.field_78032_a[index];
    }
}
