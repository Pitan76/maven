package net.pitan76.mcpitanlib.api.event.block;

import net.minecraft.block.BlockState;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.IBlockReader;
import net.minecraft.world.IWorldReader;
import org.jetbrains.annotations.Nullable;

public class PickStackEvent {

    @Deprecated
    public IWorldReader worldView;

    @Deprecated
    public IBlockReader blockView;

    public BlockPos pos;
    public BlockState state;

    public boolean includeData = true;

    public PickStackEvent(IWorldReader world, BlockPos pos, BlockState state) {
        this.worldView = world;
        this.pos = pos;
        this.state = state;
    }

    public PickStackEvent(IBlockReader world, BlockPos pos, BlockState state) {
        this.blockView = world;
        this.pos = pos;
        this.state = state;
    }

    public BlockState getState() {
        return state;
    }

    public BlockPos getPos() {
        return pos;
    }

    @Nullable
    public IBlockReader getBlockView() {
        return blockView;
    }

    @Nullable
    public IWorldReader getWorldView() {
        return worldView;
    }

    /**
     * check if the block has a block entity
     * @return boolean
     */
    public boolean hasBlockEntity() {
        return getBlockEntity() != null;
    }

    /**
     * @return BlockEntity
     */
    public TileEntity getBlockEntity() {
        if (blockView != null)
            return blockView.func_175625_s(pos);
        if (worldView != null)
            return worldView.func_175625_s(pos);
        return null;
    }

    public boolean isClient() {
        if (blockView != null)
            return getBlockEntity().func_145831_w().func_201670_d();
        if (worldView != null)
            return worldView.func_201670_d();

        try {
            net.minecraft.client.Minecraft.func_71410_x();
            return true;
        } catch (Error e) {
            return false;
        }
    }

    public void setIncludeData(boolean includeData) {
        this.includeData = includeData;
    }

    public boolean isIncludeData() {
        return includeData;
    }
}
