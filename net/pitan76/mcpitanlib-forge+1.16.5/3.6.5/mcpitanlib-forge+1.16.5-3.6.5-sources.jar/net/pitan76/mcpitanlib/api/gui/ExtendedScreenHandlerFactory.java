package net.pitan76.mcpitanlib.api.gui;

import me.shedaniel.architectury.registry.menu.ExtendedMenuProvider;
import net.minecraft.network.PacketBuffer;
import net.minecraft.util.text.ITextComponent;
import net.pitan76.mcpitanlib.api.event.container.factory.DisplayNameArgs;
import net.pitan76.mcpitanlib.api.event.container.factory.ExtraDataArgs;

@Deprecated
public interface ExtendedScreenHandlerFactory extends ExtendedMenuProvider {
    @Override
    default ITextComponent func_145748_c_() {
        return getDisplayName(new DisplayNameArgs());
    }

    @Override
    default void saveExtraData(PacketBuffer buf) {
        writeExtraData(new ExtraDataArgs(buf));
    }

    ITextComponent getDisplayName(DisplayNameArgs args);

    void writeExtraData(ExtraDataArgs args);
}
