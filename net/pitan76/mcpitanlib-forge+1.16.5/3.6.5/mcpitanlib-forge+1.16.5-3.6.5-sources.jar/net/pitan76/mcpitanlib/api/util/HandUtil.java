package net.pitan76.mcpitanlib.api.util;

import net.minecraft.inventory.EquipmentSlotType;
import net.minecraft.util.Hand;

public class HandUtil {
    public static Hand getOppositeHand(Hand hand) {
        return hand == Hand.MAIN_HAND ? Hand.OFF_HAND : Hand.MAIN_HAND;
    }

    public static EquipmentSlotType getEquipmentSlot(Hand hand) {
        return hand == Hand.MAIN_HAND ? EquipmentSlotType.MAINHAND : EquipmentSlotType.OFFHAND;
    }

    public static Hand getHand(EquipmentSlotType slot) {
        return slot == EquipmentSlotType.MAINHAND ? Hand.MAIN_HAND : Hand.OFF_HAND;
    }

    public static Hand getHand(boolean mainHand) {
        return mainHand ? Hand.MAIN_HAND : Hand.OFF_HAND;
    }

    public static boolean isMainHand(Hand hand) {
        return hand == Hand.MAIN_HAND;
    }

    public static boolean isOffHand(Hand hand) {
        return hand == Hand.OFF_HAND;
    }

    public static boolean isMainHand(EquipmentSlotType slot) {
        return slot == EquipmentSlotType.MAINHAND;
    }

    public static boolean isOffHand(EquipmentSlotType slot) {
        return slot == EquipmentSlotType.OFFHAND;
    }
}
