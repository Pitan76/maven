package net.pitan76.mcpitanlib.api.event.v0.event;

import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.DamageSource;
import net.minecraft.world.World;
import net.pitan76.mcpitanlib.api.entity.Player;

public class LivingHurtEvent {
    public LivingEntity entity;
    public DamageSource damageSource;
    public float damageAmount;

    public LivingHurtEvent(LivingEntity entity, DamageSource damageSource, float damageAmount) {
        this.entity = entity;
        this.damageSource = damageSource;
        this.damageAmount = damageAmount;
    }

    public LivingEntity getEntity() {
        return entity;
    }

    public DamageSource getDamageSource() {
        return damageSource;
    }

    public float getDamageAmount() {
        return damageAmount;
    }

    public Entity getAttacker() {
        return damageSource.func_76346_g();
    }

    public Entity getSource() {
        return damageSource.func_76364_f();
    }

    public boolean isDirect() {
        return !damageSource.func_76350_n();
    }

    public boolean isPlayerAttacker() {
        return getAttacker() instanceof PlayerEntity;
    }

    public PlayerEntity getPlayerEntityAttacker() {
        return (PlayerEntity) getAttacker();
    }

    public Player getPlayerAttacker() {
        return new Player(getPlayerEntityAttacker());
    }

    public World getWorld() {
        return entity.func_130014_f_();
    }

    public boolean isClient() {
        return getWorld().func_201670_d();
    }

    public ItemStack getWeaponStack() {
        if (isPlayerAttacker())
            return getPlayerAttacker().getMainHandStack();

        if (getAttacker() instanceof LivingEntity) {
            LivingEntity livingEntity = (LivingEntity) getAttacker();
            return livingEntity.func_184614_ca();
        }

        return ItemStack.field_190927_a;
    }

    public Item getWeaponItem() {
        return getWeaponStack().func_77973_b();
    }

    public boolean isWeaponEmpty() {
        return getWeaponStack().func_190926_b();
    }

    public boolean isWeaponItemEqual(Item item) {
        if (isWeaponEmpty()) return false;
        return getWeaponItem() == item;
    }
}
