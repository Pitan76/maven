package net.pitan76.mcpitanlib.api.gui.slot;

import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.inventory.IInventory;
import net.minecraft.inventory.container.Slot;
import net.minecraft.item.ItemStack;
import net.pitan76.mcpitanlib.api.entity.Player;
import net.pitan76.mcpitanlib.api.util.inventory.ICompatInventory;

public class CompatibleSlot extends Slot {
    public IInventory inventory;
    public int index;
    public int x;
    public int y;

    public CompatibleSlot(IInventory inventory, int index, int x, int y) {
        super(inventory, index, x, y);
        this.field_75224_c = inventory;
        this.index = index;
        this.field_75223_e = x;
        this.field_75221_f = y;
    }

    public CompatibleSlot(ICompatInventory inventory, int index, int x, int y) {
        super(inventory, index, x, y);
        this.field_75224_c = inventory;
        this.index = index;
        this.field_75223_e = x;
        this.field_75221_f = y;
    }

    public void callSetStack(ItemStack stack) {
        super.func_75215_d(stack);
    }

    public void callSetStackNoCallbacks(ItemStack stack) {
        //super.setStackNoCallbacks(stack);
    }

    public ItemStack callGetStack() {
        return super.func_75211_c();
    }

    public ItemStack callTakeStack(int amount) {
        return super.func_75209_a(amount);
    }

    public boolean callHasStack() {
        return super.func_75216_d();
    }

    @Deprecated
    @Override
    public void func_75215_d(ItemStack stack) {
       callSetStack(stack);
    }

    @Deprecated
    @Override
    public ItemStack func_75211_c() {
        return callGetStack();
    }

    @Deprecated
    @Override
    public ItemStack func_75209_a(int amount) {
        return callTakeStack(amount);
    }

    @Deprecated
    @Override
    public boolean func_75216_d() {
        return callHasStack();
    }

    public IInventory callGetInventory() {
        return field_75224_c;
    }

    public int callGetIndex() {
        return index;
    }

    public int callGetId() {
        return super.field_75222_d;
    }

    public int callGetX() {
        return super.field_75223_e;
    }

    public int callGetY() {
        return super.field_75221_f;
    }

    public void callMarkDirty() {
        super.func_75218_e();
    }

    @Override
    public boolean func_75214_a(ItemStack stack) {
        return canInsert(net.pitan76.mcpitanlib.midohra.item.ItemStack.of(stack));
    }

    @Override
    public boolean func_82869_a(PlayerEntity playerEntity) {
        return canTakeItems(new Player(playerEntity));
    }

    public boolean canInsert(net.pitan76.mcpitanlib.midohra.item.ItemStack stack) {
        return super.func_75214_a(stack.toMinecraft());
    }

    public boolean canTakeItems(Player player) {
        return super.func_82869_a(player.getEntity());
    }

    public boolean canTakePartial(Player player) {
        return canTakeItems(player);
    }
}
