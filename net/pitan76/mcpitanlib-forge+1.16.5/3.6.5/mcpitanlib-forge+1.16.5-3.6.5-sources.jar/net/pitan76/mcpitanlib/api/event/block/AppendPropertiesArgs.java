package net.pitan76.mcpitanlib.api.event.block;

import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.state.Property;
import net.minecraft.state.StateContainer;
import net.pitan76.mcpitanlib.api.event.BaseEvent;
import net.pitan76.mcpitanlib.api.state.property.IProperty;
import net.pitan76.mcpitanlib.api.util.DirectionBoolPropertyUtil;

public class AppendPropertiesArgs extends BaseEvent {
    public StateContainer.Builder<Block, BlockState> builder;

    public AppendPropertiesArgs(StateContainer.Builder<Block, BlockState> builder) {
        this.builder = builder;
    }

    public StateContainer.Builder<Block, BlockState> getBuilder() {
        return builder;
    }

    public void addProperty(Property<?>... properties) {
        builder.func_206894_a(properties);
    }

    public void addProperty(IProperty<?>... properties) {
        for (IProperty<?> property : properties) {
            builder.func_206894_a(property.getProperty());
        }
    }

    public void addAllDirectionBoolProperties() {
        DirectionBoolPropertyUtil.addProperties(this);
    }
}
