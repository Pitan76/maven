package net.pitan76.mcpitanlib.api.world;

import net.minecraft.nbt.CompoundNBT;
import net.minecraft.world.storage.WorldSavedData;
import net.pitan76.mcpitanlib.api.event.nbt.ReadNbtArgs;
import net.pitan76.mcpitanlib.api.event.nbt.WriteNbtArgs;

public abstract class CompatiblePersistentState extends WorldSavedData {

    public static int count = 1;

    // 1.16
    public CompatiblePersistentState(String key) {
        super(key);
    }

    public CompatiblePersistentState() {
        this("mcpitanlib_" + count);
        count++;
    }

    // 1.16
    @Deprecated
    public void readNbt(CompoundNBT tag) {
        readNbt(new ReadNbtArgs(tag));
    }

    public abstract void readNbt(ReadNbtArgs args);

    @Deprecated
    @Override
    public void func_76184_a(CompoundNBT tag) {
        readNbt(tag);
    }

    @Deprecated
    @Override
    public CompoundNBT func_189551_b(CompoundNBT nbt) {
        return writeNbt(new WriteNbtArgs(nbt));
    }

    public abstract CompoundNBT writeNbt(WriteNbtArgs args);

    @Deprecated
    @Override
    public void func_76185_a() {
        callMarkDirty();
    }

    public void callMarkDirty() {
        super.func_76185_a();
    }

    @Deprecated
    @Override
    public void func_76186_a(boolean dirty) {
        callSetDirty(dirty);
    }

    public void callSetDirty(boolean dirty) {
        super.func_76186_a(dirty);
    }
}
