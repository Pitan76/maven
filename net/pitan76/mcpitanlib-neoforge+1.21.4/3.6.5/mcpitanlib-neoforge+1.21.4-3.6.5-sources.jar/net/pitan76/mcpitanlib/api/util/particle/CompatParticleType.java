package net.pitan76.mcpitanlib.api.util.particle;

import net.minecraft.core.particles.ParticleType;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;
import net.pitan76.mcpitanlib.api.util.CompatIdentifier;

public class CompatParticleType {
    private final ParticleType<?> particleType;

    public CompatParticleType(ParticleType<?> particleType) {
        this.particleType = particleType;
    }

    public static CompatParticleType of(ParticleType<?> particleType) {
        return new CompatParticleType(particleType);
    }

    public ParticleType<?> getRaw() {
        return particleType;
    }

    public boolean shouldAlwaysSpawn() {
        return particleType.getOverrideLimiter();
    }

    public ResourceLocation getId() {
        return BuiltInRegistries.PARTICLE_TYPE.getKey(particleType);
    }

    public CompatIdentifier getCompatId() {
        return CompatIdentifier.fromMinecraft(getId());
    }

    @Override
    public int hashCode() {
        return particleType.hashCode();
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        CompatParticleType other = (CompatParticleType) obj;
        return particleType.equals(other.particleType);
    }
}
