package net.pitan76.mcpitanlib.api.client.registry.neoforge;

import net.minecraft.client.color.block.BlockColor;
import net.minecraft.world.level.block.Block;
import net.neoforged.neoforge.client.event.RegisterColorHandlersEvent;

import java.util.HashMap;
import java.util.Map;

public class CompatRegistryClientImpl {

    public static Map<BlockColor, Block[]> blockColorProviders = new HashMap<>();

    public static void registerColorProviderBlock(BlockColor provider, Block... blocks) {
        blockColorProviders.put(provider, blocks);
    }

    public static void registerBlockColors(RegisterColorHandlersEvent.Block event){
        if (blockColorProviders.isEmpty()) return;

        for (Map.Entry<BlockColor, Block[]> entry : blockColorProviders.entrySet()) {
            BlockColor provider = entry.getKey();
            Block[] blocks = entry.getValue();

            if (blocks == null || blocks.length == 0) {
                event.register(provider);
            } else {
                event.register(provider, blocks);
            }
        }
    }
}
