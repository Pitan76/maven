package net.pitan76.mcpitanlib.api.client.render;

import net.minecraft.client.renderer.RenderType;
import net.pitan76.mcpitanlib.api.util.CompatIdentifier;

public class CompatRenderLayer {
    public static final CompatRenderLayer CUTOUT = new CompatRenderLayer(RenderType.cutout());
    public static final CompatRenderLayer CUTOUT_MIPPED = new CompatRenderLayer(RenderType.cutoutMipped());
    public static final CompatRenderLayer TRANSLUCENT = new CompatRenderLayer(RenderType.translucent());
    public static final CompatRenderLayer TRANSLUCENT_MOVING_BLOCK = new CompatRenderLayer(RenderType.translucentMovingBlock());
    public static final CompatRenderLayer SOLID = new CompatRenderLayer(RenderType.solid());
    public static final CompatRenderLayer LINES = new CompatRenderLayer(RenderType.lines());
    public static final CompatRenderLayer LINE_STRIP = new CompatRenderLayer(RenderType.lineStrip());
    public static final CompatRenderLayer GLINT = new CompatRenderLayer(RenderType.glint());

    public final RenderType layer;

    public CompatRenderLayer(RenderType layer) {
        this.layer = layer;
    }

    public RenderType raw() {
        return layer;
    }

    public static CompatRenderLayer getEntityCutout(CompatIdentifier id) {
        return new CompatRenderLayer(RenderType.entityCutout(id.toMinecraft()));
    }

    public static CompatRenderLayer getEntityCutoutNoCull(CompatIdentifier id) {
        return new CompatRenderLayer(RenderType.entityCutoutNoCull(id.toMinecraft()));
    }

    public static CompatRenderLayer getEntityTranslucent(CompatIdentifier id) {
        return new CompatRenderLayer(RenderType.entityTranslucent(id.toMinecraft()));
    }

    public static CompatRenderLayer getArmorCutoutNoCull(CompatIdentifier id) {
        return new CompatRenderLayer(RenderType.armorCutoutNoCull(id.toMinecraft()));
    }

    public static CompatRenderLayer getEntitySolid(CompatIdentifier id) {
        return new CompatRenderLayer(RenderType.entitySolid(id.toMinecraft()));
    }
}
