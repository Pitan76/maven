package net.pitan76.mcpitanlib.api.util.inventory;

import net.minecraft.core.NonNullList;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.ItemStack;
import net.pitan76.mcpitanlib.api.entity.Player;

public class PlayerInventoryUtil {
    public static Player getPlayer(Inventory playerInventory) {
        return new Player(playerInventory.player);
    }

    public static int getSelectedSlot(Inventory playerInventory) {
        return playerInventory.selected;
    }

    public static void setSelectedSlot(Inventory playerInventory, int slot) {
        playerInventory.selected = slot;
    }

    public static void dropAllItems(Inventory inv) {
        inv.dropAll();
    }

    public static NonNullList<ItemStack> getMain(Inventory inv) {
        return inv.items;
    }

    public static NonNullList<ItemStack> getArmor(Inventory inv) {
        return inv.armor;
    }

    public static NonNullList<ItemStack> getOffHand(Inventory inv) {
        return inv.offhand;
    }

    public static ItemStack getMainHandStack(Inventory inv) {
        return inv.getSelected();
    }
}
