package net.pitan76.mcpitanlib.api.util;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.datafix.DataFixTypes;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.saveddata.SavedData;
import net.minecraft.world.level.storage.DimensionDataStorage;
import java.util.function.Function;
import java.util.function.Supplier;

public class PersistentStateUtil {
    public static <T extends SavedData> T getOrCreate(DimensionDataStorage manager, String id, Supplier<T> supplier, Function<CompoundTag, T> function) {
        SavedData.Factory<T> type = new SavedData.Factory<>(supplier, (nbtCompound, wrapperLookup) -> function.apply(nbtCompound), DataFixTypes.LEVEL);
        return manager.computeIfAbsent(type, id);
    }

    public static DimensionDataStorage getManagerFromServer(MinecraftServer server) {
        return server.getLevel(Level.OVERWORLD).getDataStorage();
    }

    public static DimensionDataStorage getManagerFromWorld(ServerLevel world) {
        return world.getDataStorage();
    }

    public static void markDirty(SavedData state) {
        state.setDirty();
    }
}