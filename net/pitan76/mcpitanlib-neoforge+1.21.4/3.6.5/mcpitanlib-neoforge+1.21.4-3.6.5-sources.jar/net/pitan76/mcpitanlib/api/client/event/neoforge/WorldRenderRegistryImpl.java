package net.pitan76.mcpitanlib.api.client.event.neoforge;

import net.minecraft.client.Camera;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.render.*;
import net.minecraft.client.renderer.GameRenderer;
import net.minecraft.client.renderer.LevelRenderer;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.culling.Frustum;
import net.neoforged.neoforge.client.event.RenderHighlightEvent;
import net.neoforged.neoforge.client.event.RenderLevelStageEvent;
import net.pitan76.mcpitanlib.api.client.event.listener.BeforeBlockOutlineEvent;
import net.pitan76.mcpitanlib.api.client.event.listener.BeforeBlockOutlineListener;
import net.pitan76.mcpitanlib.api.client.event.listener.WorldRenderContext;
import net.pitan76.mcpitanlib.api.client.event.listener.WorldRenderContextListener;
import org.joml.Matrix4f;
import com.mojang.blaze3d.vertex.PoseStack;
import java.util.ArrayList;
import java.util.List;

public class WorldRenderRegistryImpl {

    public static List<BeforeBlockOutlineListener> beforeBlockOutlineListeners = new ArrayList<>();
    public static List<WorldRenderContextListener> worldRenderAfterLevelListeners = new ArrayList<>();

    public static void renderOutlineEventBlock(RenderHighlightEvent.Block event) {
        for (BeforeBlockOutlineListener listener : beforeBlockOutlineListeners) {
            boolean eventContinue = listener.beforeBlockOutline(new BeforeBlockOutlineEvent(new WorldRenderContext() {
                @Override
                public LevelRenderer getWorldRenderer() {
                    return event.getLevelRenderer();
                }

                @Override
                public PoseStack getMatrixStack() {
                    return event.getPoseStack();
                }

                @Override
                public float getTickDelta() {
                    return event.getDeltaTracker().getGameTimeDeltaPartialTick(true);
                }

                @Override
                public Camera getCamera() {
                    return event.getCamera();
                }

                @Override
                public GameRenderer getGameRenderer() {
                    return Minecraft.getInstance().gameRenderer;
                }

                @Override
                public LightTexture getLightmapTextureManager() {
                    return Minecraft.getInstance().gameRenderer.lightTexture();
                }

                @Deprecated
                @Override
                public Matrix4f getProjectionMatrix() {
                    return null;
                }

                @Override
                public ClientLevel getWorld() {
                    return Minecraft.getInstance().level;
                }

                @Deprecated
                @Override
                public boolean isAdvancedTranslucency() {
                    return event.getLevelRenderer().hasRenderedAllSections();
                }

                @Override
                public MultiBufferSource getConsumers() {
                    return event.getMultiBufferSource();
                }

                @Override
                public Frustum getFrustum() {
                    return event.getLevelRenderer().getFrustum();
                }
            }, event.getTarget()));

            if (!eventContinue) {
                event.setCanceled(true);
                break;
            }
        }
    }

    public static void renderOutlineEvent(RenderHighlightEvent.Entity event) {
        for (BeforeBlockOutlineListener listener : beforeBlockOutlineListeners) {
            listener.beforeBlockOutline(new BeforeBlockOutlineEvent(new WorldRenderContext() {
                @Override
                public LevelRenderer getWorldRenderer() {
                    return event.getLevelRenderer();
                }

                @Override
                public PoseStack getMatrixStack() {
                    return event.getPoseStack();
                }

                @Override
                public float getTickDelta() {
                    return event.getDeltaTracker().getGameTimeDeltaPartialTick(true);
                }

                @Override
                public Camera getCamera() {
                    return event.getCamera();
                }

                @Override
                public GameRenderer getGameRenderer() {
                    return Minecraft.getInstance().gameRenderer;
                }

                @Override
                public LightTexture getLightmapTextureManager() {
                    return Minecraft.getInstance().gameRenderer.lightTexture();
                }

                @Deprecated
                @Override
                public Matrix4f getProjectionMatrix() {
                    return null;
                }

                @Override
                public ClientLevel getWorld() {
                    return Minecraft.getInstance().level;
                }

                @Deprecated
                @Override
                public boolean isAdvancedTranslucency() {
                    return event.getLevelRenderer().hasRenderedAllSections();
                }

                @Override
                public MultiBufferSource getConsumers() {
                    return event.getMultiBufferSource();
                }

                @Override
                public Frustum getFrustum() {
                    return event.getLevelRenderer().getFrustum();
                }
            }, event.getTarget()));
        }
    }

    public static void renderLevelStageEvent(RenderLevelStageEvent event) {
        if (!event.getStage().equals(RenderLevelStageEvent.Stage.AFTER_LEVEL)) return;

        for (WorldRenderContextListener listener : worldRenderAfterLevelListeners) {
            listener.render(new WorldRenderContext() {
                @Override
                public LevelRenderer getWorldRenderer() {
                    return event.getLevelRenderer();
                }

                @Override
                public PoseStack getMatrixStack() {
                    return event.getPoseStack();
                }

                @Override
                public float getTickDelta() {
                    return event.getPartialTick().getGameTimeDeltaPartialTick(true);
                }

                @Override
                public Camera getCamera() {
                    return event.getCamera();
                }

                @Override
                public GameRenderer getGameRenderer() {
                    return Minecraft.getInstance().gameRenderer;
                }

                @Override
                public LightTexture getLightmapTextureManager() {
                    return Minecraft.getInstance().gameRenderer.lightTexture();
                }

                @Deprecated
                @Override
                public Matrix4f getProjectionMatrix() {
                    return event.getProjectionMatrix();
                }

                @Override
                public ClientLevel getWorld() {
                    return Minecraft.getInstance().level;
                }

                @Deprecated
                @Override
                public boolean isAdvancedTranslucency() {
                    return event.getLevelRenderer().hasRenderedAllSections();
                }

                @Override
                public MultiBufferSource getConsumers() {
                    return Minecraft.getInstance().renderBuffers().outlineBufferSource();
                }

                @Override
                public Frustum getFrustum() {
                    return event.getLevelRenderer().getFrustum();
                }
            });
        }
    }

    public static void registerWorldRenderBeforeBlockOutline(BeforeBlockOutlineListener listener) {
        beforeBlockOutlineListeners.add(listener);
    }

    public static void registerWorldRenderAfterLevel(WorldRenderContextListener listener) {
        worldRenderAfterLevelListeners.add(listener);
    }
}

