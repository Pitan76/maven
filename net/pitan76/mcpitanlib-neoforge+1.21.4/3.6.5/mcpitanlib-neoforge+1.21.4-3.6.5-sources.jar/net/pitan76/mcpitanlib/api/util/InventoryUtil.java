package net.pitan76.mcpitanlib.api.util;

import net.minecraft.core.NonNullList;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.Container;
import net.minecraft.world.ContainerHelper;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.pitan76.mcpitanlib.api.event.nbt.NbtRWArgs;
import net.pitan76.mcpitanlib.api.registry.CompatRegistryLookup;

public class InventoryUtil {
    public static boolean insertItem(ItemStack insertStack, NonNullList<ItemStack> inventory) {
        return insertItem(insertStack, inventory, false);
    }

    public static boolean insertItem(ItemStack insertStack, NonNullList<ItemStack> inventory, boolean test) {
        boolean isInserted = false;
        for (int i = 0; i < inventory.size(); i++) {
            ItemStack stack = inventory.get(i);
            if (stack.isEmpty()) {
                if (!test) inventory.set(i, insertStack);
                isInserted = true;
                break;
            } else if (canMergeItems(stack, insertStack)) {
                int j = insertStack.getCount();
                if (!test) stack.grow(j);
                isInserted = j > 0;
                break;
            }
        }
        return isInserted;

    }

    public static boolean canMergeItems(ItemStack first, ItemStack second) {
        if (!first.is(second.getItem())) {
            return false;
        }
        if (first.getDamageValue() != second.getDamageValue()) {
            return false;
        }
        if (first.getCount() + second.getCount() > first.getMaxStackSize()) {
            return false;
        }
        return ItemStackUtil.areNbtOrComponentEqual(first, second);
    }

    public static CompoundTag writeNbt(NbtRWArgs args, CompoundTag nbt, NonNullList<ItemStack> stacks, boolean setIfEmpty) {
        return ContainerHelper.saveAllItems(nbt, stacks, setIfEmpty, args.getWrapperLookup());
    }

    public static void readNbt(NbtRWArgs args, CompoundTag nbt, NonNullList<ItemStack> stacks) {
        ContainerHelper.loadAllItems(nbt, stacks, args.getWrapperLookup());
    }

    public static CompoundTag writeNbt(NbtRWArgs args, NonNullList<ItemStack> stacks, boolean setIfEmpty) {
        return writeNbt(args, args.getNbt(), stacks, setIfEmpty);
    }

    public static CompoundTag writeNbt(NbtRWArgs args, NonNullList<ItemStack> stacks) {
        return writeNbt(args, stacks, true);
    }

    public static void readNbt(NbtRWArgs args, NonNullList<ItemStack> stacks) {
        readNbt(args, args.getNbt(), stacks);
    }

    public static void readNbt(CompatRegistryLookup registryLookup, CompoundTag nbt, NonNullList<ItemStack> stacks) {
        ContainerHelper.loadAllItems(nbt, stacks, registryLookup.getRegistryLookup());
    }

    public static CompoundTag writeNbt(CompatRegistryLookup registryLookup, CompoundTag nbt, NonNullList<ItemStack> stacks, boolean setIfEmpty) {
        return ContainerHelper.saveAllItems(nbt, stacks, setIfEmpty, registryLookup.getRegistryLookup());
    }

    public static CompoundTag writeNbt(CompatRegistryLookup registryLookup, CompoundTag nbt, NonNullList<ItemStack> stacks) {
        return writeNbt(registryLookup, nbt, stacks, true);
    }

    // deprecated
    /**
     * @deprecated Use {@link #writeNbt(NbtRWArgs, NonNullList)} instead
     */
    @Deprecated
    public static CompoundTag writeNbt(Level world, CompoundTag nbt, NonNullList<ItemStack> stacks) {
        return writeNbt(world, nbt, true, stacks);
    }

    /**
     * @deprecated Use {@link #writeNbt(NbtRWArgs, NonNullList, boolean)} instead
     */
    @Deprecated
    public static CompoundTag writeNbt(Level world, CompoundTag nbt, boolean setIfEmpty, NonNullList<ItemStack> stacks) {
        return ContainerHelper.saveAllItems(nbt, stacks, setIfEmpty, world.registryAccess());
    }

    /**
     * @deprecated Use {@link #readNbt(NbtRWArgs, NonNullList)} instead
     */
    @Deprecated
    public static void readNbt(Level world, CompoundTag nbt, NonNullList<ItemStack> stacks) {
        ContainerHelper.loadAllItems(nbt, stacks, world.registryAccess());
    }
    // ----

    public static SimpleContainer createSimpleInventory(int size) {
        return new SimpleContainer(size);
    }

    public static void copyToInv(NonNullList<ItemStack> from, Container to) {
        for (int i = 0; i < from.size(); i++) {
            to.setItem(i, from.get(i));
        }
    }

    public static void copyToList(Container from, NonNullList<ItemStack> to) {
        for (int i = 0; i < from.getContainerSize(); i++) {
            to.set(i, from.getItem(i));
        }
    }

    public static int getSize(Container inventory) {
        return inventory.getContainerSize();
    }

    public static ItemStack getStack(Container inventory, int slot) {
        return inventory.getItem(slot);
    }

    public static void setStack(Container inventory, int slot, ItemStack stack) {
        inventory.setItem(slot, stack);
    }

    public static boolean isEmpty(Container inventory) {
        return inventory.isEmpty();
    }

    public static ItemStack removeStack(Container inventory, int slot) {
        return inventory.removeItemNoUpdate(slot);
    }

    public static ItemStack removeStack(Container inventory, int slot, int amount) {
        return inventory.removeItem(slot, amount);
    }

    public static void clear(Container inventory) {
        inventory.clearContent();
    }

    public static void markDirty(Container inventory) {
        inventory.setChanged();
    }
}
