package net.pitan76.mcpitanlib.api.util;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;

public class SoundEventUtil {
    public static ResourceLocation getId(SoundEvent soundEvent) {
        return soundEvent.location();
    }

    public static SoundEvent getSoundEvent(ResourceLocation id) {
        return SoundEvent.createVariableRangeEvent(id);
    }

    public static CompatIdentifier getCompatId(SoundEvent soundEvent) {
        return CompatIdentifier.fromMinecraft(getId(soundEvent));
    }

    public static SoundEvent getSoundEvent(CompatIdentifier id) {
        return getSoundEvent(id.toMinecraft());
    }

    public static List<SoundEvent> getAllSoundEvents() {
        return BuiltInRegistries.SOUND_EVENT.stream().collect(Collectors.toList());
    }

    public static List<ResourceLocation> getAllSoundEventIds() {
        return new ArrayList<>(BuiltInRegistries.SOUND_EVENT.keySet());
    }
}
