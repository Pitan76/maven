package net.pitan76.mcpitanlib.api.item.v2;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.pitan76.mcpitanlib.api.item.CompatibleArmorMaterial;
import net.pitan76.mcpitanlib.api.sound.CompatSoundEvent;
import net.pitan76.mcpitanlib.api.util.CompatIdentifier;

@Deprecated
public interface CompatArmorMaterial extends CompatibleArmorMaterial {

    @Override
    default SoundEvent getEquipSound() {
        return getEquipCompatSound().get();
    }

    CompatSoundEvent getEquipCompatSound();

    @Override
    default ResourceLocation getId() {
        return getCompatId().toMinecraft();
    }

    CompatIdentifier getCompatId();
}
