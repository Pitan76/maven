package net.pitan76.mcpitanlib.api.event.nbt;

import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.pitan76.mcpitanlib.api.registry.CompatRegistryLookup;

public class WriteNbtArgs extends NbtRWArgs {

    @Deprecated
    public WriteNbtArgs(CompoundTag nbt, HolderLookup.Provider wrapperLookup) {
        super(nbt, wrapperLookup);
    }

    public WriteNbtArgs(CompoundTag nbt, CompatRegistryLookup registryLookup) {
        super(nbt, registryLookup);
    }

    public WriteNbtArgs(CompoundTag nbt) {
        super(nbt);
    }

    @Override
    public boolean isViewEmpty() {
        return false;
    }

    @Override
    public NbtRWArgs copy() {
        return new WriteNbtArgs(nbt.copy(), registryLookup);
    }

    public WriteNbtArgs(net.pitan76.mcpitanlib.midohra.nbt.NbtCompound nbt, CompatRegistryLookup registryLookup) {
        this(nbt.toMinecraft(), registryLookup);
    }

    public WriteNbtArgs(net.pitan76.mcpitanlib.midohra.nbt.NbtCompound nbt) {
        this(nbt.toMinecraft());
    }
}
