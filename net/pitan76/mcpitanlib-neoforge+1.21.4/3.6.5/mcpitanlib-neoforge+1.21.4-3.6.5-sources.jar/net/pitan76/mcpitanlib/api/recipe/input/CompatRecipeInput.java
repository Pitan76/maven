package net.pitan76.mcpitanlib.api.recipe.input;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.crafting.RecipeInput;

public class CompatRecipeInput<I extends RecipeInput> {
    protected I input;

    public CompatRecipeInput(I input) {
        this.input = input;
    }

    public I getInput() {
        return input;
    }

    public ItemStack getStack(int slot) {
        return input.getItem(slot);
    }

    public net.pitan76.mcpitanlib.midohra.item.ItemStack getMidohraStack(int slot) {
        return net.pitan76.mcpitanlib.midohra.item.ItemStack.of(getStack(slot));
    }

    public int getSize() {
        return input.size();
    }

    public boolean isEmpty() {
        return input.isEmpty();
    }
}
