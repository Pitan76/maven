package net.pitan76.mcpitanlib.api.client;

import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.pitan76.mcpitanlib.api.util.CompatIdentifier;

@Deprecated
public abstract class CompatInventoryScreen extends SimpleInventoryScreen {

    public CompatInventoryScreen(AbstractContainerMenu handler, Inventory inventory, Component title) {
        super(handler, inventory, title);
    }

    public abstract CompatIdentifier getCompatTexture();

    @Override
    public ResourceLocation getTexture() {
        return getCompatTexture().toMinecraft();
    }
}
