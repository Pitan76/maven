package net.pitan76.mcpitanlib.api.entity;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.projectile.ThrowableItemProjectile;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;
import net.pitan76.mcpitanlib.api.event.entity.CollisionEvent;
import net.pitan76.mcpitanlib.api.event.entity.EntityHitEvent;
import net.pitan76.mcpitanlib.api.event.entity.InitDataTrackerArgs;
import net.pitan76.mcpitanlib.api.event.nbt.ReadNbtArgs;
import net.pitan76.mcpitanlib.api.event.nbt.WriteNbtArgs;
import net.pitan76.mcpitanlib.api.util.ItemStackUtil;
import net.pitan76.mcpitanlib.midohra.entity.IEntityM;

public abstract class CompatThrownItemEntity extends ThrowableItemProjectile implements IEntityM {

    public CompatThrownItemEntity(EntityType<? extends ThrowableItemProjectile> entityType, Level world) {
        super(entityType, world);
    }

    public CompatThrownItemEntity(EntityType<? extends ThrowableItemProjectile> entityType, double d, double e, double f, Level world) {
        super(entityType, d, e, f, world, ItemStackUtil.empty());
    }

    public CompatThrownItemEntity(EntityType<? extends ThrowableItemProjectile> entityType, LivingEntity livingEntity, Level world) {
        super(entityType, livingEntity, world, ItemStackUtil.empty());
    }

    public abstract Item getDefaultItemOverride();

    @Deprecated
    @Override
    protected Item getDefaultItem() {
        return getDefaultItemOverride();
    }

    public ItemStack callGetItem() {
        return super.getItem();
    }

    @Deprecated
    @Override
    public ItemStack getItem() {
        return callGetItem();
    }

    public void callSetItem(ItemStack stack) {
        super.setItem(stack);
    }

    @Deprecated
    @Override
    public void setItem(ItemStack stack) {
        callSetItem(stack);
    }

    public void callHandleStatus(byte status) {
        super.handleEntityEvent(status);
    }

    @Deprecated
    @Override
    public void handleEntityEvent(byte status) {
        callHandleStatus(status);
    }

    public void onEntityHit(EntityHitEvent event) {
        super.onHitEntity(event.entityHitResult);
    }

    @Deprecated
    @Override
    protected void onHitEntity(EntityHitResult entityHitResult) {
        onEntityHit(new EntityHitEvent(entityHitResult));
    }

    public void onCollision(CollisionEvent event) {
        super.onHit(event.hitResult);
    }

    @Deprecated
    @Override
    protected void onHit(HitResult hitResult) {
        onCollision(new CollisionEvent(hitResult));
    }

    // ------------------ ExtendEntity ------------------

    @Deprecated
    @Override
    public void defineSynchedData(SynchedEntityData.Builder builder) {
        initDataTracker(new InitDataTrackerArgs(builder, entityData));
    }

    public void initDataTracker(InitDataTrackerArgs args) {
        super.defineSynchedData(args.getBuilder());
    }

    public void readCustomDataFromNbt(ReadNbtArgs nbt) {
        super.readAdditionalSaveData(nbt.getNbt());
    }

    public void writeCustomDataToNbt(WriteNbtArgs nbt) {
        super.addAdditionalSaveData(nbt.getNbt());
    }

    @Deprecated
    @Override
    public void readAdditionalSaveData(CompoundTag nbt) {
        readCustomDataFromNbt(new ReadNbtArgs(nbt));
    }

    @Deprecated
    @Override
    public void addAdditionalSaveData(CompoundTag nbt) {
        writeCustomDataToNbt(new WriteNbtArgs(nbt));
    }

    public void writeNbt(WriteNbtArgs args) {
        super.saveWithoutId(args.getNbt());
    }

    public void readNbt(ReadNbtArgs args) {
        super.load(args.getNbt());
    }

    @Deprecated
    @Override
    public CompoundTag saveWithoutId(CompoundTag nbt) {
        writeNbt(new WriteNbtArgs(nbt));
        return nbt;
    }

    @Deprecated
    @Override
    public void load(CompoundTag nbt) {
        readNbt(new ReadNbtArgs(nbt));
    }

    @Override
    public Level level() {
        return super.level();
    }

    public void setStack(net.pitan76.mcpitanlib.midohra.item.ItemStack stack) {
        callSetItem(stack.toMinecraft());
    }

    public net.pitan76.mcpitanlib.midohra.item.ItemStack getStackM() {
        return net.pitan76.mcpitanlib.midohra.item.ItemStack.of(callGetItem());
    }
}
