package net.pitan76.mcpitanlib.api.event.item;

import net.minecraft.network.chat.Component;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;
import net.pitan76.mcpitanlib.api.event.BaseEvent;
import net.pitan76.mcpitanlib.api.registry.CompatRegistryLookup;
import net.pitan76.mcpitanlib.api.text.TextComponent;
import net.pitan76.mcpitanlib.api.util.RegistryLookupUtil;
import net.pitan76.mcpitanlib.api.util.TextUtil;
import org.jetbrains.annotations.Nullable;

import java.util.List;

public class ItemAppendTooltipEvent extends BaseEvent {
    public ItemStack stack;
    public Level world;
    public List<Component> tooltip;

    public TooltipFlag type;
    public Item.TooltipContext context;

    public ItemAppendTooltipEvent(ItemStack stack, @Nullable Level world, List<Component> tooltip, TooltipFlag type, Item.TooltipContext context) {
        this.stack = stack;
        this.world = world;
        this.tooltip = tooltip;
        this.type = type;
        this.context = context;
    }

    public ItemStack getStack() {
        return stack;
    }

    public Level getWorld() {
        return world;
    }

    public List<Component> getTooltip() {
        return tooltip;
    }

    public Item.TooltipContext getContext() {
        return context;
    }

    public void addTooltip(Component text) {
        tooltip.add(text);
    }

    public void addTooltip(List<Component> texts) {
        tooltip.addAll(texts);
    }

    public boolean removeTooltip(Component text) {
        return tooltip.remove(text);
    }

    public boolean isCreative() {
        return type.isCreative();
    }

    public boolean isAdvanced() {
        return type.isAdvanced();
    }

    public CompatRegistryLookup getRegistryLookup() {
        return RegistryLookupUtil.getRegistryLookup(this);
    }

    public void addTooltip(TextComponent textComponent) {
        addTooltip(textComponent.getText());
    }

    public void addTooltip(String text) {
        addTooltip(TextUtil.literal(text));
    }
}
