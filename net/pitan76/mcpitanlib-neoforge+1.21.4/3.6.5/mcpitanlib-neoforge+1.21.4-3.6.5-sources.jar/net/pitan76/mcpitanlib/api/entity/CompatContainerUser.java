package net.pitan76.mcpitanlib.api.entity;

import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;

public class CompatContainerUser {
    protected Player containerUser;

    public CompatContainerUser(Player containerUser) {
        this.containerUser = containerUser;
    }

    public double getContainerInteractionRange() {
        return 4.5d;
    }

    public LivingEntity asLivingEntity() {
        return containerUser;
    }

    public boolean isPlayer() {
        return true;
    }

    public net.pitan76.mcpitanlib.api.entity.Player asPlayer() {
        return new net.pitan76.mcpitanlib.api.entity.Player(containerUser);
    }

    @Deprecated
    public Player getRaw() {
        return containerUser;
    }
}
