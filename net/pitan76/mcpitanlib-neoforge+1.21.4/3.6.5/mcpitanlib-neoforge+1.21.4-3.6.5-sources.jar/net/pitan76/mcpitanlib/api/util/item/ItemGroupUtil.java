package net.pitan76.mcpitanlib.api.util.item;

import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.CreativeModeTab;
import net.pitan76.mcpitanlib.api.util.CompatIdentifier;

public class ItemGroupUtil {
    public static ResourceLocation toID(CreativeModeTab itemGroup) {
        return BuiltInRegistries.CREATIVE_MODE_TAB.getKey(itemGroup);
    }

    public static CreativeModeTab fromId(ResourceLocation identifier) {
        return BuiltInRegistries.CREATIVE_MODE_TAB.getValue(identifier);
    }

    public static boolean isExist(ResourceLocation identifier) {
        return BuiltInRegistries.CREATIVE_MODE_TAB.containsKey(identifier);
    }

    public static CompatIdentifier toCompatID(CreativeModeTab itemGroup) {
        return CompatIdentifier.fromMinecraft(toID(itemGroup));
    }

    public static CreativeModeTab fromId(CompatIdentifier identifier) {
        return fromId(identifier.toMinecraft());
    }

    public static boolean isExist(CompatIdentifier identifier) {
        return isExist(identifier.toMinecraft());
    }

    public static int getRawId(CreativeModeTab itemGroup) {
        return BuiltInRegistries.CREATIVE_MODE_TAB.getId(itemGroup);
    }

    public static CreativeModeTab fromIndex(int index) {
        return BuiltInRegistries.CREATIVE_MODE_TAB.byId(index);
    }
}
