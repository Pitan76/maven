package net.pitan76.mcpitanlib.api.util.block.entity;

import net.minecraft.core.BlockPos;
import net.minecraft.world.Container;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.crafting.AbstractCookingRecipe;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.AbstractFurnaceBlockEntity;
import net.pitan76.mcpitanlib.api.recipe.MatchGetter;
import net.pitan76.mcpitanlib.api.recipe.input.CompatRecipeInput;
import net.pitan76.mcpitanlib.api.util.WorldUtil;
import net.pitan76.mcpitanlib.api.util.recipe.input.SingleStackRecipeInputUtil;

public class FurnaceUtil {
    public static int getDefaultCookTime() {
        return AbstractFurnaceBlockEntity.f_154988_;
    }

    public static boolean canUseAsFuel(net.pitan76.mcpitanlib.midohra.item.ItemStack stack, Level world) {
        return canUseAsFuel(stack.toMinecraft(), world);
    }

    public static boolean canUseAsFuel(ItemStack stack, Level world) {
        return AbstractFurnaceBlockEntity.m_58399_(stack);
    }

    public static void tick(Level world, BlockPos pos, AbstractFurnaceBlockEntity blockEntity) {
        AbstractFurnaceBlockEntity.m_155013_(world, pos, WorldUtil.getBlockState(world, pos), blockEntity);
    }

    public static int getCookTime(Level world, AbstractFurnaceBlockEntity furnace, MatchGetter<Container, ? extends AbstractCookingRecipe> matchGetter) {
        return getCookTime(world, furnace.m_8020_(0), matchGetter);
    }

    public static int getCookTime(Level world, ItemStack stack, MatchGetter<Container, ? extends AbstractCookingRecipe> matchGetter) {
        CompatRecipeInput<Container> input = (CompatRecipeInput<Container>) SingleStackRecipeInputUtil.create(stack);

        matchGetter.getFirstMatch(input, world);

        return matchGetter.getFirstMatch(input, world).map(
                (recipe) -> (recipe.getRecipe()).m_43753_()).orElse(200);
    }
}
