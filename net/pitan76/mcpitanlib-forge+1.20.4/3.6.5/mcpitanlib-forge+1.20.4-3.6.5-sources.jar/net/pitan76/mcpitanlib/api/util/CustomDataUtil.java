package net.pitan76.mcpitanlib.api.util;

import java.util.Set;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.item.ItemStack;

/**
 * カスタムデータのユーティリティクラス
 */
public class CustomDataUtil {
    /**
     * NBTを取得する。存在しない場合は新しいNBTを作成する。
     * @param stack ItemStack
     * @return NBT
     */
    public static CompoundTag getOrCreateNbt(ItemStack stack) {
        if (!hasNbt(stack)) {
            return NbtUtil.create();
        }

        return getNbt(stack);
    }

    /**
     * NBTを設定する。
     * @param stack ItemStack
     * @param nbt NBT
     */
    public static void setNbt(ItemStack stack, CompoundTag nbt) {
        CompoundTag components = NbtUtil.create();
        if (hasNbt(stack)) {
            components = stack.m_41783_().m_128469_("components");
        }
        components.m_128365_("minecraft:custom_data", nbt);
        stack.m_41784_().m_128365_("components", components);
    }
    
    /**
     * NBTが存在するかどうかを取得する。
     * @param stack ItemStack
     * @return NBTが存在するかどうか
     */
    public static boolean hasNbt(ItemStack stack) {
        if (stack.m_41783_() == null) return false;

        return stack.m_41783_().m_128441_("components") &&
                stack.m_41783_().m_128469_("components").m_128441_("minecraft:custom_data");
    }
    
    /**
     * NBTを取得する。
     * @param stack ItemStack
     * @return NBT
     */
    public static CompoundTag getNbt(ItemStack stack) {
        CompoundTag customData = NbtUtil.create();
        if (!hasNbt(stack))
            return customData;

        if (stack.m_41783_().m_128441_("components")) {
            CompoundTag components = stack.m_41783_().m_128469_("components");
            if (components.m_128441_("minecraft:custom_data")) {
                customData = components.m_128469_("minecraft:custom_data").m_6426_();
            }
        }
        return customData;
    }
    
    /**
     * 値を設定する。
     * @param stack ItemStack
     * @param key キー
     * @param value 値
     */
    public static void put(ItemStack stack, String key, CompoundTag value) {
        CompoundTag nbt = getOrCreateNbt(stack);
        NbtUtil.put(nbt, key, value);
        setNbt(stack, nbt);
    }
    
    /**
     * 値を取得する。
     * @param stack ItemStack
     * @param key キー
     * @return 値
     */
    public static CompoundTag get(ItemStack stack, String key) {
        CompoundTag nbt = getNbt(stack);
        return nbt.m_128469_(key);
    }
    
    /**
     * 値を削除する。
     * @param stack ItemStack
     * @param key キー
     */
    public static void remove(ItemStack stack, String key) {
        CompoundTag nbt = getNbt(stack);
        nbt.m_128473_(key);
        setNbt(stack, nbt);
    }
    
    /**
     * 値が存在するかどうかを取得する。
     * @param stack ItemStack
     * @param key キー
     * @return 値が存在するかどうか
     */
    public static boolean has(ItemStack stack, String key) {
        if (!hasNbt(stack))
            return false;

        CompoundTag nbt = getNbt(stack);
        return nbt.m_128441_(key);
    }
    
    /**
     * 指定した型の値を取得する
     * @param stack ItemStack
     * @param key キー
     * @param clazz クラス
     * @param <T> 値
     */
    public static <T> T get(ItemStack stack, String key, Class<T> clazz) {
        CompoundTag nbt = getNbt(stack);
        return NbtUtil.get(nbt, key, clazz);
    }
    
    /**
     * 値を設定する。
     * @param stack ItemStack
     * @param key キー
     * @param value 値
     */
    public static <T> void set(ItemStack stack, String key, T value) {
        CompoundTag nbt = getOrCreateNbt(stack);
        NbtUtil.set(nbt, key, value);
        setNbt(stack, nbt);
    }
    
    /**
     * キーの一覧を取得する。
     * @param stack ItemStack
     * @return キーの一覧
     */
    public static Set<String> getKeys(ItemStack stack) {
        CompoundTag nbt = getNbt(stack);
        return NbtUtil.getKeys(nbt);
    }

    /**
     * set(stack, key, value) のエイリアス
     * @param stack ItemStack
     * @param key キー
     * @param value 値
     */
    public static <T> void put(ItemStack stack, String key, T value) {
        set(stack, key, value);
    }

    /**
     * has(stack, key) のエイリアス
     * @param stack ItemStack
     * @param key キー
     * @return 値が存在するかどうか
     */
    public static boolean contains(ItemStack stack, String key) {
        return has(stack, key);
    }

    /**
     * 1.20.3以前下位互換のための修正用
     * @param stack ItemStack
     * @param keys 移植するキー
     */
    public static void fix_oldNbt(ItemStack stack, String[] keys) {

    }

    /**
     * カスタムNBTを削除する
     * @param stack ItemStack
     */
    public static void remove(ItemStack stack) {
        CompoundTag nbt = stack.m_41784_();
        if (nbt.m_128441_("components")) {
            CompoundTag components = nbt.m_128469_("components");
            components.m_128473_("minecraft:custom_data");
            nbt.m_128365_("components", components);
        }
    }
}
