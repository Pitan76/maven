package net.pitan76.mcpitanlib.api.util.recipe.input;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.ticks.ContainerSingleItem;
import net.pitan76.mcpitanlib.api.recipe.input.CompatRecipeInput;
import net.pitan76.mcpitanlib.api.util.ItemStackUtil;

import java.util.Optional;

public class SingleStackRecipeInputUtil {
    public static Optional<ContainerSingleItem> get(CompatRecipeInput<?> input) {
        if (input.getInput() instanceof ContainerSingleItem) {
            return Optional.of((ContainerSingleItem) input.getInput());
        }
        return Optional.empty();
    }

    public static CompatRecipeInput<?> create(ContainerSingleItem input) {
        return new CompatRecipeInput<>(input);
    }

    public static CompatRecipeInput<?> create(ItemStack stack) {
        return new CompatRecipeInput<>(new ContainerSingleItem() {
            private ItemStack itemStack = stack;

            @Override
            public void m_6596_() {

            }

            @Override
            public ItemStack m_306082_() {
                return itemStack;
            }

            @Override
            public ItemStack m_305214_(int count) {
                ItemStackUtil.decrementCount(itemStack, count);
                return itemStack;
            }

            @Override
            public void m_305072_(ItemStack stack) {
                this.itemStack = stack;
            }

            @Override
            public BlockEntity m_304707_() {
                return null;
            }
        });
    }

    public static ItemStack getStack(CompatRecipeInput<?> input) {
        Optional<ContainerSingleItem> recipeInput = get(input);
        if (!recipeInput.isPresent()) return ItemStackUtil.empty();

        return recipeInput.get().m_8020_(0);
    }
}
