package net.pitan76.mcpitanlib.api.client.gui.widget;

import com.google.common.collect.ImmutableList;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.AbstractWidget;
import net.minecraft.client.gui.components.ContainerObjectSelectionList;
import net.minecraft.client.gui.components.events.GuiEventListener;
import net.minecraft.client.gui.narration.NarratableEntry;
import net.pitan76.mcpitanlib.api.client.render.handledscreen.RenderArgs;
import org.jetbrains.annotations.Nullable;

import java.util.List;
import java.util.Optional;

@Environment(EnvType.CLIENT)
public class SimpleListWidget extends ContainerObjectSelectionList<SimpleListWidget.WidgetEntry> {

    public SimpleListWidget(Minecraft client, int width, int height, int top, int bottom, int itemHeight) {
        this(client, width, bottom - top, top, itemHeight);
    }

    public SimpleListWidget(Minecraft client, int width, int height, int y, int itemHeight) {
        super(client, width, height, y, itemHeight);
        this.f_93394_ = false;
    }

    public void add(AbstractWidget widget) {
        super.m_7085_(WidgetEntry.create(widget));
    }

    @Override
    public int m_5759_() {
        return 400;
    }

    public int m_5711_() {
        return this.f_93618_;
    }

    public int m_93694_() {
        return this.f_93619_;
    }

    @Override
    protected int m_5756_() {
        return super.m_5756_() + 32;
    }

    @Nullable
    public AbstractWidget getWidget(int index) {
        if (index < 0 || index >= this.m_6702_().size()) {
            return null;
        }
        return this.m_6702_().get(index).getWidget();
    }

    public Optional<AbstractWidget> getHoveredWidget(double mouseX, double mouseY) {
        for (WidgetEntry entry : this.m_6702_()) {
            if (entry.getWidget().m_5953_(mouseX, mouseY)) {
                return Optional.of(entry.getWidget());
            }
        }
        return Optional.empty();
    }

    /*
    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        this.render(new RenderArgs(new DrawObjectDM(context), mouseX, mouseY, delta));
    }
    */

    public void render(RenderArgs args) {
        super.m_88315_(args.drawObjectDM.getContext(), args.mouseX, args.mouseY, args.delta);
    }

    @Environment(EnvType.CLIENT)
    public static class WidgetEntry extends Entry<WidgetEntry> {
        protected final AbstractWidget widget;

        public WidgetEntry(AbstractWidget widget) {
            this.widget = widget;
        }

        public static WidgetEntry create(AbstractWidget widget) {
            return new WidgetEntry(widget);
        }

        @Deprecated
        @Override
        public void render(GuiGraphics matrices, int index, int y, int x, int entryWidth, int entryHeight, int mouseX, int mouseY, boolean hovered, float tickDelta) {
            widget.m_253211_(y);
            widget.m_88315_(matrices, mouseX, mouseY, tickDelta);
        }

        @Deprecated
        @Override
        public List<? extends GuiEventListener> children() {
            return ImmutableList.of(widget);
        }

        @Deprecated
        @Override
        public List<? extends NarratableEntry> selectableChildren() {
            return ImmutableList.of(widget);
        }

        public AbstractWidget getWidget() {
            return widget;
        }
    }
}
