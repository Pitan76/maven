package net.pitan76.mcpitanlib.api.recipe.v2;

import net.minecraft.recipe.*;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.crafting.Recipe;
import net.minecraft.world.item.crafting.RecipeHolder;
import net.minecraft.world.item.crafting.RecipeSerializer;
import net.minecraft.world.item.crafting.RecipeType;
import net.pitan76.mcpitanlib.api.util.CompatIdentifier;
import net.pitan76.mcpitanlib.api.util.RecipeUtil;
import org.jetbrains.annotations.Nullable;

@Deprecated
public class CompatRecipeEntry<T extends Recipe<?>> {
    private final RecipeHolder<T> entry;

    public String group = "";
    public RecipeUtil.CompatibilityCraftingRecipeCategory category = null;

    @Deprecated
    public CompatRecipeEntry(RecipeHolder<T> entry) {
        this.entry = entry;
    }

    public CompatRecipeEntry(ResourceLocation id, String group, RecipeUtil.CompatibilityCraftingRecipeCategory category, T recipe) {
        this.entry = new RecipeHolder<>(id, recipe);
        this.group = group;
        this.category = category;
    }

    public CompatRecipeEntry(CompatIdentifier id, String group, RecipeUtil.CompatibilityCraftingRecipeCategory category, T recipe) {
        this(id.toMinecraft(), group, category, recipe);
    }

    public boolean isNull() {
        return entry == null;
    }

    @Deprecated
    public RecipeHolder<?> getRecipeEntry() {
        return entry;
    }

    public T getRecipe() {
        return entry.f_291008_();
    }

    public ResourceLocation getId() {
        return entry.f_291676_();
    }

    public CompatIdentifier getCompatId() {
        return CompatIdentifier.fromMinecraft(getId());
    }

    public RecipeType<?> getType() {
        T recipe = getRecipe();
        if (recipe == null) return null;

        return recipe.m_6671_();
    }

    public RecipeSerializer<?> getSerializer() {
        Recipe<?> recipe = getRecipe();
        if (recipe == null) return null;

        return recipe.m_7707_();
    }

    @Nullable
    public RecipeUtil.CompatibilityCraftingRecipeCategory getCategory() {
        return category;
    }

    public String getGroup() {
        return group;
    }
}
