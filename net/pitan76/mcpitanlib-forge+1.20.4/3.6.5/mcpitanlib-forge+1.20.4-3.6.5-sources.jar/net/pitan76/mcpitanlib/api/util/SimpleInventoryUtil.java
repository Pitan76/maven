package net.pitan76.mcpitanlib.api.util;

import net.minecraft.core.NonNullList;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.item.ItemStack;

public class SimpleInventoryUtil {
    public static NonNullList<ItemStack> getHeldStacks(SimpleContainer inventory) {
        return inventory.m_307332_();
    }

    public static SimpleContainer create(int size) {
        return InventoryUtil.createSimpleInventory(size);
    }

    public static ItemStack getStack(SimpleContainer inventory, int slot) {
        return inventory.m_8020_(slot);
    }

    public static void setStack(SimpleContainer inventory, int slot, ItemStack stack) {
        inventory.m_6836_(slot, stack);
    }

    public static void clear(SimpleContainer inventory) {
        inventory.m_6211_();
    }

    public static int size(SimpleContainer inventory) {
        return inventory.m_6643_();
    }

    public static boolean isEmpty(SimpleContainer inventory) {
        return inventory.m_7983_();
    }
}
