package net.pitan76.mcpitanlib.api.block;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;

public class CompatBlocks {
    public static final Block AIR = Blocks.f_50016_;
    public static final Block STONE = Blocks.f_50069_;
    public static final Block COBBLESTONE = Blocks.f_50652_;
    public static final Block GRASS_BLOCK = Blocks.f_50440_;
    public static final Block DIRT = Blocks.f_50493_;
    public static final Block SAND = Blocks.f_49992_;
    public static final Block RED_SAND = Blocks.f_49993_;
    public static final Block GRANITE = Blocks.f_50122_;
    public static final Block POLISHED_GRANITE = Blocks.f_50175_;
    public static final Block DIORITE = Blocks.f_50228_;
    public static final Block POLISHED_DIORITE = Blocks.f_50281_;
    public static final Block ANDESITE = Blocks.f_50334_;
    public static final Block POLISHED_ANDESITE = Blocks.f_50387_;
    public static final Block COARSE_DIRT = Blocks.f_50546_;
    public static final Block PODZOL = Blocks.f_50599_;

    public static final Block OAK_LOG = Blocks.f_49999_;
    public static final Block SPRUCE_LOG = Blocks.f_50000_;
    public static final Block BIRCH_LOG = Blocks.f_50001_;
    public static final Block JUNGLE_LOG = Blocks.f_50002_;
    public static final Block ACACIA_LOG = Blocks.f_50003_;
    public static final Block DARK_OAK_LOG = Blocks.f_50004_;
    public static final Block OAK_PLANKS = Blocks.f_50705_;
    public static final Block SPRUCE_PLANKS = Blocks.f_50741_;
    public static final Block BIRCH_PLANKS = Blocks.f_50742_;
    public static final Block JUNGLE_PLANKS = Blocks.f_50743_;
    public static final Block ACACIA_PLANKS = Blocks.f_50744_;
    public static final Block DARK_OAK_PLANKS = Blocks.f_50745_;
    public static final Block OAK_SAPLING = Blocks.f_50746_;
    public static final Block SPRUCE_SAPLING = Blocks.f_50747_;
    public static final Block BIRCH_SAPLING = Blocks.f_50748_;
    public static final Block JUNGLE_SAPLING = Blocks.f_50749_;
    public static final Block ACACIA_SAPLING = Blocks.f_50750_;
    public static final Block DARK_OAK_SAPLING = Blocks.f_50751_;

    public static final Block SANDSTONE = Blocks.f_50062_;
    public static final Block CHISELED_SANDSTONE = Blocks.f_50063_;
    public static final Block CUT_SANDSTONE = Blocks.f_50064_;
    public static final Block NOTE_BLOCK = Blocks.f_50065_;
    public static final Block POWERED_RAIL = Blocks.f_50030_;
    public static final Block DETECTOR_RAIL = Blocks.f_50031_;
    public static final Block PISTON = Blocks.f_50039_;
    public static final Block STICKY_PISTON = Blocks.f_50032_;
    public static final Block COBWEB = Blocks.f_50033_;
    public static final Block GRAVEL = Blocks.f_49994_;
    public static final Block GLASS = Blocks.f_50058_;
    public static final Block DISPENSER = Blocks.f_50061_;

    public static final Block COAL_ORE = Blocks.f_49997_;
    public static final Block IRON_ORE = Blocks.f_49996_;
    public static final Block COPPER_ORE = Blocks.f_152505_;
    public static final Block GOLD_ORE = Blocks.f_49995_;
    public static final Block DIAMOND_ORE = Blocks.f_50089_;
    public static final Block REDSTONE_ORE = Blocks.f_50173_;
    public static final Block EMERALD_ORE = Blocks.f_50264_;
    public static final Block LAPIS_ORE = Blocks.f_50059_;
    public static final Block NETHER_QUARTZ_ORE = Blocks.f_50331_;

    public static final Block COAL_BLOCK = Blocks.f_50353_;
    public static final Block IRON_BLOCK = Blocks.f_50075_;
    public static final Block COPPER_BLOCK = Blocks.f_152504_;
    public static final Block GOLD_BLOCK = Blocks.f_50074_;
    public static final Block DIAMOND_BLOCK = Blocks.f_50090_;
    public static final Block REDSTONE_BLOCK = Blocks.f_50330_;
    public static final Block EMERALD_BLOCK = Blocks.f_50268_;
    public static final Block LAPIS_BLOCK = Blocks.f_50060_;
    public static final Block QUARTZ_BLOCK = Blocks.f_50333_;

    public static final Block TNT = Blocks.f_50077_;
    public static final Block BOOKSHELF = Blocks.f_50078_;
    public static final Block OBSIDIAN = Blocks.f_50080_;
    public static final Block TORCH = Blocks.f_50081_;
    public static final Block WALL_TORCH = Blocks.f_50082_;
    public static final Block FIRE = Blocks.f_50083_;
    public static final Block SOUL_FIRE = Blocks.f_50084_;
    public static final Block SPAWNER = Blocks.f_50085_;
    public static final Block OAK_STAIRS = Blocks.f_50086_;
    public static final Block CHEST = Blocks.f_50087_;
    public static final Block REDSTONE_WIRE = Blocks.f_50088_;

    public static final Block WATER = Blocks.f_49990_;
    public static final Block LAVA = Blocks.f_49991_;
    public static final Block BEDROCK = Blocks.f_50752_;

    // ----

    public static boolean isExist(Block block) {
        return block != null && block != Blocks.f_50016_;
    }
}
