package net.pitan76.mcpitanlib.api.entity.attribute;

import net.minecraft.world.entity.ai.attributes.Attribute;

public class CompatEntityAttribute {
    public final Attribute raw;

    @Deprecated
    public CompatEntityAttribute(Attribute attribute) {
        this.raw = attribute;
    }

    @Deprecated
    public Attribute raw() {
        return raw;
    }

    public String getId() {
        return raw.m_22087_();
    }

    public Attribute getValue() {
        return raw();
    }

    public boolean isNull() {
        return raw == null;
    }

    @Deprecated
    public static CompatEntityAttribute of(Attribute attribute) {
        return new CompatEntityAttribute(attribute);
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (!(obj instanceof CompatEntityAttribute)) return false;
        CompatEntityAttribute that = (CompatEntityAttribute) obj;
        return raw.equals(that.raw);
    }

    @Override
    public int hashCode() {
        if (raw == null) return super.hashCode();
        return raw.hashCode();
    }
}
