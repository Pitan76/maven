package net.pitan76.mcpitanlib.api.recipe;

import net.minecraft.world.Container;
import net.minecraft.world.item.crafting.Recipe;
import net.minecraft.world.level.Level;
import net.pitan76.mcpitanlib.api.recipe.input.CompatRecipeInput;
import net.pitan76.mcpitanlib.api.recipe.v2.CompatRecipeEntry;

import java.util.Optional;

@Deprecated
public interface MatchGetter<I extends Container, T extends Recipe<I>> {
    Optional<CompatRecipeEntry<I>> getFirstMatch(CompatRecipeInput<I> input, Level world);
}
