package net.pitan76.mcpitanlib.api.util;

import com.mojang.math.Quaternion;
import com.mojang.math.Vector3f;
import net.pitan76.mcpitanlib.api.util.math.random.CompatRandom;

public class MathUtil {

    public static CompatRandom createRandom(long seed) {
        return CompatRandom.of(seed);
    }

    public static CompatRandom createRandom() {
        return CompatRandom.of();
    }

    @Deprecated
    public static Quaternion getRotationDegrees(RotationAxisType type, float deg) {
        return type.axis.m_122240_(deg);
    }

    public static class RotationAxisType {

        public static RotationAxisType POSITIVE_X = new RotationAxisType(Vector3f.f_122223_);
        public static RotationAxisType POSITIVE_Y = new RotationAxisType(Vector3f.f_122225_);
        public static RotationAxisType POSITIVE_Z = new RotationAxisType(Vector3f.f_122227_);

        protected final Vector3f axis;
        protected RotationAxisType(Vector3f axis) {
            this.axis = axis;
        }
    }
}
