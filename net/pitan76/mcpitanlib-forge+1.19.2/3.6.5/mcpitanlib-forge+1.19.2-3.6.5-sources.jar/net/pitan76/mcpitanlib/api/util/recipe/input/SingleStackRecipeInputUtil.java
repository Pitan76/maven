package net.pitan76.mcpitanlib.api.util.recipe.input;

import net.minecraft.world.Container;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.pitan76.mcpitanlib.api.recipe.input.CompatRecipeInput;
import net.pitan76.mcpitanlib.api.util.ItemStackUtil;

import java.util.Optional;

public class SingleStackRecipeInputUtil {
    public static Optional<Container> get(CompatRecipeInput<?> input) {
        if (input.getInput() instanceof Container) {
            return Optional.of( input.getInput());
        }
        return Optional.empty();
    }

    public static CompatRecipeInput<?> create(Container input) {
        return new CompatRecipeInput<>(input);
    }

    public static CompatRecipeInput<?> create(ItemStack stack) {
        return new CompatRecipeInput<>(new Container() {

            private ItemStack itemStack = stack;

            @Override
            public void m_6211_() {
                itemStack = ItemStackUtil.empty();
            }

            @Override
            public int m_6643_() {
                return 1;
            }

            @Override
            public boolean m_7983_() {
                return false;
            }

            @Override
            public ItemStack m_8020_(int slot) {
                if (slot == 0)
                    return itemStack;
                return ItemStackUtil.empty();
            }

            @Override
            public ItemStack m_7407_(int slot, int amount) {
                if (slot == 0) {
                    ItemStack stack = itemStack;
                    ItemStackUtil.decrementCount(stack, amount);
                    return stack;
                }
                return ItemStackUtil.empty();
            }

            @Override
            public ItemStack m_8016_(int slot) {
                if (slot == 0) {
                    ItemStack stack = itemStack;
                    itemStack = ItemStackUtil.empty();
                    return stack;
                }
                return ItemStackUtil.empty();
            }

            @Override
            public void m_6836_(int slot, ItemStack stack) {
                if (slot == 0)
                    itemStack = stack;
            }

            @Override
            public void m_6596_() {

            }

            @Override
            public boolean m_6542_(Player player) {
                return false;
            }
        });
    }

    public static ItemStack getStack(CompatRecipeInput<?> input) {
        Optional<Container> recipeInput = get(input);
        if (!recipeInput.isPresent()) return ItemStackUtil.empty();

        return recipeInput.get().m_8020_(0);
    }
}
