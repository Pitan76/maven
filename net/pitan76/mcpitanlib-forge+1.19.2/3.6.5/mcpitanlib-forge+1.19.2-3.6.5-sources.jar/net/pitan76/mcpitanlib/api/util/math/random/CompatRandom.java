package net.pitan76.mcpitanlib.api.util.math.random;

public class CompatRandom {
    private java.util.Random javaRandom;
    private net.minecraft.util.RandomSource mcRandom;

    public CompatRandom(java.util.Random javaRandom) {
        this.javaRandom = javaRandom;
    }

    public CompatRandom(net.minecraft.util.RandomSource mcRandom) {
        this.mcRandom = mcRandom;
    }

    @Deprecated
    public CompatRandom() {
        this.mcRandom = net.minecraft.util.RandomSource.m_216327_();
    }

    @Deprecated
    public CompatRandom(long seed) {
        this.mcRandom = net.minecraft.util.RandomSource.m_216335_(seed);
    }

    public static CompatRandom of(long seed) {
        return new CompatRandom(seed);
    }

    public static CompatRandom of() {
        return new CompatRandom();
    }

    public void setSeed(long seed) {
        if (javaRandom != null) {
            javaRandom.setSeed(seed);
        } else {
            mcRandom.m_188584_(seed);
        }
    }

    public void skip(int count) {
        if (javaRandom != null) {
            for (int i = 0; i < count; i++) {
                javaRandom.nextInt();
            }
        } else {
            mcRandom.m_190110_(count);
        }
    }

    public void split() {
        if (javaRandom != null) {
            javaRandom.nextInt();
        } else {
            mcRandom.m_213769_();
        }
    }

    public int nextInt() {
        if (javaRandom != null) {
            return javaRandom.nextInt();
        } else {
            return mcRandom.m_188502_();
        }
    }

    public int nextInt(int bound) {
        if (javaRandom != null) {
            return javaRandom.nextInt(bound);
        } else {
            return mcRandom.m_188503_(bound);
        }
    }

    public long nextLong() {
        if (javaRandom != null) {
            return javaRandom.nextLong();
        } else {
            return mcRandom.m_188505_();
        }
    }

    public double nextDouble() {
        if (javaRandom != null) {
            return javaRandom.nextDouble();
        } else {
            return mcRandom.m_188500_();
        }
    }

    public double nextGaussian() {
        if (javaRandom != null) {
            return javaRandom.nextGaussian();
        } else {
            return mcRandom.m_188583_();
        }
    }

    public float nextFloat() {
        if (javaRandom != null) {
            return javaRandom.nextFloat();
        } else {
            return mcRandom.m_188501_();
        }
    }

    public int nextBetween(int min, int max) {
        if (javaRandom != null) {
            return min + javaRandom.nextInt(max - min);
        } else {
            return min + mcRandom.m_188503_(max - min);
        }
    }

    public int nextBetweenExclusive(int min, int max) {
        if (javaRandom != null) {
            return min + javaRandom.nextInt(max - min - 1);
        } else {
            return min + mcRandom.m_188503_(max - min - 1);
        }
    }

    public boolean nextBoolean() {
        if (javaRandom != null) {
            return javaRandom.nextBoolean();
        } else {
            return mcRandom.m_188499_();
        }
    }

    @Deprecated
    public java.util.Random getJavaRandom() {
        return javaRandom;
    }

    @Deprecated
    public net.minecraft.util.RandomSource getMcRandom() {
        return mcRandom;
    }
}
