package net.pitan76.mcpitanlib.api.util;

import net.minecraft.world.Container;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.ItemStack;
import net.pitan76.mcpitanlib.api.entity.Player;

public class SlotUtil {
    public static void setStack(Slot slot, ItemStack stack) {
        slot.m_5852_(stack);
    }

    public static ItemStack getStack(Slot slot) {
        return slot.m_7993_();
    }

    public static void takeStack(Slot slot, int amount) {
        slot.m_6201_(amount);
    }

    public static boolean hasStack(Slot slot) {
        return slot.m_6657_();
    }

    public static void markDirty(Slot slot) {
        slot.m_6654_();
    }

    public static boolean canInsert(Slot slot, ItemStack stack) {
        return slot.m_5857_(stack);
    }

    public static boolean canTakeItems(Slot slot) {
        return slot.m_8010_(null);
    }

    public static void onTakeItem(Slot slot, Player player, ItemStack stack) {
        slot.m_142406_(player.getEntity(), stack);
    }

    public static Container getInventory(Slot slot) {
        return slot.f_40218_;
    }
}
