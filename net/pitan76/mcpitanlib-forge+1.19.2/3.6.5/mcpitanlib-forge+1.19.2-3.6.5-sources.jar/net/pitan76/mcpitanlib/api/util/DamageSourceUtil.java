package net.pitan76.mcpitanlib.api.util;

import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.pitan76.mcpitanlib.api.entity.Player;

public class DamageSourceUtil {
    public static DamageSource thrownProjectile(Entity projectile, Entity attacker, Entity source) {
        return thrownProjectile(projectile, attacker);
    }

    public static DamageSource thrownProjectile(Entity projectile, Entity attacker) {
        return DamageSource.m_19361_(projectile, attacker);
    }

    public static DamageSource playerAttack(Player attacker, Entity source) {
        return playerAttack(attacker);
    }

    public static DamageSource playerAttack(Player attacker) {
        return DamageSource.m_19344_(attacker.getPlayerEntity());
    }

    public static DamageSource mobAttack(LivingEntity attacker, Entity source) {
        return mobAttack(attacker);
    }

    public static DamageSource mobAttack(LivingEntity attacker) {
        return DamageSource.m_19370_(attacker);
    }

    public static DamageSource mobProjectile(Entity projectile, LivingEntity attacker, Entity source) {
        return mobProjectile(projectile, attacker);
    }

    public static DamageSource mobProjectile(Entity projectile, LivingEntity attacker) {
        return DamageSource.m_19340_(projectile, attacker);
    }

    public static DamageSource fall(Entity source) {
        return DamageSource.f_19315_;
    }
}
