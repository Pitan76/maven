package net.pitan76.mcpitanlib.api.util.event;

import net.minecraft.world.item.Item;
import net.pitan76.mcpitanlib.api.event.item.ItemUseEvent;
import net.pitan76.mcpitanlib.api.util.CompatActionResult;

public class ItemEventGenerator {
    public static CompatActionResult onRightClick(Item item, ItemUseEvent e) {
        return CompatActionResult.create(item.m_7203_(e.world, e.user.getPlayerEntity(), e.hand).m_19089_());
    }
}
