package net.pitan76.mcpitanlib.api.gui.inventory;

import net.minecraft.core.NonNullList;
import net.minecraft.world.Container;
import net.minecraft.world.ContainerHelper;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;

public interface IInventory extends Container {

    NonNullList<ItemStack> getItems();

    static IInventory of(NonNullList<ItemStack> items) {
        return () -> items;
    }

    static IInventory ofSize(int size) {
        return of(NonNullList.m_122780_(size, ItemStack.f_41583_));
    }

    @Override
    default int m_6643_() {
        return getItems().size();
    }

    @Override
    default boolean m_7983_() {
        for (int i = 0; i < m_6643_(); i++) {
            ItemStack stack = m_8020_(i);
            if (!stack.m_41619_()) {
                return false;
            }
        }
        return true;
    }

    @Override
    default ItemStack m_8020_(int slot) {
        return getItems().get(slot);
    }

    @Override
    default ItemStack m_7407_(int slot, int count) {
        ItemStack result = ContainerHelper.m_18969_(getItems(), slot, count);
        if (!result.m_41619_()) {
            m_6596_();
        }
        return result;
    }

    @Override
    default ItemStack m_8016_(int slot) {
        return ContainerHelper.m_18966_(getItems(), slot);
    }

    @Override
    default void m_6836_(int slot, ItemStack stack) {
        getItems().set(slot, stack);
        if (stack.m_41613_() > m_6893_()) {
            stack.m_41764_(m_6893_());
        }
    }

    @Override
    default void m_6211_() {
        getItems().clear();
    }

    @Override
    default void m_6596_() {
    }

    @Override
    default boolean m_6542_(Player player) {
        return true;
    }
}