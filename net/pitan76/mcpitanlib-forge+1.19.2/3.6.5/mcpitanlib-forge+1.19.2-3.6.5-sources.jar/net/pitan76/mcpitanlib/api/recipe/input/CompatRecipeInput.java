package net.pitan76.mcpitanlib.api.recipe.input;

import net.minecraft.world.Container;
import net.minecraft.world.item.ItemStack;

public class CompatRecipeInput<I extends Container> {
    protected I input;

    public CompatRecipeInput(I input) {
        this.input = input;
    }

    public I getInput() {
        return input;
    }

    public ItemStack getStack(int slot) {
        return input.m_8020_(slot);
    }

    public net.pitan76.mcpitanlib.midohra.item.ItemStack getMidohraStack(int slot) {
        return net.pitan76.mcpitanlib.midohra.item.ItemStack.of(getStack(slot));
    }

    public int getSize() {
        return input.m_6643_();
    }

    public boolean isEmpty() {
        return input.m_7983_();
    }
}
