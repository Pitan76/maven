package net.pitan76.mcpitanlib.api.util.screen;

import org.jetbrains.annotations.Nullable;

import java.util.Set;
import net.minecraft.util.Mth;
import net.minecraft.world.Container;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.entity.BlockEntity;

public class ScreenHandlerUtil {
    public static int calcComparatorOutput(@Nullable Container inventory) {
        return AbstractContainerMenu.m_38938_(inventory);
    }

    public static int calcComparatorOutput(@Nullable BlockEntity blockEntity) {
        return AbstractContainerMenu.m_38918_(blockEntity);
    }

    public static int calculateStackSize(Set<Slot> slots, int mode, ItemStack stack) {
        int stackSize;

        switch (mode) {
            case 0:
                stackSize = Mth.m_14143_((float)stack.m_41613_() / (float)slots.size());
                break;
            case 1:
                stackSize = 1;
                break;
            case 2:
                stackSize = stack.m_41741_();
                break;
            default:
                stackSize = stack.m_41613_();
        }

        return stackSize;
    }

    public static boolean canInsertItemIntoSlot(@Nullable Slot slot, ItemStack stack, boolean allowOverflow) {
        return AbstractContainerMenu.m_38899_(slot, stack, allowOverflow);
    }
}
