package net.pitan76.mcpitanlib.api.item;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.item.ArmorMaterial;
import net.minecraft.world.item.crafting.Ingredient;

public interface CompatibleArmorMaterial {
    int getDurability(ArmorEquipmentType type);

    int getProtection(ArmorEquipmentType type);

    int getEnchantability();

    SoundEvent getEquipSound();

    Ingredient getRepairIngredient();

    /**
     * @return the name of the material
     */
    default String getName() {
        return getId().m_135815_();
    }

    /**
     * @return the id of the material
     */
    ResourceLocation getId();

    float getToughness();

    float getKnockbackResistance();

    @Deprecated
    default ArmorMaterial build() {
        return new ArmorMaterial() {
            @Override
            public int m_7366_(EquipmentSlot slot) {
                return CompatibleArmorMaterial.this.getDurability(ArmorEquipmentType.of(slot));
            }

            @Override
            public int m_7365_(EquipmentSlot slot) {
                return CompatibleArmorMaterial.this.getProtection(ArmorEquipmentType.of(slot));
            }

            @Override
            public int m_6646_() {
                return CompatibleArmorMaterial.this.getEnchantability();
            }

            @Override
            public SoundEvent m_7344_() {
                return CompatibleArmorMaterial.this.getEquipSound();
            }

            @Override
            public Ingredient m_6230_() {
                return CompatibleArmorMaterial.this.getRepairIngredient();
            }

            @Override
            public String m_6082_() {
                return CompatibleArmorMaterial.this.getName();
            }

            @Override
            public float m_6651_() {
                return CompatibleArmorMaterial.this.getToughness();
            }

            @Override
            public float m_6649_() {
                return CompatibleArmorMaterial.this.getKnockbackResistance();
            }
        };
    }
}
