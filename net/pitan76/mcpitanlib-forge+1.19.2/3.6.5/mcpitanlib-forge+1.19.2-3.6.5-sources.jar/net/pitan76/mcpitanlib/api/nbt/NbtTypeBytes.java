package net.pitan76.mcpitanlib.api.nbt;

import net.minecraft.nbt.Tag;

public class NbtTypeBytes {
    public static final byte END = Tag.f_178193_;
    public static final byte BYTE = Tag.f_178194_;
    public static final byte SHORT = Tag.f_178195_;
    public static final byte INT = Tag.f_178196_;
    public static final byte LONG = Tag.f_178197_;
    public static final byte FLOAT = Tag.f_178198_;
    public static final byte DOUBLE = Tag.f_178199_;
    public static final byte BYTE_ARRAY = Tag.f_178200_;
    public static final byte STRING = Tag.f_178201_;
    public static final byte LIST = Tag.f_178202_;
    public static final byte COMPOUND = Tag.f_178203_;
    public static final byte INT_ARRAY = Tag.f_178204_;
    public static final byte LONG_ARRAY = Tag.f_178205_;
    public static final byte NUMBER = Tag.f_178206_;
}
