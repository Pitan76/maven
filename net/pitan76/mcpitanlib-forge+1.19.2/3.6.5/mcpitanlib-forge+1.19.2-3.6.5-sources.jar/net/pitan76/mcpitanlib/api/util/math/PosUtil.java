package net.pitan76.mcpitanlib.api.util.math;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.Position;
import net.minecraft.core.Vec3i;
import net.minecraft.util.math.*;
import net.minecraft.world.phys.Vec3;

public class PosUtil {
    public static BlockPos flooredBlockPos(double x, double y, double z) {
        return new BlockPos(x, y, z);
    }

    public static BlockPos flooredBlockPos(Position pos) {
        return new BlockPos(pos);
    }

    public static BlockPos flooredBlockPos(Vec3 pos) {
        return new BlockPos(pos);
    }

    public static net.pitan76.mcpitanlib.midohra.util.math.BlockPos midohraBlockPos(int x, int y, int z) {
        return net.pitan76.mcpitanlib.midohra.util.math.BlockPos.of(x, y, z);
    }

    public static net.pitan76.mcpitanlib.midohra.util.math.BlockPos flooredMidohraBlockPos(double x, double y, double z) {
        int x1 = (int) Math.floor(x);
        int y1 = (int) Math.floor(y);
        int z1 = (int) Math.floor(z);
        return midohraBlockPos(x1, y1, z1);
    }

    public static double getSquaredDistance(BlockPos pos1, BlockPos pos2) {
        return pos1.m_123331_(pos2);
    }

    public static double getSquaredDistance(BlockPos pos1, double x, double y, double z) {
        return pos1.m_203202_(x, y, z);
    }

    public static Iterable<BlockPos> iterate(BlockPos start, BlockPos end) {
        return BlockPos.m_121940_(start, end);
    }

    public static BlockPos[] getNeighborPoses(BlockPos pos) {
        return new BlockPos[]{pos.m_122012_(), pos.m_122019_(), pos.m_122029_(), pos.m_122024_(), pos.m_7494_(), pos.m_7495_()};
    }

    public static BlockPos up(BlockPos pos) {
        return pos.m_7494_();
    }

    public static BlockPos down(BlockPos pos) {
        return pos.m_7495_();
    }

    public static BlockPos north(BlockPos pos) {
        return pos.m_122012_();
    }

    public static BlockPos south(BlockPos pos) {
        return pos.m_122019_();
    }

    public static BlockPos east(BlockPos pos) {
        return pos.m_122029_();
    }

    public static BlockPos west(BlockPos pos) {
        return pos.m_122024_();
    }

    public static BlockPos add(BlockPos pos, int x, int y, int z) {
        return pos.m_7918_(x, y, z);
    }

    public static BlockPos sub(BlockPos pos, int x, int y, int z) {
        return pos.m_121996_(new Vec3i(x, y, z));
    }

    public static BlockPos mul(BlockPos pos, int n) {
        return pos.m_142393_(n);
    }

    public static int x(BlockPos pos) {
        return pos.m_123341_();
    }

    public static int y(BlockPos pos) {
        return pos.m_123342_();
    }

    public static int z(BlockPos pos) {
        return pos.m_123343_();
    }

    public static BlockPos offset(BlockPos pos, Direction direction) {
        return pos.m_121945_(direction);
    }

    public static BlockPos offset(BlockPos pos, Direction direction, int n) {
        return pos.m_5484_(direction, n);
    }

    public static BlockPos offset(BlockPos pos, net.pitan76.mcpitanlib.midohra.util.math.Direction direction) {
        return pos.m_121945_(direction.toMinecraft());
    }

    public static BlockPos offset(BlockPos pos, net.pitan76.mcpitanlib.midohra.util.math.Direction direction, int n) {
        return pos.m_5484_(direction.toMinecraft(), n);
    }

    public static BlockPos toImmutable(BlockPos pos) {
        return pos.m_7949_();
    }

    public static long asLong(BlockPos pos) {
        return pos.m_121878_();
    }
}
