package net.pitan76.mcpitanlib.api.gui.slot;

import net.minecraft.world.Container;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.ItemStack;
import net.pitan76.mcpitanlib.api.entity.Player;
import net.pitan76.mcpitanlib.api.util.inventory.ICompatInventory;

public class CompatibleSlot extends Slot {
    
    public Container inventory;
    public int index;
    public int x;
    public int y;

    public CompatibleSlot(Container inventory, int index, int x, int y) {
        super(inventory, index, x, y);
        this.f_40218_ = inventory;
        this.index = index;
        this.f_40220_ = x;
        this.f_40221_ = y;
    }

    public CompatibleSlot(ICompatInventory inventory, int index, int x, int y) {
        super(inventory, index, x, y);
        this.f_40218_ = inventory;
        this.index = index;
        this.f_40220_ = x;
        this.f_40221_ = y;
    }

    public void callSetStack(ItemStack stack) {
        super.m_5852_(stack);
    }

    public void callSetStackNoCallbacks(ItemStack stack) {
        super.m_219996_(stack);
    }

    public ItemStack callGetStack() {
        return super.m_7993_();
    }

    public ItemStack callTakeStack(int amount) {
        return super.m_6201_(amount);
    }

    public boolean callHasStack() {
        return super.m_6657_();
    }

    @Deprecated
    @Override
    public void m_5852_(ItemStack stack) {
       callSetStack(stack);
    }

    @Deprecated
    @Override
    public void m_219996_(ItemStack stack) {
        callSetStackNoCallbacks(stack);
    }

    @Deprecated
    @Override
    public ItemStack m_7993_() {
        return callGetStack();
    }

    @Deprecated
    @Override
    public ItemStack m_6201_(int amount) {
        return callTakeStack(amount);
    }

    @Deprecated
    @Override
    public boolean m_6657_() {
        return callHasStack();
    }

    public Container callGetInventory() {
        return f_40218_;
    }

    public int callGetIndex() {
        return super.m_150661_();
    }

    public int callGetId() {
        return super.f_40219_;
    }

    public int callGetX() {
        return super.f_40220_;
    }

    public int callGetY() {
        return super.f_40221_;
    }

    public void callMarkDirty() {
        super.m_6654_();
    }

    @Override
    public boolean m_5857_(ItemStack stack) {
        return canInsert(net.pitan76.mcpitanlib.midohra.item.ItemStack.of(stack));
    }

    @Override
    public boolean m_8010_(net.minecraft.world.entity.player.Player playerEntity) {
        return canTakeItems(new Player(playerEntity));
    }

    public boolean canInsert(net.pitan76.mcpitanlib.midohra.item.ItemStack stack) {
        return super.m_5857_(stack.toMinecraft());
    }

    public boolean canTakeItems(Player player) {
        return super.m_8010_(player.getEntity());
    }

    @Deprecated
    @Override
    public boolean m_150651_(net.minecraft.world.entity.player.Player player) {
        return canTakePartial(new Player(player));
    }

    public boolean canTakePartial(Player player) {
        return super.m_150651_(player.getEntity());
    }
}
