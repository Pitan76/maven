package net.pitan76.mcpitanlib.api.entity.effect;

import org.jetbrains.annotations.Nullable;

import java.util.Optional;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectInstance;

public class CompatStatusEffectInstance {
    private final MobEffectInstance instance;
    
    @Deprecated
    public CompatStatusEffectInstance(MobEffectInstance instance) {
        this.instance = instance;
    }

    public MobEffectInstance getInstance() {
        return instance;
    }

    public Optional<CompatStatusEffect> getCompatStatusEffect() {
        return Optional.of(new CompatStatusEffect(instance.m_19544_()));
    }

    public CompatStatusEffectInstance(CompatStatusEffect effect) {
        this(effect, 0, 0);
    }

    public CompatStatusEffectInstance(CompatStatusEffect effect, int duration) {
        this(effect, duration, 0);
    }

    public CompatStatusEffectInstance(CompatStatusEffect effect, int duration, int amplifier) {
        this(effect, duration, amplifier, false, true);
    }

    public CompatStatusEffectInstance(CompatStatusEffect effect, int duration, int amplifier, boolean ambient, boolean visible) {
        this(effect, duration, amplifier, ambient, visible, visible);
    }

    public CompatStatusEffectInstance(CompatStatusEffect effect, int duration, int amplifier, boolean ambient, boolean showParticles, boolean showIcon) {
        this(effect, duration, amplifier, ambient, showParticles, showIcon, null);
    }
    
    public CompatStatusEffectInstance(CompatStatusEffect effect, int duration, int amplifier, boolean ambient, boolean showParticles, boolean showIcon, @Nullable MobEffectInstance hiddenEffect) {
        MobEffect statusEffect = effect.getStatusEffect(null);
        this.instance = new MobEffectInstance(statusEffect, duration, amplifier, ambient, showParticles, showIcon, hiddenEffect, statusEffect.m_216881_());
    }

    public int getDuration() {
        return instance.m_19557_();
    }

    public int getAmplifier() {
        return instance.m_19564_();
    }

    public boolean isAmbient() {
        return instance.m_19571_();
    }

    public boolean showParticles() {
        return instance.m_19572_();
    }

    public boolean showIcon() {
        return instance.m_19575_();
    }

    public boolean isInfinite() {
        return instance.m_19577_();
    }
}
