package net.pitan76.mcpitanlib.api.util.client;

import com.mojang.authlib.GameProfile;
import com.mojang.blaze3d.platform.Window;
import net.minecraft.client.Minecraft;
import net.minecraft.client.MouseHandler;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.client.renderer.GameRenderer;
import net.minecraft.client.renderer.LevelRenderer;
import net.minecraft.client.renderer.entity.ItemRenderer;
import net.minecraft.client.renderer.texture.TextureManager;
import net.minecraft.server.packs.resources.ResourceManager;
import net.minecraft.util.profiling.ProfilerFiller;
import net.minecraft.world.phys.HitResult;
import net.pitan76.mcpitanlib.api.client.option.GameOptionsWrapper;
import net.pitan76.mcpitanlib.api.entity.Player;

import java.io.File;
import java.util.Optional;

public class ClientUtil {
    public static void setScreen(Screen screen) {
        getClient().m_91152_(screen);
    }

    public static Screen getScreen() {
        return getClient().f_91080_;
    }

    public static Player getPlayer() {
        return new Player(getClientPlayer());
    }

    public static LocalPlayer getClientPlayer() {
        return getClient().f_91074_;
    }

    public static Minecraft getClient() {
        return Minecraft.m_91087_();
    }

    public static Font getTextRenderer() {
        return getClient().f_91062_;
    }

    public static ItemRenderer getItemRenderer() {
        return getClient().m_91291_();
    }

    public static ResourceManager getResourceManager() {
        return getClient().m_91098_();
    }

    public static TextureManager getTextureManager() {
        return getClient().m_91097_();
    }

    public static ClientLevel getWorld() {
        return getClient().f_91073_;
    }

    public static GameRenderer getGameRenderer() {
        return getClient().f_91063_;
    }

    public static Optional<Long> getTime() {
        if (getClient().f_91073_ == null) return Optional.empty();
        return Optional.of(getClient().f_91073_.m_46467_());
    }

    public static long getRenderTime() {
        return (long) getClient().m_91296_();
    }

    public static HitResult getTarget() {
        return getClient().f_91077_;
    }

    public static LevelRenderer getWorldRenderer() {
        return getClient().f_91060_;
    }

    public static File getRunDirectory() {
        return getClient().f_91069_;
    }

    public static ProfilerFiller getProfiler() {
        return getClient().m_91307_();
    }

    public static GameProfile getGameProfile() {
        if (getClient().f_91074_ == null) return null;
        return getClient().f_91074_.m_36316_();
    }

    public static Window getWindow() {
        return getClient().m_91268_();
    }

    public static MouseHandler getMouse() {
        return getClient().f_91067_;
    }

    public static boolean isInSingleplayer() {
        return getClient().m_91090_();
    }

    public static boolean isPaused() {
        return getClient().m_91104_();
    }

    public static GameOptionsWrapper getOptions() {
        return new GameOptionsWrapper(getClient().f_91066_);
    }
}
