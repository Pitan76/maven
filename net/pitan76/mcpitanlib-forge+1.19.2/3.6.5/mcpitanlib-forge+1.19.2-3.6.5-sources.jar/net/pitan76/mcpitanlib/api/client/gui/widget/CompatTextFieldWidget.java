package net.pitan76.mcpitanlib.api.client.gui.widget;

import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.network.chat.Component;
import net.pitan76.mcpitanlib.api.util.TextUtil;
import org.jetbrains.annotations.Nullable;

public class CompatTextFieldWidget extends EditBox {
    public CompatTextFieldWidget(Font textRenderer, int width, int height) {
        this(textRenderer, width, height, TextUtil.empty());
    }

    public CompatTextFieldWidget(Font textRenderer, int x, int y, int width, int height) {
        this(textRenderer, x, y, width, height, TextUtil.empty());
    }

    // ----

    public CompatTextFieldWidget(Font textRenderer, int width, int height, Component text) {
        super(textRenderer, 0, 0, width, height, text);
    }

    public CompatTextFieldWidget(Font textRenderer, int x, int y, int width, int height, Component text) {
        super(textRenderer, x, y, width, height, text);
    }

    public CompatTextFieldWidget(Font textRenderer, int x, int y, int width, int height, @Nullable EditBox copyFrom, Component text) {
        super(textRenderer, x, y, width, height, copyFrom, text);
    }

    // ----

    @Deprecated
    @Override
    public void m_94182_(boolean drawsBackground) {
        callSetDrawsBackground(drawsBackground);
    }

    public void callSetDrawsBackground(boolean drawsBackground) {
        super.m_94182_(drawsBackground);
    }

    @Deprecated
    @Override
    public void m_93692_(boolean focused) {
        callSetFocused(focused);
    }

    public void callSetFocused(boolean focused) {
        super.m_93692_(focused);
    }

    @Deprecated
    @Override
    public void m_94190_(boolean focusUnlocked) {
        callSetFocusUnlocked(focusUnlocked);
    }

    public void callSetFocusUnlocked(boolean focusUnlocked) {
        super.m_94190_(focusUnlocked);
    }

    @Deprecated
    @Override
    public void m_94199_(int maxLength) {
        callSetMaxLength(maxLength);
    }

    public void callSetMaxLength(int maxLength) {
        super.m_94199_(maxLength);
    }

    @Deprecated
    @Override
    public void m_94144_(String text) {
        callSetText(text);
    }

    public void callSetText(String text) {
        super.m_94144_(text);
    }

    @Deprecated
    @Override
    public String m_94155_() {
        return callGetText();
    }

    public String callGetText() {
        return super.m_94155_();
    }

    @Deprecated
    @Override
    public void m_94186_(boolean editable) {
        callSetEditable(editable);
    }

    public void callSetEditable(boolean editable) {
        super.m_94186_(editable);
    }

    @Deprecated
    @Override
    public boolean m_93696_() {
        return callIsFocused();
    }

    public boolean callIsFocused() {
        return super.m_93696_();
    }

    @Deprecated
    @Override
    public boolean m_7933_(int keyCode, int scanCode, int modifiers) {
        return callKeyPressed(keyCode, scanCode, modifiers);
    }

    public boolean callKeyPressed(int keyCode, int scanCode, int modifiers) {
        return super.m_7933_(keyCode, scanCode, modifiers);
    }

    @Deprecated
    @Override
    public boolean m_7920_(int keyCode, int scanCode, int modifiers) {
        return callKeyReleased(keyCode, scanCode, modifiers);
    }

    public boolean callKeyReleased(int keyCode, int scanCode, int modifiers) {
        return super.m_7920_(keyCode, scanCode, modifiers);
    }

    @Deprecated
    @Override
    public boolean m_5534_(char chr, int modifiers) {
        return callCharTyped(chr, modifiers);
    }

    public boolean callCharTyped(char chr, int modifiers) {
        return super.m_5534_(chr, modifiers);
    }
}
