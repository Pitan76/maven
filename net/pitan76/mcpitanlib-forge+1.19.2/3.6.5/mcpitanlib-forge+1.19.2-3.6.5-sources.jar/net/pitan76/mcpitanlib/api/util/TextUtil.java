package net.pitan76.mcpitanlib.api.util;

import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.network.chat.Style;
import net.pitan76.mcpitanlib.api.text.TextConverter;

public class TextUtil {
    public static MutableComponent literal(String string) {
        return Component.m_237113_(string);
    }

    public static MutableComponent translatable(String key) {
        return Component.m_237115_(key);
    }

    public static MutableComponent translatable(String key, Object... args) {
        return Component.m_237110_(key, args);
    }

    public static MutableComponent empty() {
        return literal("");
    }

    public static MutableComponent keybind(String string) {
        return Component.m_237117_(string);
    }

    public static String txt2str(Component text) {
        return text.getString();
    }

    public static MutableComponent setStyle(MutableComponent text, Style style) {
        return text.m_6270_(style);
    }

    public static Style getStyle(MutableComponent text) {
        return text.m_7383_();
    }

    public static MutableComponent withColor(MutableComponent text, int color) {
        return setStyle(text, StyleUtil.withColor(text.m_7383_(), color));
    }

    public static MutableComponent withBold(MutableComponent text, boolean bold) {
        return setStyle(text, StyleUtil.withBold(text.m_7383_(), bold));
    }

    public static MutableComponent append(MutableComponent text, Component sibling) {
        return text.m_7220_(sibling);
    }

    public static MutableComponent append(MutableComponent text, String string) {
        return text.m_130946_(string);
    }

    public static MutableComponent of(String string) {
        return literal(string);
    }

    public static MutableComponent convert(String text) {
        return TextConverter.convert(text, false);
    }

    public static MutableComponent convertWithTranslatable(String text) {
        return TextConverter.convert(text, true);
    }

    public static boolean contains(Component text, Component text1) {
        return text.m_240452_(text1);
    }
}