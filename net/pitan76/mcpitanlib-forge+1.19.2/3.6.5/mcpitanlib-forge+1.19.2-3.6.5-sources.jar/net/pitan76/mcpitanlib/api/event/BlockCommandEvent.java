package net.pitan76.mcpitanlib.api.event;

import net.minecraft.commands.arguments.blocks.BlockStateArgument;
import net.minecraft.world.level.block.Block;
import net.pitan76.mcpitanlib.api.command.argument.BlockCommand;

public class BlockCommandEvent extends RequiredCommandEvent {
    public Block getValue() {
        return BlockStateArgument.m_116123_(context, ((BlockCommand) getCommand()).getArgumentName()).m_114669_().m_60734_();
    }
}
