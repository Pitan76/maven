package net.pitan76.mcpitanlib.api.util.inventory;

import net.minecraft.core.NonNullList;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.ItemStack;
import net.pitan76.mcpitanlib.api.entity.Player;

public class PlayerInventoryUtil {
    public static Player getPlayer(Inventory playerInventory) {
        return new Player(playerInventory.f_35978_);
    }

    public static int getSelectedSlot(Inventory playerInventory) {
        return playerInventory.f_35977_;
    }

    public static void setSelectedSlot(Inventory playerInventory, int slot) {
        playerInventory.f_35977_ = slot;
    }

    public static void dropAllItems(Inventory inv) {
        inv.m_36071_();
    }

    public static NonNullList<ItemStack> getMain(Inventory inv) {
        return inv.f_35974_;
    }

    public static NonNullList<ItemStack> getArmor(Inventory inv) {
        return inv.f_35975_;
    }

    public static NonNullList<ItemStack> getOffHand(Inventory inv) {
        return inv.f_35976_;
    }

    public static ItemStack getMainHandStack(Inventory inv) {
        return inv.m_36056_();
    }
}
