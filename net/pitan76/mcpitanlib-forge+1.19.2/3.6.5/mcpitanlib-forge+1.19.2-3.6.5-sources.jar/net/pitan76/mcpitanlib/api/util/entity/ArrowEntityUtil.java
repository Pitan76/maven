package net.pitan76.mcpitanlib.api.util.entity;

import net.minecraft.world.entity.projectile.Arrow;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.pitan76.mcpitanlib.api.util.ItemStackUtil;
import org.jetbrains.annotations.Nullable;

public class ArrowEntityUtil {
    public static Arrow create(Level world, double x, double y, double z, ItemStack stack, @Nullable ItemStack shotFrom) {
        Arrow arrow = new Arrow(world, x, y, z);
        arrow.m_36878_(stack);
        return arrow;
    }

    public static Arrow create(Level world, double x, double y, double z, ItemStack stack) {
        return create(world, x, y, z, stack, null);
    }

    public static Arrow create(Level world, double x, double y, double z) {
        return create(world, x, y, z, ItemStackUtil.getDefaultStack(Items.f_42412_));
    }

    public static void setVelocity(Arrow arrow, double x, double y, double z, float velocity, float divergence) {
        arrow.m_6686_(x, y, z, velocity, divergence);
    }
}
