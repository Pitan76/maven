package net.pitan76.mcpitanlib.api.util;

import net.minecraft.SharedConstants;
import net.pitan76.mcpitanlib.api.util.client.ClientUtil;

public class MCVersionUtil {

    public static int getProtocolVersion() {
        return SharedConstants.m_136192_();
    }

    public static String getGameVersion() {
        return ClientUtil.getClient().m_91388_();
    }

    public static boolean isSupportedComponent() {
        return SharedConstants.m_136192_() >= 766;
    }
}
