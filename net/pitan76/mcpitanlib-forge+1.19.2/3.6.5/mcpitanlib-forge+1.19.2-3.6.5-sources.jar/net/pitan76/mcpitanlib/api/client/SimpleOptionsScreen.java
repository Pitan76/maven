package net.pitan76.mcpitanlib.api.client;

import net.minecraft.client.Options;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

public class SimpleOptionsScreen extends SimpleScreen {

    protected final Screen parent;
    protected final Options gameOptions;

    public SimpleOptionsScreen(Component title, Screen parent, Options gameOptions) {
        super(title);
        this.parent = parent;
        this.gameOptions = gameOptions;
    }

    @Override
    public void m_7861_() {
        f_96541_.f_91066_.m_92169_();
    }

    @Override
    public void m_7379_() {
        f_96541_.m_91152_(this.parent);
    }
}
