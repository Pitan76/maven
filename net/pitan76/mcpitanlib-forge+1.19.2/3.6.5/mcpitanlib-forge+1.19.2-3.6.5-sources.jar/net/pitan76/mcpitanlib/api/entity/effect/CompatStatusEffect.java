package net.pitan76.mcpitanlib.api.entity.effect;

import net.minecraft.core.Registry;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.level.Level;
import net.pitan76.mcpitanlib.api.util.StatusEffectUtil;
import org.jetbrains.annotations.Nullable;

public class CompatStatusEffect {
    private final MobEffect statusEffect;

    @Deprecated
    public CompatStatusEffect(MobEffect statusEffect) {
        this.statusEffect = statusEffect;
    }

    public CompatStatusEffect of(ResourceLocation identifier) {
        return StatusEffectUtil.getStatusEffect(identifier);
    }

    public ResourceLocation getId() {
        return Registry.f_122823_.m_7981_(statusEffect);
    }

    public String toString() {
        return getId().toString();
    }

    public boolean equals(Object obj) {
        if (obj instanceof CompatStatusEffect) {
            return ((CompatStatusEffect) obj).getId().equals(getId());
        }
        return false;
    }

    public MobEffect getStatusEffect(@Nullable Level world) {
        return statusEffect;
    }
}
