package net.pitan76.mcpitanlib.api.event.nbt;

import net.minecraft.nbt.CompoundTag;
import net.pitan76.mcpitanlib.api.registry.CompatRegistryLookup;

public class NbtRWArgs {
    public CompoundTag nbt;
    public CompatRegistryLookup registryLookup;

    public NbtRWArgs(CompoundTag nbt, CompatRegistryLookup registryLookup) {
        this.nbt = nbt;
        this.registryLookup = registryLookup;
    }

    public NbtRWArgs(CompoundTag nbt) {
        this.nbt = nbt;
    }

    public CompoundTag getNbt() {
        return nbt;
    }

    public CompatRegistryLookup getRegistryLookup() {
        return registryLookup;
    }

    public boolean hasRegistryLookup() {
        return registryLookup != null;
    }

    public boolean isNbtEmpty() {
        return nbt != null && !nbt.m_128456_();
    }

    public boolean isViewEmpty() {
        return false;
    }

    public boolean isEmpty() {
        return isNbtEmpty() || isViewEmpty();
    }

    public NbtRWArgs copy() {
        return new NbtRWArgs(nbt.m_6426_(), registryLookup);
    }

    public net.pitan76.mcpitanlib.midohra.nbt.NbtCompound getNbtM() {
        return net.pitan76.mcpitanlib.midohra.nbt.NbtCompound.of(nbt);
    }
}
