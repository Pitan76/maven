package net.pitan76.mcpitanlib.api.network;

import dev.architectury.networking.NetworkManager;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;

import static dev.architectury.networking.NetworkManager.Side.C2S;

public class ServerNetworking {
    public static void send(ServerPlayer player, ResourceLocation identifier, FriendlyByteBuf buf) {
        NetworkManager.sendToPlayer(player, identifier, buf);
    }

    public static void send(Iterable<ServerPlayer> players, ResourceLocation identifier, FriendlyByteBuf buf) {
        NetworkManager.sendToPlayers(players, identifier, buf);
    }


    public static void sendAll(MinecraftServer server, ResourceLocation identifier, FriendlyByteBuf buf) {
        send(server.m_6846_().m_11314_(), identifier, buf);
    }

    public static void registerReceiver(ResourceLocation identifier, ServerNetworkHandler handler) {
        NetworkManager.registerReceiver(C2S, identifier, ((buf, context) -> handler.receive(context.getPlayer().m_20194_(), (ServerPlayer) context.getPlayer(), buf)));
    }

    @FunctionalInterface
    public interface ServerNetworkHandler {
        void receive(MinecraftServer server, ServerPlayer player, FriendlyByteBuf buf);
    }

    public static void registerS2CPayloadType(ResourceLocation identifier) {
        // ignore
    }
}
