package net.pitan76.mcpitanlib.api.util.v1;

import net.minecraft.core.Registry;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.Block;
import net.pitan76.mcpitanlib.api.item.CompatibleItemSettings;
import net.pitan76.mcpitanlib.api.tag.TagKey;

import java.util.ArrayList;
import java.util.List;

public class ItemUtilV1 {
    public static Item item(ResourceLocation id) {
        return Registry.f_122827_.m_7745_(id);
    }

    public static boolean isEqual(Item item, Item item2) {
        return item == item2;
    }

    public static boolean isOf(ItemStack stack, Item item) {
        return stack.m_150930_(item);
    }

    public static boolean isIn(ItemStack stack, TagKey<Item> tagKey) {
        return isIn(stack.m_41720_(), tagKey);
    }

    public static boolean isIn(Item item, TagKey<Item> tagKey) {
        if (item.m_204114_().m_203656_(tagKey.getTagKey())) return true;
        return tagKey.isOf(item);
    }

    public static boolean isExist(ResourceLocation identifier) {
        return Registry.f_122827_.m_7804_(identifier);
    }
    public static ResourceLocation toID(Item item) {
        return Registry.f_122827_.m_7981_(item);
    }

    public static Item fromId(ResourceLocation identifier) {
        return Registry.f_122827_.m_7745_(identifier);
    }

    @Deprecated
    public static BlockItem ofBlock(Block block, Item.Properties settings) {
        return new BlockItem(block, settings);
    }

    public static BlockItem ofBlock(Block block, CompatibleItemSettings settings) {
        return ofBlock(block, settings.build());
    }

    @Deprecated
    public static Item of(Item.Properties settings) {
        return new Item(settings);
    }

    public static Item of(CompatibleItemSettings settings) {
        return of(settings.build());
    }

    public static List<Item> getAllItems() {
        List<Item> items = new ArrayList<>();
        for (Item item : Registry.f_122827_) {
            items.add(item);
        }
        return items;
    }

    public static int getRawId(Item item) {
        return Registry.f_122827_.m_7447_(item);
    }

    public static Item fromIndex(int index) {
        return Registry.f_122827_.m_7942_(index);
    }
}
