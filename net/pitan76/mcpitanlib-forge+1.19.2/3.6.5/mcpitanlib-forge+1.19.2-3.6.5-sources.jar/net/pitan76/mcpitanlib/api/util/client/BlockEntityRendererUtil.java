package net.pitan76.mcpitanlib.api.util.client;

import net.minecraft.client.renderer.blockentity.BlockEntityRendererProvider;
import net.pitan76.mcpitanlib.api.client.registry.CompatRegistryClient;

public class BlockEntityRendererUtil {
    public static BlockEntityRendererProvider.Context convert(CompatRegistryClient.BlockEntityRendererFactory.Context ctx) {
        return new BlockEntityRendererProvider.Context(ctx.getRenderDispatcher(), ctx.getRenderManager(), ctx.getItemRenderer(), ctx.getEntityRenderDispatcher(), ctx.getLayerRenderDispatcher(), ctx.getTextRenderer());
    }

    public static CompatRegistryClient.BlockEntityRendererFactory.Context convert(BlockEntityRendererProvider.Context ctx) {
        return new CompatRegistryClient.BlockEntityRendererFactory.Context(ctx.m_173581_(), ctx.m_173584_(), ctx.m_234447_(), ctx.m_234446_(), ctx.m_173585_(), ctx.m_173586_());
    }
}
