package net.pitan76.mcpitanlib.api.item.v2;

import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.UseAnim;
import net.minecraft.world.level.Level;
import net.pitan76.mcpitanlib.api.event.item.CanRepairArgs;
import net.pitan76.mcpitanlib.api.event.item.EnchantabilityArgs;
import net.pitan76.mcpitanlib.api.event.item.EnchantableArgs;
import net.pitan76.mcpitanlib.api.event.item.InventoryTickEvent;
import net.pitan76.mcpitanlib.api.item.ExtendItem;
import net.pitan76.mcpitanlib.api.item.args.RarityArgs;
import net.pitan76.mcpitanlib.api.item.args.StoppedUsingArgs;
import net.pitan76.mcpitanlib.api.item.args.UseActionArgs;
import net.pitan76.mcpitanlib.api.item.consume.CompatUseAction;
import net.pitan76.mcpitanlib.api.tag.item.RepairIngredientTag;
import net.pitan76.mcpitanlib.api.util.CompatRarity;
import net.pitan76.mcpitanlib.core.Dummy;
import net.pitan76.mcpitanlib.midohra.item.ItemWrapper;
import org.jetbrains.annotations.Nullable;

public class CompatItem extends ExtendItem {

    public CompatibleItemSettings settings;

    public CompatItem(CompatibleItemSettings settings) {
        super(settings);
        this.settings = settings;
    }

    public CompatibleItemSettings getCompatSettings() {
        return settings;
    }

    public ItemWrapper getWrapper() {
        return ItemWrapper.of(this);
    }

    @Deprecated
    @Override
    public UseAnim m_6164_(ItemStack stack) {
        return getUseAction(new UseActionArgs(stack)).getUseAction();
    }

    public CompatUseAction getUseAction(UseActionArgs args) {
        return CompatUseAction.of(super.m_6164_(args.stack));
    }

    @Deprecated
    @Override
    public Rarity m_41460_(ItemStack stack) {
        return getRarity(new RarityArgs(stack)).getRarity();
    }

    public CompatRarity getRarity(RarityArgs args) {
        return settings.rarity;
    }

    @Override
    public boolean isEnchantable(EnchantableArgs args) {
        return settings.enchantability != -1;
    }

    @Override
    public int getEnchantability(EnchantabilityArgs args) {
        return settings.enchantability;
    }

    @Override
    public boolean canRepair(CanRepairArgs args) {
        RepairIngredientTag tag = settings.repairIngredientTag;
        return tag != null && tag.contains(args.stack);
    }

    @Override
    public boolean hasRecipeRemainder(Dummy dummy) {
        return settings.recipeRemainder != null;
    }

    @Override
    protected String m_41467_() {
        if (settings.changedTranslationKey)
            return settings.translationKey;

        return super.m_41467_();
    }

    @Deprecated
    @Override
    public void m_5551_(ItemStack stack, Level world, LivingEntity user, int remainingUseTicks) {
        onStoppedUsing(new StoppedUsingArgs(stack, world, user, remainingUseTicks));
    }

    public boolean onStoppedUsing(StoppedUsingArgs args) {
        super.m_5551_(args.stack, args.world, args.user, args.remainingUseTicks);
        return false;
    }

    @Deprecated
    @Override
    public void m_6883_(ItemStack stack, Level world, Entity entity, int slot, boolean selected) {
        inventoryTick(new InventoryTickEvent(stack, world, entity, slot, selected));
    }

    public void inventoryTick(InventoryTickEvent e) {
        super.m_6883_(e.stack, e.world, e.entity, e.slot, e.selected);
    }
}
