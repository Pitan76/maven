package net.pitan76.mcpitanlib.api.util.inventory;

import net.minecraft.world.Container;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.pitan76.mcpitanlib.api.util.ItemStackUtil;

public class ClippedInventory implements Container, ICompatInventory {

    private final Container inventory;
    private final int start;
    private final int end;

    public static ClippedInventory of(Container inventory, int start, int end) {
        if (start < 0 || end > inventory.m_6643_() || start >= end) {
            throw new IllegalArgumentException("Invalid start or end indices for clipping inventory.");
        }
        return new ClippedInventory(inventory, start, end);
    }

    public static ClippedInventory of(Container inventory) {
        return of(inventory, 0, inventory.m_6643_());
    }

    public static ClippedInventory of(Container inventory, int start) {
        return of(inventory, start, inventory.m_6643_());
    }

    public ClippedInventory(Container inventory, int start, int end) {
        this.inventory = inventory;
        this.start = start;
        this.end = end;
    }

    @Override
    public int m_6643_() {
        return end - start;
    }

    @Override
    public boolean m_7983_() {
        for (int i = start; i < end; i++) {
            if (!inventory.m_8020_(i).m_41619_()) {
                return false;
            }
        }
        return true;
    }

    @Override
    public ItemStack m_8020_(int slot) {
        return inventory.m_8020_(start + slot);
    }

    @Override
    public ItemStack m_7407_(int slot, int amount) {
        return inventory.m_7407_(start + slot, amount);
    }

    @Override
    public ItemStack m_8016_(int slot) {
        return inventory.m_8016_(start + slot);
    }

    @Override
    public void m_6836_(int slot, ItemStack stack) {
        inventory.m_6836_(start + slot, stack);
    }

    @Override
    public void m_6596_() {
        inventory.m_6596_();
    }

    @Override
    public boolean m_6542_(Player player) {
        return inventory.m_6542_(player);
    }

    @Override
    public void m_6211_() {
        for (int i = start; i < end; i++) {
            inventory.m_6836_(i, ItemStackUtil.empty());
        }
    }

    @Override
    public int m_6893_() {
        return inventory.m_6893_();
    }
}
