package net.pitan76.mcpitanlib.api.util.inventory;

import net.minecraft.world.Container;
import net.minecraft.world.item.ItemStack;
import net.pitan76.mcpitanlib.api.entity.Player;

public interface ICompatInventory extends Container {
    default void callSetStack(int slot, ItemStack stack) {
        m_6836_(slot, stack);
    }

    default ItemStack callGetStack(int slot) {
        return m_8020_(slot);
    }

    default int callSize() {
        return m_6643_();
    }

    default boolean callIsEmpty() {
        return m_7983_();
    }

    default ItemStack callRemoveStack(int slot, int amount) {
        return m_7407_(slot, amount);
    }

    default ItemStack callRemoveStack(int slot) {
        return m_8016_(slot);
    }

    default void callClear() {
        m_6211_();
    }

    default void callMarkDirty() {
        m_6596_();
    }

    default boolean callCanPlayerUse(net.minecraft.world.entity.player.Player player) {
        return m_6542_(player);
    }

    default boolean canPlayerUse(Player player) {
        return m_6542_(player.getEntity());
    }


    default void callSetStack(int slot, net.pitan76.mcpitanlib.midohra.item.ItemStack stack) {
        m_6836_(slot, stack.toMinecraft());
    }

    default net.pitan76.mcpitanlib.midohra.item.ItemStack callGetStackAsMidohra(int slot) {
        return net.pitan76.mcpitanlib.midohra.item.ItemStack.of(m_8020_(slot));
    }

    default int callGetMaxCountPerStack() {
        return m_6893_();
    }
}
