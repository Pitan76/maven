package net.pitan76.mcpitanlib.api.util;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Rotation;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.Property;
import net.minecraft.world.level.material.Fluid;
import net.minecraft.world.level.material.FluidState;
import net.minecraft.world.phys.BlockHitResult;
import net.pitan76.mcpitanlib.api.entity.Player;
import net.pitan76.mcpitanlib.api.sound.CompatBlockSoundGroup;
import net.pitan76.mcpitanlib.api.util.block.BlockHitResultUtil;
import net.pitan76.mcpitanlib.midohra.block.BlockWrapper;

public class BlockStateUtil {
    public static Block getBlock(BlockState state) {
        return state.m_60734_();
    }

    public static boolean isAir(BlockState state) {
        return state.m_60795_();
    }

    public static boolean isOpaque(BlockState state) {
        return state.m_60815_();
    }

    public static SoundType getSoundGroup(BlockState state) {
        return state.m_60827_();
    }

    public static CompatBlockSoundGroup getCompatSoundGroup(BlockState state) {
        return CompatBlockSoundGroup.of(getSoundGroup(state));
    }

    public static BlockState getDefaultState(Block block) {
        return block.m_49966_();
    }

    public static StateDefinition<Block, BlockState> getStateManager(Block block) {
        return block.m_49965_();
    }

    public static <T extends Comparable<T>, V extends T> BlockState with(BlockState state, Property<T> property, V value) {
        return state.m_61124_(property, value);
    }

    public static void neighborUpdate(BlockState state, Level world, BlockPos pos, Block block, BlockPos fromPos, boolean notify) {
        state.m_60690_(world, pos, block, fromPos, notify);
    }

    public static void updateNeighbors(BlockState state, LevelAccessor world, BlockPos pos, int flags) {
        state.m_60701_(world, pos, flags);
    }

    public static boolean hasRandomTicks(BlockState state) {
        return state.m_60823_();
    }

    public static void randomTick(BlockState state, ServerLevel world, BlockPos pos) {
        state.m_222972_(world, pos, world.f_46441_);
    }

    public static CompatActionResult onUse(BlockState state, Level world, Player player, BlockHitResult hitResult) {
        InteractionHand hand = player.getMainHandStack().m_41619_() ? InteractionHand.OFF_HAND : InteractionHand.MAIN_HAND;
        return CompatActionResult.create(state.m_60664_(world, player.getEntity(), hand, hitResult));
    }

    public static CompatActionResult onUse(BlockState state, Level world, Player player, Direction dir, BlockPos blockPos) {
        return onUse(state, world, player, BlockHitResultUtil.create(player.getPos(), dir, blockPos));
    }

    public static CompatActionResult onUseWithItem(BlockState state, ItemStack stack, Level world, net.minecraft.world.entity.player.Player player, InteractionHand hand, BlockHitResult hit) {
        return CompatActionResult.create(state.m_60664_(world, player, hand, hit));
    }

    public static CompatActionResult onUseWithItem_actionResult(BlockState state, ItemStack stack, Level world, net.minecraft.world.entity.player.Player player, InteractionHand hand, BlockHitResult hit) {
        return onUseWithItem(state, stack, world, player, hand, hit);
    }

    public static FluidState getFluidState(BlockState state) {
        return state.m_60819_();
    }

    public static Fluid getFluid(BlockState state) {
        return getFluidState(state).m_76152_();
    }

    public static BlockState rotate(BlockState state, Rotation rotation) {
        return state.m_60717_(rotation);
    }

    public static net.pitan76.mcpitanlib.midohra.block.BlockState getMidohraDefaultState(Block block) {
        return net.pitan76.mcpitanlib.midohra.block.BlockState.of(getDefaultState(block));
    }

    public static net.pitan76.mcpitanlib.midohra.block.BlockState getDefaultState(BlockWrapper block) {
        return block.getDefaultState();
    }

    public static float getHardness(BlockState state, BlockGetter world, BlockPos pos) {
        return state.m_60800_(world, pos);
    }

    public static float getHardness(BlockState state, Level world, BlockPos pos) {
        return state.m_60800_(world, pos);
    }

    public static int getLuminance(BlockState state) {
        return state.m_60791_();
    }

    public static int getOpacity(BlockState state) {
        return state.m_60739_(null, null);
    }

    public static int getComparatorOutput(BlockState state, Level world, BlockPos pos) {
        return state.m_60674_(world, pos);
    }

    public static float getHardness(net.pitan76.mcpitanlib.midohra.block.BlockState state, net.pitan76.mcpitanlib.midohra.world.BlockView world, net.pitan76.mcpitanlib.midohra.util.math.BlockPos pos) {
        return getHardness(state.toMinecraft(), world.getRaw(), pos.toMinecraft());
    }

    public static int getLuminance(net.pitan76.mcpitanlib.midohra.block.BlockState state) {
        return getLuminance(state.toMinecraft());
    }

    public static int getOpacity(net.pitan76.mcpitanlib.midohra.block.BlockState state) {
        return getOpacity(state.toMinecraft());
    }

    public static int getComparatorOutput(net.pitan76.mcpitanlib.midohra.block.BlockState state, net.pitan76.mcpitanlib.midohra.world.World world, net.pitan76.mcpitanlib.midohra.util.math.BlockPos pos) {
        return getComparatorOutput(state.toMinecraft(), world.getRaw(), pos.toMinecraft());
    }

    public static boolean canPlaceAt(BlockState state, BlockPos pos, Level world) {
        return state.m_60710_(world, pos);
    }

    public static boolean canPlaceAt(net.pitan76.mcpitanlib.midohra.block.BlockState state, net.pitan76.mcpitanlib.midohra.util.math.BlockPos pos, net.pitan76.mcpitanlib.midohra.world.World world) {
        return canPlaceAt(state.toMinecraft(), pos.toMinecraft(), world.getRaw());
    }

    public static boolean hasRandomTicks(net.pitan76.mcpitanlib.midohra.block.BlockState state) {
        return hasRandomTicks(state.toMinecraft());
    }

    public static void randomTick(net.pitan76.mcpitanlib.midohra.block.BlockState state, ServerLevel world, net.pitan76.mcpitanlib.midohra.util.math.BlockPos pos) {
        randomTick(state.toMinecraft(), world, pos.toMinecraft());
    }

    public static void randomTick(net.pitan76.mcpitanlib.midohra.block.BlockState state, net.pitan76.mcpitanlib.midohra.world.ServerWorld world, net.pitan76.mcpitanlib.midohra.util.math.BlockPos pos) {
        randomTick(state.toMinecraft(), world.getRaw(), pos.toMinecraft());
    }
}
