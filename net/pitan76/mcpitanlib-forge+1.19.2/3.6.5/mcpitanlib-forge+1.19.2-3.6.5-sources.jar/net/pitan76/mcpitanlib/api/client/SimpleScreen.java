package net.pitan76.mcpitanlib.api.client;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.components.Widget;
import net.minecraft.client.gui.components.events.GuiEventListener;
import net.minecraft.client.gui.narration.NarratableEntry;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.renderer.GameRenderer;
import net.minecraft.client.renderer.entity.ItemRenderer;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.pitan76.mcpitanlib.api.client.gui.widget.CompatibleTexturedButtonWidget;
import net.pitan76.mcpitanlib.api.client.render.DrawObjectDM;
import net.pitan76.mcpitanlib.api.client.render.handledscreen.*;
import net.pitan76.mcpitanlib.api.util.client.ScreenUtil;
import net.pitan76.mcpitanlib.api.client.render.handledscreen.KeyEventArgs;
import net.pitan76.mcpitanlib.api.client.render.handledscreen.RenderArgs;
import net.pitan76.mcpitanlib.api.client.render.screen.RenderBackgroundTextureArgs;
import net.pitan76.mcpitanlib.api.util.CompatIdentifier;
import net.pitan76.mcpitanlib.api.util.IdentifierUtil;
import net.pitan76.mcpitanlib.api.util.client.RenderUtil;

public abstract class SimpleScreen extends Screen {

    public int f_96543_, f_96544_;
    public Font f_96547_;
    public ItemRenderer f_96542_;

    public Component f_96539_;
    public Minecraft f_96541_;

    public SimpleScreen(Component title) {
        super(title);
        fixScreen();
        this.f_96539_ = title;
    }

    public <T extends GuiEventListener & Widget & NarratableEntry> T addDrawableChild_compatibility(T drawableElement) {
        return super.m_142416_(drawableElement);
        // addButton
    }

    public <T extends GuiEventListener & NarratableEntry> T addSelectableChild_compatibility(T selectableElement) {
        return super.m_7787_(selectableElement);
    }

    public CompatibleTexturedButtonWidget addDrawableCTBW(CompatibleTexturedButtonWidget widget) {
        return addDrawableChild_compatibility(widget);
    }

    public void callDrawTexture(DrawObjectDM drawObjectDM, ResourceLocation texture, int x, int y, int u, int v, int width, int height) {
        ScreenUtil.setBackground(texture);
        m_93228_(drawObjectDM.getStack(), x, y, u, v, width, height);
    }

    public void callDrawTexture(DrawObjectDM drawObjectDM, CompatIdentifier texture, int x, int y, int u, int v, int width, int height) {
        callDrawTexture(drawObjectDM, texture.toMinecraft(), x, y, u, v, width, height);
    }

    @Deprecated
    @Override
    public void m_7333_(PoseStack matrices) {
        renderBackground(new RenderArgs(new DrawObjectDM(matrices, this), 0, 0, 0));
    }

    public void renderBackground(RenderArgs args) {
        super.m_7333_(args.drawObjectDM.getStack());
    }

    public void render(RenderArgs args) {
        super.m_6305_(args.drawObjectDM.getStack(), args.mouseX, args.mouseY, args.delta);
    }

    public void resizeOverride(Minecraft client, int width, int height) {
    }

    public void initOverride() {
    }

    @Deprecated
    @Override
    protected void m_7856_() {
        super.m_7856_();
        fixScreen();
        initOverride();
    }

    @Deprecated
    @Override
    public void m_6574_(Minecraft client, int width, int height) {
        super.m_6574_(client, width, height);
        fixScreen();
        resizeOverride(client, width, height);
    }

    public void fixScreen() {
        this.f_96547_ = super.f_96547_;
        this.f_96542_ = Minecraft.m_91087_().m_91291_();
        this.f_96543_ = super.f_96543_;
        this.f_96544_ = super.f_96544_;
        if (super.f_96541_ == null)
            this.f_96541_ = Minecraft.m_91087_();
        else
            this.f_96541_ = super.f_96541_;
    }

    public void setTextRenderer(Font textRenderer) {
        this.f_96547_ = textRenderer;
        super.f_96547_ = textRenderer;
    }

    public void setItemRenderer(ItemRenderer itemRenderer) {
        this.f_96542_ = itemRenderer;
    }

    public void setWidth(int width) {
        this.f_96543_ = width;
        super.f_96543_ = width;
    }

    public void setHeight(int height) {
        this.f_96544_ = height;
        super.f_96544_ = height;
    }

    @Deprecated
    @Override
    public void m_6305_(PoseStack stack, int mouseX, int mouseY, float delta) {
        DrawObjectDM drawObjectDM = new DrawObjectDM(stack, this);
        render(new RenderArgs(drawObjectDM, mouseX, mouseY, delta));
    }

    public boolean keyReleased(KeyEventArgs args) {
        return super.m_7920_(args.keyCode, args.scanCode, args.modifiers);
    }

    public boolean keyPressed(KeyEventArgs args) {
        return super.m_7933_(args.keyCode, args.scanCode, args.modifiers);
    }

    public void renderBackgroundTexture(RenderBackgroundTextureArgs args) {
        if (getBackgroundTexture() == null) {
            super.m_96626_(args.getvOffset());
            return;
        }

        RenderSystem.m_157427_(GameRenderer::m_172820_);
        RenderSystem.m_157456_(0, getBackgroundTexture());
        RenderSystem.m_157429_(1.0F, 1.0F, 1.0F, 1.0F);

        callDrawTexture(args.drawObjectDM, getBackgroundTexture(), 0, 0, 0, 0, this.f_96543_, this.f_96544_);
    }

    @Deprecated
    @Override
    public boolean m_7920_(int keyCode, int scanCode, int modifiers) {
        return this.keyReleased(new KeyEventArgs(keyCode, scanCode, modifiers));
    }

    @Deprecated
    @Override
    public boolean m_7933_(int keyCode, int scanCode, int modifiers) {
        return this.keyPressed(new KeyEventArgs(keyCode, scanCode, modifiers));
    }

    @Deprecated
    @Override
    public void m_96626_(int vOffset) {
        this.renderBackgroundTexture(new RenderBackgroundTextureArgs(new DrawObjectDM(null, this), vOffset));
    }

    public void closeOverride() {
        super.m_7379_();
    }

    public void removedOverride() {
        super.m_7861_();
    }

    @Override
    public void m_7379_() {
        closeOverride();
    }

    @Override
    public void m_7861_() {
        removedOverride();
    }

    public ResourceLocation getBackgroundTexture() {
        return IdentifierUtil.from(getCompatBackgroundTexture());
    }

    public CompatIdentifier getCompatBackgroundTexture() {
        return null;
    }
}
