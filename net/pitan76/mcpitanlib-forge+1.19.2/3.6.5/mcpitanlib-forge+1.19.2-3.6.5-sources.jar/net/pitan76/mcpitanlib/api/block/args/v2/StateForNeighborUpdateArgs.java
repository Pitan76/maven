package net.pitan76.mcpitanlib.api.block.args.v2;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.LevelReader;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.pitan76.mcpitanlib.api.util.math.random.CompatRandom;
import net.pitan76.mcpitanlib.midohra.block.entity.BlockEntityWrapper;
import net.pitan76.mcpitanlib.midohra.holder.BlockStatePropertyHolder;
import net.pitan76.mcpitanlib.midohra.world.IWorldView;

public class StateForNeighborUpdateArgs implements BlockStatePropertyHolder {
    public BlockState state;
    public Direction direction;
    public BlockState neighborState;
    public LevelAccessor world;
    public BlockPos pos;
    public BlockPos neighborPos;
    public CompatRandom random;

    public StateForNeighborUpdateArgs(BlockState state, Direction direction, BlockState neighborState, LevelAccessor world, BlockPos pos, BlockPos neighborPos) {
        this.state = state;
        this.direction = direction;
        this.neighborState = neighborState;
        this.world = world;
        this.pos = pos;
        this.neighborPos = neighborPos;
        this.random = new CompatRandom(world.m_213780_());
    }

    public Direction getDirection() {
        return direction;
    }

    public BlockState getRawNeighborState() {
        return neighborState;
    }

    public LevelReader getRawWorld() {
        return world;
    }

    public BlockPos getRawPos() {
        return pos;
    }

    public BlockPos getRawNeighborPos() {
        return neighborPos;
    }

    public net.pitan76.mcpitanlib.midohra.block.BlockState getNeighborState() {
        return net.pitan76.mcpitanlib.midohra.block.BlockState.of(getRawNeighborState());
    }

    public net.pitan76.mcpitanlib.midohra.world.WorldView getWorld() {
        return net.pitan76.mcpitanlib.midohra.world.WorldView.of(getRawWorld());
    }

    public IWorldView getWorldView() {
        return getWorld();
    }

    public net.pitan76.mcpitanlib.midohra.util.math.BlockPos getPos() {
        return net.pitan76.mcpitanlib.midohra.util.math.BlockPos.of(getRawPos());
    }

    public net.pitan76.mcpitanlib.midohra.util.math.BlockPos getNeighborPos() {
        return net.pitan76.mcpitanlib.midohra.util.math.BlockPos.of(getRawNeighborPos());
    }

    public CompatRandom getRandom() {
        return random;
    }

    public net.pitan76.mcpitanlib.midohra.world.tick.ScheduledTickView getTickView() {
        return net.pitan76.mcpitanlib.midohra.world.tick.ScheduledTickView.of(world);
    }

    @Override
    public net.pitan76.mcpitanlib.midohra.block.BlockState getBlockState() {
        return net.pitan76.mcpitanlib.midohra.block.BlockState.of(state);
    }

    public BlockEntityWrapper getBlockEntity() {
        return getWorld().getBlockEntity(getPos());
    }

    public BlockEntity getRawBlockEntity() {
        return world.m_7702_(pos);
    }

    public boolean isClient() {
        return world.m_5776_();
    }
}
