package net.pitan76.mcpitanlib.api.recipe.v2;

import net.minecraft.recipe.*;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.Container;
import net.minecraft.world.item.crafting.Recipe;
import net.minecraft.world.item.crafting.RecipeSerializer;
import net.minecraft.world.item.crafting.RecipeType;
import net.pitan76.mcpitanlib.api.util.CompatIdentifier;
import net.pitan76.mcpitanlib.api.util.RecipeUtil;
import org.jetbrains.annotations.Nullable;

@Deprecated
public class CompatRecipeEntry<T extends Container> {
    private final Recipe<T> recipe;

    private ResourceLocation id;

    public String group = "";
    public RecipeUtil.CompatibilityCraftingRecipeCategory category = null;

    @Deprecated
    public CompatRecipeEntry(Recipe<T> recipe) {
        this.recipe = recipe;
    }

    public CompatRecipeEntry(ResourceLocation id, String group, RecipeUtil.CompatibilityCraftingRecipeCategory category, Recipe<T> recipe) {
        this.recipe = recipe;
        this.id = id;
        this.group = group;
        this.category = category;
    }

    public CompatRecipeEntry(CompatIdentifier id, String group, RecipeUtil.CompatibilityCraftingRecipeCategory category, Recipe<T> recipe) {
        this(id.toMinecraft(), group, category, recipe);
    }

    public boolean isNull() {
        return recipe == null;
    }

    public Recipe<T> getRecipe() {
        return recipe;
    }

    public ResourceLocation getId() {
        return id;
    }

    public CompatIdentifier getCompatId() {
        return CompatIdentifier.fromMinecraft(getId());
    }

    public RecipeType<?> getType() {
        Recipe<T> recipe = getRecipe();
        if (recipe == null) return null;

        return recipe.m_6671_();
    }

    public RecipeSerializer<?> getSerializer() {
        Recipe<?> recipe = getRecipe();
        if (recipe == null) return null;

        return recipe.m_7707_();
    }

    @Nullable
    public RecipeUtil.CompatibilityCraftingRecipeCategory getCategory() {
        return category;
    }

    public String getGroup() {
        return group;
    }
}
