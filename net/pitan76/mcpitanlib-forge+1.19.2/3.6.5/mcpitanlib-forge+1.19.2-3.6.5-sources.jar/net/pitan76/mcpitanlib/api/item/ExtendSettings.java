package net.pitan76.mcpitanlib.api.item;

import java.util.function.Supplier;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.Item;

/**
 * Use {@link CompatibleItemSettings} instead.
 */
public class ExtendSettings extends Item.Properties {

    // ～1.19.2
    public ExtendSettings addGroup(CreativeModeTab itemGroup) {
        super.m_41491_(itemGroup);
        return this;
    }

    // 1.19.3～
    // identifier: Item ID
    public ExtendSettings addGroup(CreativeModeTab itemGroup, ResourceLocation identifier) {
        //CreativeTabRegistry.append(itemGroup, ItemUtil.fromId(identifier));
        return addGroup(itemGroup);
    }

    public ExtendSettings addGroup(Supplier<CreativeModeTab> itemGroup, ResourceLocation identifier) {
        addGroup(itemGroup.get());
        return this;
    }
}
