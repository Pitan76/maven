package net.pitan76.mcpitanlib.api.state.property;

import net.minecraft.block.enums.*;
import net.minecraft.core.Direction;
import net.minecraft.util.StringRepresentable;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.properties.ChestType;
import net.minecraft.world.level.block.state.properties.ComparatorMode;
import net.minecraft.world.level.block.state.properties.Half;
import net.minecraft.world.level.block.state.properties.PistonType;
import net.minecraft.world.level.block.state.properties.Property;
import net.minecraft.world.level.block.state.properties.SlabType;
import net.minecraft.world.level.block.state.properties.StairsShape;

public class CompatProperties {
    public static final DirectionProperty FACING = new DirectionProperty(BlockStateProperties.f_61372_);
    public static final DirectionProperty HORIZONTAL_FACING = new DirectionProperty(BlockStateProperties.f_61374_);
    public static final DirectionProperty HOPPER_FACING = new DirectionProperty(BlockStateProperties.f_61373_);
    public static final DirectionProperty VERTICAL_DIRECTION = new DirectionProperty(BlockStateProperties.f_155997_);

    public static final BooleanProperty POWERED = new BooleanProperty(BlockStateProperties.f_61448_);
    public static final BooleanProperty ENABLED = new BooleanProperty(BlockStateProperties.f_61431_);
    public static final BooleanProperty WATERLOGGED = new BooleanProperty(BlockStateProperties.f_61362_);
    public static final BooleanProperty LIT = new BooleanProperty(BlockStateProperties.f_61443_);
    public static final BooleanProperty OCCUPIED = new BooleanProperty(BlockStateProperties.f_61445_);
    public static final BooleanProperty ATTACHED = new BooleanProperty(BlockStateProperties.f_61386_);
    public static final BooleanProperty HANGING = new BooleanProperty(BlockStateProperties.f_61435_);
    public static final BooleanProperty BOTTOM = new BooleanProperty(BlockStateProperties.f_61427_);
    public static final BooleanProperty OPEN = new BooleanProperty(BlockStateProperties.f_61446_);
    public static final BooleanProperty UNSTABLE = new BooleanProperty(BlockStateProperties.f_61361_);
    public static final BooleanProperty UP = new BooleanProperty(BlockStateProperties.f_61366_);
    public static final BooleanProperty DOWN = new BooleanProperty(BlockStateProperties.f_61367_);
    public static final BooleanProperty NORTH = new BooleanProperty(BlockStateProperties.f_61368_);
    public static final BooleanProperty EAST = new BooleanProperty(BlockStateProperties.f_61369_);
    public static final BooleanProperty SOUTH = new BooleanProperty(BlockStateProperties.f_61370_);
    public static final BooleanProperty WEST = new BooleanProperty(BlockStateProperties.f_61371_);

    public static final IntProperty POWER = new IntProperty(BlockStateProperties.f_61426_);
    public static final IntProperty LAYERS = new IntProperty(BlockStateProperties.f_61417_);
    public static final IntProperty NOTE = new IntProperty(BlockStateProperties.f_61424_);
    public static final IntProperty ROTATION = new IntProperty(BlockStateProperties.f_61390_);
    public static final IntProperty EGGS = new IntProperty(BlockStateProperties.f_61415_);
    public static final IntProperty DELAY = new IntProperty(BlockStateProperties.f_61413_);

    public static final EnumProperty<Half> BLOCK_HALF = new EnumProperty<>(BlockStateProperties.f_61402_);
    public static final EnumProperty<StairsShape> STAIR_SHAPE = new EnumProperty<>(BlockStateProperties.f_61398_);
    public static final EnumProperty<SlabType> SLAB_TYPE = new EnumProperty<>(BlockStateProperties.f_61397_);
    public static final EnumProperty<ChestType> CHEST_TYPE = new EnumProperty<>(BlockStateProperties.f_61392_);
    public static final EnumProperty<PistonType> PISTON_TYPE = new EnumProperty<>(BlockStateProperties.f_61396_);
    public static final EnumProperty<Direction.Axis> AXIS = new EnumProperty<>(BlockStateProperties.f_61365_);
    public static final EnumProperty<Direction.Axis> HORIZONTAL_AXIS = new EnumProperty<>(BlockStateProperties.f_61364_);
    public static final EnumProperty<ComparatorMode> COMPARATOR_MODE = new EnumProperty<>(BlockStateProperties.f_61393_);

    public static IProperty<?> of(Property<?> property) {
        if (property instanceof net.minecraft.world.level.block.state.properties.IntegerProperty) {
            return of((net.minecraft.world.level.block.state.properties.IntegerProperty) property);
        }
        if (property instanceof net.minecraft.world.level.block.state.properties.BooleanProperty) {
            return of((net.minecraft.world.level.block.state.properties.BooleanProperty) property);
        }
        if (property instanceof net.minecraft.world.level.block.state.properties.EnumProperty) {
            return of((net.minecraft.world.level.block.state.properties.EnumProperty<?>) property);
        }
        if (property instanceof net.minecraft.world.level.block.state.properties.DirectionProperty) {
            return ofDir((net.minecraft.world.level.block.state.properties.DirectionProperty) property);
        }
        return UnknownProperty.of(property);
    }

    public static IntProperty of(net.minecraft.world.level.block.state.properties.IntegerProperty property) {
        if (property == BlockStateProperties.f_61426_) return POWER;
        if (property == BlockStateProperties.f_61417_) return LAYERS;
        if (property == BlockStateProperties.f_61424_) return NOTE;
        if (property == BlockStateProperties.f_61390_) return ROTATION;
        if (property == BlockStateProperties.f_61415_) return EGGS;
        if (property == BlockStateProperties.f_61413_) return DELAY;

        return new IntProperty(property);
    }

    public static BooleanProperty of(net.minecraft.world.level.block.state.properties.BooleanProperty property) {
        if (property == BlockStateProperties.f_61448_) return POWERED;
        if (property == BlockStateProperties.f_61431_) return ENABLED;
        if (property == BlockStateProperties.f_61362_) return WATERLOGGED;
        if (property == BlockStateProperties.f_61443_) return LIT;
        if (property == BlockStateProperties.f_61445_) return OCCUPIED;
        if (property == BlockStateProperties.f_61386_) return ATTACHED;
        if (property == BlockStateProperties.f_61435_) return HANGING;
        if (property == BlockStateProperties.f_61427_) return BOTTOM;
        if (property == BlockStateProperties.f_61446_) return OPEN;
        if (property == BlockStateProperties.f_61361_) return UNSTABLE;
        if (property == BlockStateProperties.f_61366_) return UP;
        if (property == BlockStateProperties.f_61367_) return DOWN;
        if (property == BlockStateProperties.f_61368_) return NORTH;
        if (property == BlockStateProperties.f_61369_) return EAST;
        if (property == BlockStateProperties.f_61370_) return SOUTH;
        if (property == BlockStateProperties.f_61371_) return WEST;

        return new BooleanProperty(property);
    }

    public static <T extends Enum<T> & StringRepresentable> EnumProperty<T> of(net.minecraft.world.level.block.state.properties.EnumProperty<T> property) {
        if (property.equals(BlockStateProperties.f_61402_)) return (EnumProperty) BLOCK_HALF;
        if (property.equals(BlockStateProperties.f_61398_)) return (EnumProperty) STAIR_SHAPE;
        if (property.equals(BlockStateProperties.f_61397_)) return (EnumProperty) SLAB_TYPE;
        if (property.equals(BlockStateProperties.f_61392_)) return (EnumProperty) CHEST_TYPE;
        if (property.equals(BlockStateProperties.f_61396_)) return (EnumProperty) PISTON_TYPE;
        if (property.equals(BlockStateProperties.f_61365_)) return (EnumProperty) AXIS;
        if (property.equals(BlockStateProperties.f_61364_)) return (EnumProperty) HORIZONTAL_AXIS;
        if (property.equals(BlockStateProperties.f_61393_)) return (EnumProperty) COMPARATOR_MODE;

        return new EnumProperty<>(property);
    }

    public static DirectionProperty ofDir(net.minecraft.world.level.block.state.properties.DirectionProperty property) {
        if (property == BlockStateProperties.f_61372_) return FACING;
        if (property == BlockStateProperties.f_61374_) return HORIZONTAL_FACING;
        if (property == BlockStateProperties.f_61373_) return HOPPER_FACING;
        if (property == BlockStateProperties.f_155997_) return VERTICAL_DIRECTION;

        return new DirectionProperty(property);
    }
}
