package net.pitan76.mcpitanlib.api.util;

import it.unimi.dsi.fastutil.ints.IntList;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import net.minecraft.core.NonNullList;
import net.minecraft.core.Registry;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.tags.TagKey;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.crafting.Ingredient;
import net.minecraft.world.level.ItemLike;

public class IngredientUtil {
    public static Ingredient fromTagByIdentifier(ResourceLocation id) {
        return Ingredient.m_204132_(TagKey.m_203882_(Registry.f_122904_, id));
    }

    public static Ingredient fromTagByString(String id) {
        return fromTagByIdentifier(new ResourceLocation(id));
    }

    public static Ingredient fromTagByIdentifier(CompatIdentifier id) {
        return fromTagByIdentifier(id.toMinecraft());
    }

    public static List<Item> getItems(Ingredient ingredient) {
        List<Item> items = new ArrayList<>();
        for (int rawId : ingredient.m_43931_()) {
            try {
                items.add(ItemUtil.fromIndex(rawId));
            } catch (Exception ignored) {}
        }
        return items;
    }

    public static IntList getMatchingStacksIds(Ingredient ingredient) {
        return ingredient.m_43931_();
    }

    public static List<ItemStack> getMatchingStacksAsList(Ingredient ingredient) {
        return new ArrayList<>(Arrays.asList(getMatchingStacks(ingredient)));
    }

    public static ItemStack[] getMatchingStacks(Ingredient ingredient) {
        return ingredient.m_43908_();
    }

    public static Ingredient empty() {
        return Ingredient.f_43901_;
    }

    public static Ingredient ofItems(ItemLike... items) {
        return Ingredient.m_43929_(items);
    }

    public static NonNullList<Ingredient> buildInput(Object[] input) {
        NonNullList<Ingredient> list = NonNullList.m_122779_();
        for (Object obj : input) {
            if (obj instanceof Ingredient) {
                list.add((Ingredient) obj);
                continue;
            }

            if (obj instanceof ItemLike) {
                list.add(ofItems((ItemLike) obj));
            }
        }
        return list;
    }
}
