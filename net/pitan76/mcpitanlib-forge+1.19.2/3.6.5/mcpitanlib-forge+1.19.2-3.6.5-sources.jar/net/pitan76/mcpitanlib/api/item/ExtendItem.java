package net.pitan76.mcpitanlib.api.item;

import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.util.*;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.UseAnim;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.pitan76.mcpitanlib.api.event.item.*;
import net.pitan76.mcpitanlib.api.util.CompatActionResult;
import net.pitan76.mcpitanlib.api.util.StackActionResult;
import net.pitan76.mcpitanlib.core.Dummy;
import net.pitan76.mcpitanlib.mixin.ItemUsageContextMixin;
import org.jetbrains.annotations.Nullable;

import java.util.List;

public class ExtendItem extends Item {

    public ExtendItem(Properties settings) {
        super(settings);
    }

    public ExtendItem(CompatibleItemSettings settings) {
        super(settings.build());
    }

    @Deprecated
    @Override
    public InteractionResultHolder<ItemStack> m_7203_(Level world, Player user, InteractionHand hand) {
        return onRightClick(new ItemUseEvent(world, user, hand)).toTypedActionResult();
    }

    @Deprecated
    @Override
    public InteractionResult m_6225_(UseOnContext context) {
        ItemUsageContextMixin contextAccessor = (ItemUsageContextMixin) context;
        return onRightClickOnBlock(new ItemUseOnBlockEvent(context.m_43723_(), context.m_43724_(), contextAccessor.getHit())).toActionResult();
    }

    @Deprecated
    @Override
    public ItemStack m_5922_(ItemStack stack, Level world, LivingEntity user) {
        return onFinishUsing(new ItemFinishUsingEvent(stack, world, user));
    }

    @Deprecated
    @Override
    public InteractionResult m_6880_(ItemStack stack, Player user, LivingEntity entity, InteractionHand hand) {
        return onRightClickOnEntity(new ItemUseOnEntityEvent(stack, user, entity, hand)).toActionResult();
    }

    @Override
    public UseAnim m_6164_(ItemStack stack) {
        return super.m_6164_(stack);
    }

    @Deprecated
    @Override
    public boolean m_41470_() {
        return hasRecipeRemainder(new Dummy());
    }

    @Deprecated
    @Override
    public void m_7373_(ItemStack stack, @Nullable Level world, List<Component> tooltip, TooltipFlag context) {
        appendTooltip(new ItemAppendTooltipEvent(stack, world, tooltip, context));
    }

    @Deprecated
    @Override
    public void m_7836_(ItemStack stack, Level world, Player player) {
        onCraft(new CraftEvent(stack, world, player));
    }

    @Deprecated
    @Override
    public boolean m_7579_(ItemStack stack, LivingEntity target, LivingEntity attacker) {
        return postHit(new PostHitEvent(stack, target, attacker));
    }

    @Deprecated
    @Override
    public boolean m_6813_(ItemStack stack, Level world, BlockState state, BlockPos pos, LivingEntity miner) {
        return postMine(new PostMineEvent(stack, world, state, pos, miner));
    }

    /**
     * item right click event
     *
     * @param event ItemUseEvent
     * @return ActionResultType
     */
    public StackActionResult onRightClick(ItemUseEvent event) {
        return StackActionResult.create(CompatActionResult.create(super.m_7203_(event.world, event.user.getPlayerEntity(), event.hand).m_19089_()), event.stack);
    }

    /**
     * item right click event on block
     * @param event ItemUseOnBlockEvent
     * @return ActionResultType
     */
    public CompatActionResult onRightClickOnBlock(ItemUseOnBlockEvent event) {
        return CompatActionResult.create(super.m_6225_(event.toIUC()));
    }

    /**
     * item finish using event
     * @param event ItemFinishUsingEvent
     * @return ItemStack
     */
    public ItemStack onFinishUsing(ItemFinishUsingEvent event) {
        return super.m_5922_(event.stack, event.world, event.user);
    }

    /**
     * item right click event on entity
     * @param event ItemUseOnEntityEvent
     * @return ActionResultType
     */
    public CompatActionResult onRightClickOnEntity(ItemUseOnEntityEvent event) {
        return CompatActionResult.create(super.m_6880_(event.stack, event.user.getEntity(), event.entity, event.hand));
    }

    /**
     * check if item has recipe remainder
     * @param dummy Dummy
     * @return boolean
     */
    public boolean hasRecipeRemainder(Dummy dummy) {
        return false;
    }

    /**
     * append tooltip to item
     * @param event ItemAppendTooltipEvent
     */
    public void appendTooltip(ItemAppendTooltipEvent event) {
        super.m_7373_(event.stack, event.world, event.tooltip, event.context);
    }

    /**
     * on craft event
     * @param event CraftEvent
     */
    public void onCraft(CraftEvent event) {
        super.m_7836_(event.stack, event.world, null);
    }

    /**
     * post hit event
     * @param event PostHitEvent
     * @return boolean
     */
    public boolean postHit(PostHitEvent event) {
        return super.m_7579_(event.stack, event.target, event.attacker);
    }

    /**
     * post mine event
     * @param event PostMineEvent
     * @return boolean
     */
    public boolean postMine(PostMineEvent event) {
        return super.m_6813_(event.stack, event.world, event.state, event.pos, event.miner);
    }

    // -1.20.6
    public Rarity m_41460_(ItemStack stack) {
        return Rarity.COMMON;
    }

    @Deprecated
    @Override
    public boolean m_8120_(ItemStack stack) {
        return isEnchantable(new EnchantableArgs(stack));
    }

    public boolean isEnchantable(EnchantableArgs args) {
        return super.m_8120_(args.stack);
    }

    @Deprecated
    @Override
    public int m_6473_() {
        return getEnchantability(new EnchantabilityArgs());
    }

    public int getEnchantability(EnchantabilityArgs args) {
        return super.m_6473_();
    }

    @Deprecated
    @Override
    public int m_142159_(ItemStack stack) {
        return getItemBarColor(new ItemBarColorArgs(stack));
    }

    public int getItemBarColor(ItemBarColorArgs args) {
        return super.m_142159_(args.stack);
    }

    @Deprecated
    @Override
    public boolean m_142522_(ItemStack stack) {
        return isItemBarVisible(new ItemBarVisibleArgs(stack));
    }

    public boolean isItemBarVisible(ItemBarVisibleArgs args) {
        return super.m_142522_(args.stack);
    }

    @Deprecated
    @Override
    public int m_142158_(ItemStack stack) {
        return getItemBarStep(new ItemBarStepArgs(stack));
    }

    public int getItemBarStep(ItemBarStepArgs args) {
        return super.m_142158_(args.stack);
    }

    public float getBonusAttackDamage(BonusAttackDamageArgs args) {
        return 0;
    }

    @Deprecated
    @Override
    public boolean m_6832_(ItemStack stack, ItemStack ingredient) {
        return canRepair(new CanRepairArgs(stack, ingredient));
    }

    public boolean canRepair(CanRepairArgs args) {
        return false;
    }

    @Deprecated
    @Override
    public boolean m_6777_(BlockState state, Level world, BlockPos pos, Player miner) {
        return canMine(new CanMineArgs(state, world, pos, miner));
    }

    public boolean canMine(CanMineArgs args) {
        return super.m_6777_(args.state, args.world, args.pos, args.miner.getEntity());
    }
}
