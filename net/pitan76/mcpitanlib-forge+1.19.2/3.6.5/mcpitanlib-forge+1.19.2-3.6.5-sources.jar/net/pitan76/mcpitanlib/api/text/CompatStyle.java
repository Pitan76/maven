package net.pitan76.mcpitanlib.api.text;

import net.minecraft.network.chat.Style;

public class CompatStyle {
    private final Style style;

    public CompatStyle(Style style) {
        this.style = style;
    }

    public CompatStyle() {
        this(Style.f_131099_);
    }

    public static CompatStyle of(Style style) {
        return new CompatStyle(style);
    }

    public static CompatStyle of() {
        return new CompatStyle();
    }

    public CompatStyle withColor(CompatTextColor color) {
        return new CompatStyle(style.m_131148_(color.getRaw()));
    }

    public CompatStyle withColor(CompatFormatting formatting) {
        return new CompatStyle(style.m_131140_(formatting.getRaw()));
    }

    public CompatStyle withColor(int rgbColor) {
        return new CompatStyle(style.m_178520_(rgbColor));
    }

    public CompatStyle withBold(boolean bold) {
        return new CompatStyle(style.m_131136_(bold));
    }

    public CompatStyle withItalic(boolean italic) {
        return new CompatStyle(style.m_131155_(italic));
    }

    public CompatStyle withUnderline(boolean underline) {
        return new CompatStyle(style.m_131162_(underline));
    }

    public CompatStyle withStrikethrough(boolean strikethrough) {
        return new CompatStyle(style.m_178522_(strikethrough));
    }

    public CompatStyle withObfuscated(boolean obfuscated) {
        return new CompatStyle(style.m_178524_(obfuscated));
    }

    public CompatTextColor getColor() {
        if (style.m_131135_() == null) return null;
        return new CompatTextColor(style.m_131135_());
    }

    public boolean isBold() {
        return style.m_131154_();
    }

    public boolean isItalic() {
        return style.m_131161_();
    }

    public boolean isUnderlined() {
        return style.m_131171_();
    }

    public boolean isStrikethrough() {
        return style.m_131168_();
    }

    public boolean isObfuscated() {
        return style.m_131176_();
    }

    public boolean isEmpty() {
        return style.m_131179_();
    }

    public CompatStyle withFormatting(CompatFormatting formatting) {
        return withColor(formatting);
    }

    public Style getRaw() {
        return style;
    }

    @Override
    public int hashCode() {
        return style.hashCode();
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        CompatStyle that = (CompatStyle) obj;
        return style.equals(that.style);
    }
}
