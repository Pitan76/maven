package net.pitan76.mcpitanlib.api.item;

import net.minecraft.world.item.Item;
import net.minecraft.world.item.Items;

public class CompatItems {
    public static Item SHORT_GRASS = Items.f_41864_;
    public static Item TALL_GRASS = Items.f_42210_;
    public static Item TURTLE_SCUTE = Items.f_42355_;

    // Compatibility
    public static Item GRASS = SHORT_GRASS;
    public static Item SCUTE = TURTLE_SCUTE;

    // ----

    public static Item AIR = Items.f_41852_;
    public static Item STONE = Items.f_41905_;
    public static Item COBBLESTONE = Items.f_42594_;
    public static Item GRASS_BLOCK = Items.f_42276_;
    public static Item DIRT = Items.f_42329_;
    public static Item SAND = Items.f_41830_;
    public static Item RED_SAND = Items.f_41831_;
    public static Item GRANITE = Items.f_41958_;
    public static Item POLISHED_GRANITE = Items.f_42011_;
    public static Item DIORITE = Items.f_42064_;
    public static Item POLISHED_DIORITE = Items.f_42117_;
    public static Item ANDESITE = Items.f_42170_;
    public static Item POLISHED_ANDESITE = Items.f_42223_;
    public static Item COARSE_DIRT = Items.f_42382_;
    public static Item PODZOL = Items.f_42435_;
    public static Item OAK_LOG = Items.f_41837_;
    public static Item SPRUCE_LOG = Items.f_41838_;
    public static Item BIRCH_LOG = Items.f_41839_;
    public static Item JUNGLE_LOG = Items.f_41840_;
    public static Item ACACIA_LOG = Items.f_41841_;
    public static Item DARK_OAK_LOG = Items.f_41842_;
    public static Item OAK_PLANKS = Items.f_42647_;
    public static Item SPRUCE_PLANKS = Items.f_42700_;
    public static Item BIRCH_PLANKS = Items.f_42753_;
    public static Item JUNGLE_PLANKS = Items.f_42794_;
    public static Item ACACIA_PLANKS = Items.f_42795_;
    public static Item DARK_OAK_PLANKS = Items.f_42796_;
    public static Item GLASS = Items.f_41904_;

    public static Item STICK = Items.f_42398_;
    public static Item GLASS_BOTTLE = Items.f_42590_;
    public static Item EXP_BOTTLE = Items.f_42612_;

    public static Item GUNPOWDER = Items.f_42403_;
    public static Item REDSTONE = Items.f_42451_;
    public static Item COAL = Items.f_42413_;
    public static Item CHARCOAL = Items.f_42414_;
    public static Item IRON_INGOT = Items.f_42416_;
    public static Item COPPER_INGOT = Items.f_151052_;
    public static Item GOLD_INGOT = Items.f_42417_;
    public static Item DIAMOND = Items.f_42415_;
    public static Item EMERALD = Items.f_42616_;
    public static Item LAPIS_LAZULI = Items.f_42534_;
    public static Item NETHERITE_INGOT = Items.f_42418_;
    public static Item NETHERITE_SCRAP = Items.f_42419_;
    public static Item QUARTZ = Items.f_42692_;

    // ----

    public static boolean isExist(Item item) {
        return item != null && item != Items.f_41852_;
    }
}
