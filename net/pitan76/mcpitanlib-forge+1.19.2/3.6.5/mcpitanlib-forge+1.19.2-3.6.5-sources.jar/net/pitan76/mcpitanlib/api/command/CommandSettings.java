package net.pitan76.mcpitanlib.api.command;

import net.minecraft.commands.CommandSourceStack;

public class CommandSettings {
    private int permissionLevel = -1;
    private ICustom iCustom = null;

    public boolean requires(CommandSourceStack source) {

        return customRequires(source) && (permissionLevel == -1 || source.m_6761_(permissionLevel));
    }

    private boolean customRequires(CommandSourceStack source) {
        if (iCustom == null) return true;
        return iCustom.custom(source);
    }

    public CommandSettings permissionLevel(int level) {
        this.permissionLevel = level;
        return this;
    }

    public CommandSettings custom(ICustom iCustom) {
        this.iCustom = iCustom;
        return this;
    }

    @FunctionalInterface
    public interface ICustom {
        boolean custom(CommandSourceStack source);
    }
}
