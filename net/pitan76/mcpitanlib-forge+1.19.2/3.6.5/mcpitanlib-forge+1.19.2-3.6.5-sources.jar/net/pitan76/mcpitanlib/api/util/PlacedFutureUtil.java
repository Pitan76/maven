package net.pitan76.mcpitanlib.api.util;

import java.util.List;
import net.minecraft.core.Holder;
import net.minecraft.world.level.levelgen.VerticalAnchor;
import net.minecraft.world.level.levelgen.feature.ConfiguredFeature;
import net.minecraft.world.level.levelgen.placement.CountPlacement;
import net.minecraft.world.level.levelgen.placement.HeightRangePlacement;
import net.minecraft.world.level.levelgen.placement.InSquarePlacement;
import net.minecraft.world.level.levelgen.placement.PlacedFeature;
import net.minecraft.world.level.levelgen.placement.PlacementModifier;

public class PlacedFutureUtil {
    public static PlacedFeature create(ConfiguredFeature<?, ?> configuredFeature, List<PlacementModifier> placementModifiers) {
        return new PlacedFeature(Holder.m_205709_(configuredFeature), placementModifiers);
    }

    public static List<PlacementModifier> createPlacementModifiers(CountPlacement countPlacementModifier, InSquarePlacement squarePlacementModifier, HeightRangePlacement heightRangePlacementModifier) {
        return List.of(countPlacementModifier, squarePlacementModifier, heightRangePlacementModifier);
    }

    public static List<PlacementModifier> createPlacementModifiers(int chunkCount, int top, int bottom) {
        return createPlacementModifiers(
CountPlacement.m_191628_(chunkCount),
                InSquarePlacement.m_191715_(),
                HeightRangePlacement.m_191680_(VerticalAnchor.m_158922_(bottom), VerticalAnchor.m_158922_(top))
        );
    }

    public static List<PlacementModifier> createPlacementModifiers(int chunkCount, int top) {
        return createPlacementModifiers(
                CountPlacement.m_191628_(chunkCount),
                InSquarePlacement.m_191715_(),
                HeightRangePlacement.m_191680_(VerticalAnchor.m_158921_(), VerticalAnchor.m_158922_(top))
        );
    }
}
