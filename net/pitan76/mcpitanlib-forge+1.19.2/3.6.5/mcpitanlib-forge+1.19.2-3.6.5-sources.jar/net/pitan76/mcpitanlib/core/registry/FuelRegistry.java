package net.pitan76.mcpitanlib.core.registry;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.ItemLike;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.AbstractFurnaceBlockEntity;

public class FuelRegistry {
    private FuelRegistry() {

    }

    public static void register(int time, ItemLike... item) {
        dev.architectury.registry.fuel.FuelRegistry.register(time, item);
    }

    @Deprecated
    public static int get(ItemStack stack) {
        return dev.architectury.registry.fuel.FuelRegistry.get(stack);
    }

    public static int get(Level world, ItemStack stack) {
        return dev.architectury.registry.fuel.FuelRegistry.get(stack);
    }

    public static boolean isFuel(Level world, ItemStack stack) {
        return AbstractFurnaceBlockEntity.m_58399_(stack);
    }
}
