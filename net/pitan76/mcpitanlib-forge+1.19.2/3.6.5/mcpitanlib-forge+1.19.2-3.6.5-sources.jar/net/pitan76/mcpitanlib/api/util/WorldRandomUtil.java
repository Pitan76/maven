package net.pitan76.mcpitanlib.api.util;

import net.minecraft.world.level.Level;

public class WorldRandomUtil {
    public static int nextInt(Level world) {
        return world.m_213780_().m_188502_();
    }

    public static int nextInt(Level world, int bound) {
        return world.m_213780_().m_188503_(bound);
    }

    public static long nextLong(Level world) {
        return world.m_213780_().m_188505_();
    }

    public static double nextDouble(Level world) {
        return world.m_213780_().m_188500_();
    }

    public static double nextGaussian(Level world) {
        return world.m_213780_().m_188583_();
    }

    public static float nextFloat(Level world) {
        return world.m_213780_().m_188501_();
    }

    public static int nextBetween(Level world, int min, int max) {
        return world.m_213780_().m_216332_(min, max);
    }

    public static int nextBetweenExclusive(Level world, int min, int max) {
        return world.m_213780_().m_216339_(min, max);
    }
}
