package net.pitan76.mcpitanlib.api.item.tool;

import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.HoeItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Tier;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.pitan76.mcpitanlib.api.event.item.PostHitEvent;
import net.pitan76.mcpitanlib.api.event.item.PostMineEvent;
import net.pitan76.mcpitanlib.api.item.v2.CompatibleItemSettings;
import net.pitan76.mcpitanlib.api.item.v2.CompatItemProvider;

public class CompatibleHoeItem extends HoeItem implements CompatItemProvider {

    public CompatibleItemSettings settings;

    public CompatibleHoeItem(CompatibleToolMaterial material, int attackDamage, float attackSpeed, CompatibleItemSettings settings) {
        super(material.build(), attackDamage, attackSpeed, settings.build());
        this.settings = settings;
    }

    public CompatibleHoeItem(int attackDamage, float attackSpeed, Tier material, CompatibleItemSettings settings) {
        super(material, attackDamage, attackSpeed, settings.build());
        this.settings = settings;
    }

    @Override
    public CompatibleItemSettings getCompatSettings() {
        return settings;
    }

    public boolean overrideIsSuitableFor(BlockState state) {
        return super.m_8096_(state);
    }

    @Deprecated
    @Override
    public boolean m_8096_(BlockState state) {
        return overrideIsSuitableFor(state);
    }

    public float overrideGetMiningSpeedMultiplier(ItemStack stack, BlockState state) {
        return super.m_8102_(stack, state);
    }

    @Deprecated
    @Override
    public float m_8102_(ItemStack stack, BlockState state) {
        return overrideGetMiningSpeedMultiplier(stack, state);
    }

    @Deprecated
    @Override
    public boolean m_7579_(ItemStack stack, LivingEntity target, LivingEntity attacker) {
        return postHit(new PostHitEvent(stack, target, attacker));
    }

    @Deprecated
    @Override
    public boolean m_6813_(ItemStack stack, Level world, BlockState state, BlockPos pos, LivingEntity miner) {
        return postMine(new PostMineEvent(stack, world, state, pos, miner));
    }

    /**
     * post hit event
     * @param event PostHitEvent
     * @return boolean
     */
    public boolean postHit(PostHitEvent event) {
        return super.m_7579_(event.stack, event.target, event.attacker);
    }

    /**
     * post mine event
     * @param event PostMineEvent
     * @return boolean
     */
    public boolean postMine(PostMineEvent event) {
        return super.m_6813_(event.stack, event.world, event.state, event.pos, event.miner);
    }

    @Deprecated
    public boolean m_41465_() {
        return isDamageableOnDefault();
    }

    // -1.20.6
    public boolean isDamageableOnDefault() {
        return super.m_41465_();
    }
}