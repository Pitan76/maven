package net.pitan76.mcpitanlib.api.client.gui.widget;

import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.pitan76.mcpitanlib.api.util.client.RenderUtil;

public class RedrawableTexturedButtonWidget extends CompatibleTexturedButtonWidget {
    public ResourceLocation texture;
    public int u;
    public int v;
    public int hoveredVOffset;
    public int textureWidth;
    public int textureHeight;

    public RedrawableTexturedButtonWidget(int x, int y, int width, int height, int u, int v, int hoveredVOffset, ResourceLocation texture, int textureWidth, int textureHeight, OnPress pressAction, Component message) {
        super(x, y, width, height, u, v, hoveredVOffset, texture, textureWidth, textureHeight, pressAction, message);
        this.textureWidth = textureWidth;
        this.textureHeight = textureHeight;
        this.u = u;
        this.v = v;
        this.hoveredVOffset = hoveredVOffset;
        this.texture = texture;
    }

    public void m_6303_(PoseStack matrices, int mouseX, int mouseY, float delta) {
        RenderUtil.setShaderToPositionTexProgram();
        RenderUtil.setShaderTexture(0, this.texture);
        int i = this.v;
        if (!this.m_142518_()) {
            i += this.hoveredVOffset * 2;
        } else if (this.m_198029_()) {
            i += this.hoveredVOffset;
        }

        RenderUtil.enableDepthTest();
        m_93133_(matrices, this.f_93620_, this.f_93621_, (float)this.u, (float)i, this.f_93618_, this.f_93619_, this.textureWidth, this.textureHeight);

        if (this.f_93622_) {
            this.m_7428_(matrices, mouseX, mouseY);
        }
    }

    public void setTexture(ResourceLocation texture) {
        this.texture = texture;
    }

    public void setU(int u) {
        this.u = u;
    }

    public void setV(int v) {
        this.v = v;
    }

    public void setHoveredVOffset(int hoveredVOffset) {
        this.hoveredVOffset = hoveredVOffset;
    }

    public void setTextureWidth(int textureWidth) {
        this.textureWidth = textureWidth;
    }

    public void setTextureHeight(int textureHeight) {
        this.textureHeight = textureHeight;
    }
}
