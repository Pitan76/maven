package net.pitan76.mcpitanlib.api.event.item;

import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.pitan76.mcpitanlib.api.entity.Player;
import net.pitan76.mcpitanlib.api.event.BaseEvent;
import net.pitan76.mcpitanlib.api.item.ArmorEquipmentType;
import net.pitan76.mcpitanlib.api.tag.TagKey;
import net.pitan76.mcpitanlib.api.util.BlockUtil;
import net.pitan76.mcpitanlib.api.util.WorldUtil;

public class PostMineEvent extends BaseEvent {
    public ItemStack stack;
    public Level world;
    public BlockState state;
    public BlockPos pos;
    public LivingEntity miner;

    public PostMineEvent(ItemStack stack, Level world, BlockState state, BlockPos pos, LivingEntity miner) {
        this.stack = stack;
        this.world = world;
        this.state = state;
        this.pos = pos;
        this.miner = miner;
    }

    public BlockState getState() {
        return state;
    }

    public BlockPos getPos() {
        return pos;
    }

    public Level getWorld() {
        return world;
    }

    public ItemStack getStack() {
        return stack;
    }

    public LivingEntity getMiner() {
        return miner;
    }

    public BlockEntity getBlockEntity() {
        return WorldUtil.getBlockEntity(world, pos);
    }

    public boolean isClient() {
        return world.f_46443_;
    }

    public boolean stateIsIn(TagKey<Block> tagKey) {
        return BlockUtil.isIn(state.m_60734_(), tagKey);
    }

    public boolean stateIsOf(Block block) {
        return BlockUtil.isEqual(state.m_60734_(), block);
    }

    /**
     * Damages the stack in the given slot
     * @param amount the amount of damage to deal
     * @param slot the slot to damage
     */
    public void damageStack(int amount, EquipmentSlot slot) {
        stack.m_41622_(amount, miner, (entity) -> {
            entity.m_21166_(slot);
        });
    }

    /**
     * Damages the stack in the given slot
     * @param amount the amount of damage to deal
     * @param type the type of armor equipment
     */
    public void damageStack(int amount, ArmorEquipmentType type) {
        stack.m_41622_(amount, miner, (entity) -> {
            entity.m_21166_(type.getSlot());
        });
    }

    /**
     * Damages the stack in the main hand
     * @param amount the amount of damage to deal
     */
    public void damageStack(int amount) {
        stack.m_41622_(amount, miner, (entity) -> {
            entity.m_21166_(EquipmentSlot.MAINHAND);
        });
    }

    public boolean isPlayer() {
        return miner instanceof net.minecraft.world.entity.player.Player;
    }

    public Player getPlayer() {
        if (isPlayer())
            return new Player((net.minecraft.world.entity.player.Player) miner);

        return null;
    }

    public boolean isCreative() {
        return isPlayer() && getPlayer().isCreative();
    }

    public boolean isSneaking() {
        return miner.m_6144_();
    }

    public ItemStack getMainHandStack() {
        return miner.m_21205_();
    }
}
