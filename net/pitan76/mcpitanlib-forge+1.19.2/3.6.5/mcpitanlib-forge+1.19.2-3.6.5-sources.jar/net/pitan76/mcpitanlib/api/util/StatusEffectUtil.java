package net.pitan76.mcpitanlib.api.util;

import net.minecraft.core.Registry;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.effect.MobEffect;
import net.pitan76.mcpitanlib.api.entity.effect.CompatStatusEffect;

public class StatusEffectUtil {
    public static CompatStatusEffect getStatusEffect(ResourceLocation identifier) {
        MobEffect statusEffect = Registry.f_122823_.m_7745_(identifier);
        return new CompatStatusEffect(statusEffect);
    }

    public static CompatStatusEffect getStatusEffect(CompatIdentifier identifier) {
        return getStatusEffect(identifier.toMinecraft());
    }

    public static ResourceLocation getId(CompatStatusEffect statusEffect) {
        return statusEffect.getId();
    }

    public static CompatIdentifier getCompatId(CompatStatusEffect statusEffect) {
        return CompatIdentifier.fromMinecraft(statusEffect.getId());
    }

}
