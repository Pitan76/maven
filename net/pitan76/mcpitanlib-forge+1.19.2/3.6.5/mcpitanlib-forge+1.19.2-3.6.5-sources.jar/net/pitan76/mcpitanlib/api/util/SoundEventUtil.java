package net.pitan76.mcpitanlib.api.util;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import net.minecraft.core.Registry;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;

public class SoundEventUtil {
    public static ResourceLocation getId(SoundEvent soundEvent) {
        return soundEvent.m_11660_();
    }

    public static SoundEvent getSoundEvent(ResourceLocation id) {
        return new SoundEvent(id);
    }

    public static CompatIdentifier getCompatId(SoundEvent soundEvent) {
        return CompatIdentifier.fromMinecraft(getId(soundEvent));
    }

    public static SoundEvent getSoundEvent(CompatIdentifier id) {
        return getSoundEvent(id.toMinecraft());
    }

    public static List<SoundEvent> getAllSoundEvents() {
        return Registry.f_122821_.m_123024_().collect(Collectors.toList());
    }

    public static List<ResourceLocation> getAllSoundEventIds() {
        return new ArrayList<>(Registry.f_122821_.m_6566_());
    }
}
