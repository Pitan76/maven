package net.pitan76.mcpitanlib.api.util.client.render;

import net.minecraft.client.renderer.block.model.ItemTransforms;
import net.pitan76.mcpitanlib.api.util.CompatStringIdentifiable;

public class CompatItemDisplayContext implements CompatStringIdentifiable {
    private final ItemTransforms.TransformType context;

    public static final CompatItemDisplayContext NONE = of(ItemTransforms.TransformType.NONE);
    public static final CompatItemDisplayContext THIRD_PERSON_LEFT_HAND = of(ItemTransforms.TransformType.THIRD_PERSON_LEFT_HAND);
    public static final CompatItemDisplayContext THIRD_PERSON_RIGHT_HAND = of(ItemTransforms.TransformType.THIRD_PERSON_RIGHT_HAND);
    public static final CompatItemDisplayContext FIRST_PERSON_LEFT_HAND = of(ItemTransforms.TransformType.FIRST_PERSON_LEFT_HAND);
    public static final CompatItemDisplayContext FIRST_PERSON_RIGHT_HAND = of(ItemTransforms.TransformType.FIRST_PERSON_RIGHT_HAND);
    public static final CompatItemDisplayContext HEAD = of(ItemTransforms.TransformType.HEAD);
    public static final CompatItemDisplayContext GUI = of(ItemTransforms.TransformType.GUI);
    public static final CompatItemDisplayContext GROUND = of(ItemTransforms.TransformType.GROUND);
    public static final CompatItemDisplayContext FIXED = of(ItemTransforms.TransformType.FIXED);

    public CompatItemDisplayContext(ItemTransforms.TransformType context) {
        this.context = context;
    }

    public static CompatItemDisplayContext of(ItemTransforms.TransformType context) {
        return new CompatItemDisplayContext(context);
    }

    public ItemTransforms.TransformType getContext() {
        return context;
    }

    public String getName() {
        return context.name();
    }

    @Override
    public String asString_compat() {
        return getName();
    }
}
