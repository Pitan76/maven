package net.pitan76.mcpitanlib.api.util;

import java.io.IOException;
import java.io.InputStream;
import java.util.Map;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.packs.resources.Resource;
import net.minecraft.server.packs.resources.ResourceManager;

public class ResourceUtil {
    public static Resource getResource(ResourceManager resourceManager, ResourceLocation identifier) {
        return resourceManager.m_213713_(identifier).get();
    }

    public static InputStream getInputStream(Resource resource) throws IOException {
        return resource.m_215507_();
    }

    public static Map<ResourceLocation, Resource> findResources(ResourceManager resourceManager, String startingPath, String endingPath) throws IOException {
        return resourceManager.m_214159_(startingPath, s -> s.toString().endsWith(endingPath));
    }

    public static void close(Resource resource) throws IOException {
        getInputStream(resource).close();
    }
}
