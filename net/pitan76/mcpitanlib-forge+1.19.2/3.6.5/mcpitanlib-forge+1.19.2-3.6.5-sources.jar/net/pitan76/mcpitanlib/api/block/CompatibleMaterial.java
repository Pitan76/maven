package net.pitan76.mcpitanlib.api.block;

import net.minecraft.world.level.material.Material;
import net.minecraft.world.level.material.MaterialColor;
import net.minecraft.world.level.material.PushReaction;

public final class CompatibleMaterial {
    public static final CompatibleMaterial AIR;
    public static final CompatibleMaterial STRUCTURE_VOID;
    public static final CompatibleMaterial PORTAL;
    public static final CompatibleMaterial CARPET;
    public static final CompatibleMaterial PLANT;
    public static final CompatibleMaterial UNDERWATER_PLANT;
    public static final CompatibleMaterial REPLACEABLE_PLANT;
    public static final CompatibleMaterial NETHER_SHOOTS;
    public static final CompatibleMaterial REPLACEABLE_UNDERWATER_PLANT;
    public static final CompatibleMaterial WATER;
    public static final CompatibleMaterial BUBBLE_COLUMN;
    public static final CompatibleMaterial LAVA;
    public static final CompatibleMaterial SNOW_LAYER;
    public static final CompatibleMaterial FIRE;
    public static final CompatibleMaterial DECORATION;
    public static final CompatibleMaterial COBWEB;
    public static final CompatibleMaterial SCULK;
    public static final CompatibleMaterial REDSTONE_LAMP;
    public static final CompatibleMaterial ORGANIC_PRODUCT;
    public static final CompatibleMaterial SOIL;
    public static final CompatibleMaterial SOLID_ORGANIC;
    public static final CompatibleMaterial DENSE_ICE;
    public static final CompatibleMaterial AGGREGATE;
    public static final CompatibleMaterial SPONGE;
    public static final CompatibleMaterial SHULKER_BOX;
    public static final CompatibleMaterial WOOD;
    public static final CompatibleMaterial NETHER_WOOD;
    public static final CompatibleMaterial BAMBOO_SAPLING;
    public static final CompatibleMaterial BAMBOO;
    public static final CompatibleMaterial WOOL;
    public static final CompatibleMaterial TNT;
    public static final CompatibleMaterial LEAVES;
    public static final CompatibleMaterial GLASS;
    public static final CompatibleMaterial ICE;
    public static final CompatibleMaterial CACTUS;
    public static final CompatibleMaterial STONE;
    public static final CompatibleMaterial METAL;
    public static final CompatibleMaterial SNOW_BLOCK;
    public static final CompatibleMaterial REPAIR_STATION;
    public static final CompatibleMaterial BARRIER;
    public static final CompatibleMaterial PISTON;
    public static final CompatibleMaterial MOSS_BLOCK;
    public static final CompatibleMaterial GOURD;
    public static final CompatibleMaterial EGG;
    public static final CompatibleMaterial CAKE;
    public static final CompatibleMaterial AMETHYST;
    public static final CompatibleMaterial POWDER_SNOW;
    private final MaterialColor color;
    private final PushReaction pistonBehavior;
    private final boolean burnable;
    private final boolean liquid;
    private final boolean replaceable;
    private final boolean solid;
    private Material material;

    public CompatibleMaterial(MaterialColor color, boolean liquid, boolean solid, boolean burnable, boolean replaceable, PushReaction pistonBehavior) {
        this.color = color;
        this.liquid = liquid;
        this.solid = solid;
        this.burnable = burnable;
        this.replaceable = replaceable;
        this.pistonBehavior = pistonBehavior;
        this.material = Material.f_76278_;
    }

    private CompatibleMaterial(Material material, MaterialColor color, boolean liquid, boolean solid, boolean burnable, boolean replaceable, PushReaction pistonBehavior) {
        this(material.m_76339_(), material.m_76332_(), material.m_76333_(), material.m_76335_(), material.m_76336_(), material.m_76338_());
        this.material = material;
    }

    @Deprecated
    public Material getMaterial() {
        return material;
    }

    public boolean isLiquid() {
        return this.liquid;
    }

    public boolean isSolid() {
        return this.solid;
    }

    public boolean isBurnable() {
        return this.burnable;
    }

    public boolean isReplaceable() {
        return this.replaceable;
    }

    public PushReaction getPistonBehavior() {
        return this.pistonBehavior;
    }

    public MaterialColor getColor() {
        return this.color;
    }

    static {
        AIR = (new Builder(MaterialColor.f_76398_)).allowsMovement().lightPassesThrough().notSolid().replaceable().material(Material.f_76296_).build();
        STRUCTURE_VOID = (new Builder(MaterialColor.f_76398_)).allowsMovement().lightPassesThrough().notSolid().replaceable().material(Material.f_76297_).build();
        PORTAL = (new Builder(MaterialColor.f_76398_)).allowsMovement().lightPassesThrough().notSolid().blocksPistons().material(Material.f_76298_).build();
        CARPET = (new Builder(MaterialColor.f_76401_)).allowsMovement().lightPassesThrough().notSolid().burnable().material(Material.f_76299_).build();
        PLANT = (new Builder(MaterialColor.f_76405_)).allowsMovement().lightPassesThrough().notSolid().destroyedByPiston().material(Material.f_76300_).build();
        UNDERWATER_PLANT = (new Builder(MaterialColor.f_76410_)).allowsMovement().lightPassesThrough().notSolid().destroyedByPiston().material(Material.f_76301_).build();
        REPLACEABLE_PLANT = (new Builder(MaterialColor.f_76405_)).allowsMovement().lightPassesThrough().notSolid().destroyedByPiston().replaceable().burnable().material(Material.f_76302_).build();
        NETHER_SHOOTS = (new Builder(MaterialColor.f_76405_)).allowsMovement().lightPassesThrough().notSolid().destroyedByPiston().replaceable().material(Material.f_76303_).build();
        REPLACEABLE_UNDERWATER_PLANT = (new Builder(MaterialColor.f_76410_)).allowsMovement().lightPassesThrough().notSolid().destroyedByPiston().replaceable().material(Material.f_76304_).build();
        WATER = (new Builder(MaterialColor.f_76410_)).allowsMovement().lightPassesThrough().notSolid().destroyedByPiston().replaceable().liquid().material(Material.f_76305_).build();
        BUBBLE_COLUMN = (new Builder(MaterialColor.f_76410_)).allowsMovement().lightPassesThrough().notSolid().destroyedByPiston().replaceable().liquid().material(Material.f_76306_).build();
        LAVA = (new Builder(MaterialColor.f_76402_)).allowsMovement().lightPassesThrough().notSolid().destroyedByPiston().replaceable().liquid().material(Material.f_76307_).build();
        SNOW_LAYER = (new Builder(MaterialColor.f_76406_)).allowsMovement().lightPassesThrough().notSolid().destroyedByPiston().replaceable().material(Material.f_76308_).build();
        FIRE = (new Builder(MaterialColor.f_76398_)).allowsMovement().lightPassesThrough().notSolid().destroyedByPiston().replaceable().material(Material.f_76309_).build();
        DECORATION = (new Builder(MaterialColor.f_76398_)).allowsMovement().lightPassesThrough().notSolid().destroyedByPiston().material(Material.f_76310_).build();
        COBWEB = (new Builder(MaterialColor.f_76401_)).allowsMovement().lightPassesThrough().destroyedByPiston().material(Material.f_76311_).build();
        SCULK = (new Builder(MaterialColor.f_76365_)).material(Material.f_164533_).build();
        REDSTONE_LAMP = (new Builder(MaterialColor.f_76398_)).material(Material.f_76312_).build();
        ORGANIC_PRODUCT = (new Builder(MaterialColor.f_76407_)).material(Material.f_76313_).build();
        SOIL = (new Builder(MaterialColor.f_76408_)).material(Material.f_76314_).build();
        SOLID_ORGANIC = (new Builder(MaterialColor.f_76399_)).material(Material.f_76315_).build();
        DENSE_ICE = (new Builder(MaterialColor.f_76403_)).material(Material.f_76316_).build();
        AGGREGATE = (new Builder(MaterialColor.f_76400_)).material(Material.f_76317_).build();
        SPONGE = (new Builder(MaterialColor.f_76416_)).material(Material.f_76318_).build();
        SHULKER_BOX = (new Builder(MaterialColor.f_76422_)).material(Material.f_76319_).build();
        WOOD = (new Builder(MaterialColor.f_76411_)).burnable().material(Material.f_76320_).build();
        NETHER_WOOD = (new Builder(MaterialColor.f_76411_)).material(Material.f_76321_).build();
        BAMBOO_SAPLING = (new Builder(MaterialColor.f_76411_)).burnable().destroyedByPiston().allowsMovement().material(Material.f_76270_).build();
        BAMBOO = (new Builder(MaterialColor.f_76411_)).burnable().destroyedByPiston().material(Material.f_76271_).build();
        WOOL = (new Builder(MaterialColor.f_76401_)).burnable().material(Material.f_76272_).build();
        TNT = (new Builder(MaterialColor.f_76402_)).burnable().lightPassesThrough().material(Material.f_76273_).build();
        LEAVES = (new Builder(MaterialColor.f_76405_)).burnable().lightPassesThrough().destroyedByPiston().material(Material.f_76274_).build();
        GLASS = (new Builder(MaterialColor.f_76398_)).lightPassesThrough().material(Material.f_76275_).build();
        ICE = (new Builder(MaterialColor.f_76403_)).lightPassesThrough().material(Material.f_76276_).build();
        CACTUS = (new Builder(MaterialColor.f_76405_)).lightPassesThrough().destroyedByPiston().material(Material.f_76277_).build();
        STONE = (new Builder(MaterialColor.f_76409_)).material(Material.f_76278_).build();
        METAL = (new Builder(MaterialColor.f_76404_)).material(Material.f_76279_).build();
        SNOW_BLOCK = (new Builder(MaterialColor.f_76406_)).material(Material.f_76280_).build();
        REPAIR_STATION = (new Builder(MaterialColor.f_76404_)).blocksPistons().material(Material.f_76281_).build();
        BARRIER = (new Builder(MaterialColor.f_76398_)).blocksPistons().material(Material.f_76282_).build();
        PISTON = (new Builder(MaterialColor.f_76409_)).blocksPistons().material(Material.f_76283_).build();
        MOSS_BLOCK = (new Builder(MaterialColor.f_76405_)).destroyedByPiston().material(Material.f_164530_).build();
        GOURD = (new Builder(MaterialColor.f_76405_)).destroyedByPiston().material(Material.f_76285_).build();
        EGG = (new Builder(MaterialColor.f_76405_)).destroyedByPiston().material(Material.f_76286_).build();
        CAKE = (new Builder(MaterialColor.f_76398_)).destroyedByPiston().material(Material.f_76287_).build();
        AMETHYST = (new Builder(MaterialColor.f_76422_)).material(Material.f_164531_).build();
        POWDER_SNOW = (new Builder(MaterialColor.f_76406_)).notSolid().allowsMovement().material(Material.f_164532_).build();
    }

    public static class Builder {
        private PushReaction pistonBehavior;
        private boolean blocksMovement;
        private boolean burnable;
        private boolean liquid;
        private boolean replaceable;
        private boolean solid;
        private final MaterialColor color;
        private boolean blocksLight;
        private Material material = Material.f_76278_;

        public Builder(MaterialColor color) {
            this.pistonBehavior = PushReaction.NORMAL;
            this.blocksMovement = true;
            this.solid = true;
            this.blocksLight = true;
            this.color = color;
        }

        public Builder liquid() {
            this.liquid = true;
            return this;
        }

        public Builder notSolid() {
            this.solid = false;
            return this;
        }

        public Builder allowsMovement() {
            this.blocksMovement = false;
            return this;
        }

        Builder lightPassesThrough() {
            this.blocksLight = false;
            return this;
        }

        protected Builder burnable() {
            this.burnable = true;
            return this;
        }

        public Builder replaceable() {
            this.replaceable = true;
            return this;
        }

        protected Builder destroyedByPiston() {
            this.pistonBehavior = PushReaction.DESTROY;
            return this;
        }

        protected Builder blocksPistons() {
            this.pistonBehavior = PushReaction.BLOCK;
            return this;
        }

        protected Builder material(Material material) {
            this.material = material;
            return this;
        }

        public CompatibleMaterial build() {
            return new CompatibleMaterial(material, this.color, this.liquid, this.solid, this.burnable, this.replaceable, this.pistonBehavior);
        }
    }
}
