package net.pitan76.mcpitanlib.api.item.tool;

import net.minecraft.tags.ItemTags;
import net.minecraft.tags.TagKey;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Tier;
import net.minecraft.world.item.crafting.Ingredient;
import net.pitan76.mcpitanlib.api.util.IngredientUtil;

public interface CompatibleToolMaterial {

    int getCompatMiningLevel();

    float getCompatAttackDamage();

    float getCompatMiningSpeedMultiplier();

    default Ingredient getCompatRepairIngredient() {
        return IngredientUtil.fromTagByIdentifier(getRepairTag().f_203868_());
    }

    int getCompatDurability();

    int getCompatEnchantability();

    @Deprecated
    default float getAttackDamage() {
        return getCompatAttackDamage();
    }

    @Deprecated
    default float getMiningSpeedMultiplier() {
        return getCompatMiningSpeedMultiplier();
    }

    @Deprecated
    default Ingredient getRepairIngredient() {
        return getCompatRepairIngredient();
    }

    @Deprecated
    default int getDurability() {
        return getCompatDurability();
    }

    @Deprecated
    default int getEnchantability() {
        return getCompatEnchantability();
    }

    default TagKey<Item> getRepairTag() {
        return ItemTags.f_144312_;
    }

    default Tier build() {
        return new Tier() {
            @Override
            public int m_6609_() {
                return getCompatDurability();
            }

            @Override
            public float m_6624_() {
                return getCompatMiningSpeedMultiplier();
            }

            @Override
            public float m_6631_() {
                return getCompatAttackDamage();
            }

            @Override
            public int m_6604_() {
                return getCompatMiningLevel();
            }

            @Override
            public int m_6601_() {
                return getCompatEnchantability();
            }

            @Override
            public Ingredient m_6282_() {
                return getCompatRepairIngredient();
            }
        };
    }
}