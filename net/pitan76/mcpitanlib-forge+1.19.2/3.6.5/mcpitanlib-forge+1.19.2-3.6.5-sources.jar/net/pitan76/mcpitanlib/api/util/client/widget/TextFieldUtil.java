package net.pitan76.mcpitanlib.api.util.client.widget;

import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.network.chat.Component;
import net.pitan76.mcpitanlib.api.client.render.handledscreen.RenderArgs;
import net.pitan76.mcpitanlib.api.util.TextUtil;

public class TextFieldUtil {
    public static void setFocused(EditBox widget, boolean focused) {
        widget.m_94178_(focused);
    }

    public static void render(EditBox widget, RenderArgs args) {
        widget.m_6305_(args.drawObjectDM.getStack(), args.mouseX, args.mouseY, args.delta);
    }

    public static void setEditable(EditBox widget, boolean editable) {
        widget.m_94186_(editable);
    }

    public static void setMaxLength(EditBox widget, int maxLength) {
        widget.m_94199_(maxLength);
    }

    public static void setSuggestion(EditBox widget, String suggestion) {
        widget.m_94167_(suggestion);
    }

    public static void setText(EditBox widget, String text) {
        widget.m_94144_(text);
    }

    public static String getText(EditBox widget) {
        return widget.m_94155_();
    }

    public static void setDrawsBackground(EditBox widget, boolean drawsBackground) {
        widget.m_94182_(drawsBackground);
    }

    public static void setFocusUnlocked(EditBox widget, boolean focusUnlocked) {
        widget.m_94190_(focusUnlocked);
    }

    public static boolean isFocused(EditBox widget) {
        return widget.m_93696_();
    }

    public static boolean keyPressed(EditBox widget, int keyCode, int scanCode, int modifiers) {
        return widget.m_7933_(keyCode, scanCode, modifiers);
    }

    public static boolean keyReleased(EditBox widget, int keyCode, int scanCode, int modifiers) {
        return widget.m_7920_(keyCode, scanCode, modifiers);
    }

    public static boolean charTyped(EditBox widget, char chr, int modifiers) {
        return widget.m_5534_(chr, modifiers);
    }

    public static EditBox create(Font renderer, int x, int y, int width, int height, Component text) {
        return new EditBox(renderer, x, y, width, height, text);
    }

    public static EditBox create(Font renderer, int width, int height, Component text) {
        return create(renderer, 0, 0, width, height, text);
    }

    public static EditBox create(Font renderer, int x, int y, int width, int height) {
        return new EditBox(renderer, x, y, width, height, TextUtil.empty());
    }

    public static EditBox create(Font renderer, int width, int height) {
        return create(renderer, width, height, TextUtil.empty());
    }
}
