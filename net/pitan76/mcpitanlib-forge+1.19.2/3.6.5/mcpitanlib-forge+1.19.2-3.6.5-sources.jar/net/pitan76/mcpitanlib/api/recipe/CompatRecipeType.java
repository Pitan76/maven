package net.pitan76.mcpitanlib.api.recipe;

import net.minecraft.core.Registry;
import net.minecraft.recipe.*;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.crafting.BlastingRecipe;
import net.minecraft.world.item.crafting.CampfireCookingRecipe;
import net.minecraft.world.item.crafting.CraftingRecipe;
import net.minecraft.world.item.crafting.Recipe;
import net.minecraft.world.item.crafting.RecipeType;
import net.minecraft.world.item.crafting.SmeltingRecipe;
import net.minecraft.world.item.crafting.SmokingRecipe;
import net.minecraft.world.item.crafting.StonecutterRecipe;
import net.minecraft.world.item.crafting.UpgradeRecipe;
import net.pitan76.mcpitanlib.api.util.CompatIdentifier;

@Deprecated
public class CompatRecipeType<T extends Recipe<?>> {
    public static final CompatRecipeType<CraftingRecipe> CRAFTING = new CompatRecipeType<>(RecipeType.f_44107_);
    public static final CompatRecipeType<SmeltingRecipe> SMELTING = new CompatRecipeType<>(RecipeType.f_44108_);
    public static final CompatRecipeType<BlastingRecipe> BLASTING = new CompatRecipeType<>(RecipeType.f_44109_);
    public static final CompatRecipeType<SmokingRecipe> SMOKING = new CompatRecipeType<>(RecipeType.f_44110_);
    public static final CompatRecipeType<CampfireCookingRecipe> CAMPFIRE_COOKING = new CompatRecipeType<>(RecipeType.f_44111_);
    public static final CompatRecipeType<StonecutterRecipe> STONECUTTING = new CompatRecipeType<>(RecipeType.f_44112_);
    public static final CompatRecipeType<UpgradeRecipe> SMITHING = new CompatRecipeType<>(RecipeType.f_44113_);

    private final RecipeType<T> type;

    public CompatRecipeType(String id) {
        this(RecipeType.m_44119_(id));
    }

    public CompatRecipeType(RecipeType<T> type) {
        this.type = type;
    }

    public RecipeType<T> getType() {
        return type;
    }

    public CompatIdentifier getName() {
        ResourceLocation id = Registry.f_122864_.m_7981_(type);
        if (id == null) return CompatIdentifier.empty();

        return CompatIdentifier.fromMinecraft(id);
    }

    public static CompatRecipeType<?> of(CompatIdentifier id) {
        RecipeType<?> type = Registry.f_122864_.m_7745_(id.toMinecraft());
        if (type == null) return null;

        return new CompatRecipeType<>(type);
    }

    public static <T extends Recipe<?>> CompatRecipeType<T> of(CompatIdentifier id, Class<T> clazz) {
        return (CompatRecipeType<T>) of(id);
    }

    public static <T extends Recipe<?>> CompatRecipeType<T> of(RecipeType<T> type) {
        return new CompatRecipeType<>(type);
    }

    public net.pitan76.mcpitanlib.midohra.recipe.RecipeType toMidohra() {
        return net.pitan76.mcpitanlib.midohra.recipe.RecipeType.of(type);
    }
}
