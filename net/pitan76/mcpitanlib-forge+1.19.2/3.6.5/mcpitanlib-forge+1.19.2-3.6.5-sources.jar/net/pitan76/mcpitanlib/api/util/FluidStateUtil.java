package net.pitan76.mcpitanlib.api.util;

import net.minecraft.tags.FluidTags;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.material.Fluid;
import net.minecraft.world.level.material.FluidState;
import net.pitan76.mcpitanlib.midohra.fluid.FluidWrapper;
import net.pitan76.mcpitanlib.midohra.util.math.BlockPos;
import net.pitan76.mcpitanlib.midohra.world.World;

public class FluidStateUtil {
    public static boolean isWater(FluidState state) {
        return state.m_205070_(FluidTags.f_13131_);
    }

    public static boolean isLava(FluidState state) {
        return state.m_205070_(FluidTags.f_13132_);
    }

    @Deprecated
    public static FluidState getFluidState(BlockState state) {
        return state.m_60819_();
    }

    public static FluidState getDefaultState(Fluid state) {
        return state.m_76145_();
    }

    public static Fluid getFluid(FluidState state) {
        return state.m_76152_();
    }

    public static FluidWrapper getFluidWrapper(FluidState state) {
        return FluidWrapper.of(getFluid(state));
    }

    public static FluidWrapper getFluidWrapper(BlockState state) {
        return getFluidWrapper(getFluidState(state));
    }

    public static FluidWrapper getFluidWrapper(net.pitan76.mcpitanlib.midohra.block.BlockState state) {
        return getFluidWrapper(state.toMinecraft());
    }

    public static FluidWrapper getFluidWrapper(World world, BlockPos pos) {
        return getFluidWrapper(world.getBlockState(pos));
    }
}
