package net.pitan76.mcpitanlib.api.util.client;

import com.mojang.blaze3d.platform.Window;

public class WindowUtil {

    public static Window getWindow() {
        return ClientUtil.getWindow();
    }

    public static int getWindowScaledWidth() {
        return getWindow().m_85445_();
    }

    public static int getWindowScaledHeight() {
        return getWindow().m_85446_();
    }

    public static int getWindowWidth() {
        return getWindow().m_85443_();
    }

    public static int getWindowHeight() {
        return getWindow().m_85444_();
    }

    public static int getWindowX() {
        return getWindow().m_85447_();
    }

    public static int getWindowY() {
        return getWindow().m_85448_();
    }

    public static void setTitle(String title) {
        getWindow().m_85422_(title);
    }

    public static void close() {
        getWindow().close();
    }
}
