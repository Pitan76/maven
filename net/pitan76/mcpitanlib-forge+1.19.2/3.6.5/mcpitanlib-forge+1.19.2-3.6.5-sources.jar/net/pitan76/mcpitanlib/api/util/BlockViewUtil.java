package net.pitan76.mcpitanlib.api.util;

import net.minecraft.core.BlockPos;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;

public class BlockViewUtil {
    public static BlockState getBlockState(BlockGetter blockView, BlockPos pos) {
        return blockView.m_8055_(pos);
    }

    public static BlockEntity getBlockEntity(BlockGetter blockView, BlockPos pos) {
        return blockView.m_7702_(pos);
    }

    public static boolean hasBlockEntity(BlockGetter blockView, BlockPos pos) {
        return getBlockEntity(blockView, pos) != null;
    }

    public static boolean isAir(BlockGetter blockView, BlockPos pos) {
        return getBlockState(blockView, pos).m_60795_();
    }
}
