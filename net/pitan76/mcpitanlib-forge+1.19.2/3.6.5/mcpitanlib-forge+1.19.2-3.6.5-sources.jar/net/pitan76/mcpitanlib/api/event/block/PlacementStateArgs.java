package net.pitan76.mcpitanlib.api.event.block;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.Property;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.Vec3;
import net.pitan76.mcpitanlib.api.entity.Player;
import net.pitan76.mcpitanlib.api.event.BaseEvent;
import net.pitan76.mcpitanlib.api.event.item.ItemUseOnBlockEvent;
import net.pitan76.mcpitanlib.api.state.property.IProperty;
import net.pitan76.mcpitanlib.api.util.BlockStateUtil;
import net.pitan76.mcpitanlib.api.util.WorldUtil;
import net.pitan76.mcpitanlib.mixin.ItemUsageContextMixin;
import org.jetbrains.annotations.Nullable;

public class PlacementStateArgs extends BaseEvent {
    public BlockPlaceContext ctx;

    @Nullable
    public Block block;

    public PlacementStateArgs(BlockPlaceContext ctx) {
        this.ctx = ctx;
    }

    public PlacementStateArgs(BlockPlaceContext ctx, @Nullable Block block) {
        this.ctx = ctx;
        this.block = block;
    }

    public boolean canPlace() {
        return ctx.m_7059_();
    }

    public BlockPos getPos() {
        return ctx.m_8083_();
    }

    public Player getPlayer() {
        return new Player(ctx.m_43723_());
    }

    public Direction[] getPlacementDirections() {
        return ctx.m_6232_();
    }

    public InteractionHand getHand() {
        return ctx.m_43724_();
    }

    public Direction getSide() {
        return ctx.m_43719_();
    }

    public Direction getHorizontalPlayerFacing() {
        return ctx.m_8125_();
    }

    public float getPlayerYaw() {
        return ctx.m_7074_();
    }

    public Level getWorld() {
        return ctx.m_43725_();
    }

    public boolean isClient() {
        return getWorld().m_5776_();
    }

    public Vec3 getHitPos() {
        return ctx.m_43720_();
    }

    public boolean canReplaceExisting() {
        return ctx.m_7058_();
    }

    @Deprecated
    public ItemUsageContextMixin getIUCAccessor() {
        return (ItemUsageContextMixin) ctx;
    }

    public BlockHitResult getHitResult() {
        return getIUCAccessor().getHit();
    }

    public ItemUseOnBlockEvent toItemUseOnBlockEvent() {
        return new ItemUseOnBlockEvent(getWorld(), getPlayer().getPlayerEntity(), getHand(), ctx.m_43722_(), getHitResult());
    }

    public BlockPlaceContext getCtx() {
        return ctx;
    }

    public <T extends Comparable<T>, V extends T> BlockState withBlockState(Property<T> property, V value) {
        if (block == null)
            return null;

        return BlockStateUtil.with(BlockStateUtil.getDefaultState(block), property, value);
    }

    public <T extends Comparable<T>, V extends T> net.pitan76.mcpitanlib.midohra.block.BlockState with(IProperty<T> property, V value) {
        return net.pitan76.mcpitanlib.midohra.block.BlockState.of(withBlockState(property.getProperty(), value));
    }

    public BlockState getBlockState() {
        return BlockStateUtil.getDefaultState(block);
    }

    public net.pitan76.mcpitanlib.midohra.block.BlockState getMidohraBlockState() {
        return net.pitan76.mcpitanlib.midohra.block.BlockState.of(getBlockState());
    }

    public BlockEntity getBlockEntity() {
        return WorldUtil.getBlockEntity(getWorld(), getPos());
    }
}
