package net.pitan76.mcpitanlib.api.tag.v2;

import net.minecraft.core.Registry;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.inventory.MenuType;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.material.Fluid;
import net.pitan76.mcpitanlib.api.util.CompatIdentifier;

public class CompatTagKeyType<T> {
    public static final CompatTagKeyType<Block> BLOCK = of(Registry.f_122901_);
    public static final CompatTagKeyType<Item> ITEM = new CompatTagKeyType<>(Registry.f_122904_);
    public static final CompatTagKeyType<Fluid> FLUID = new CompatTagKeyType<>(Registry.f_122899_);
    public static final CompatTagKeyType<EntityType<?>> ENTITY_TYPE = new CompatTagKeyType<>(Registry.f_122903_);
    public static final CompatTagKeyType<BlockEntityType<?>> BLOCK_ENTITY_TYPE = new CompatTagKeyType<>(Registry.f_122907_);
    public static final CompatTagKeyType<MenuType<?>> SCREEN_HANDLER = new CompatTagKeyType<>(Registry.f_122913_);

    public final CompatIdentifier id;

    protected CompatTagKeyType(CompatIdentifier id) {
        this.id = id;
    }

    public static <T> CompatTagKeyType<T> of(CompatIdentifier id) {
        return new CompatTagKeyType<>(id);
    }

    // RegistryKey
    private ResourceKey<Registry<T>> key;

    protected CompatTagKeyType(ResourceKey<Registry<T>> key) {
        this.id = CompatIdentifier.fromMinecraft(key.m_211136_());
        this.key = key;
    }

    public static <T> CompatTagKeyType<T> of(ResourceKey<Registry<T>> key) {
        return new CompatTagKeyType<>(key);
    }

    @Deprecated
    public ResourceKey<Registry<T>> getRegistryKey() {
        return key;
    }
}
