package net.pitan76.mcpitanlib.api.event.block;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;

public class StateForNeighborUpdateArgs {
    public BlockState state;
    public Direction direction;
    public BlockState neighborState;
    public LevelAccessor world;
    public BlockPos pos;
    public BlockPos neighborPos;

    public StateForNeighborUpdateArgs(BlockState state, Direction direction, BlockState neighborState, LevelAccessor world, BlockPos pos, BlockPos neighborPos) {
        this.state = state;
        this.direction = direction;
        this.neighborState = neighborState;
        this.world = world;
        this.pos = pos;
        this.neighborPos = neighborPos;
    }

    public BlockState getState() {
        return state;
    }

    public BlockEntity getBlockEntity() {
        return world.m_7702_(pos);
    }

    public BlockState getBlockState(BlockPos pos) {
        return world.m_8055_(pos);
    }

    public BlockEntity getBlockEntity(BlockPos pos) {
        return world.m_7702_(pos);
    }

    public Direction getDirection() {
        return direction;
    }

    public BlockState getNeighborState() {
        return neighborState;
    }

    public LevelAccessor getWorld() {
        return world;
    }

    public BlockPos getPos() {
        return pos;
    }

    public BlockPos getNeighborPos() {
        return neighborPos;
    }
}
