package net.pitan76.mcpitanlib.api.util.color;

import net.minecraft.world.level.material.MaterialColor;

public class CompatMapColor {
    private final MaterialColor color;

    public static final CompatMapColor CLEAR = of(MaterialColor.f_76398_);
    public static final CompatMapColor PALE_GREEN = of(MaterialColor.f_76399_);
    public static final CompatMapColor PALE_YELLOW = of(MaterialColor.f_76400_);
    public static final CompatMapColor WHITE_GRAY = of(MaterialColor.f_76401_);
    public static final CompatMapColor BRIGHT_RED = of(MaterialColor.f_76402_);
    public static final CompatMapColor PALE_PURPLE = of(MaterialColor.f_76403_);
    public static final CompatMapColor IRON_GRAY = of(MaterialColor.f_76404_);
    public static final CompatMapColor DARK_GREEN = of(MaterialColor.f_76405_);
    public static final CompatMapColor WHITE = of(MaterialColor.f_76406_);
    public static final CompatMapColor LIGHT_BLUE_GRAY = of(MaterialColor.f_76407_);
    public static final CompatMapColor DIRT_BROWN = of(MaterialColor.f_76408_);
    public static final CompatMapColor STONE_GRAY = of(MaterialColor.f_76409_);
    public static final CompatMapColor WATER_BLUE = of(MaterialColor.f_76410_);
    public static final CompatMapColor OAK_TAN = of(MaterialColor.f_76411_);
    public static final CompatMapColor OFF_WHITE = of(MaterialColor.f_76412_);
    public static final CompatMapColor ORANGE = of(MaterialColor.f_76413_);
    public static final CompatMapColor MAGENTA = of(MaterialColor.f_76414_);
    public static final CompatMapColor LIGHT_BLUE = of(MaterialColor.f_76415_);
    public static final CompatMapColor YELLOW = of(MaterialColor.f_76416_);
    public static final CompatMapColor LIME = of(MaterialColor.f_76417_);
    public static final CompatMapColor PINK = of(MaterialColor.f_76418_);
    public static final CompatMapColor GRAY = of(MaterialColor.f_76419_);
    public static final CompatMapColor LIGHT_GRAY = of(MaterialColor.f_76420_);
    public static final CompatMapColor CYAN = of(MaterialColor.f_76421_);
    public static final CompatMapColor PURPLE = of(MaterialColor.f_76422_);
    public static final CompatMapColor BLUE = of(MaterialColor.f_76361_);
    public static final CompatMapColor BROWN = of(MaterialColor.f_76362_);
    public static final CompatMapColor GREEN = of(MaterialColor.f_76363_);
    public static final CompatMapColor RED = of(MaterialColor.f_76364_);
    public static final CompatMapColor BLACK = of(MaterialColor.f_76365_);
    public static final CompatMapColor GOLD = of(MaterialColor.f_76366_);
    public static final CompatMapColor DIAMOND_BLUE = of(MaterialColor.f_76367_);
    public static final CompatMapColor LAPIS_BLUE = of(MaterialColor.f_76368_);
    public static final CompatMapColor EMERALD_GREEN = of(MaterialColor.f_76369_);
    public static final CompatMapColor SPRUCE_BROWN = of(MaterialColor.f_76370_);
    public static final CompatMapColor DARK_RED = of(MaterialColor.f_76371_);
    public static final CompatMapColor TERRACOTTA_WHITE = of(MaterialColor.f_76372_);
    public static final CompatMapColor TERRACOTTA_ORANGE = of(MaterialColor.f_76373_);
    public static final CompatMapColor TERRACOTTA_MAGENTA = of(MaterialColor.f_76374_);
    public static final CompatMapColor TERRACOTTA_LIGHT_BLUE = of(MaterialColor.f_76375_);
    public static final CompatMapColor TERRACOTTA_YELLOW = of(MaterialColor.f_76376_);
    public static final CompatMapColor TERRACOTTA_LIME = of(MaterialColor.f_76377_);
    public static final CompatMapColor TERRACOTTA_PINK = of(MaterialColor.f_76378_);
    public static final CompatMapColor TERRACOTTA_GRAY = of(MaterialColor.f_76379_);
    public static final CompatMapColor TERRACOTTA_LIGHT_GRAY = of(MaterialColor.f_76380_);
    public static final CompatMapColor TERRACOTTA_CYAN = of(MaterialColor.f_76381_);
    public static final CompatMapColor TERRACOTTA_PURPLE = of(MaterialColor.f_76382_);
    public static final CompatMapColor TERRACOTTA_BLUE = of(MaterialColor.f_76383_);
    public static final CompatMapColor TERRACOTTA_BROWN = of(MaterialColor.f_76384_);
    public static final CompatMapColor TERRACOTTA_GREEN = of(MaterialColor.f_76385_);
    public static final CompatMapColor TERRACOTTA_RED = of(MaterialColor.f_76386_);
    public static final CompatMapColor TERRACOTTA_BLACK = of(MaterialColor.f_76388_);
    public static final CompatMapColor DULL_RED = of(MaterialColor.f_76389_);
    public static final CompatMapColor DULL_PINK = of(MaterialColor.f_76390_);
    public static final CompatMapColor DARK_CRIMSON = of(MaterialColor.f_76391_);
    public static final CompatMapColor TEAL = of(MaterialColor.f_76392_);
    public static final CompatMapColor DARK_AQUA = of(MaterialColor.f_76393_);
    public static final CompatMapColor DARK_DULL_PINK = of(MaterialColor.f_76394_);
    public static final CompatMapColor BRIGHT_TEAL = of(MaterialColor.f_76395_);
    public static final CompatMapColor DEEPSLATE_GRAY = of(MaterialColor.f_164534_);
    public static final CompatMapColor RAW_IRON_PINK = of(MaterialColor.f_164535_);
    public static final CompatMapColor LICHEN_GREEN = of(MaterialColor.f_164536_);

    public CompatMapColor(MaterialColor color) {
        this.color = color;
    }

    public static CompatMapColor of(MaterialColor color) {
        return new CompatMapColor(color);
    }

    public MaterialColor getColor() {
        return color;
    }

    public int getId() {
        return color.f_76397_;
    }

    public int getRgb() {
        return color.f_76396_;
    }

    public int getRenderColor(CompatBrightness brightness) {
        return color.m_192921_(brightness.get());
    }

    @Override
    public int hashCode() {
        return color.hashCode();
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        CompatMapColor other = (CompatMapColor) obj;
        return color.equals(other.color);
    }
}
