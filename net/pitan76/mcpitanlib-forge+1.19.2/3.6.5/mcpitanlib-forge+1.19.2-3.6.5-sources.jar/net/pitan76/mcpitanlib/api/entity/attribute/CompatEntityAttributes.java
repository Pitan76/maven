package net.pitan76.mcpitanlib.api.entity.attribute;

import net.minecraft.world.entity.ai.attributes.Attribute;
import net.minecraft.world.entity.ai.attributes.Attributes;

public class CompatEntityAttributes {

    public static final CompatEntityAttribute ARMOR = of(Attributes.f_22284_);
    public static final CompatEntityAttribute ARMOR_TOUGHNESS = of(Attributes.f_22285_);
    public static final CompatEntityAttribute ATTACK_DAMAGE = of(Attributes.f_22281_);
    public static final CompatEntityAttribute ATTACK_KNOCKBACK = of(Attributes.f_22282_);
    public static final CompatEntityAttribute ATTACK_SPEED = of(Attributes.f_22283_);
    public static final CompatEntityAttribute FOLLOW_RANGE = of(Attributes.f_22277_);
    public static final CompatEntityAttribute KNOCKBACK_RESISTANCE = of(Attributes.f_22278_);
    public static final CompatEntityAttribute LUCK = of(Attributes.f_22286_);
    public static final CompatEntityAttribute MOVEMENT_SPEED = of(Attributes.f_22279_);
    public static final CompatEntityAttribute MAX_HEALTH = of(Attributes.f_22276_);
    public static final CompatEntityAttribute JUMP_STRENGTH = of(Attributes.f_22288_);
    public static final CompatEntityAttribute GRAVITY = of(null);
    public static final CompatEntityAttribute FLYING_SPEED = of(Attributes.f_22280_);
    public static final CompatEntityAttribute BLOCK_BREAK_SPEED = of(null);
    public static final CompatEntityAttribute BLOCK_INTERACTION_RANGE = of(null);

    public static CompatEntityAttribute of(Attribute attribute) {
        return CompatEntityAttribute.of(attribute);
    }
}
