package net.pitan76.mcpitanlib.api.util;

import net.minecraft.core.NonNullList;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.Container;
import net.minecraft.world.ContainerHelper;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.pitan76.mcpitanlib.api.event.nbt.NbtRWArgs;
import net.pitan76.mcpitanlib.api.registry.CompatRegistryLookup;

public class InventoryUtil {
    public static boolean insertItem(ItemStack insertStack, NonNullList<ItemStack> inventory) {
        return insertItem(insertStack, inventory, false);
    }

    public static boolean insertItem(ItemStack insertStack, NonNullList<ItemStack> inventory, boolean test) {
        boolean isInserted = false;
        for (int i = 0; i < inventory.size(); i++) {
            ItemStack stack = inventory.get(i);
            if (stack.m_41619_()) {
                if (!test) inventory.set(i, insertStack);
                isInserted = true;
                break;
            } else if (canMergeItems(stack, insertStack)) {
                int j = insertStack.m_41613_();
                if (!test) stack.m_41769_(j);
                isInserted = j > 0;
                break;
            }
        }
        return isInserted;

    }

    public static boolean canMergeItems(ItemStack first, ItemStack second) {
        if (!first.m_150930_(second.m_41720_())) {
            return false;
        }
        if (first.m_41773_() != second.m_41773_()) {
            return false;
        }
        if (first.m_41613_() + second.m_41613_() > first.m_41741_()) {
            return false;
        }
        return ItemStackUtil.areNbtOrComponentEqual(first, second);
    }

    public static CompoundTag writeNbt(NbtRWArgs args, CompoundTag nbt, NonNullList<ItemStack> stacks, boolean setIfEmpty) {
        return ContainerHelper.m_18976_(nbt, stacks, setIfEmpty);
    }

    public static void readNbt(NbtRWArgs args, CompoundTag nbt, NonNullList<ItemStack> stacks) {
        ContainerHelper.m_18980_(nbt, stacks);
    }

    public static CompoundTag writeNbt(NbtRWArgs args, NonNullList<ItemStack> stacks, boolean setIfEmpty) {
        return ContainerHelper.m_18976_(args.getNbt(), stacks, setIfEmpty);
    }

    public static CompoundTag writeNbt(NbtRWArgs args, NonNullList<ItemStack> stacks) {
        return writeNbt(args, stacks, true);
    }

    public static void readNbt(NbtRWArgs args, NonNullList<ItemStack> stacks) {
        ContainerHelper.m_18980_(args.getNbt(), stacks);
    }

    public static void readNbt(CompatRegistryLookup registryLookup, CompoundTag nbt, NonNullList<ItemStack> stacks) {
        ContainerHelper.m_18980_(nbt, stacks);
    }

    public static CompoundTag writeNbt(CompatRegistryLookup registryLookup, CompoundTag nbt, NonNullList<ItemStack> stacks, boolean setIfEmpty) {
        return ContainerHelper.m_18976_(nbt, stacks, setIfEmpty);
    }

    public static CompoundTag writeNbt(CompatRegistryLookup registryLookup, CompoundTag nbt, NonNullList<ItemStack> stacks) {
        return writeNbt(registryLookup, nbt, stacks, true);
    }

    // deprecated
    /**
     * @deprecated Use {@link #writeNbt(NbtRWArgs, NonNullList)} instead
     */
    @Deprecated
    public static CompoundTag writeNbt(Level world, CompoundTag nbt, NonNullList<ItemStack> stacks) {
        return writeNbt(world, nbt, true, stacks);
    }

    /**
     * @deprecated Use {@link #writeNbt(NbtRWArgs, NonNullList, boolean)} instead
     */
    @Deprecated
    public static CompoundTag writeNbt(Level world, CompoundTag nbt, boolean setIfEmpty, NonNullList<ItemStack> stacks) {
        return ContainerHelper.m_18976_(nbt, stacks, setIfEmpty);
    }

    /**
     * @deprecated Use {@link #readNbt(NbtRWArgs, NonNullList)} instead
     */
    @Deprecated
    public static void readNbt(Level world, CompoundTag nbt, NonNullList<ItemStack> stacks) {
        ContainerHelper.m_18980_(nbt, stacks);
    }
    // ----

    public static SimpleContainer createSimpleInventory(int size) {
        return new SimpleContainer(size);
    }

    public static void copyToInv(NonNullList<ItemStack> from, Container to) {
        for (int i = 0; i < from.size(); i++) {
            to.m_6836_(i, from.get(i));
        }
    }

    public static void copyToList(Container from, NonNullList<ItemStack> to) {
        for (int i = 0; i < from.m_6643_(); i++) {
            to.set(i, from.m_8020_(i));
        }
    }

    public static int getSize(Container inventory) {
        return inventory.m_6643_();
    }

    public static ItemStack getStack(Container inventory, int slot) {
        return inventory.m_8020_(slot);
    }

    public static void setStack(Container inventory, int slot, ItemStack stack) {
        inventory.m_6836_(slot, stack);
    }

    public static boolean isEmpty(Container inventory) {
        return inventory.m_7983_();
    }

    public static ItemStack removeStack(Container inventory, int slot) {
        return inventory.m_8016_(slot);
    }

    public static ItemStack removeStack(Container inventory, int slot, int amount) {
        return inventory.m_7407_(slot, amount);
    }

    public static void clear(Container inventory) {
        inventory.m_6211_();
    }

    public static void markDirty(Container inventory) {
        inventory.m_6596_();
    }
}
