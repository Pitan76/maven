package net.pitan76.mcpitanlib.api.client.render;

import net.minecraft.client.renderer.RenderType;
import net.pitan76.mcpitanlib.api.util.CompatIdentifier;

public class CompatRenderLayer {
    public static final CompatRenderLayer CUTOUT = new CompatRenderLayer(RenderType.m_110463_());
    public static final CompatRenderLayer CUTOUT_MIPPED = new CompatRenderLayer(RenderType.m_110457_());
    public static final CompatRenderLayer TRANSLUCENT = new CompatRenderLayer(RenderType.m_110466_());
    public static final CompatRenderLayer TRANSLUCENT_MOVING_BLOCK = new CompatRenderLayer(RenderType.m_110469_());
    public static final CompatRenderLayer SOLID = new CompatRenderLayer(RenderType.m_110451_());
    public static final CompatRenderLayer LINES = new CompatRenderLayer(RenderType.m_110504_());
    public static final CompatRenderLayer LINE_STRIP = new CompatRenderLayer(RenderType.m_173247_());
    public static final CompatRenderLayer GLINT = new CompatRenderLayer(RenderType.m_110490_());

    public final RenderType layer;

    public CompatRenderLayer(RenderType layer) {
        this.layer = layer;
    }

    public RenderType raw() {
        return layer;
    }

    public static CompatRenderLayer getEntityCutout(CompatIdentifier id) {
        return new CompatRenderLayer(RenderType.m_110452_(id.toMinecraft()));
    }

    public static CompatRenderLayer getEntityCutoutNoCull(CompatIdentifier id) {
        return new CompatRenderLayer(RenderType.m_110458_(id.toMinecraft()));
    }

    public static CompatRenderLayer getEntityTranslucent(CompatIdentifier id) {
        return new CompatRenderLayer(RenderType.m_110473_(id.toMinecraft()));
    }

    public static CompatRenderLayer getArmorCutoutNoCull(CompatIdentifier id) {
        return new CompatRenderLayer(RenderType.m_110431_(id.toMinecraft()));
    }

    public static CompatRenderLayer getEntitySolid(CompatIdentifier id) {
        return new CompatRenderLayer(RenderType.m_110446_(id.toMinecraft()));
    }
}
