package net.pitan76.mcpitanlib.api.event.entity;

import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.SynchedEntityData;

public class InitDataTrackerArgs {
    public SynchedEntityData tracker;

    public InitDataTrackerArgs(SynchedEntityData tracker) {
        this.tracker = tracker;
    }

    public <T> void set(EntityDataAccessor<T> data, T value) {
        tracker.m_135381_(data, value);
    }

    public <T> void addTracking(EntityDataAccessor<T> data, T value) {
        if (tracker != null) {
            set(data, value);
            return;
        }
    }
}
