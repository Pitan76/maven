package net.pitan76.mcpitanlib.api.util.world;

import net.minecraft.core.BlockPos;
import net.minecraft.tags.FluidTags;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.LevelReader;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.dimension.DimensionType;
import net.minecraft.world.level.material.Fluid;
import net.minecraft.world.level.material.FluidState;
import net.minecraft.world.phys.AABB;
import net.pitan76.mcpitanlib.midohra.entity.EntityTypeWrapper;

import java.util.List;
import java.util.Optional;
import java.util.function.Predicate;

public class WorldViewUtil {

    public static boolean isClient(LevelReader world) {
        return world.m_5776_();
    }

    public static BlockState getBlockState(LevelReader world, BlockPos pos) {
        return world.m_8055_(pos);
    }

    public static Block getBlock(LevelReader world, BlockPos pos) {
        return getBlockState(world, pos).m_60734_();
    }

    public static BlockEntity getBlockEntity(LevelReader world, BlockPos pos) {
        return world.m_7702_(pos);
    }

    public static <T extends BlockEntity> Optional<T> getBlockEntity(LevelReader world, BlockPos pos, BlockEntityType<T> type) {
        return world.m_141902_(pos, type);
    }

    public static FluidState getFluidState(LevelReader world, BlockPos pos) {
        return getBlockState(world, pos).m_60819_();
    }

    public static Fluid getFluid(LevelReader world, BlockPos pos) {
        return getFluidState(world, pos).m_76152_();
    }

    public static int getBottomY(LevelReader world) {
        return world.m_141937_();
    }

    public static int getTopY(LevelReader world) {
        return world.m_151558_();
    }

    public static boolean isChunkLoaded(LevelReader world, BlockPos pos) {
        return world.m_46805_(pos);
    }

    public static boolean isRegionLoaded(LevelReader world, BlockPos min, BlockPos max) {
        return world.m_46832_(min, max);
    }

    public static DimensionType getDimensionType(LevelReader world) {
        return world.m_6042_();
    }

    public static boolean isAirBlock(LevelReader world, BlockPos pos) {
        return getBlockState(world, pos).m_60795_();
    }

    public static boolean isOpaqueBlock(LevelReader world, BlockPos pos) {
        return getBlockState(world, pos).m_60815_();
    }

    public static boolean isWater(LevelReader world, BlockPos pos) {
        return getFluidState(world, pos).m_205070_(FluidTags.f_13131_);
    }

    public static <T extends Entity> List<T> getEntitiesByClass(LevelAccessor world, Class<T> entityClass, AABB box, Predicate<? super T> predicate) {
        return world.m_6443_(entityClass, box, predicate);
    }

    public static <T extends Entity> List<T> getEntitiesByClass(LevelAccessor world, Class<T> entityClass, net.pitan76.mcpitanlib.midohra.util.math.Box box, Predicate<? super T> predicate) {
        return getEntitiesByClass(world, entityClass, box.toMinecraft(), predicate);
    }

    public static <T extends Entity> List<T> getEntitiesByType(LevelAccessor world, EntityType<T> entityType, AABB box, Predicate<? super Entity> predicate) {
        return world.m_142425_(entityType, box, predicate);
    }

    public static <T extends Entity> List<T> getEntitiesByType(LevelAccessor world, EntityType<T> entityType, net.pitan76.mcpitanlib.midohra.util.math.Box box, Predicate<? super Entity> predicate) {
        return getEntitiesByType(world, entityType, box.toMinecraft(), predicate);
    }

    public static List<?> getEntitiesByType(LevelAccessor world, EntityTypeWrapper entityType, AABB box, Predicate<? super Entity> predicate) {
        return getEntitiesByType(world, entityType.get(), box, predicate);
    }
}
