package net.pitan76.mcpitanlib.api.entity;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.protocol.Packet;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.level.Level;
import net.pitan76.mcpitanlib.api.nbt.NbtTag;

public class ExtendEntity extends Entity {
    public ExtendEntity(EntityType<?> type, Level world) {
        super(type, world);
    }

    public void m_8097_() {
    }

    public void m_7378_(CompoundTag nbt) {

    }

    public void m_7380_(CompoundTag nbt) {

    }

    public Packet<?> m_5654_() {
        return null;
    }

    // 互換性用 (NbtTag型をOverrideすること)
    public void writeNbt(NbtTag nbt) {
        super.m_20240_(nbt);
    }

    public void readNbt(NbtTag nbt) {
        super.m_20258_(nbt);
    }

    // 1.18
    @Override
    public CompoundTag m_20240_(CompoundTag nbt) {
        this.writeNbt(NbtTag.from(nbt));
        return nbt;
    }

    @Override
    public void m_20258_(CompoundTag nbt) {
        this.readNbt(NbtTag.from(nbt));
    }

    // 1.14
    public CompoundTag toTag(CompoundTag nbt) {
        this.writeNbt(NbtTag.from(nbt));
        return nbt;
    }

    public CompoundTag fromTag(CompoundTag nbt) {
        this.readNbt(NbtTag.from(nbt));
        return nbt;
    }

    @Override
    public Level m_9236_() {
        return super.m_9236_();
    }
}