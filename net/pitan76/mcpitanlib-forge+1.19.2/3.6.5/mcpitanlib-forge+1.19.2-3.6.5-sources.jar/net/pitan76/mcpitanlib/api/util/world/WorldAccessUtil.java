package net.pitan76.mcpitanlib.api.util.world;

import net.minecraft.core.BlockPos;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.material.Fluid;

public class WorldAccessUtil extends WorldViewUtil {

    public static void scheduleBlockTick(LevelAccessor world, BlockPos pos, Block block, int delay) {
        world.m_186460_(pos, block, delay);
    }

    public static void scheduleFluidTick(LevelAccessor world, BlockPos pos, Fluid fluid, int delay) {
        world.m_186469_(pos, fluid, delay);
    }

    public static boolean setBlockState(LevelAccessor world, BlockPos pos, BlockState state, int flags) {
        return world.m_7731_(pos, state, flags);
    }

    public static boolean setBlockState(LevelAccessor world, BlockPos pos, BlockState state, int flags, int maxUpdateDepth) {
        return world.m_6933_(pos, state, flags, maxUpdateDepth);
    }

    public static boolean setBlockState(LevelAccessor world, BlockPos pos, BlockState state) {
        return setBlockState(world, pos, state, 3);
    }

    public static BlockState getBlockState(LevelAccessor world, BlockPos pos) {
        return world.m_8055_(pos);
    }

    public static boolean breakBlock(LevelAccessor world, BlockPos pos, boolean drop) {
        return world.m_46961_(pos, drop);
    }

    public static boolean breakBlock(LevelAccessor world, BlockPos pos, boolean drop, Entity entity) {
        return world.m_46953_(pos, drop, entity);
    }

    public static boolean removeBlock(LevelAccessor world, BlockPos pos, boolean move) {
        return world.m_7471_(pos, move);
    }

    public static MinecraftServer getServer(LevelAccessor world) {
        return world.m_7654_();
    }
}
