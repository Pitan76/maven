package net.pitan76.mcpitanlib.api.util.client;

import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.renderer.GameRenderer;
import net.minecraft.resources.ResourceLocation;

public class RenderUtil {
    public static void setShaderToPositionTexProgram() {
        RenderSystem.m_157427_(GameRenderer::m_172817_);
    }

    public static void setShaderColor(float red, float green, float blue, float alpha) {
        RenderSystem.m_157429_(red, green, blue, alpha);
    }

    public static void setShaderTexture(int texture, ResourceLocation id) {
        RenderSystem.m_157456_(texture, id);
    }

    public static void enableDepthTest() {
        RenderSystem.m_69482_();
    }

    public static void enableTexture() {
        RenderSystem.m_69493_();
    }

    public static void disableTexture() {
        RenderSystem.m_69472_();
    }

    public static class RendererUtil extends ScreenUtil.RendererUtil {}
}