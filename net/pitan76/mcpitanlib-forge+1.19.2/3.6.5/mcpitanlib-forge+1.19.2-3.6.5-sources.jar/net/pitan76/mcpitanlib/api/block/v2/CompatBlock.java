package net.pitan76.mcpitanlib.api.block.v2;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.LevelReader;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.Rotation;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.VoxelShape;
import net.pitan76.mcpitanlib.api.block.CompatBlockRenderType;
import net.pitan76.mcpitanlib.api.block.ExtendBlock;
import net.pitan76.mcpitanlib.api.block.args.RenderTypeArgs;
import net.pitan76.mcpitanlib.api.block.args.RotateArgs;
import net.pitan76.mcpitanlib.api.block.args.SideInvisibleArgs;
import net.pitan76.mcpitanlib.api.block.args.v2.*;
import net.pitan76.mcpitanlib.midohra.block.BlockWrapper;
import org.jetbrains.annotations.Nullable;

public class CompatBlock extends ExtendBlock {

    public CompatibleBlockSettings settings;

    public CompatBlock(CompatibleBlockSettings settings) {
        super(settings);
        this.settings = settings;
    }

    public CompatibleBlockSettings getCompatSettings() {
        return settings;
    }

    public BlockWrapper getWrapper() {
        return BlockWrapper.of(this);
    }

    @Override
    @Deprecated
    public RenderShape m_7514_(BlockState state) {
        return getRenderType(new RenderTypeArgs(state)).renderType;
    }

    public CompatBlockRenderType getRenderType(RenderTypeArgs args) {
        return new CompatBlockRenderType(super.m_7514_(args.state));
    }

    @Override
    @Deprecated
    public BlockState m_6843_(BlockState state, Rotation rotation) {
        return rotate(new RotateArgs(state, rotation)).toMinecraft();
    }

    public net.pitan76.mcpitanlib.midohra.block.BlockState rotate(RotateArgs args) {
        return net.pitan76.mcpitanlib.midohra.block.BlockState.of(super.m_6843_(args.state, args.rotation));
    }

    @Override
    @Deprecated
    public boolean m_6104_(BlockState state, BlockState stateFrom, Direction direction) {
        return isSideInvisible(new SideInvisibleArgs(state, stateFrom, direction));
    }

    public boolean isSideInvisible(SideInvisibleArgs args) {
        return super.m_6104_(args.state, args.stateFrom, args.direction);
    }

    /**
     * Compatible for getDefaultState()
     * @return default block state
     */
    public net.pitan76.mcpitanlib.midohra.block.BlockState getDefaultMidohraState() {
        return net.pitan76.mcpitanlib.midohra.block.BlockState.of(getNewDefaultState());
    }

    /**
     * Compatible for setDefaultState()
     * @param state BlockState
     */
    public void setDefaultState(net.pitan76.mcpitanlib.midohra.block.BlockState state) {
        setNewDefaultState(state.toMinecraft());
    }

    public @Nullable net.pitan76.mcpitanlib.midohra.block.BlockState getPlacementState(PlacementStateArgs args) {
        return net.pitan76.mcpitanlib.midohra.block.BlockState.of(super.m_5573_(args.ctx));
    }

    @Override
    public @Nullable BlockState m_5573_(BlockPlaceContext ctx) {
        return getPlacementState(new PlacementStateArgs(ctx)).toMinecraft();
    }

    @Deprecated
    @Override
    public @Nullable BlockState getPlacementState(net.pitan76.mcpitanlib.api.event.block.PlacementStateArgs args) {
        return super.getPlacementState(args);
    }

    public net.pitan76.mcpitanlib.midohra.block.BlockState getStateForNeighborUpdate(StateForNeighborUpdateArgs args) {
        return net.pitan76.mcpitanlib.midohra.block.BlockState.of(super.m_7417_(args.state, args.direction, args.neighborState, args.world, args.pos, args.neighborPos));
    }

    @Override
    public BlockState m_7417_(BlockState state, Direction direction, BlockState neighborState, LevelAccessor world, BlockPos pos, BlockPos neighborPos) {
        return getStateForNeighborUpdate(new StateForNeighborUpdateArgs(state, direction, neighborState, world, pos, neighborPos)).toMinecraft();
    }

    @Deprecated
    @Override
    public BlockState getStateForNeighborUpdate(net.pitan76.mcpitanlib.api.event.block.StateForNeighborUpdateArgs args) {
        return super.getStateForNeighborUpdate((args));
    }

    public VoxelShape getOutlineShape(OutlineShapeEvent e) {
        return super.m_5940_(e.state.toMinecraft(), e.world.getRaw(), e.pos.toMinecraft(), e.context);
    }

    @Override
    public VoxelShape m_5940_(BlockState state, BlockGetter world, BlockPos pos, CollisionContext context) {
        return getOutlineShape(new OutlineShapeEvent(state, world, pos, context));
    }

    @Deprecated
    @Override
    public VoxelShape getOutlineShape(net.pitan76.mcpitanlib.api.event.block.OutlineShapeEvent e) {
        return super.getOutlineShape(e);
    }

    public VoxelShape getCollisionShape(CollisionShapeEvent e) {
        return super.m_5939_(e.state.toMinecraft(), e.world.getRaw(), e.pos.toMinecraft(), e.context);
    }

    @Deprecated
    @Override
    public VoxelShape m_5939_(BlockState state, BlockGetter world, BlockPos pos, CollisionContext context) {
        return getCollisionShape(new CollisionShapeEvent(state, world, pos, context));
    }

    @Deprecated
    @Override
    public VoxelShape getCollisionShape(net.pitan76.mcpitanlib.api.event.block.CollisionShapeEvent e) {
        return super.getCollisionShape(e);
    }

    @Deprecated
    @Override
    public boolean m_7278_(BlockState state) {
        return hasComparatorOutput(new HasComparatorOutputArgs(state));
    }

    public boolean hasComparatorOutput(HasComparatorOutputArgs args) {
        return super.m_7278_(args.state);
    }

    @Deprecated
    @Override
    public int m_6782_(BlockState state, Level world, BlockPos pos) {
        return getComparatorOutput(new GetComparatorOutputArgs(state, world, pos));
    }

    public int getComparatorOutput(GetComparatorOutputArgs args) {
        return super.m_6782_(args.state, args.world, args.pos);
    }

    @Deprecated
    @Override
    public boolean m_7898_(BlockState state, LevelReader world, BlockPos pos) {
        return canPlaceAt(new CanPlaceAtArgs(state, world, pos));
    }

    public boolean canPlaceAt(CanPlaceAtArgs args) {
        return super.m_7898_(args.state, args.world, args.pos);
    }
}
