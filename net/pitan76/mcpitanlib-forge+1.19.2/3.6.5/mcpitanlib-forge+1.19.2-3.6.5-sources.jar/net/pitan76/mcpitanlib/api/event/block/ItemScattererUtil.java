package net.pitan76.mcpitanlib.api.event.block;

import net.minecraft.core.BlockPos;
import net.minecraft.core.NonNullList;
import net.minecraft.world.Container;
import net.minecraft.world.Containers;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.pitan76.mcpitanlib.api.util.WorldUtil;

public class ItemScattererUtil {
    public static void spawn(Level world, BlockPos pos, BlockEntity blockEntity) {
        if (blockEntity instanceof Container) {
            spawn(world, pos, (Container) blockEntity);
        }
    }

    public static void spawn(Level world, BlockPos pos, Container inventory) {
        Containers.m_19002_(world, pos, inventory);
    }

    public static void spawn(Level world, BlockPos pos, ItemStack stack) {
        Containers.m_18992_(world, pos.m_123341_(), pos.m_123342_(), pos.m_123343_(), stack);
    }

    public static void spawn(Level world, BlockPos pos, NonNullList<ItemStack> stacks) {
        Containers.m_19010_(world, pos, stacks);
    }

    public static void onStateReplaced(StateReplacedEvent e) {
        onStateReplaced(e.getState(), e.getNewState(), e.getWorld(), e.getPos());
    }

    public static void onStateReplaced(BlockState state, BlockState newState, Level world, BlockPos pos) {
        if (state.m_60713_(newState.m_60734_())) return;
        BlockEntity blockEntity = world.m_7702_(pos);
        if (blockEntity instanceof Container) {
            spawn(world, pos, (Container) blockEntity);
            WorldUtil.updateComparators(world, pos, state.m_60734_());
        }
    }

    public static void spawn(net.pitan76.mcpitanlib.midohra.world.World world, net.pitan76.mcpitanlib.midohra.util.math.BlockPos pos, ItemStack stack) {
        spawn(world.getRaw(), pos.toMinecraft(), stack);
    }

    public static void spawn(net.pitan76.mcpitanlib.midohra.world.World world, net.pitan76.mcpitanlib.midohra.util.math.BlockPos pos, NonNullList<ItemStack> stacks) {
        spawn(world.getRaw(), pos.toMinecraft(), stacks);
    }

    public static void spawn(net.pitan76.mcpitanlib.midohra.world.World world, net.pitan76.mcpitanlib.midohra.util.math.BlockPos pos, Container inventory) {
        spawn(world.getRaw(), pos.toMinecraft(), inventory);
    }
}
