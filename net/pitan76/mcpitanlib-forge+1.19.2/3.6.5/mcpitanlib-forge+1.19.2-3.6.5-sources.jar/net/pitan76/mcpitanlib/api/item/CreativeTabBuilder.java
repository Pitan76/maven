package net.pitan76.mcpitanlib.api.item;

import dev.architectury.registry.CreativeTabRegistry;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.pitan76.mcpitanlib.api.util.CompatIdentifier;

import java.util.HashMap;
import java.util.Map;
import java.util.function.Supplier;

public class CreativeTabBuilder {
    @Deprecated
    public static final Map<ResourceLocation, CreativeModeTab> itemGroupMap = new HashMap<>();

    @Deprecated
    public static final Map<ResourceLocation, CreativeTabBuilder> itemGroupBuilderMap = new HashMap<>();

    private final ResourceLocation identifier;
    private Component displayName = null;
    private Supplier<ItemStack> iconSupplier = null;
    private boolean noRenderedName = false;
    private boolean noScrollbar = false;
    private boolean special = false;
    private String texture;

    @Deprecated
    // Recommend: create(identifier)
    public CreativeTabBuilder(ResourceLocation identifier) {
        this.identifier = identifier;
        itemGroupBuilderMap.put(identifier, this);
    }

    public static CreativeTabBuilder create(ResourceLocation identifier) {
        return new CreativeTabBuilder(identifier);
    }

    public static CreativeTabBuilder create(CompatIdentifier identifier) {
        return create(identifier.toMinecraft());
    }

    public CreativeTabBuilder setDisplayName(Component text) {
        this.displayName = text;
        return this;
    }

    /**
     * Set icon
     * @param iconSupplier Icon supplier
     * @return CreativeTabBuilder
     */
    public CreativeTabBuilder setIcon(Supplier<ItemStack> iconSupplier) {
        this.iconSupplier = iconSupplier;
        return this;
    }

    /**
     * Set icon (Already registered item only)
     * @param item Item
     * @return CreativeTabBuilder
     */
    public CreativeTabBuilder setIcon(Item item) {
        return setIcon(() -> new ItemStack(item));
    }

    public void noRenderedName() {
        this.noRenderedName = true;
    }

    public void noScrollbar() {
        this.noScrollbar = true;
    }

    public void special() {
        this.special = true;
    }

    public void setTexture(String texture) {
        this.texture = texture;
    }

    /**
     * Build ItemGroup (If loader is forge, not recommended)
     * @return ItemGroup
     */
    public CreativeModeTab build() {
        if (itemGroupMap.containsKey(identifier)) return itemGroupMap.get(identifier);
        CreativeModeTab itemGroup = CreativeTabRegistry.create(identifier, iconSupplier);
        if (displayName != null) itemGroup.m_40784_(displayName.getString());
        if (noRenderedName) itemGroup.m_40784_("");
        if (noScrollbar) itemGroup.m_40792_();
        if (special) itemGroup.m_6563_();
        if (texture != null) itemGroup.m_40779_(texture);
        itemGroupMap.put(identifier, itemGroup);
        return itemGroup;
    }

    public ResourceLocation getIdentifier() {
        return identifier;
    }
}
