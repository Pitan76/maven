package net.pitan76.mcpitanlib.api.registry;

import net.minecraft.nbt.CompoundTag;
import net.pitan76.mcpitanlib.api.event.nbt.NbtRWArgs;
import net.pitan76.mcpitanlib.api.event.nbt.ReadNbtArgs;
import net.pitan76.mcpitanlib.api.event.nbt.WriteNbtArgs;

public class CompatRegistryLookup {

    public CompatRegistryLookup() {

    }

    public NbtRWArgs getNbtRWArgs(CompoundTag nbt) {
        return new NbtRWArgs(nbt);
    }

    public WriteNbtArgs createWriteNbtArgs(CompoundTag nbt) {
        return new WriteNbtArgs(nbt);
    }

    public ReadNbtArgs createReadNbtArgs(CompoundTag nbt) {
        return new ReadNbtArgs(nbt);
    }
}
