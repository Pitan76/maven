package net.pitan76.mcpitanlib.api.util.client;

import net.minecraft.client.MouseHandler;

public class MouseUtil {

    public static MouseHandler getMouse() {
        return ClientUtil.getMouse();
    }

    public static double getMouseX() {
        return getMouse().m_91589_();
    }

    public static double getMouseY() {
        return getMouse().m_91594_();
    }

    public static boolean isCursorLocked() {
        return getMouse().m_91600_();
    }

    public static void lockCursor() {
        getMouse().m_91601_();
    }

    public static void unlockCursor() {
        getMouse().m_91602_();
    }

    public static void tick() {
        getMouse().m_91523_();
    }

    public static boolean wasLeftButtonClicked() {
        return getMouse().m_91560_();
    }

    public static boolean wasRightButtonClicked() {
        return getMouse().m_91584_();
    }

    public static boolean wasMiddleButtonClicked() {
        return getMouse().m_168090_();
    }
}
