package net.pitan76.mcpitanlib.api.util.entity;

import net.minecraft.world.entity.projectile.Snowball;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.pitan76.mcpitanlib.api.util.ItemStackUtil;

public class SnowballEntityUtil {
    public static Snowball create(Level world, double x, double y, double z) {
        return new Snowball(world, x, y, z);
    }

    public static Snowball create(Level world, double x, double y, double z, ItemStack stack) {
        Snowball entity = create(world, x, y, z);
        entity.m_37446_(stack);
        return entity;
    }

    public static void setVelocity(Snowball entity, double x, double y, double z, float velocity, float divergence) {
        entity.m_6686_(x, y, z, velocity, divergence);
    }

    public static void setItem(Snowball entity, ItemStack stack) {
        entity.m_37446_(stack);
    }

    public static ItemStack getItem(Snowball entity) {
        return entity.m_7846_();
    }
}
