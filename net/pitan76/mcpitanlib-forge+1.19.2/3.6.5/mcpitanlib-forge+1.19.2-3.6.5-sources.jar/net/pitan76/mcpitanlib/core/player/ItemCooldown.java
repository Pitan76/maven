package net.pitan76.mcpitanlib.core.player;

import net.minecraft.world.item.Item;
import net.pitan76.mcpitanlib.api.entity.Player;

public class ItemCooldown {
    public final Player player;

    public ItemCooldown(Player player) {
        this.player = player;
    }

    public boolean isCoolingDown(Item item) {
        return player.getItemCooldownManager().m_41519_(item);
    }

    public void set(Item item, int duration) {
        player.getItemCooldownManager().m_41524_(item, duration);
    }
}
