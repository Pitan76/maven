package net.pitan76.mcpitanlib.api.util.recipe.input;

import net.minecraft.world.entity.player.StackedContents;
import net.minecraft.world.inventory.CraftingContainer;
import net.minecraft.world.item.ItemStack;
import net.pitan76.mcpitanlib.api.recipe.input.CompatRecipeInput;
import net.pitan76.mcpitanlib.api.util.ItemStackUtil;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class CraftingRecipeInputUtil {
    public static Optional<CraftingContainer> get(CompatRecipeInput<?> input) {
        if (input.getInput() instanceof CraftingContainer) {
            return Optional.of((CraftingContainer) input.getInput());
        }
        return Optional.empty();
    }

    public static CompatRecipeInput<?> create(CraftingContainer input) {
        return new CompatRecipeInput<>(input);
    }

    public static CompatRecipeInput<?> create(int width, int height, List<ItemStack> stacks) {

        CraftingContainer inventory = new CraftingContainer(null, width, height);

        int size = stacks.size();
        for (int i = 0; i < size; i++) {
            inventory.m_6836_(i, stacks.get(i));
        }

        return new CompatRecipeInput<>(inventory);
    }

    public static ItemStack getStack(CraftingContainer input, int x, int y) {
        return input.m_8020_(x + y * input.m_39347_());
    }

    public static ItemStack getStack(CompatRecipeInput<?> input, int x, int y) {
        Optional<CraftingContainer> recipeInput = get(input);
        if (!recipeInput.isPresent()) return ItemStackUtil.empty();

        return getStack(recipeInput.get(), x, y);
    }

    public static net.pitan76.mcpitanlib.midohra.item.ItemStack getMidohraStack(CompatRecipeInput<?> input, int x, int y) {
        return net.pitan76.mcpitanlib.midohra.item.ItemStack.of(getStack(input, x, y));
    }

    public static StackedContents getRecipeMatcher(CraftingContainer input) {
        return null;
    }

    public static StackedContents getRecipeMatcher(CompatRecipeInput<?> input) {
        Optional<CraftingContainer> recipeInput = get(input);
        if (!recipeInput.isPresent()) return null;

        return getRecipeMatcher(recipeInput.get());
    }

    public static List<ItemStack> getStacks(CraftingContainer input) {
        List<ItemStack> stacks = new ArrayList<>();
        int size = input.m_6643_();
        for (int i = 0; i < size; i++) {
            stacks.add(input.m_8020_(i));
        }
        return stacks;
    }

    public static List<ItemStack> getStacks(CompatRecipeInput<?> input) {
        Optional<CraftingContainer> recipeInput = get(input);
        if (!recipeInput.isPresent()) return null;

        return getStacks(recipeInput.get());
    }

    public static int getWidth(CraftingContainer input) {
        return input.m_39347_();
    }

    public static int getWidth(CompatRecipeInput<?> input) {
        Optional<CraftingContainer> recipeInput = get(input);
        if (!recipeInput.isPresent()) return -1;

        return getWidth(recipeInput.get());
    }

    public static int getHeight(CraftingContainer input) {
        return input.m_39346_();
    }

    public static int getHeight(CompatRecipeInput<?> input) {
        Optional<CraftingContainer> recipeInput = get(input);
        if (!recipeInput.isPresent()) return -1;

        return getHeight(recipeInput.get());
    }

    public static int getStackCount(CraftingContainer input) {
        return input.m_6643_();
    }

    public static int getStackCount(CompatRecipeInput<?> input) {
        Optional<CraftingContainer> recipeInput = get(input);
        if (!recipeInput.isPresent()) return -1;

        return getStackCount(recipeInput.get());
    }
}
