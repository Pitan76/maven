package net.pitan76.mcpitanlib.api.util.color;

import net.minecraft.world.level.material.MaterialColor;

public class CompatBrightness {
    private final MaterialColor.Brightness brightness;

    public static final CompatBrightness LOW = of(MaterialColor.Brightness.LOW);
    public static final CompatBrightness NORMAL = of(MaterialColor.Brightness.NORMAL);
    public static final CompatBrightness HIGH = of(MaterialColor.Brightness.HIGH);
    public static final CompatBrightness LOWEST = of(MaterialColor.Brightness.LOWEST);

    public CompatBrightness(MaterialColor.Brightness brightness) {
        this.brightness = brightness;
    }

    public static CompatBrightness of(MaterialColor.Brightness brightness) {
        return new CompatBrightness(brightness);
    }

    public MaterialColor.Brightness get() {
        return brightness;
    }

    public String getName() {
        return get().name();
    }

    public int getId() {
        return get().f_192933_;
    }

    public int getBrightness() {
        return get().f_192934_;
    }

    @Override
    public int hashCode() {
        return brightness.hashCode();
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        CompatBrightness other = (CompatBrightness) obj;
        return brightness == other.brightness;
    }
}
