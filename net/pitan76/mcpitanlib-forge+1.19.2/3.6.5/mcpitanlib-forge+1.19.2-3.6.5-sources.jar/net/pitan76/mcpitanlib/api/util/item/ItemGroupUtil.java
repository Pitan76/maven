package net.pitan76.mcpitanlib.api.util.item;

import net.minecraft.network.chat.MutableComponent;
import net.minecraft.network.chat.contents.TranslatableContents;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.CreativeModeTab;
import net.pitan76.mcpitanlib.api.util.CompatIdentifier;

public class ItemGroupUtil {
    public static ResourceLocation toID(CreativeModeTab itemGroup) {
        if (itemGroup.m_40786_() instanceof MutableComponent) {
            MutableComponent mutableText = (MutableComponent) itemGroup.m_40786_();
            if (mutableText.m_214077_() instanceof TranslatableContents) {
                TranslatableContents translatableTextContent = (TranslatableContents) mutableText.m_214077_();
                String[] strings = translatableTextContent.m_237508_().split("\\.");

                if (strings.length == 3)
                    return new ResourceLocation(strings[1], strings[2]);

            }
        }

        return CompatIdentifier.empty().toMinecraft();
    }

    public static CreativeModeTab fromId(ResourceLocation identifier) {
        return null;
    }

    public static boolean isExist(ResourceLocation identifier) {
        return false;
    }

    public static CompatIdentifier toCompatID(CreativeModeTab itemGroup) {
        return CompatIdentifier.fromMinecraft(toID(itemGroup));
    }

    public static CreativeModeTab fromId(CompatIdentifier identifier) {
        return fromId(identifier.toMinecraft());
    }

    public static boolean isExist(CompatIdentifier identifier) {
        return isExist(identifier.toMinecraft());
    }

    public static int getRawId(CreativeModeTab itemGroup) {
        return itemGroup.m_40775_();
    }

    public static CreativeModeTab fromIndex(int index) {
        return CreativeModeTab.f_40748_[index];
    }
}
