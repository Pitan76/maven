package net.pitan76.mcpitanlib.api.util.inventory;

import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.ItemStack;
import net.pitan76.mcpitanlib.api.entity.Player;

public class CompatPlayerInventory implements ICompatInventory {
    public Inventory inv;

    public CompatPlayerInventory(Inventory inv) {
        this.inv = inv;
    }

    public Player getPlayer() {
        return PlayerInventoryUtil.getPlayer(inv);
    }

    public int getSelectedSlot() {
        return PlayerInventoryUtil.getSelectedSlot(inv);
    }

    public void setSelectedSlot(int slot) {
        PlayerInventoryUtil.setSelectedSlot(inv, slot);
    }

    public void dropAllItems() {
        PlayerInventoryUtil.dropAllItems(inv);
    }

    public void offerOrDrop(ItemStack stack) {
        inv.m_150079_(stack);
    }

    public void offerOrDrop(net.pitan76.mcpitanlib.midohra.item.ItemStack stack) {
        offerOrDrop(stack.toMinecraft());
    }

    public Inventory getRaw() {
        return inv;
    }

    @Override
    public int m_6643_() {
        return inv.m_6643_();
    }

    @Override
    public boolean m_7983_() {
        return inv.m_7983_();
    }

    @Override
    public ItemStack m_8020_(int slot) {
        return inv.m_8020_(slot);
    }

    @Override
    public ItemStack m_7407_(int slot, int count) {
        return inv.m_7407_(slot, count);
    }

    @Override
    public ItemStack m_8016_(int slot) {
        return inv.m_8016_(slot);
    }

    @Override
    public void m_6836_(int slot, ItemStack itemStack) {
        inv.m_6836_(slot, itemStack);
    }

    @Override
    public void m_6596_() {
        inv.m_6596_();
    }

    @Override
    public boolean m_6542_(net.minecraft.world.entity.player.Player player) {
        return inv.m_6542_(player);
    }

    @Override
    public void m_6211_() {
        inv.m_6211_();
    }
}

