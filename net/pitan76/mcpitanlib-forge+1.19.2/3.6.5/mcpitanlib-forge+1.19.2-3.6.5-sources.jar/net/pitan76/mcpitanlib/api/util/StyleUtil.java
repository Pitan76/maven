package net.pitan76.mcpitanlib.api.util;

import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.ClickEvent;
import net.minecraft.network.chat.HoverEvent;
import net.minecraft.network.chat.Style;

public class StyleUtil {
    public static Style emptyStyle() {
        return Style.f_131099_;
    }

    public static Style withColor(Style style, int color) {
        return style.m_178520_(color);
    }

    public static Style withBold(Style style, boolean bold) {
        return style.m_131136_(bold);
    }

    public static Style withItalic(Style style, boolean italic) {
        return style.m_131155_(italic);
    }

    public static Style withUnderline(Style style, boolean underline) {
        return style.m_131162_(underline);
    }

    public static Style withStrikethrough(Style style, boolean strikethrough) {
        return style.m_178522_(strikethrough);
    }

    public static Style withObfuscated(Style style, boolean obfuscated) {
        return style.m_178524_(obfuscated);
    }

    public static Style withInsertion(Style style, String insertion) {
        return style.m_131138_(insertion);
    }

    public static Style withClickEvent(Style style, ClickEvent clickEvent) {
        return style.m_131142_(clickEvent);
    }

    public static Style withHoverEvent(Style style, HoverEvent hoverEvent) {
        return style.m_131144_(hoverEvent);
    }

    public static Style withFont(Style style, CompatIdentifier font) {
        return style.m_131150_(font.toMinecraft());
    }

    public static Style withFormatting(Style style, ChatFormatting formatting) {
        return style.m_131157_(formatting);
    }

    public static Style withExclusiveFormatting(Style style, ChatFormatting formatting) {
        return style.m_131164_(formatting);
    }
}
