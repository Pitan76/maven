package net.pitan76.mcpitanlib.api.event.block;

import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.storage.loot.LootContext;
import net.minecraft.world.level.storage.loot.parameters.LootContextParams;
import net.pitan76.mcpitanlib.api.event.BaseEvent;

public class DroppedStacksArgs extends BaseEvent {
    public BlockState state;
    public LootContext.Builder builder;

    public DroppedStacksArgs(BlockState state, LootContext.Builder builder) {
        this.state = state;
        this.builder = builder;
    }

    public BlockState getState() {
        return state;
    }

    @Deprecated
    public LootContext.Builder getBuilder() {
        return builder;
    }

    public BlockEntity getBlockEntity() {
        return builder.m_78970_(LootContextParams.f_81462_);
    }
}
