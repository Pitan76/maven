package net.pitan76.mcpitanlib.api.item;

import net.minecraft.world.item.CreativeModeTab;

public class DefaultItemGroups {
    public static final CreativeModeTab BUILDING_BLOCKS = CreativeModeTab.f_40749_;
    public static final CreativeModeTab COLORED_BLOCKS = CreativeModeTab.f_40749_;
    public static final CreativeModeTab NATURAL = CreativeModeTab.f_40750_;
    public static final CreativeModeTab FUNCTIONAL = CreativeModeTab.f_40752_;
    public static final CreativeModeTab REDSTONE = CreativeModeTab.f_40751_;
    public static final CreativeModeTab HOTBAR = CreativeModeTab.f_40760_;
    public static final CreativeModeTab SEARCH = CreativeModeTab.f_40754_;
    public static final CreativeModeTab TOOLS = CreativeModeTab.f_40756_;
    public static final CreativeModeTab COMBAT = CreativeModeTab.f_40757_;
    public static final CreativeModeTab FOOD_AND_DRINK = CreativeModeTab.f_40755_;
    public static final CreativeModeTab INGREDIENTS = CreativeModeTab.f_40753_;
    public static final CreativeModeTab SPAWN_EGGS = CreativeModeTab.f_40753_;
    public static final CreativeModeTab OPERATOR = CreativeModeTab.f_40753_;
    public static final CreativeModeTab INVENTORY = CreativeModeTab.f_40761_;

    // ～1.19.2 Item Group
    public static final CreativeModeTab BREWING = CreativeModeTab.f_40758_; // if version is 1.19.3, FOOD_AND_DRINK
    public static final CreativeModeTab TRANSPORTATION = CreativeModeTab.f_40752_; // if version is 1.19.3, FUNCTIONAL
    public static final CreativeModeTab DECORATIONS = CreativeModeTab.f_40750_; // if version is 1.19.3, NATURAL
    public static final CreativeModeTab MISC = CreativeModeTab.f_40753_; // if version is 1.19.3, INGREDIENTS
}
