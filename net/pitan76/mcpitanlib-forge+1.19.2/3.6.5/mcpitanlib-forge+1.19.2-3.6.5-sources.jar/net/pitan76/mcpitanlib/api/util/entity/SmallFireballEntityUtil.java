package net.pitan76.mcpitanlib.api.util.entity;

import net.minecraft.world.entity.projectile.SmallFireball;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

public class SmallFireballEntityUtil {
    public static SmallFireball create(Level world, double x, double y, double z, double velocityX, double velocityY, double velocityZ) {
        return new SmallFireball(world, x, y, z, velocityX, velocityY, velocityZ);
    }

    public static SmallFireball create(Level world, double x, double y, double z, Vec3 velocity) {
        return create(world, x, y, z, velocity.f_82479_, velocity.f_82480_, velocity.f_82481_);
    }

    public static void setVelocity(SmallFireball entity, double x, double y, double z, float velocity, float divergence) {
        entity.m_6686_(x, y, z, velocity, divergence);
    }

    public static void setItem(SmallFireball entity, ItemStack stack) {
        entity.m_37010_(stack);
    }

    public static ItemStack getItem(SmallFireball entity) {
        return entity.m_7846_();
    }
}
