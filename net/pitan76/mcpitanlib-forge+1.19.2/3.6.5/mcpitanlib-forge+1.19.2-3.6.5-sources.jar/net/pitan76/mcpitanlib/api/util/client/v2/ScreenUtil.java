package net.pitan76.mcpitanlib.api.util.client.v2;

import net.minecraft.client.gui.components.events.GuiEventListener;
import net.minecraft.client.gui.screens.Screen;

public class ScreenUtil extends net.pitan76.mcpitanlib.api.util.client.ScreenUtil {

    public static void setFocus(Screen screen, boolean focus) {
    }

    public static void setFocus(Screen screen, GuiEventListener element) {
        screen.m_7522_(element);
    }

    public static boolean isFocused(Screen screen) {
        return false;
    }

    public static void setDragging(Screen screen, boolean dragging) {
        screen.m_7897_(dragging);
    }

    public static boolean isDragging(Screen screen) {
        return screen.m_7282_();
    }

    public static int getWidth(Screen screen) {
        return screen.f_96543_;
    }

    public static int getHeight(Screen screen) {
        return screen.f_96544_;
    }
}
