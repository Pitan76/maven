package net.pitan76.mcpitanlib.api.entity;

import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;
import net.pitan76.mcpitanlib.api.event.entity.InitDataTrackerArgs;
import net.pitan76.mcpitanlib.api.event.nbt.ReadNbtArgs;
import net.pitan76.mcpitanlib.api.event.nbt.WriteNbtArgs;
import net.pitan76.mcpitanlib.midohra.util.math.Vector3d;

public class CompatEntity extends Entity {
    public CompatEntity(EntityType<?> type, Level world) {
        super(type, world);
    }

    @Deprecated
    @Override
    public void m_8097_() {
        initDataTracker(new InitDataTrackerArgs(f_19804_));
    }

    public void initDataTracker(InitDataTrackerArgs args) {

    }

    public void readCustomDataFromNbt(ReadNbtArgs nbt) {

    }

    public void writeCustomDataToNbt(WriteNbtArgs nbt) {

    }

    @Deprecated
    @Override
    public void m_7378_(CompoundTag nbt) {
        readCustomDataFromNbt(new ReadNbtArgs(nbt));
    }

    @Deprecated
    @Override
    public void m_7380_(CompoundTag nbt) {
        writeCustomDataToNbt(new WriteNbtArgs(nbt));
    }

    public Packet<ClientGamePacketListener> m_5654_() {
        return null;
    }

    public void writeNbt(WriteNbtArgs args) {
        super.m_20240_(args.getNbt());
    }

    public void readNbt(ReadNbtArgs args) {
        super.m_20258_(args.getNbt());
    }

    @Deprecated
    @Override
    public CompoundTag m_20240_(CompoundTag nbt) {
        writeNbt(new WriteNbtArgs(nbt));
        return nbt;
    }

    @Deprecated
    @Override
    public void m_20258_(CompoundTag nbt) {
        readNbt(new ReadNbtArgs(nbt));
    }

    @Deprecated
    @Override
    public Level m_9236_() {
        return callGetWorld();
    }

    public Level callGetWorld() {
        return super.m_9236_();
    }

    public BlockPos callGetBlockPos() {
        return m_20183_();
    }

    public Vec3 callGetPos() {
        return m_20182_();
    }

    public boolean hasServerWorld() {
        return callGetWorld() instanceof ServerLevel;
    }

    public ServerLevel getServerWorld() {
        return (ServerLevel) m_9236_();
    }

    public net.pitan76.mcpitanlib.midohra.world.World getMidohraWorld() {
        return net.pitan76.mcpitanlib.midohra.world.World.of(callGetWorld());
    }

    public net.pitan76.mcpitanlib.midohra.util.math.BlockPos getMidohraBlockPos() {
        return net.pitan76.mcpitanlib.midohra.util.math.BlockPos.of(callGetBlockPos());
    }

     public Vector3d getMidohraPos() {
        return Vector3d.of(callGetPos());
     }

     public net.pitan76.mcpitanlib.midohra.world.ServerWorld getMidohraServerWorld() {
         return net.pitan76.mcpitanlib.midohra.world.ServerWorld.of(getServerWorld());
     }
}