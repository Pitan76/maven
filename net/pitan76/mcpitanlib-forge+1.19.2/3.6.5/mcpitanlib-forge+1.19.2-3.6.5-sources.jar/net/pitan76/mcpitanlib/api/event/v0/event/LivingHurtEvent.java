package net.pitan76.mcpitanlib.api.event.v0.event;

import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.pitan76.mcpitanlib.api.entity.Player;

public class LivingHurtEvent {
    public LivingEntity entity;
    public DamageSource damageSource;
    public float damageAmount;

    public LivingHurtEvent(LivingEntity entity, DamageSource damageSource, float damageAmount) {
        this.entity = entity;
        this.damageSource = damageSource;
        this.damageAmount = damageAmount;
    }

    public LivingEntity getEntity() {
        return entity;
    }

    public DamageSource getDamageSource() {
        return damageSource;
    }

    public float getDamageAmount() {
        return damageAmount;
    }

    public Entity getAttacker() {
        return damageSource.m_7639_();
    }

    public Entity getSource() {
        return damageSource.m_7640_();
    }

    public boolean isDirect() {
        return !damageSource.m_181121_();
    }

    public boolean isPlayerAttacker() {
        return getAttacker() instanceof net.minecraft.world.entity.player.Player;
    }

    public net.minecraft.world.entity.player.Player getPlayerEntityAttacker() {
        return (net.minecraft.world.entity.player.Player) getAttacker();
    }

    public Player getPlayerAttacker() {
        return new Player(getPlayerEntityAttacker());
    }

    public Level getWorld() {
        return entity.m_9236_();
    }

    public boolean isClient() {
        return getWorld().m_5776_();
    }

    public ItemStack getWeaponStack() {
        if (isPlayerAttacker())
            return getPlayerAttacker().getMainHandStack();

        if (getAttacker() instanceof LivingEntity) {
            LivingEntity livingEntity = (LivingEntity) getAttacker();
            return livingEntity.m_21205_();
        }

        return ItemStack.f_41583_;
    }

    public Item getWeaponItem() {
        return getWeaponStack().m_41720_();
    }

    public boolean isWeaponEmpty() {
        return getWeaponStack().m_41619_();
    }

    public boolean isWeaponItemEqual(Item item) {
        if (isWeaponEmpty()) return false;
        return getWeaponItem() == item;
    }
}
