package net.pitan76.mcpitanlib.api.entity;

import dev.architectury.registry.menu.ExtendedMenuProvider;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.NonNullList;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.network.ServerGamePacketListenerImpl;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.stats.Stat;
import net.minecraft.stats.StatType;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.MenuProvider;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.player.Abilities;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.item.ItemCooldowns;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;
import net.pitan76.mcpitanlib.api.entity.effect.CompatStatusEffect;
import net.pitan76.mcpitanlib.api.entity.effect.CompatStatusEffectInstance;
import net.pitan76.mcpitanlib.api.gui.ExtendedNamedScreenHandlerFactory;
import net.pitan76.mcpitanlib.api.gui.v2.ExtendedScreenHandlerFactory;
import net.pitan76.mcpitanlib.api.item.ArmorEquipmentType;
import net.pitan76.mcpitanlib.api.item.CompatFoodComponent;
import net.pitan76.mcpitanlib.api.sound.CompatSoundCategory;
import net.pitan76.mcpitanlib.api.sound.CompatSoundEvent;
import net.pitan76.mcpitanlib.api.text.TextComponent;
import net.pitan76.mcpitanlib.api.util.CompatIdentifier;
import net.pitan76.mcpitanlib.api.util.ScreenHandlerUtil;
import net.pitan76.mcpitanlib.api.util.TextUtil;
import net.pitan76.mcpitanlib.api.util.entity.LivingEntityUtil;
import net.pitan76.mcpitanlib.core.player.ItemCooldown;
import net.pitan76.mcpitanlib.midohra.util.math.Vector3d;

import java.util.*;
import java.util.function.Consumer;

/*
PlayerEntity helper
 */
public class Player {
    private final net.minecraft.world.entity.player.Player entity;

    public net.minecraft.world.entity.player.Player getEntity() {
        return entity;
    }

    public net.minecraft.world.entity.player.Player getPlayerEntity() {
        return getEntity();
    }

    public Player(net.minecraft.world.entity.player.Player playerEntity) {
        this.entity = playerEntity;
    }

    /**
     * Get player inventory
     * @return PlayerInventory
     */
    public Inventory getInv() {
        return getEntity().m_150109_();
    }

    /**
     * Alias of getInv()
     * @return PlayerInventory
     */
    public Inventory getInventory() {
        return getInv();
    }

    /**
     * Get armor's item stack list
     * @return DefaultedList<ItemStack>
     */
    public NonNullList<ItemStack> getArmor() {
        return getInv().f_35975_;
    }

    /**
     * Get main's item stack list
     * @return DefaultedList<ItemStack>
     */
    public NonNullList<ItemStack> getMain() {
        return getInv().f_35974_;
    }

    /**
     * Get off hand's item stack list
     * @return DefaultedList<ItemStack>
     */
    public NonNullList<ItemStack> getOffHand() {
        return getInv().f_35976_;
    }

    /**
     * Get select slot integer
     * @return int
     */
    public int getSelectSlot() {
        return getInv().f_35977_;
    }

    /**
     * Get player inventory size
     * @return player inventory size
     */
    public int getInvSize() {
        return getInv().m_6643_();
    }

    public OptionalInt openGuiScreen(MenuProvider factory) {
        return getEntity().m_5893_(factory);
    }

    public OptionalInt openGuiScreen(Level world, BlockState state, BlockPos pos) {
        return openGuiScreen(state.m_60750_(world, pos));
    }

    public boolean isServerPlayerEntity() {
        return this.getEntity() instanceof ServerPlayer;
    }

    public void openExtendedMenu(MenuProvider provider, Consumer<FriendlyByteBuf> bufWriter) {
        if (isServerPlayerEntity())
            ScreenHandlerUtil.openExtendedMenu((ServerPlayer) this.getPlayerEntity(), provider, bufWriter);
    }

    public void openExtendedMenu(ExtendedMenuProvider provider) {
        if (isServerPlayerEntity())
            ScreenHandlerUtil.openExtendedMenu((ServerPlayer) this.getPlayerEntity(), provider);
    }

    public void openExtendedMenu(ExtendedNamedScreenHandlerFactory provider) {
        this.openExtendedMenu((ExtendedMenuProvider) provider);
    }

    public void openMenu(MenuProvider provider) {
        if (isServerPlayerEntity())
            ScreenHandlerUtil.openMenu((ServerPlayer) this.getPlayerEntity(), provider);
    }

    public void insertStack(ItemStack stack) {
        getInv().m_36054_(stack);
    }

    public void insertStack(int slot, ItemStack stack) {
        getInv().m_36040_(slot, stack);
    }

    public void offerOrDrop(ItemStack itemStack) {
        getInv().m_150079_(itemStack);
    }

    public void giveStack(ItemStack stack) {
        getEntity().m_36356_(stack);
    }

    public String getName() {
        return getEntity().m_7755_().getString();
    }

    public UUID getUUID() {
        return getEntity().m_20148_();
    }

    public Abilities getAbilities() {
        return getEntity().m_150110_();
    }

    /**
     * Returns whether this player is in creative mode.
     */
    public boolean isCreative() {
        return getAbilities().f_35937_;
    }

    public boolean isFlying() {
        return getAbilities().f_35935_;
    }

    public boolean isInvulnerable() {
        return getAbilities().f_35934_;
    }

    public Level getWorld() {
        return getEntity().m_9236_();
    }

    public AbstractContainerMenu getCurrentScreenHandler() {
        return getEntity().f_36096_;
    }

    public boolean isSneaking() {
        return getEntity().m_6144_();
    }

    public ItemStack getCursorStack() {
        return getCurrentScreenHandler().m_142621_();
    }

    public boolean isClient() {
        return getWorld().m_5776_();
    }
    public boolean isServer() {
        return !isClient();
    }

    public void readCustomDataFromNbt(CompoundTag nbt) {
        getEntity().m_7378_(nbt);
    }

    public void writeCustomDataToNbt(CompoundTag nbt) {
        getEntity().m_7380_(nbt);
    }

    public void sendMessage(Component text) {
        getEntity().m_5661_(text, false);
    }

    public void sendActionBar(Component text) {
        getEntity().m_5661_(text, true);
    }

    public void equipStack(EquipmentSlot slot, ItemStack stack) {
        getEntity().m_8061_(slot, stack);
    }

    public void dropStack(ItemStack stack, boolean throwRandomly, boolean retainOwnership) {
        getEntity().m_7197_(stack, throwRandomly, retainOwnership);
    }

    public void dropStack(ItemStack stack, boolean retainOwnership) {
        dropStack(stack, false, retainOwnership);
    }

    public void dropStack(ItemStack stack) {
        dropStack(stack, false, false);
    }

    public BlockPos getBlockPos() {
        return getEntity().m_20183_();
    }

    public Vec3 getPos() {
        return getEntity().m_20182_();
    }

    public ItemStack getStackInHand(InteractionHand hand) {
        return this.getEntity().m_21120_(hand);
    }

    public void heal(float amount) {
        this.getEntity().m_5634_(amount);
    }

    public float getYaw() {
        return this.getEntity().m_146908_();
    }

    public float getPitch() {
        return this.getEntity().m_146909_();
    }

    public void playSound(SoundEvent event, SoundSource category, float volume, float pitch) {
        if (isServerPlayerEntity()) {
            Optional<ServerPlayer> player = getServerPlayer();
            if (player.isPresent()) {
                player.get().m_6330_(event, category, volume, pitch);
                return;
            }
        }

        playSound(event, volume, pitch);
    }

    public void playSound(SoundEvent event, float volume, float pitch) {
        if (isServerPlayerEntity()) {
            Optional<ServerPlayer> player = getServerPlayer();
            if (player.isPresent()) {
                player.get().m_5496_(event, volume, pitch);
                return;
            }
        }

        getEntity().m_5496_(event, volume, pitch);
    }

    public void playSound(CompatSoundEvent event, CompatSoundCategory category, float volume, float pitch) {
        playSound(event.get(), category.get(), volume, pitch);
    }

    public void playSound(CompatSoundEvent event, float volume, float pitch) {
        playSound(event.get(), volume, pitch);
    }

    public ItemCooldown itemCooldown = new ItemCooldown(this);

    public ItemCooldown getItemCooldown() {
        return itemCooldown;
    }

    public ItemCooldowns getItemCooldownManager() {
        return getEntity().m_36335_();
    }

    public void incrementStat(Stat<?> stat) {
        getEntity().m_36246_(stat);
    }

    public <T> void incrementStat(StatType<T> type, T object) {
        getEntity().m_36246_(type.m_12902_(object));
    }

    public void incrementStat(ResourceLocation id) {
        getEntity().m_36220_(id);
    }

    public void incrementStat(CompatIdentifier id) {
        getEntity().m_36220_(id.toMinecraft());
    }

    public void teleport(double x, double y, double z) {
        getEntity().m_20984_(x, y, z, false);
    }

    public ItemStack getMainHandStack() {
        return getStackInHand(InteractionHand.MAIN_HAND);
    }

    public ItemStack getOffHandStack() {
        return getStackInHand(InteractionHand.OFF_HAND);
    }

    public Direction getHorizontalFacing() {
        return getEntity().m_6350_();
    }

    public double getX() {
        return getEntity().m_20185_();
    }

    public double getY() {
        return getEntity().m_20186_();
    }

    public double getZ() {
        return getEntity().m_20189_();
    }

    public boolean isServerPlayer() {
        return getEntity() instanceof ServerPlayer;
    }

    public Optional<ServerPlayer> getServerPlayer() {
        if (isServerPlayer())
            return Optional.of((ServerPlayer) getEntity());

        return Optional.empty();
    }

    @Environment(EnvType.CLIENT)
    public Optional<LocalPlayer> getClientPlayer() {
        if (getEntity() instanceof LocalPlayer)
            return Optional.of((LocalPlayer) getEntity());

        return Optional.empty();
    }

    public void setVelocity(double x, double y, double z) {
        getEntity().m_20334_(x, y, z);
    }

    public void setVelocity(Vec3 velocity) {
        getEntity().m_20256_(velocity);
    }

    public Vec3 getVelocity() {
        return getEntity().m_20184_();
    }

    public Optional<ServerGamePacketListenerImpl> getNetworkHandler() {
        Optional<ServerPlayer> player = getServerPlayer();
        return player.map(sp -> sp.f_8906_);
    }

    public boolean hasNetworkHandler() {
        return getNetworkHandler().isPresent();
    }

    public boolean isSpectator() {
        return getEntity().m_5833_();
    }

    /**
     * Returns the current {@link ItemStack} in the {@link Player}'s hand, or offhand if the
     * main hand is empty.
     *
     * @return {@code ItemStack} that the {@link Player} is holding. Can be {@link null}.
     */
    public Optional<ItemStack> getCurrentHandItem() {
        boolean playerIsHoldingInMainHand = !getMainHandStack().m_41619_();
        if (playerIsHoldingInMainHand)
            return Optional.ofNullable(getMainHandStack());

        boolean playerIsHoldingInOffHand = !getOffHandStack().m_41619_();

        if (playerIsHoldingInOffHand)
            return Optional.ofNullable(getOffHandStack());

        return Optional.empty();
    }

    public void addStatusEffect(CompatStatusEffectInstance effect) {
        getEntity().m_7292_(effect.getInstance());
    }

    public void removeStatusEffect(CompatStatusEffect effect) {
        getEntity().m_21195_(effect.getStatusEffect(getWorld()));
    }

    public List<CompatStatusEffectInstance> getStatusEffects() {
        List<CompatStatusEffectInstance> compatEffects = new ArrayList<>();

        for (MobEffectInstance effect : getEntity().m_21220_()) {
            compatEffects.add(new CompatStatusEffectInstance(effect));
        }

        return compatEffects;
    }

    public void addExperience(int experience) {
        getEntity().m_6756_(experience);
    }

    public int getExperienceLevel() {
        return getEntity().f_36078_;
    }

    public void addExperienceLevels(int levels) {
        getEntity().m_6749_(levels);
    }

    public void setExperienceLevel(int level) {
        getEntity().f_36078_ = level;
    }

    public void addScore(int score) {
        getEntity().m_36401_(score);
    }

    public int getScore() {
        return getEntity().m_36344_();
    }

    public void setScore(int score) {
        getEntity().m_36397_(score);
    }

    public int getTotalExperience() {
        return getEntity().f_36079_;
    }

    public void setTotalExperience(int experience) {
        getEntity().f_36079_ = experience;
    }

    public boolean isSwimming() {
        return getEntity().m_6069_();
    }

    public void setStackInHand(InteractionHand hand, ItemStack stack) {
        getEntity().m_21008_(hand, stack);
    }

    public void setStackInHand(InteractionHand hand, net.pitan76.mcpitanlib.midohra.item.ItemStack stack) {
        setStackInHand(hand, stack.toMinecraft());
    }

    public net.pitan76.mcpitanlib.midohra.item.ItemStack getMidohraStackInHand(InteractionHand hand) {
        return net.pitan76.mcpitanlib.midohra.item.ItemStack.of(getStackInHand(hand));
    }

    public InteractionHand getActiveHand() {
        return getEntity().m_7655_();
    }

    public float getBlockBreakingSpeed(BlockState state) {
        return getEntity().m_36281_(state);
    }

    public boolean canHarvest(BlockState state) {
        return getEntity().m_36298_(state);
    }

    public net.pitan76.mcpitanlib.midohra.world.World getMidohraWorld() {
        return net.pitan76.mcpitanlib.midohra.world.World.of(getWorld());
    }

    public void eatFood(ItemStack stack, CompatFoodComponent foodComponent) {
        getEntity().m_5584_(getWorld(), stack);
    }

    public void sendMessage(String message) {
        sendMessage(TextUtil.of(message));
    }

    public void sendActionBar(String message) {
        sendActionBar(TextUtil.of(message));
    }

    public void sendMessagef(String format, Object... args) {
        sendMessage(TextUtil.of(String.format(format, args)));
    }

    public void sendMessage(TextComponent textComponent) {
        sendMessage(textComponent.getText());
    }

    public void sendActionBar(TextComponent textComponent) {
        sendActionBar(textComponent.getText());
    }


    public void openExtendedMenu(ExtendedScreenHandlerFactory provider) {
        this.openExtendedMenu((ExtendedMenuProvider) provider);
    }

    public void offerOrDrop(net.pitan76.mcpitanlib.midohra.item.ItemStack stack) {
        offerOrDrop(stack.toMinecraft());
    }

    public void insertStack(net.pitan76.mcpitanlib.midohra.item.ItemStack stack) {
        insertStack(stack.toMinecraft());
    }

    public void insertStack(int slot, net.pitan76.mcpitanlib.midohra.item.ItemStack stack) {
        insertStack(slot, stack.toMinecraft());
    }

    public void giveStack(net.pitan76.mcpitanlib.midohra.item.ItemStack stack) {
        giveStack(stack.toMinecraft());
    }

    public Vector3d getPosM() {
        return Vector3d.of(getPos());
    }

    public net.pitan76.mcpitanlib.midohra.util.math.BlockPos getBlockPosM() {
        return net.pitan76.mcpitanlib.midohra.util.math.BlockPos.of(getBlockPos());
    }

    public ItemStack getEquippedStack(ArmorEquipmentType type) {
        return LivingEntityUtil.getEquippedStack(getEntity(), type.getSlot());
    }

    public net.pitan76.mcpitanlib.midohra.item.ItemStack getEquippedStackM(ArmorEquipmentType type) {
        return net.pitan76.mcpitanlib.midohra.item.ItemStack.of(getEquippedStack(type));
    }
}