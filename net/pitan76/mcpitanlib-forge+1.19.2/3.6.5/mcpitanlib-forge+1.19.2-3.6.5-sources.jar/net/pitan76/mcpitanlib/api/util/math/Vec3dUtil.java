package net.pitan76.mcpitanlib.api.util.math;

import net.minecraft.world.phys.Vec3;

public class Vec3dUtil {
    public static Vec3 create(double x, double y, double z) {
        return new Vec3(x, y, z);
    }

    public static Vec3 add(Vec3 a, Vec3 b) {
        return a.m_82549_(b);
    }

    public static Vec3 subtract(Vec3 a, Vec3 b) {
        return a.m_82546_(b);
    }

    public static Vec3 multiply(Vec3 a, double b) {
        return a.m_82490_(b);
    }

    public static Vec3 divide(Vec3 a, double b) {
        return a.m_82490_(1.0D / b);
    }

    public static double dot(Vec3 a, Vec3 b) {
        return a.m_82526_(b);
    }

    public static Vec3 cross(Vec3 a, Vec3 b) {
        return a.m_82537_(b);
    }

    public static Vec3 normalize(Vec3 a) {
        return a.m_82541_();
    }

    public static Vec3 rotateX(Vec3 a, float angle) {
        return a.m_82496_(angle);
    }

    public static Vec3 rotateY(Vec3 a, float angle) {
        return a.m_82524_(angle);
    }

    public static Vec3 rotateZ(Vec3 a, float angle) {
        return a.m_82535_(angle);
    }

    public static Vec3 add(Vec3 a, double x, double y, double z) {
        return a.m_82520_(x, y, z);
    }

    public static Vec3 subtract(Vec3 a, double x, double y, double z) {
        return a.m_82492_(x, y, z);
    }

    public static Vec3 multiply(Vec3 a, double x, double y, double z) {
        return a.m_82542_(x, y, z);
    }

    public static double distanceTo(Vec3 a, Vec3 b) {
        return a.m_82554_(b);
    }

    public static Vec3 ofCenter(double x, double y, double z) {
        return new Vec3(x + 0.5, y + 0.5, z + 0.5);
    }
}
