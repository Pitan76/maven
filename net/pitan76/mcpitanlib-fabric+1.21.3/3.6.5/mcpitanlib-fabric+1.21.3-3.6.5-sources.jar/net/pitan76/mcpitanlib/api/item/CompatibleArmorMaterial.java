package net.pitan76.mcpitanlib.api.item;

import net.minecraft.class_1741;
import net.minecraft.class_1792;
import net.minecraft.class_1856;
import net.minecraft.class_2960;
import net.minecraft.class_3414;
import net.minecraft.class_3489;
import net.minecraft.class_6862;
import net.minecraft.class_6880;
import net.minecraft.class_8051;
import net.pitan76.mcpitanlib.api.util.IngredientUtil;

import java.util.EnumMap;

public interface CompatibleArmorMaterial {
    int getDurability(ArmorEquipmentType type);

    int getProtection(ArmorEquipmentType type);

    int getEnchantability();

    class_3414 getEquipSound();

    default class_1856 getRepairIngredient() {
        return IngredientUtil.fromTagByIdentifier(getRepairTag().comp_327());
    }

    /**
     * @return the name of the material
     */
    default String getName() {
        return getId().method_12832();
    }

    /**
     * @return the id of the material
     */
    class_2960 getId();

    float getToughness();

    float getKnockbackResistance();

    default class_6862<class_1792> getRepairTag() {
        return class_3489.field_54061;
    }

    @Deprecated
    default class_1741 build() {
        return new class_1741(0, getDefense(), getEnchantability(), class_6880.method_40223(getEquipSound()), getToughness(), getKnockbackResistance(), getRepairTag(), getId());
    }

    default EnumMap<class_8051, Integer> getDefense() {
        EnumMap<class_8051, Integer> map = new EnumMap<>(class_8051.class);
        map.put(class_8051.field_41934, this.getProtection(ArmorEquipmentType.HEAD));
        map.put(class_8051.field_41935, this.getProtection(ArmorEquipmentType.CHEST));
        map.put(class_8051.field_41936, this.getProtection(ArmorEquipmentType.LEGS));
        map.put(class_8051.field_41937, this.getProtection(ArmorEquipmentType.FEET));
        return map;
    }
}
