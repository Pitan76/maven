package net.pitan76.mcpitanlib.api.util;

import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2487;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.pitan76.mcpitanlib.api.registry.CompatRegistryLookup;
import org.jetbrains.annotations.Nullable;

public class BlockEntityUtil {

    public static class_2586 getBlockEntity(class_1937 world, class_2338 pos) {
        return WorldUtil.getBlockEntity(world, pos);
    }

    public static class_2487 getBlockEntityNbt(@Nullable class_1937 world, class_2586 blockEntity) {
        if (world == null)
            world = getWorld(blockEntity);
        if (world == null)
            return NbtUtil.create();

        return blockEntity.method_38244(world.method_30349());
    }

    public static class_2487 getBlockEntityNbt(class_2586 blockEntity) {
        return getBlockEntityNbt(null, blockEntity);
    }

    public static class_1937 getWorld(class_2586 blockEntity) {
        return blockEntity.method_10997();
    }

    public static boolean hasWorld(class_2586 blockEntity) {
        return blockEntity.method_11002();
    }

    public static class_2338 getPos(class_2586 blockEntity) {
        return blockEntity.method_11016();
    }

    public static class_2680 getCachedState(class_2586 blockEntity) {
        return blockEntity.method_11010();
    }

    public static class_2680 getBlockState(class_2586 blockEntity) {
        return getWorld(blockEntity).method_8320(getPos(blockEntity));
    }

    public static class_2248 getBlock(class_2586 blockEntity) {
        return getBlockState(blockEntity).method_26204();
    }

    public static void markRemoved(class_2586 blockEntity) {
        blockEntity.method_11012();
    }

    public static void markDirty(class_2586 blockEntity) {
        blockEntity.method_5431();
    }

    public static class_2591<?> getType(class_2586 blockEntity) {
        return blockEntity.method_11017();
    }

    public static void readNbt(class_2586 blockEntity, class_2487 nbt, CompatRegistryLookup registryLookup) {
        blockEntity.method_11014(nbt, registryLookup.getRegistryLookup());
    }

    public static void writeNbt(class_2586 blockEntity, class_2487 nbt, CompatRegistryLookup registryLookup) {
        blockEntity.method_11007(nbt, registryLookup.getRegistryLookup());
    }

    public static void read(class_2586 blockEntity, class_2487 nbt, CompatRegistryLookup registryLookup) {
        blockEntity.method_58690(nbt, registryLookup.getRegistryLookup());
    }

    public static class_2487 createNbt(class_2586 blockEntity, CompatRegistryLookup registryLookup) {
        return blockEntity.method_38244(registryLookup.getRegistryLookup());
    }

    public static void setStackNbt(class_2586 blockEntity, class_1799 stack, CompatRegistryLookup registryLookup) {
        blockEntity.method_38240(stack, registryLookup.getRegistryLookup());
    }

    public static class_3218 getServerWorld(class_2586 blockEntity) {
        return (class_3218) getWorld(blockEntity);
    }

    public static void writeToStack(class_1799 stack, class_2586 blockEntity, CompatRegistryLookup registryLookup) {
        class_2487 nbt = blockEntity.method_58692(registryLookup.getRegistryLookup());
        if (!NbtUtil.has(nbt, "id"))
            NbtUtil.putString(nbt, "id", BlockEntityTypeUtil.toID(BlockEntityUtil.getType(blockEntity)).toString());

        BlockEntityDataUtil.setBlockEntityNbt(stack, nbt);

        stack.method_57365(blockEntity.method_57590());
    }

    public static boolean isRemoved(class_2586 blockEntity) {
        return blockEntity.method_11015();
    }
}
