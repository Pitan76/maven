package net.pitan76.mcpitanlib.api.util;

import it.unimi.dsi.fastutil.ints.IntArrayList;
import it.unimi.dsi.fastutil.ints.IntList;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1856;
import net.minecraft.class_1935;
import net.minecraft.class_2371;
import net.minecraft.class_2960;
import net.minecraft.class_6880;
import net.minecraft.class_6885;
import net.minecraft.class_7923;

public class IngredientUtil {
    public static class_1856 fromTagByIdentifier(class_2960 id) {
        List<class_1792> items = ItemUtil.getItems(id);

        List<class_6880<class_1792>> entryList = new ArrayList<>();
        for (class_1792 item : items) {
            entryList.add(class_7923.field_41178.method_47983(item));
        }

        class_6885<class_1792> entryList2 = class_6885.method_40242(entryList);

        return class_1856.method_8106(entryList2);
    }

    public static class_1856 fromTagByString(String id) {
        return fromTagByIdentifier(IdentifierUtil.id(id));
    }

    public static class_1856 fromTagByIdentifier(CompatIdentifier id) {
        return fromTagByIdentifier(id.toMinecraft());
    }

    public static List<class_1792> getItems(class_1856 ingredient) {
        List<class_1792> items = new ArrayList<>();

        for (class_6880<class_1792> entry : ingredient.method_8105()) {
            items.add(entry.comp_349());
        }

        return items;
    }

    public static IntList getMatchingStacksIds(class_1856 ingredient) {
        IntList ids = new IntArrayList();

        for (class_1792 item : getItems(ingredient)) {
            ids.add(ItemUtil.getRawId(item));
        }

        return ids;
    }

    public static List<class_1799> getMatchingStacksAsList(class_1856 ingredient) {
        return new ArrayList<>(Arrays.asList(getMatchingStacks(ingredient)));
    }

    public static class_1799[] getMatchingStacks(class_1856 ingredient) {
        List<class_1799> stacks = new ArrayList<>();
        for (class_1792 item : getItems(ingredient)) {
            stacks.add(new class_1799(item));
        }

        return stacks.toArray(new class_1799[0]);
    }

    public static class_1856 empty() {
        return null;
    }

    public static class_1856 ofItems(class_1935... items) {
        return class_1856.method_8091(items);
    }

    public static class_2371<class_1856> buildInput(Object[] input) {
        class_2371<class_1856> list = class_2371.method_10211();
        for (Object obj : input) {
            if (obj instanceof class_1856) {
                list.add((class_1856) obj);
                continue;
            }

            if (obj instanceof class_1935) {
                list.add(ofItems((class_1935) obj));
            }
        }
        return list;
    }
}
