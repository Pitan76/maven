package net.pitan76.mcpitanlib.api.util;

import net.minecraft.entity.EntityType;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import net.minecraft.util.registry.Registry;

public class EntityTypeUtil {
    public static Identifier toID(EntityType<?> entityType) {
        return Registry.ENTITY_TYPE.getId(entityType);
    }

    public static EntityType<?> fromId(Identifier identifier) {
        return Registry.ENTITY_TYPE.get(identifier);
    }

    public static boolean isExist(Identifier identifier) {
        return Registry.ENTITY_TYPE.containsId(identifier);
    }

    public static CompatIdentifier toCompatID(EntityType<?> entityType) {
        return CompatIdentifier.fromMinecraft(toID(entityType));
    }

    public static EntityType<?> fromId(CompatIdentifier identifier) {
        return fromId(identifier.toMinecraft());
    }

    public static boolean isExist(CompatIdentifier identifier) {
        return isExist(identifier.toMinecraft());
    }

    public static int getRawId(EntityType<?> type) {
        return Registry.ENTITY_TYPE.getRawId(type);
    }

    public static EntityType<?> fromIndex(int index) {
        return Registry.ENTITY_TYPE.get(index);
    }

    public static Text getName(EntityType<?> entityType) {
        return entityType.getName();
    }

    public static String getTranslationKey(EntityType<?> entityType) {
        return entityType.getTranslationKey();
    }
}
