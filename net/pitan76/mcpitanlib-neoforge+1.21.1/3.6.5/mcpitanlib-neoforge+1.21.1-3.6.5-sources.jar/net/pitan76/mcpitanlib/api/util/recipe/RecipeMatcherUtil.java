package net.pitan76.mcpitanlib.api.util.recipe;

import it.unimi.dsi.fastutil.ints.IntList;
import net.minecraft.world.entity.player.StackedContents;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.crafting.Recipe;
import net.pitan76.mcpitanlib.api.recipe.CompatibleRecipeEntry;

public class RecipeMatcherUtil {
    public static ItemStack getStackFromId(int itemId) {
        return StackedContents.fromStackingIndex(itemId);
    }

    public static int getItemId(ItemStack stack) {
        return StackedContents.getStackingIndex(stack);
    }

    public static boolean match(StackedContents matcher, CompatibleRecipeEntry entry, IntList output) {
        return match(matcher, entry.getRecipe(), output);
    }

    public static boolean match(StackedContents matcher, CompatibleRecipeEntry entry, IntList output, int multiplier) {
        return match(matcher, entry.getRecipe(), output, multiplier);
    }

    public static boolean match(StackedContents matcher, Recipe<?> recipe, IntList output) {
        return matcher.canCraft(recipe, output);
    }

    public static boolean match(StackedContents matcher, Recipe<?> recipe, IntList output, int multiplier) {
        return matcher.canCraft(recipe, output, multiplier);
    }

    public static void clear(StackedContents matcher) {
        matcher.clear();
    }
}
