package net.pitan76.mcpitanlib.api.entity;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.level.Level;
import net.pitan76.mcpitanlib.api.nbt.NbtTag;

public class ExtendEntity extends Entity {
    public ExtendEntity(EntityType<?> type, Level world) {
        super(type, world);
    }

    @Deprecated
    @Override
    public void defineSynchedData(SynchedEntityData.Builder builder) {
        initDataTracker();
    }

    public void initDataTracker() {
    }

    public void readAdditionalSaveData(CompoundTag nbt) {

    }

    public void addAdditionalSaveData(CompoundTag nbt) {

    }

    public Packet<ClientGamePacketListener> createSpawnPacket() {
        return null;
    }

    // 互換性用 (NbtTag型をOverrideすること)
    public void writeNbt(NbtTag nbt) {
        super.saveWithoutId(nbt);
    }

    public void readNbt(NbtTag nbt) {
        super.load(nbt);
    }

    // 1.18
    @Override
    public CompoundTag saveWithoutId(CompoundTag nbt) {
        this.writeNbt(NbtTag.from(nbt));
        return nbt;
    }

    @Override
    public void load(CompoundTag nbt) {
        this.readNbt(NbtTag.from(nbt));
    }

    // 1.14
    public CompoundTag toTag(CompoundTag nbt) {
        this.writeNbt(NbtTag.from(nbt));
        return nbt;
    }

    public CompoundTag fromTag(CompoundTag nbt) {
        this.readNbt(NbtTag.from(nbt));
        return nbt;
    }

    @Override
    public Level level() {
        return super.level();
    }
}