package net.pitan76.mcpitanlib.api.item.tool;

import net.minecraft.tags.BlockTags;
import net.minecraft.tags.ItemTags;
import net.minecraft.tags.TagKey;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Tier;
import net.minecraft.world.item.crafting.Ingredient;
import net.minecraft.world.level.block.Block;
import net.pitan76.mcpitanlib.api.util.IngredientUtil;

public interface CompatibleToolMaterial {

    int getCompatMiningLevel();

    float getCompatAttackDamage();

    float getCompatMiningSpeedMultiplier();

    default Ingredient getCompatRepairIngredient() {
        return IngredientUtil.fromTagByIdentifier(getRepairTag().location());
    }

    int getCompatDurability();

    int getCompatEnchantability();

    default TagKey<Block> getInverseTag() {

        return level2inverseTag(getCompatMiningLevel());
    }

    @Deprecated
    default TagKey<Block> _getInverseTag() {
        return getInverseTag();
    }

    public static TagKey<Block> level2inverseTag(int level) {
        switch (level) {
            case 1:
                return BlockTags.INCORRECT_FOR_WOODEN_TOOL;
            case 2:
                return BlockTags.INCORRECT_FOR_STONE_TOOL;
            case 3:
                return BlockTags.INCORRECT_FOR_IRON_TOOL;
            case 4:
                return BlockTags.INCORRECT_FOR_GOLD_TOOL;
            case 5:
                return BlockTags.INCORRECT_FOR_DIAMOND_TOOL;
            case 6:
                return BlockTags.INCORRECT_FOR_NETHERITE_TOOL;

            default:
                return BlockTags.INCORRECT_FOR_WOODEN_TOOL;
        }
    }

    @Deprecated
    default float getAttackDamage() {
        return getCompatAttackDamage();
    }

    @Deprecated
    default float getMiningSpeedMultiplier() {
        return getCompatMiningSpeedMultiplier();
    }

    @Deprecated
    default Ingredient getRepairIngredient() {
        return getCompatRepairIngredient();
    }

    @Deprecated
    default int getDurability() {
        return getCompatDurability();
    }

    @Deprecated
    default int getEnchantability() {
        return getCompatEnchantability();
    }

    default TagKey<Item> getRepairTag() {
        return ItemTags.IRON_ORES;
    }

    default Tier build() {
        return new Tier() {
            @Override
            public int getUses() {
                return getCompatDurability();
            }

            @Override
            public float getSpeed() {
                return getCompatMiningSpeedMultiplier();
            }

            @Override
            public float getAttackDamageBonus() {
                return getCompatAttackDamage();
            }

            @Override
            public TagKey<Block> getIncorrectBlocksForDrops() {
                return _getInverseTag();
            }

            @Override
            public int getEnchantmentValue() {
                return getCompatEnchantability();
            }

            @Override
            public Ingredient getRepairIngredient() {
                return getCompatRepairIngredient();
            }
        };
    }
}