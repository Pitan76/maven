package net.pitan76.mcpitanlib.api.event.v0.event;

import com.google.common.collect.ImmutableMap;
import com.google.common.collect.ImmutableMultimap;
import com.google.gson.JsonElement;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.packs.resources.ResourceManager;
import net.minecraft.util.profiling.ProfilerFiller;
import net.minecraft.world.item.crafting.Recipe;
import net.minecraft.world.item.crafting.RecipeHolder;
import net.minecraft.world.item.crafting.RecipeType;
import net.pitan76.mcpitanlib.api.recipe.CompatibleRecipeEntry;
import net.pitan76.mcpitanlib.api.recipe.v2.CompatRecipeEntry;
import net.pitan76.mcpitanlib.api.recipe.v3.CompatRecipe;

import java.util.Map;

public class RecipeManagerEvent {
    public Map<ResourceLocation, JsonElement> jsonMap;
    public ResourceManager resourceManager;
    public ProfilerFiller profiler;

    @Deprecated
    public ImmutableMap.Builder<ResourceLocation, RecipeHolder<?>> recipesById;

    @Deprecated
    public ImmutableMultimap.Builder<RecipeType<?>, RecipeHolder<?>> recipesByType;

    public RecipeManagerEvent(Map<ResourceLocation, JsonElement> map, ResourceManager resourceManager, ProfilerFiller profiler, ImmutableMap.Builder<ResourceLocation, RecipeHolder<?>> recipesById, ImmutableMultimap.Builder<RecipeType<?>, RecipeHolder<?>> recipesByType) {
        this.jsonMap = map;
        this.resourceManager = resourceManager;
        this.profiler = profiler;
        this.recipesById = recipesById;
        this.recipesByType = recipesByType;
    }

    public Map<ResourceLocation, JsonElement> getJsonMap() {
        return jsonMap;
    }

    @Deprecated
    public ImmutableMap.Builder<ResourceLocation, RecipeHolder<?>> getRecipesById() {
        return recipesById;
    }

    @Deprecated
    public ImmutableMultimap.Builder<RecipeType<?>, RecipeHolder<?>> getRecipesByType() {
        return recipesByType;
    }

    public ProfilerFiller getProfiler() {
        return profiler;
    }

    public ResourceManager getResourceManager() {
        return resourceManager;
    }

    public net.pitan76.mcpitanlib.midohra.resource.ResourceManager getResourceManagerM() {
        return net.pitan76.mcpitanlib.midohra.resource.ResourceManager.of(resourceManager);
    }

    public void putCompatibleRecipeEntry(ResourceLocation id, CompatibleRecipeEntry entry) {
        putCompatibleRecipeEntry(entry);
    }

    public void putCompatibleRecipeEntry(CompatibleRecipeEntry entry) {
        recipesById.put(entry.getId(), entry.getRecipeEntry());
        recipesByType.put(entry.getType(), entry.getRecipeEntry());
    }

    public <T extends Recipe<?>> void putCompatibleRecipeEntry(CompatRecipeEntry<T> entry) {
        recipesById.put(entry.getId(), entry.getRecipeEntry());
        recipesByType.put(entry.getType(), entry.getRecipeEntry());
    }

    public void putRecipeEntry(net.pitan76.mcpitanlib.midohra.recipe.entry.RecipeEntry entry) {
        recipesById.put(entry.getId().toMinecraft(), entry.toMinecraft());
        recipesByType.put(entry.getRawRecipeType(), entry.toMinecraft());
    }

    public void putRecipe(CompatRecipe recipe) {
        recipesById.put(recipe.getId(), recipe.getRecipeEntry().getRecipeEntry());
        recipesByType.put(recipe.getType(), recipe.getRecipeEntry().getRecipeEntry());
    }
}
