package net.pitan76.mcpitanlib.api.client.render;

import net.minecraft.class_1921;
import net.pitan76.mcpitanlib.api.util.CompatIdentifier;

public class CompatRenderLayer {
    public static final CompatRenderLayer CUTOUT = new CompatRenderLayer(class_1921.method_23581());
    public static final CompatRenderLayer CUTOUT_MIPPED = new CompatRenderLayer(class_1921.method_23579());
    public static final CompatRenderLayer TRANSLUCENT = new CompatRenderLayer(class_1921.method_30676());
    public static final CompatRenderLayer TRANSLUCENT_MOVING_BLOCK = new CompatRenderLayer(class_1921.method_29380());
    public static final CompatRenderLayer SOLID = new CompatRenderLayer(class_1921.method_23577());
    public static final CompatRenderLayer LINES = new CompatRenderLayer(class_1921.method_23594());
    public static final CompatRenderLayer LINE_STRIP = new CompatRenderLayer(class_1921.method_34572());
    public static final CompatRenderLayer GLINT = new CompatRenderLayer(class_1921.method_23590());

    public final class_1921 layer;

    public CompatRenderLayer(class_1921 layer) {
        this.layer = layer;
    }

    public class_1921 raw() {
        return layer;
    }

    public static CompatRenderLayer getEntityCutout(CompatIdentifier id) {
        return new CompatRenderLayer(class_1921.method_23576(id.toMinecraft()));
    }

    public static CompatRenderLayer getEntityCutoutNoCull(CompatIdentifier id) {
        return new CompatRenderLayer(class_1921.method_23578(id.toMinecraft()));
    }

    public static CompatRenderLayer getEntityTranslucent(CompatIdentifier id) {
        return new CompatRenderLayer(class_1921.method_23580(id.toMinecraft()));
    }

    public static CompatRenderLayer getArmorCutoutNoCull(CompatIdentifier id) {
        return new CompatRenderLayer(class_1921.method_25448(id.toMinecraft()));
    }

    public static CompatRenderLayer getEntitySolid(CompatIdentifier id) {
        return new CompatRenderLayer(class_1921.method_23572(id.toMinecraft()));
    }
}
