package net.pitan76.mcpitanlib.api.client.gui.widget;

import net.minecraft.class_10799;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_344;
import net.minecraft.class_4185;
import net.minecraft.class_8666;
import net.pitan76.mcpitanlib.api.util.CompatIdentifier;
import net.pitan76.mcpitanlib.api.util.TextUtil;

public class CompatibleTexturedButtonWidget extends class_344 {
    private final class_2960 texture;
    private final int u;
    private final int v;
    private final int hoveredVOffset;
    private final int textureWidth;
    private final int textureHeight;

    public CompatibleTexturedButtonWidget(int x, int y, int width, int height, int u, int v, class_2960 texture, class_4185.class_4241 pressAction) {
        this(x, y, width, height, u, v, height, texture, 256, 256, pressAction);
    }

    public CompatibleTexturedButtonWidget(int x, int y, int width, int height, int u, int v, int hoveredVOffset, class_2960 texture, class_4185.class_4241 pressAction) {
        this(x, y, width, height, u, v, hoveredVOffset, texture, 256, 256, pressAction);
    }

    public CompatibleTexturedButtonWidget(int x, int y, int width, int height, int u, int v, int hoveredVOffset, class_2960 texture, int textureWidth, int textureHeight, class_4185.class_4241 pressAction) {
        this(x, y, width, height, u, v, hoveredVOffset, texture, textureWidth, textureHeight, pressAction, TextUtil.empty());
    }

    public CompatibleTexturedButtonWidget(int x, int y, int width, int height, int u, int v, int hoveredVOffset, class_2960 texture, int textureWidth, int textureHeight, class_4185.class_4241 pressAction, class_2561 text) {
        super(x, y, width, height, new class_8666(texture, texture), pressAction, text);
        this.textureWidth = textureWidth;
        this.textureHeight = textureHeight;
        this.u = u;
        this.v = v;
        this.hoveredVOffset = hoveredVOffset;
        this.texture = texture;
    }

    public CompatibleTexturedButtonWidget(int x, int y, int width, int height, int u, int v, CompatIdentifier texture, class_4185.class_4241 pressAction) {
        this(x, y, width, height, u, v, texture.toMinecraft(), pressAction);
    }

    public CompatibleTexturedButtonWidget(int x, int y, int width, int height, int u, int v, int hoveredVOffset, CompatIdentifier texture, class_4185.class_4241 pressAction) {
        this(x, y, width, height, u, v, hoveredVOffset, texture.toMinecraft(), pressAction);
    }

    public CompatibleTexturedButtonWidget(int x, int y, int width, int height, int u, int v, int hoveredVOffset, CompatIdentifier texture, int textureWidth, int textureHeight, class_4185.class_4241 pressAction) {
        this(x, y, width, height, u, v, hoveredVOffset, texture.toMinecraft(), textureWidth, textureHeight, pressAction);
    }

    public CompatibleTexturedButtonWidget(int x, int y, int width, int height, int u, int v, int hoveredVOffset, CompatIdentifier texture, int textureWidth, int textureHeight, class_4185.class_4241 pressAction, class_2561 text) {
        this(x, y, width, height, u, v, hoveredVOffset, texture.toMinecraft(), textureWidth, textureHeight, pressAction, text);
    }

    public void setPos(int x, int y) {
        method_46421(x);
        method_46419(y);
    }

    @Override
    public void method_48579(class_332 context, int mouseX, int mouseY, float delta) {
        int i = v;
        if (this.method_25360().toString().isEmpty()) {
            i = v + hoveredVOffset * 2;
        } else if (this.method_49606()) {
            i += hoveredVOffset;
        }

        context.method_25290(class_10799.field_56883, texture, this.method_46426(), this.method_46427(), u, i, this.field_22758, this.field_22759, textureWidth, textureHeight);
    }
}
