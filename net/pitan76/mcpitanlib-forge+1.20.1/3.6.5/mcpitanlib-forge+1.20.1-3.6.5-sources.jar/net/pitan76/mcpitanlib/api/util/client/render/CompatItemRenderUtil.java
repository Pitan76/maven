package net.pitan76.mcpitanlib.api.util.client.render;

import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.entity.ItemRenderer;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.pitan76.mcpitanlib.api.client.render.block.entity.event.BlockEntityRenderEvent;

/**
 * Cross-version utility for rendering items in block entity renderers.
 */
public class CompatItemRenderUtil {
    /**
     * Renders an ItemStack in FIXED transform mode.
     */
    public static void renderItemFixed(ItemStack stack, BlockEntityRenderEvent<?> e, Level world) {
        renderItem(stack, CompatItemDisplayContext.FIXED, e, world);
    }

    /**
     * Renders an ItemStack
     */
    public static void renderItem(ItemStack stack, CompatItemDisplayContext displayContext, BlockEntityRenderEvent<?> e, Level world) {
        ItemRenderer renderer = e.getItemRenderer() != null ? e.getItemRenderer() : Minecraft.m_91087_().m_91291_();
        renderer.m_269128_(stack, displayContext.getContext(), e.getLight(), e.getOverlay(), e.matrices, e.vertexConsumers, world, 0);
    }

    public static void renderItemFixed(net.pitan76.mcpitanlib.midohra.item.ItemStack stack, BlockEntityRenderEvent<?> e, net.pitan76.mcpitanlib.midohra.world.World world) {
        renderItemFixed(stack.toMinecraft(), e, world.toMinecraft());
    }

    public static void renderItem(net.pitan76.mcpitanlib.midohra.item.ItemStack stack, CompatItemDisplayContext displayContext, BlockEntityRenderEvent<?> e, net.pitan76.mcpitanlib.midohra.world.World world) {
        renderItem(stack.toMinecraft(), displayContext, e, world.toMinecraft());
    }
}
