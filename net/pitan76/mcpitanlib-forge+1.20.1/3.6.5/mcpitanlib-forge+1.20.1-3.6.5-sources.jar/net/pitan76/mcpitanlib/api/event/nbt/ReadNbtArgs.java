package net.pitan76.mcpitanlib.api.event.nbt;

import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.pitan76.mcpitanlib.api.registry.CompatRegistryLookup;

public class ReadNbtArgs extends NbtRWArgs {

    @Deprecated
    public ReadNbtArgs(CompoundTag nbt, HolderLookup.Provider wrapperLookup) {
        super(nbt, wrapperLookup);
    }

    public ReadNbtArgs(CompoundTag nbt) {
        super(nbt);
    }

    public ReadNbtArgs(CompoundTag nbt, CompatRegistryLookup registryLookup) {
        super(nbt, registryLookup);
    }

    @Override
    public boolean isViewEmpty() {
        return false;
    }

    @Override
    public NbtRWArgs copy() {
        return new ReadNbtArgs(nbt.m_6426_(), registryLookup);
    }

    public ReadNbtArgs(net.pitan76.mcpitanlib.midohra.nbt.NbtCompound nbt, CompatRegistryLookup registryLookup) {
        this(nbt.toMinecraft(), registryLookup);
    }

    public ReadNbtArgs(net.pitan76.mcpitanlib.midohra.nbt.NbtCompound nbt) {
        this(nbt.toMinecraft());
    }
}
