package net.pitan76.mcpitanlib.api.enchantment;

import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraft.world.item.enchantment.EnchantmentHelper;
import net.minecraft.world.level.Level;
import net.pitan76.mcpitanlib.api.util.EnchantmentUtil;
import org.jetbrains.annotations.Nullable;

public class CompatEnchantment {
    private final Enchantment enchantment;

    @Deprecated
    public CompatEnchantment(Enchantment enchantment) {
        this.enchantment = enchantment;
    }

    public CompatEnchantment of(ResourceLocation identifier) {
        return EnchantmentUtil.getEnchantment(identifier);
    }

    public ResourceLocation getId() {
        return BuiltInRegistries.f_256876_.m_7981_(enchantment);
    }

    public String toString() {
        return getId().toString();
    }

    public boolean equals(Object obj) {
        if (obj instanceof CompatEnchantment) {
            return ((CompatEnchantment) obj).getId().equals(getId());
        }
        return false;
    }

    public Enchantment getEnchantment(@Nullable Level world) {
        return enchantment;
    }

    public int getLevel(ItemStack stack, @Nullable Level world) {
        return EnchantmentHelper.m_44843_(enchantment, stack);
    }
}
