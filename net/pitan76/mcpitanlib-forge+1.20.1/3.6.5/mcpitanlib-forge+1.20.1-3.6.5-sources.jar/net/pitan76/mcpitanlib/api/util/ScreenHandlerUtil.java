package net.pitan76.mcpitanlib.api.util;

import dev.architectury.registry.menu.ExtendedMenuProvider;
import dev.architectury.registry.menu.MenuRegistry;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;
import net.minecraft.core.NonNullList;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.MenuProvider;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.MenuType;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.ItemStack;

public class ScreenHandlerUtil {
    public static NonNullList<Slot> getSlots(AbstractContainerMenu screenHandler) {
        return screenHandler.f_38839_;
    }

    public static Slot getSlot(AbstractContainerMenu screenHandler, int index) {
        return screenHandler.m_38853_(index);
    }

    public static List<MenuType<?>> getAllScreenHandlerTypes() {
        List<MenuType<?>> screenHandlerTypes = new ArrayList<>();
        for (MenuType<?> screenHandler : BuiltInRegistries.f_256818_) {
            screenHandlerTypes.add(screenHandler);
        }
        return screenHandlerTypes;
    }

    public static void openExtendedMenu(ServerPlayer player, MenuProvider provider, Consumer<FriendlyByteBuf> bufWriter) {
        MenuRegistry.openExtendedMenu(player, provider, bufWriter);
    }

    public static void openExtendedMenu(ServerPlayer player, ExtendedMenuProvider provider) {
        MenuRegistry.openExtendedMenu(player, provider);
    }

    public static void openMenu(ServerPlayer player, MenuProvider provider) {
        MenuRegistry.openMenu(player, provider);
    }

    public static int getRawId(MenuType<?> type) {
        return BuiltInRegistries.f_256818_.m_7447_(type);
    }

    public static MenuType<?> fromIndex(int index) {
        return BuiltInRegistries.f_256818_.m_7942_(index);
    }

    public static ItemStack getCursorStack(AbstractContainerMenu screenHandler) {
        return screenHandler.m_142621_();
    }

    public static net.pitan76.mcpitanlib.midohra.item.ItemStack getCursorStackM(AbstractContainerMenu screenHandler) {
        return net.pitan76.mcpitanlib.midohra.item.ItemStack.of(getCursorStack(screenHandler));
    }

    public static void setCursorStack(AbstractContainerMenu screenHandler, ItemStack stack) {
        screenHandler.m_142503_(stack);
    }

    public static void setCursorStackM(AbstractContainerMenu screenHandler, net.pitan76.mcpitanlib.midohra.item.ItemStack stack) {
        setCursorStack(screenHandler, stack.toMinecraft());
    }
}
