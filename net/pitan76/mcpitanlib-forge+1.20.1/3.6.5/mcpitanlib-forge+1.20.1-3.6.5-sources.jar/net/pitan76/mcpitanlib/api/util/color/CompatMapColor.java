package net.pitan76.mcpitanlib.api.util.color;

import net.minecraft.world.level.material.MapColor;

public class CompatMapColor {
    private final MapColor color;

    public static final CompatMapColor CLEAR = of(MapColor.f_283808_);
    public static final CompatMapColor PALE_GREEN = of(MapColor.f_283824_);
    public static final CompatMapColor PALE_YELLOW = of(MapColor.f_283761_);
    public static final CompatMapColor WHITE_GRAY = of(MapColor.f_283930_);
    public static final CompatMapColor BRIGHT_RED = of(MapColor.f_283816_);
    public static final CompatMapColor PALE_PURPLE = of(MapColor.f_283828_);
    public static final CompatMapColor IRON_GRAY = of(MapColor.f_283906_);
    public static final CompatMapColor DARK_GREEN = of(MapColor.f_283915_);
    public static final CompatMapColor WHITE = of(MapColor.f_283811_);
    public static final CompatMapColor LIGHT_BLUE_GRAY = of(MapColor.f_283744_);
    public static final CompatMapColor DIRT_BROWN = of(MapColor.f_283762_);
    public static final CompatMapColor STONE_GRAY = of(MapColor.f_283947_);
    public static final CompatMapColor WATER_BLUE = of(MapColor.f_283864_);
    public static final CompatMapColor OAK_TAN = of(MapColor.f_283825_);
    public static final CompatMapColor OFF_WHITE = of(MapColor.f_283942_);
    public static final CompatMapColor ORANGE = of(MapColor.f_283750_);
    public static final CompatMapColor MAGENTA = of(MapColor.f_283931_);
    public static final CompatMapColor LIGHT_BLUE = of(MapColor.f_283869_);
    public static final CompatMapColor YELLOW = of(MapColor.f_283832_);
    public static final CompatMapColor LIME = of(MapColor.f_283916_);
    public static final CompatMapColor PINK = of(MapColor.f_283765_);
    public static final CompatMapColor GRAY = of(MapColor.f_283818_);
    public static final CompatMapColor LIGHT_GRAY = of(MapColor.f_283779_);
    public static final CompatMapColor CYAN = of(MapColor.f_283772_);
    public static final CompatMapColor PURPLE = of(MapColor.f_283889_);
    public static final CompatMapColor BLUE = of(MapColor.f_283743_);
    public static final CompatMapColor BROWN = of(MapColor.f_283748_);
    public static final CompatMapColor GREEN = of(MapColor.f_283784_);
    public static final CompatMapColor RED = of(MapColor.f_283913_);
    public static final CompatMapColor BLACK = of(MapColor.f_283927_);
    public static final CompatMapColor GOLD = of(MapColor.f_283757_);
    public static final CompatMapColor DIAMOND_BLUE = of(MapColor.f_283821_);
    public static final CompatMapColor LAPIS_BLUE = of(MapColor.f_283933_);
    public static final CompatMapColor EMERALD_GREEN = of(MapColor.f_283812_);
    public static final CompatMapColor SPRUCE_BROWN = of(MapColor.f_283819_);
    public static final CompatMapColor DARK_RED = of(MapColor.f_283820_);
    public static final CompatMapColor TERRACOTTA_WHITE = of(MapColor.f_283919_);
    public static final CompatMapColor TERRACOTTA_ORANGE = of(MapColor.f_283895_);
    public static final CompatMapColor TERRACOTTA_MAGENTA = of(MapColor.f_283850_);
    public static final CompatMapColor TERRACOTTA_LIGHT_BLUE = of(MapColor.f_283791_);
    public static final CompatMapColor TERRACOTTA_YELLOW = of(MapColor.f_283843_);
    public static final CompatMapColor TERRACOTTA_LIME = of(MapColor.f_283778_);
    public static final CompatMapColor TERRACOTTA_PINK = of(MapColor.f_283870_);
    public static final CompatMapColor TERRACOTTA_GRAY = of(MapColor.f_283861_);
    public static final CompatMapColor TERRACOTTA_LIGHT_GRAY = of(MapColor.f_283907_);
    public static final CompatMapColor TERRACOTTA_CYAN = of(MapColor.f_283846_);
    public static final CompatMapColor TERRACOTTA_PURPLE = of(MapColor.f_283892_);
    public static final CompatMapColor TERRACOTTA_BLUE = of(MapColor.f_283908_);
    public static final CompatMapColor TERRACOTTA_BROWN = of(MapColor.f_283774_);
    public static final CompatMapColor TERRACOTTA_GREEN = of(MapColor.f_283856_);
    public static final CompatMapColor TERRACOTTA_RED = of(MapColor.f_283798_);
    public static final CompatMapColor TERRACOTTA_BLACK = of(MapColor.f_283771_);
    public static final CompatMapColor DULL_RED = of(MapColor.f_283909_);
    public static final CompatMapColor DULL_PINK = of(MapColor.f_283804_);
    public static final CompatMapColor DARK_CRIMSON = of(MapColor.f_283883_);
    public static final CompatMapColor TEAL = of(MapColor.f_283745_);
    public static final CompatMapColor DARK_AQUA = of(MapColor.f_283749_);
    public static final CompatMapColor DARK_DULL_PINK = of(MapColor.f_283807_);
    public static final CompatMapColor BRIGHT_TEAL = of(MapColor.f_283898_);
    public static final CompatMapColor DEEPSLATE_GRAY = of(MapColor.f_283875_);
    public static final CompatMapColor RAW_IRON_PINK = of(MapColor.f_283877_);
    public static final CompatMapColor LICHEN_GREEN = of(MapColor.f_283769_);

    public CompatMapColor(MapColor color) {
        this.color = color;
    }

    public static CompatMapColor of(MapColor color) {
        return new CompatMapColor(color);
    }

    public MapColor getColor() {
        return color;
    }

    public int getId() {
        return color.f_283805_;
    }

    public int getRgb() {
        return color.f_283871_;
    }

    public int getRenderColor(CompatBrightness brightness) {
        return color.m_284280_(brightness.get());
    }

    @Override
    public int hashCode() {
        return color.hashCode();
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        CompatMapColor other = (CompatMapColor) obj;
        return color.equals(other.color);
    }
}
