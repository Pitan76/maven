package net.pitan76.mcpitanlib.api.util.client;

import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.renderer.GameRenderer;
import net.minecraft.resources.ResourceLocation;

public class RenderUtil {
    public static void setShaderToPositionTexProgram() {
        RenderSystem.setShader(GameRenderer::m_172817_);
    }

    public static void setShaderColor(float red, float green, float blue, float alpha) {
        RenderSystem.setShaderColor(red, green, blue, alpha);
    }

    public static void setShaderTexture(int texture, ResourceLocation id) {
        RenderSystem.setShaderTexture(texture, id);
    }

    public static void enableDepthTest() {
        RenderSystem.enableDepthTest();
    }

    public static void enableTexture() {
        // ～1.19.2
    }

    public static void disableTexture() {
        // ～1.19.2
    }

    public static class RendererUtil extends ScreenUtil.RendererUtil {}
}