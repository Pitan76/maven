package net.pitan76.mcpitanlib.api.item;

import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.CreativeModeTabs;

public class DefaultItemGroups {
    public static final CreativeModeTab BUILDING_BLOCKS = BuiltInRegistries.f_279662_.m_6246_(CreativeModeTabs.f_256788_);
    public static final CreativeModeTab COLORED_BLOCKS = BuiltInRegistries.f_279662_.m_6246_(CreativeModeTabs.f_256725_); // if 1.19.2 and below, BUILDING_BLOCKS
    public static final CreativeModeTab NATURAL = BuiltInRegistries.f_279662_.m_6246_(CreativeModeTabs.f_256776_); // if 1.19.2 and below, DECORATIONS
    public static final CreativeModeTab FUNCTIONAL = BuiltInRegistries.f_279662_.m_6246_(CreativeModeTabs.f_256791_); // if 1.19.2 and below, TRANSPORTATION
    public static final CreativeModeTab REDSTONE = BuiltInRegistries.f_279662_.m_6246_(CreativeModeTabs.f_257028_);
    public static final CreativeModeTab HOTBAR = BuiltInRegistries.f_279662_.m_6246_(CreativeModeTabs.f_256917_);
    public static final CreativeModeTab SEARCH = BuiltInRegistries.f_279662_.m_6246_(CreativeModeTabs.f_256750_);
    public static final CreativeModeTab TOOLS = BuiltInRegistries.f_279662_.m_6246_(CreativeModeTabs.f_256869_);
    public static final CreativeModeTab COMBAT = BuiltInRegistries.f_279662_.m_6246_(CreativeModeTabs.f_256797_);
    public static final CreativeModeTab FOOD_AND_DRINK = BuiltInRegistries.f_279662_.m_6246_(CreativeModeTabs.f_256839_); // if 1.19.2 and below, FOOD
    public static final CreativeModeTab INGREDIENTS = BuiltInRegistries.f_279662_.m_6246_(CreativeModeTabs.f_256968_); // if 1.19.2 and below, MISC
    public static final CreativeModeTab SPAWN_EGGS = BuiltInRegistries.f_279662_.m_6246_(CreativeModeTabs.f_256731_); // if 1.19.2 and below, MISC
    public static final CreativeModeTab OPERATOR = BuiltInRegistries.f_279662_.m_6246_(CreativeModeTabs.f_256837_); // if 1.19.2 and below, MISC
    public static final CreativeModeTab INVENTORY = BuiltInRegistries.f_279662_.m_6246_(CreativeModeTabs.f_257039_);

    // ～1.19.2 Item Group
    public static final CreativeModeTab BREWING = FOOD_AND_DRINK;
    public static final CreativeModeTab TRANSPORTATION = FUNCTIONAL;
    public static final CreativeModeTab DECORATIONS = NATURAL;
    public static final CreativeModeTab MISC = INGREDIENTS;
}