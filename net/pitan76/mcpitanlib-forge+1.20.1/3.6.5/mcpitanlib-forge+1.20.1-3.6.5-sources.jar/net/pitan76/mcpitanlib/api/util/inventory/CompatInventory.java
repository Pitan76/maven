package net.pitan76.mcpitanlib.api.util.inventory;

import net.minecraft.core.NonNullList;
import net.minecraft.world.Container;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.pitan76.mcpitanlib.api.entity.CompatContainerUser;
import net.pitan76.mcpitanlib.api.entity.Player;
import net.pitan76.mcpitanlib.api.registry.CompatRegistryLookup;
import net.pitan76.mcpitanlib.api.util.collection.ItemStackList;
import net.pitan76.mcpitanlib.api.util.inventory.args.CanInsertArgs;
import net.pitan76.mcpitanlib.midohra.nbt.NbtList;

import java.util.List;

public class CompatInventory extends SimpleContainer implements ICompatInventory {
    public CompatInventory(int size) {
        super(size);
    }

    @Override
    public void m_6836_(int slot, ItemStack stack) {
        super.m_6836_(slot, stack);
    }

    /**
     * super method of setStack(slot, stack)
     */
    public final void superSetStack(int slot, ItemStack stack) {
        super.m_6836_(slot, stack);
    }

    /**
     * super method of removeStack(slot, amount)
     */
    public final ItemStack superRemoveStack(int slot, int amount) {
        return super.m_7407_(slot, amount);
    }

    @Override
    public ItemStack m_7407_(int slot, int amount) {
        return callRemoveStack(slot, amount);
    }

    public ItemStack callRemoveStack(int slot, int amount) {
        return super.m_7407_(slot, amount);
    }

    @Override
    public ItemStack m_8016_(int slot) {
        return super.m_8016_(slot);
    }

    @Override
    public ItemStack m_19170_(Item item, int count) {
        return super.m_19170_(item, count);
    }

    @Deprecated
    @Override
    public void m_5856_(net.minecraft.world.entity.player.Player player) {
        onOpen(new Player(player));
    }

    @Deprecated
    @Override
    public void m_5785_(net.minecraft.world.entity.player.Player player) {
        onClose(new Player(player));
    }

    @Deprecated
    @Override
    public net.minecraft.nbt.ListTag m_7927_() {
        return toNbtList(new CompatRegistryLookup()).toMinecraft();
    }

    @Deprecated
    @Override
    public void m_7797_(net.minecraft.nbt.ListTag list) {
        readNbtList(NbtList.of(list), new CompatRegistryLookup());
    }

    @Deprecated
    @Override
    public boolean m_6542_(net.minecraft.world.entity.player.Player player) {
        return canPlayerUse(new Player(player));
    }

    @Deprecated
    @Override
    public boolean m_19183_(ItemStack stack) {
        return canInsert(new CanInsertArgs(stack));
    }

    public void onOpen(Player player) {
        this.onOpen(new CompatContainerUser(player.getEntity()));
    }

    public void onClose(Player player) {
        this.onClose(new CompatContainerUser(player.getEntity()));
    }

    public void onOpen(CompatContainerUser user) {
        super.m_5856_(user.getRaw());
    }

    public void onClose(CompatContainerUser user) {
        super.m_5785_(user.getRaw());
    }

    public NbtList toNbtList(CompatRegistryLookup registries) {
        return NbtList.of(super.m_7927_());
    }

    public void readNbtList(NbtList list, CompatRegistryLookup registries) {
        super.m_7797_(list.toMinecraft());
    }

    public boolean canPlayerUse(Player player) {
        return true;
    }

    public boolean canInsert(CanInsertArgs args) {
        return super.m_19183_(args.getMcStack());
    }

    @Deprecated
    @Override
    public List<ItemStack> m_19195_() {
        return callClearToList();
    }

    public List<ItemStack> callClearToList() {
        return super.m_19195_();
    }

    public NonNullList<ItemStack> callGetHeldStacks() {
        ItemStackList list = ItemStackList.m_182647_(m_6643_());
        for (int i = 0; i < m_6643_(); i++) {
            list.add(callGetStack(i));
        }

        return list;
    }

    public ItemStackList callGetHeldStacksAsItemStackList() {
        return ItemStackList.of(callGetHeldStacks());
    }

    @Deprecated
    @Override
    public ItemStack m_8020_(int slot) {
        return callGetStack(slot);
    }

    public ItemStack callGetStack(int slot) {
        return super.m_8020_(slot);
    }

    @Deprecated
    @Override
    public int m_6643_() {
        return getSize();
    }

    public int getSize() {
        return super.m_6643_();
    }

    @Deprecated
    @Override
    public boolean m_7983_() {
        return callIsEmpty();
    }

    public boolean callIsEmpty() {
        return super.m_7983_();
    }

    @Deprecated
    @Override
    public boolean m_271862_(Container hopperInventory, int slot, ItemStack stack) {
        return callCanTransferTo(hopperInventory, slot, stack);
    }

    public boolean callCanTransferTo(Container hopperInventory, int slot, ItemStack stack) {
        return super.m_271862_(hopperInventory, slot, stack);
    }

    @Deprecated
    @Override
    public ItemStack m_19173_(ItemStack stack) {
        return callAddStack(stack);
    }

    public ItemStack callAddStack(ItemStack stack) {
        return super.m_19173_(stack);
    }

    @Deprecated
    @Override
    public int m_6893_() {
        return callGetMaxCountPerStack();
    }

    public int callGetMaxCountPerStack() {
        return super.m_6893_();
    }
}
