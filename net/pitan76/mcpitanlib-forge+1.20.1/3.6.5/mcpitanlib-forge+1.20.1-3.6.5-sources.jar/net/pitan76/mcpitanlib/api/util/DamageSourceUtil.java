package net.pitan76.mcpitanlib.api.util;

import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.pitan76.mcpitanlib.api.entity.Player;

public class DamageSourceUtil {
    public static DamageSource thrownProjectile(Entity projectile, Entity attacker, Entity source) {
        return source.m_269291_().m_269390_(projectile, attacker);
    }

    public static DamageSource thrownProjectile(Entity projectile, Entity attacker) {
        return thrownProjectile(projectile, attacker, projectile);
    }

    public static DamageSource playerAttack(Player attacker, Entity source) {
        return source.m_269291_().m_269075_(attacker.getPlayerEntity());
    }

    public static DamageSource playerAttack(Player attacker) {
        return playerAttack(attacker, attacker.getPlayerEntity());
    }

    public static DamageSource mobAttack(LivingEntity attacker, Entity source) {
        return source.m_269291_().m_269333_(attacker);
    }

    public static DamageSource mobAttack(LivingEntity attacker) {
        return mobAttack(attacker, attacker);
    }

    public static DamageSource mobProjectile(Entity projectile, LivingEntity attacker, Entity source) {
        return source.m_269291_().m_269299_(projectile, attacker);
    }

    public static DamageSource mobProjectile(Entity projectile, LivingEntity attacker) {
        return mobProjectile(projectile, attacker, projectile);
    }

    public static DamageSource fall(Entity source) {
        return source.m_269291_().m_268989_();
    }
}
