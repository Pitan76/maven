package net.pitan76.mcpitanlib.api.client.gui.screen;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Renderable;
import net.minecraft.client.gui.components.events.GuiEventListener;
import net.minecraft.client.gui.narration.NarratableEntry;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.client.renderer.entity.ItemRenderer;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.pitan76.mcpitanlib.api.client.gui.widget.CompatibleTexturedButtonWidget;
import net.pitan76.mcpitanlib.api.client.render.DrawObjectDM;
import net.pitan76.mcpitanlib.api.client.render.handledscreen.*;
import net.pitan76.mcpitanlib.api.client.render.screen.RenderBackgroundTextureArgs;
import net.pitan76.mcpitanlib.api.text.TextComponent;
import net.pitan76.mcpitanlib.api.util.CompatIdentifier;
import net.pitan76.mcpitanlib.api.util.IdentifierUtil;
import net.pitan76.mcpitanlib.api.util.client.ClientUtil;
import net.pitan76.mcpitanlib.api.util.client.RenderUtil;
import net.pitan76.mcpitanlib.api.util.client.ScreenUtil;
import net.pitan76.mcpitanlib.core.datafixer.Pair;

public abstract class SimpleHandledScreen<S extends AbstractContainerMenu> extends AbstractContainerScreen<S> {

    public int f_96543_, f_96544_, f_97726_, f_97727_, f_97735_, f_97736_;
    public S f_97732_;
    public Font f_96547_;
    public ItemRenderer itemRenderer;

    public Component f_96539_;
    public Minecraft f_96541_;
    public SimpleHandledScreen(S handler, Inventory inventory, Component title) {
        super(handler, inventory, title);
        fixScreen();
        this.f_97732_ = handler;
        this.f_96539_ = title;

    }

    @Deprecated
    @Override
    public S m_6262_() {
        return getScreenHandlerOverride();
    }

    public S getScreenHandlerOverride() {
        return super.m_6262_();
    }

    public <T extends GuiEventListener & Renderable & NarratableEntry> T addDrawableChild_compatibility(T drawableElement) {
        return super.m_142416_(drawableElement);
        // addButton
    }

    public <T extends GuiEventListener & NarratableEntry> T addSelectableChild_compatibility(T selectableElement) {
        return super.m_7787_(selectableElement);
    }

    public CompatibleTexturedButtonWidget addDrawableCTBW(CompatibleTexturedButtonWidget widget) {
        return addDrawableChild_compatibility(widget);
    }

    @Deprecated
    @Override
    protected void m_7286_(GuiGraphics context, float delta, int mouseX, int mouseY) {
        DrawObjectDM drawObjectDM = new DrawObjectDM(context, this);
        drawBackgroundOverride(new DrawBackgroundArgs(drawObjectDM, delta, mouseX, mouseY));
    }

    public abstract void drawBackgroundOverride(DrawBackgroundArgs args);

    @Deprecated
    @Override
    protected void m_280003_(GuiGraphics context, int mouseX, int mouseY) {
        DrawObjectDM drawObjectDM = new DrawObjectDM(context, this);
        drawForegroundOverride(new DrawForegroundArgs(drawObjectDM, mouseX, mouseY));
    }

    protected void drawForegroundOverride(DrawForegroundArgs args) {
        super.m_280003_(args.drawObjectDM.getContext(), args.mouseX, args.mouseY);
    }

    public void callDrawTexture(DrawObjectDM drawObjectDM, ResourceLocation texture, int x, int y, int u, int v, int width, int height) {
        //ScreenUtil.setBackground(GUI);
        //super.drawTexture(matrices, x, y, u, v, width, height);
        drawObjectDM.getContext().m_280218_(texture, x, y, u, v, width, height);
    }

    public void callDrawTexture(DrawObjectDM drawObjectDM, CompatIdentifier texture, int x, int y, int u, int v, int width, int height) {
        callDrawTexture(drawObjectDM, texture.toMinecraft(), x, y, u, v, width, height);
    }

    @Deprecated
    public void callRenderBackground(DrawObjectDM drawObjectDM) {
        callRenderBackground(new RenderArgs(drawObjectDM, 0, 0, 0));
    }


    public void callRenderBackground(RenderArgs args) {
        super.m_280273_(args.drawObjectDM.getContext());
    }

    public void callDrawMouseoverTooltip(DrawMouseoverTooltipArgs args) {
        super.m_280072_(args.drawObjectDM.getContext(), args.mouseX, args.mouseY);
    }

    public void renderOverride(RenderArgs args) {
        super.m_88315_(args.drawObjectDM.getContext(), args.mouseX, args.mouseY, args.delta);
    }

    public void resizeOverride(Minecraft client, int width, int height) {
    }

    public void initOverride() {
    }

    @Deprecated
    @Override
    protected void m_7856_() {
        super.m_7856_();
        fixScreen();
        initOverride();
    }

    @Deprecated
    @Override
    public void m_6574_(Minecraft client, int width, int height) {
        super.m_6574_(client, width, height);
        fixScreen();
        resizeOverride(client, width, height);
    }

    public void fixScreen() {
        this.f_97726_ = getBackgroundWidth();
        this.f_97727_ = getBackgroundHeight();
        this.f_97735_ = super.f_97735_; //(this.width - this.backgroundWidth) / 2;
        this.f_97736_ = super.f_97736_; //(this.height - this.backgroundHeight) / 2;
        this.f_96547_ = super.f_96547_;
        this.itemRenderer = Minecraft.m_91087_().m_91291_();
        this.f_96543_ = super.f_96543_;
        this.f_96544_ = super.f_96544_;
        if (super.f_96541_ == null)
            this.f_96541_ = Minecraft.m_91087_();
        else
            this.f_96541_ = super.f_96541_;
    }

    public void setX(int x) {
        this.f_97735_ = x;
        super.f_97735_ = x;
    }

    public void setY(int y) {
        this.f_97736_ = y;
        super.f_97736_ = y;
    }

    public void setTextRenderer(Font textRenderer) {
        this.f_96547_ = textRenderer;
        super.f_96547_ = textRenderer;
    }

    public void setItemRenderer(ItemRenderer itemRenderer) {
        this.itemRenderer = itemRenderer;
    }

    public void setWidth(int width) {
        this.f_96543_ = width;
        super.f_96543_ = width;
    }

    public void setBackgroundWidth(int backgroundWidth) {
        this.f_97726_ = backgroundWidth;
        super.f_97726_ = backgroundWidth;
    }

    public void setBackgroundHeight(int backgroundHeight) {
        this.f_97727_ = backgroundHeight;
        super.f_97727_ = backgroundHeight;
    }

    public void setHeight(int height) {
        this.f_96544_ = height;
        super.f_96544_ = height;
    }

    public int getBackgroundWidth() {
        return super.f_97726_;
    }

    public int getBackgroundHeight() {
        return super.f_97727_;
    }

    @Deprecated
    @Override
    public void m_88315_(GuiGraphics context, int mouseX, int mouseY, float delta) {
        DrawObjectDM drawObjectDM = new DrawObjectDM(context, this);
        renderOverride(new RenderArgs(drawObjectDM, mouseX, mouseY, delta));
    }

    public boolean keyReleased(KeyEventArgs args) {
        return super.m_7920_(args.keyCode, args.scanCode, args.modifiers);
    }

    public boolean keyPressed(KeyEventArgs args) {
        return super.m_7933_(args.keyCode, args.scanCode, args.modifiers);
    }

    public void renderBackgroundTexture(RenderBackgroundTextureArgs args) {
        if (getBackgroundTexture() == null) {
            super.m_280039_(args.drawObjectDM.getContext());
            return;
        }

        RenderUtil.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
        callDrawTexture(args.drawObjectDM, getBackgroundTexture(), 0, 0, 0, 0, f_96543_, f_96544_);
    }

    @Deprecated
    @Override
    public boolean m_7920_(int keyCode, int scanCode, int modifiers) {
        return this.keyReleased(new KeyEventArgs(keyCode, scanCode, modifiers));
    }

    @Deprecated
    @Override
    public boolean m_7933_(int keyCode, int scanCode, int modifiers) {
        return this.keyPressed(new KeyEventArgs(keyCode, scanCode, modifiers));
    }

    @Deprecated
    @Override
    public void m_280039_(GuiGraphics context) {
        this.renderBackgroundTexture(new RenderBackgroundTextureArgs(new DrawObjectDM(context, this), 0));
    }

    public void closeOverride() {
        super.m_7379_();
    }

    public void removedOverride() {
        super.m_7861_();
    }

    @Override
    public void m_7379_() {
        closeOverride();
    }

    @Override
    public void m_7861_() {
        removedOverride();
    }

    public ResourceLocation getBackgroundTexture() {
        return IdentifierUtil.from(getCompatBackgroundTexture());
    }

    public CompatIdentifier getCompatBackgroundTexture() {
        return null;
    }

    public void setTitleX(int x) {
        this.f_97728_ = x;
    }

    public void setTitleY(int y) {
        this.f_97729_ = y;
    }

    public void setTitlePos(int x, int y) {
        setTitleX(x);
        setTitleY(y);
    }

    public void setTitleXCenter() {
        if (f_96547_ == null)
            f_96547_ = ClientUtil.getTextRenderer();

        setTitleX(f_97726_ / 2 - f_96547_.m_92852_(f_96539_) / 2);
    }

    public int getTitleX() {
        return f_97728_;
    }

    public int getTitleY() {
        return f_97729_;
    }

    public void drawText(DrawObjectDM drawObjectDM, Component text, int x, int y, int color) {
        ScreenUtil.RendererUtil.drawText(f_96547_, drawObjectDM, text, x, y, color);
    }

    public void drawText(DrawObjectDM drawObjectDM, TextComponent text, int x, int y, int color) {
        ScreenUtil.RendererUtil.drawText(f_96547_, drawObjectDM, text, x, y, color);
    }

    public void drawText(DrawObjectDM drawObjectDM, Component text, int x, int y) {
        ScreenUtil.RendererUtil.drawText(f_96547_, drawObjectDM, text, x, y);
    }

    public void drawText(DrawObjectDM drawObjectDM, TextComponent text, int x, int y) {
        ScreenUtil.RendererUtil.drawText(f_96547_, drawObjectDM, text, x, y);
    }

    @Deprecated
    @Override
    public Component m_96636_() {
        return callGetTitle();
    }

    public Component callGetTitle() {
        return super.m_96636_();
    }

    public Pair<Integer, Integer> getTitlePosP() {
        return new Pair<>(getTitleX(), getTitleY());
    }

    public int getPlayerInvTitleX() {
        return f_97730_;
    }

    public int getPlayerInvTitleY() {
        return f_97731_;
    }

    public void setPlayerInvTitleX(int x) {
        f_97730_ = x;
    }

    public void setPlayerInvTitleY(int y) {
        f_97731_ = y;
    }

    public void setPlayerInvTitle(int x, int y) {
        setPlayerInvTitleX(x);
        setPlayerInvTitleY(y);
    }

    public Font callGetTextRenderer() {
        if (f_96547_ != null)
            return f_96547_;

        if (super.f_96547_ != null)
            return super.f_96547_;

        return ClientUtil.getTextRenderer();
    }

    public ItemRenderer callGetItemRenderer() {
        if (itemRenderer != null)
            return itemRenderer;

        return ClientUtil.getItemRenderer();
    }

    public Component getPlayerInvTitle() {
        return f_169604_;
    }
}
