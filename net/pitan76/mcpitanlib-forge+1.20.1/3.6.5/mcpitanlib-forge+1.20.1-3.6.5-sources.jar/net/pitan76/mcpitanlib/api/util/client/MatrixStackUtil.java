package net.pitan76.mcpitanlib.api.util.client;

import net.pitan76.mcpitanlib.api.util.MathUtil;

import static net.pitan76.mcpitanlib.api.util.MathUtil.getRotationDegrees;

import com.mojang.blaze3d.vertex.PoseStack;

public class MatrixStackUtil {
    public static void multiply(PoseStack matrixStack, MathUtil.RotationAxisType type, float deg) {
        matrixStack.m_252781_(getRotationDegrees(type, deg));
    }

    public static void push(PoseStack matrices) {
        matrices.m_85836_();
    }

    public static void pop(PoseStack matrices) {
        matrices.m_85849_();
    }

    public static void translate(PoseStack matrices, double x, double y, double z) {
        matrices.m_85837_(x, y, z);
    }

    public static void scale(PoseStack matrices, float x, float y, float z) {
        matrices.m_85841_(x, y, z);
    }

    public static PoseStack.Pose peek(PoseStack matrices) {
        return matrices.m_85850_();
    }
}
