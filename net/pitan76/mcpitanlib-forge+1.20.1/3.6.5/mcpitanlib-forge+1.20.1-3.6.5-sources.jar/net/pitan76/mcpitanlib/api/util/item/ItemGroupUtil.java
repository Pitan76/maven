package net.pitan76.mcpitanlib.api.util.item;

import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.CreativeModeTab;
import net.pitan76.mcpitanlib.api.util.CompatIdentifier;

public class ItemGroupUtil {
    public static ResourceLocation toID(CreativeModeTab itemGroup) {
        return BuiltInRegistries.f_279662_.m_7981_(itemGroup);
    }

    public static CreativeModeTab fromId(ResourceLocation identifier) {
        return BuiltInRegistries.f_279662_.m_7745_(identifier);
    }

    public static boolean isExist(ResourceLocation identifier) {
        return BuiltInRegistries.f_279662_.m_7804_(identifier);
    }

    public static CompatIdentifier toCompatID(CreativeModeTab itemGroup) {
        return CompatIdentifier.fromMinecraft(toID(itemGroup));
    }

    public static CreativeModeTab fromId(CompatIdentifier identifier) {
        return fromId(identifier.toMinecraft());
    }

    public static boolean isExist(CompatIdentifier identifier) {
        return isExist(identifier.toMinecraft());
    }

    public static int getRawId(CreativeModeTab itemGroup) {
        return BuiltInRegistries.f_279662_.m_7447_(itemGroup);
    }

    public static CreativeModeTab fromIndex(int index) {
        return BuiltInRegistries.f_279662_.m_7942_(index);
    }
}
