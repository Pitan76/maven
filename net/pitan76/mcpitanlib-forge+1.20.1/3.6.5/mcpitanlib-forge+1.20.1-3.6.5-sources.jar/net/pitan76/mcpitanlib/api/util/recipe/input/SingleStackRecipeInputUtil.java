package net.pitan76.mcpitanlib.api.util.recipe.input;

import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.ticks.ContainerSingleItem;
import net.pitan76.mcpitanlib.api.recipe.input.CompatRecipeInput;
import net.pitan76.mcpitanlib.api.util.ItemStackUtil;

import java.util.Optional;

public class SingleStackRecipeInputUtil {
    public static Optional<ContainerSingleItem> get(CompatRecipeInput<?> input) {
        if (input.getInput() instanceof ContainerSingleItem) {
            return Optional.of((ContainerSingleItem) input.getInput());
        }
        return Optional.empty();
    }

    public static CompatRecipeInput<?> create(ContainerSingleItem input) {
        return new CompatRecipeInput<>(input);
    }

    public static CompatRecipeInput<?> create(ItemStack stack) {
        return new CompatRecipeInput<>(new ContainerSingleItem() {
            private ItemStack itemStack = stack;

            @Override
            public ItemStack m_8020_(int slot) {
                if (slot == 0)
                    return itemStack;
                return ItemStackUtil.empty();
            }

            @Override
            public ItemStack m_7407_(int slot, int amount) {
                if (slot == 0) {
                    ItemStack stack = itemStack;
                    itemStack = ItemStackUtil.empty();
                    return stack;
                }
                return ItemStackUtil.empty();
            }

            @Override
            public void m_6836_(int slot, ItemStack stack) {
                if (slot == 0)
                    itemStack = stack;
            }

            @Override
            public void m_6596_() {

            }

            @Override
            public boolean m_6542_(Player player) {
                return false;
            }

            @Override
            public ItemStack m_272036_() {
                return itemStack;
            }

            @Override
            public void m_272287_(ItemStack stack) {
                this.itemStack = stack;
            }
        });
    }

    public static ItemStack getStack(CompatRecipeInput<?> input) {
        Optional<ContainerSingleItem> recipeInput = get(input);
        if (!recipeInput.isPresent()) return ItemStackUtil.empty();

        return recipeInput.get().m_8020_(0);
    }
}
