package net.pitan76.mcpitanlib.api.client.event.listener;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.Camera;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.render.*;
import net.minecraft.client.renderer.GameRenderer;
import net.minecraft.client.renderer.LevelRenderer;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.culling.Frustum;
import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.shapes.VoxelShape;
import net.pitan76.mcpitanlib.api.util.VoxelShapeUtil;
import net.pitan76.mcpitanlib.midohra.client.render.CameraWrapper;
import org.jetbrains.annotations.Nullable;
import org.joml.Matrix4f;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import java.util.Objects;
import java.util.Optional;

public interface WorldRenderContext {

    LevelRenderer getWorldRenderer();

    PoseStack getMatrixStack();

    float getTickDelta();

    Camera getCamera();

    GameRenderer getGameRenderer();

    LightTexture getLightmapTextureManager();

    @Deprecated
    Matrix4f getProjectionMatrix();

    ClientLevel getWorld();

    @Deprecated
    boolean isAdvancedTranslucency();

    @Nullable MultiBufferSource getConsumers();
    @Nullable Frustum getFrustum();

    @Environment(EnvType.CLIENT)
    interface BlockOutlineContext {
        @Deprecated
        VertexConsumer vertexConsumer();

        Entity entity();

        double cameraX();

        double cameraY();

        double cameraZ();

        BlockPos blockPos();

        BlockState blockState();
    }

    default HitResult getHitResult() {
        return Minecraft.m_91087_().f_91077_;
    }

    default Optional<BlockState> getBlockState() {
        return Optional.ofNullable(getWorld().m_8055_(getBlockPos().orElse(null)));
    }

    default Optional<BlockPos> getBlockPos() {
        return Optional.ofNullable(((BlockHitResult) getHitResult()).m_82425_());
    }

    default boolean isBlockType() {
        return getHitResultType() == HitResult.Type.BLOCK;
    }

    default HitResult.Type getHitResultType() {
        return getHitResult().m_6662_();
    }

    default Optional<VoxelShape> getOutlineShape() {
        return getBlockState().map(blockState -> blockState.m_60808_(getWorld(),
                getBlockPos().orElse(null)));
    }

    default void push() {
        getMatrixStack().m_85836_();
    }

    default void translate(double x, double y, double z) {
        getMatrixStack().m_85837_(x, y, z);
    }

    default void pop() {
        getMatrixStack().m_85849_();
    }

    default Optional<VertexConsumer> getVertexConsumer() {
        if (getConsumers() == null)
            return Optional.empty();

        return Optional.of(Objects.requireNonNull(getConsumers()).m_6299_(RenderType.m_110504_()));
    }

    default void drawBox(float red, float green, float blue, float alpha) {
        Optional<VoxelShape> outlineShape = getOutlineShape();
        if (!outlineShape.isPresent()) return;

        drawBox(VoxelShapeUtil.getBoundingBox(outlineShape.get()), red, green, blue, alpha);
    }

    default void drawBox(AABB box, float red, float green, float blue, float alpha) {
        Optional<VertexConsumer> vertexConsumer = getVertexConsumer();

        if (!vertexConsumer.isPresent())
            return;

        LevelRenderer.m_109646_(getMatrixStack(), vertexConsumer.get(), box, red, green, blue, alpha);
    }

    default CameraWrapper getCameraWrapper() {
        return CameraWrapper.of(getCamera());
    }
}
