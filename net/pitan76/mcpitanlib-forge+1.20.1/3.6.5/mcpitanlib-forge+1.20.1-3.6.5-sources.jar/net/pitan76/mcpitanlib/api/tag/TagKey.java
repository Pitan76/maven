package net.pitan76.mcpitanlib.api.tag;

import net.minecraft.core.Holder;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.material.Fluid;
import net.pitan76.mcpitanlib.api.util.*;

public class TagKey<T> {
    private final net.minecraft.tags.TagKey<T> tagKey;

    @Deprecated
    public TagKey(net.minecraft.tags.TagKey<T> tagKey) {
        this.tagKey = tagKey;
    }

    public static TagKey<?> create(Type type, ResourceLocation identifier) {
        return switch (type) {
            case BLOCK -> new TagKey<>(net.minecraft.tags.TagKey.m_203882_(Registries.f_256747_, identifier));
            case ITEM -> new TagKey<>(net.minecraft.tags.TagKey.m_203882_(Registries.f_256913_, identifier));
            case FLUID -> new TagKey<>(net.minecraft.tags.TagKey.m_203882_(Registries.f_256808_, identifier));
            case ENTITY_TYPE -> new TagKey<>(net.minecraft.tags.TagKey.m_203882_(Registries.f_256939_, identifier));
        };
    }

    public static TagKey<?> create(Type type, CompatIdentifier id) {
        return create(type, id.toMinecraft());
    }

    @Deprecated
    public net.minecraft.tags.TagKey<T> getTagKey() {
        return tagKey;
    }

    public enum Type {
        BLOCK,
        ITEM,
        FLUID,
        ENTITY_TYPE,
    }

    public boolean isOf(T value) {
        if (value instanceof Item)
            return getTagKey() == net.minecraft.tags.TagKey.m_203882_(Registries.f_256913_, ItemUtil.toID((Item) value));
        if (value instanceof Block)
            return getTagKey() == net.minecraft.tags.TagKey.m_203882_(Registries.f_256747_, BlockUtil.toID((Block) value));
        if (value instanceof Fluid)
            return getTagKey() == net.minecraft.tags.TagKey.m_203882_(Registries.f_256808_, FluidUtil.toID((Fluid) value));
        if (value instanceof EntityType<?>)
            return getTagKey() == net.minecraft.tags.TagKey.m_203882_(Registries.f_256939_, EntityTypeUtil.toID((EntityType<?>) value));

        return Holder.m_205709_(value).m_203656_(getTagKey());
    }
}
