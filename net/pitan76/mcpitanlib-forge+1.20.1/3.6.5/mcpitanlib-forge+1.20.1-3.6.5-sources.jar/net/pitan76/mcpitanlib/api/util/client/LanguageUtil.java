package net.pitan76.mcpitanlib.api.util.client;

import net.minecraft.client.resources.language.I18n;
import net.minecraft.client.resources.language.LanguageManager;
import net.pitan76.mcpitanlib.midohra.resource.ResourceManager;

public class LanguageUtil {
    public static boolean hasTranslation(String key) {
        return I18n.m_118936_(key);
    }

    public static String translate(String key) {
        return I18n.m_118938_(key);
    }

    public static String translate(String key, Object... args) {
        return I18n.m_118938_(key, args);
    }

    public static String translateWithFallback(String key, String fallback) {
        return I18n.m_118936_(key) ? I18n.m_118938_(key) : fallback;
    }

    public static String translateWithFallback(String key, String fallback, Object... args) {
        return I18n.m_118936_(key) ? I18n.m_118938_(key, args) : fallback;
    }

    public static LanguageManager getLanguageManager() {
        return ClientUtil.getClient().m_91102_();
    }

    public static String getLanguage() {
        return getLanguageManager().m_264236_();
    }

    public static void setLanguage(String language) {
        getLanguageManager().m_264110_(language);
    }

    public static void reload(net.minecraft.server.packs.resources.ResourceManager resourceManager) {
        getLanguageManager().m_6213_(resourceManager);
    }

    public static void reload(ResourceManager resourceManager) {
        reload(resourceManager.getRaw());
    }
}
