package net.pitan76.mcpitanlib.api.item;

import dev.architectury.registry.registries.RegistrySupplier;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.food.FoodProperties;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Rarity;
import net.pitan76.mcpitanlib.api.util.CompatIdentifier;
import net.pitan76.mcpitanlib.core.registry.MCPLRegistry1_20;

import java.util.function.Supplier;

@Deprecated
public class CompatibleItemSettings {
    protected final ExtendSettings settings = new ExtendSettings();

    protected ResourceLocation itemGroupId = null;

    @Deprecated
    public static CompatibleItemSettings of() {
        return new CompatibleItemSettings();
    }

    // ～1.19.2
    public CompatibleItemSettings addGroup(CreativeModeTab itemGroup) {
        settings.addGroup(itemGroup);
        return this;
    }

    // 1.19.3～
    // identifier: Item ID
    public CompatibleItemSettings addGroup(CreativeModeTab itemGroup, ResourceLocation identifier) {
        settings.addGroup(itemGroup, identifier);
        return this;
    }

    public CompatibleItemSettings addGroup(Supplier<CreativeModeTab> itemGroup, ResourceLocation identifier) {
        settings.addGroup(itemGroup, identifier);
        return this;
    }

    public CompatibleItemSettings addGroup(CreativeTabBuilder itemGroup) {
        this.itemGroupId = itemGroup.getIdentifier();
        return this;
    }

    public CompatibleItemSettings maxCount(int maxCount) {
        settings.m_41487_(maxCount);
        return this;
    }

    public CompatibleItemSettings maxDamage(int maxDamage) {
        settings.m_41503_(maxDamage);
        return this;
    }

    public CompatibleItemSettings maxDamageIfAbsent(int maxDamage) {
        settings.m_41499_(maxDamage);
        return this;
    }

    @Deprecated
    public CompatibleItemSettings food(FoodProperties foodComponent) {
        settings.m_41489_(foodComponent);
        return this;
    }

    public CompatibleItemSettings rarity(Rarity rarity) {
        settings.m_41497_(rarity);
        return this;
    }

    public CompatibleItemSettings recipeRemainder(Item recipeRemainder) {
        settings.m_41495_(recipeRemainder);
        return this;
    }

    public ExtendSettings build() {
        if (itemGroupId != null) {
            RegistrySupplier<CreativeModeTab> itemGroup = MCPLRegistry1_20.REGISTRY_SUPPLIER_ITEM_GROUP_CACHE.get(itemGroupId);
            settings.arch$tab(itemGroup);
        }
        return settings;
    }

    public CompatibleItemSettings addGroup(CreativeModeTab itemGroup, CompatIdentifier identifier) {
        return addGroup(itemGroup, identifier.toMinecraft());
    }

    public CompatibleItemSettings addGroup(Supplier<CreativeModeTab> itemGroup, CompatIdentifier identifier) {
        return addGroup(itemGroup, identifier.toMinecraft());
    }

    public CompatibleItemSettings food(CompatFoodComponent foodComponent) {
        return food(foodComponent.build());
    }
}
