package net.pitan76.mcpitanlib.api.util;

import net.minecraft.server.MinecraftServer;
import net.minecraft.server.players.PlayerList;
import net.minecraft.world.level.Level;
import net.pitan76.mcpitanlib.api.entity.Player;

public class ServerUtil {
    public static MinecraftServer getServer(Level world) {
        return world.m_7654_();
    }

    public static String getIP(MinecraftServer server) {
        return server.m_130009_();
    }

    public static int getPort(MinecraftServer server) {
        return server.m_7010_();
    }

    public static String getMotd(MinecraftServer server) {
        return server.m_129916_();
    }

    public static String getServerModName(MinecraftServer server) {
        return server.getServerModName();
    }

    public static int getMaxPlayerCount(MinecraftServer server) {
        return server.m_7418_();
    }

    public static int getCurrentPlayerCount(MinecraftServer server) {
        return server.m_7416_();
    }

    public static boolean isOnlineMode(MinecraftServer server) {
        return server.m_129797_();
    }

    public static boolean isServerRunning(MinecraftServer server) {
        return server.m_130010_();
    }

    public static boolean isServerDedicated(MinecraftServer server) {
        return server.m_6982_();
    }

    public static boolean isSingleplayer(MinecraftServer server) {
        return server.m_129792_();
    }

    public static PlayerList getPlayerManager(MinecraftServer server) {
        return server.m_6846_();
    }

    public static MinecraftServer getServer(Player player) {
        return getServer(player.getWorld());
    }

    public static void execute(MinecraftServer server, Runnable runnable) {
        server.execute(runnable);
    }
}
