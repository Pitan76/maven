package net.pitan76.mcpitanlib.api.util.v1;

import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.pitan76.mcpitanlib.api.block.CompatibleBlockSettings;
import net.pitan76.mcpitanlib.api.tag.MineableToolTags;

import java.util.ArrayList;
import java.util.List;

public class BlockUtilV1 {
    public static Block block(ResourceLocation id) {
        return BuiltInRegistries.f_256975_.m_7745_(id);
    }

    /**
     * ～1.16?
     * @param settings
     * @param toolTags
     * @param level
     * @return
     */
    public static BlockBehaviour.Properties breakByTool(BlockBehaviour.Properties settings, MineableToolTags toolTags, int level) {
        return settings;
    }

    public static BlockBehaviour.Properties dropsNothing(BlockBehaviour.Properties settings) {
        return settings.m_222994_();
    }

    public static BlockBehaviour.Properties requiresTool(BlockBehaviour.Properties settings) {
        return settings.m_60999_();
    }

    public static boolean isExist(ResourceLocation identifier) {
        return BuiltInRegistries.f_256975_.m_7804_(identifier);
    }

    public static ResourceLocation toID(Block block) {
        return BuiltInRegistries.f_256975_.m_7981_(block);
    }

    public static Block fromId(ResourceLocation identifier) {
        return BuiltInRegistries.f_256975_.m_7745_(identifier);
    }

    public static List<Block> getAllBlocks() {
        List<Block> blocks = new ArrayList<>();
        for (Block block : BuiltInRegistries.f_256975_) {
            blocks.add(block);
        }
        return blocks;
    }

    @Deprecated
    public static Block of(BlockBehaviour.Properties settings) {
        return new Block(settings);
    }

    public static Block of(CompatibleBlockSettings settings) {
        return of(settings.build());
    }

    public static int getRawId(Block block) {
        return BuiltInRegistries.f_256975_.m_7447_(block);
    }

    public static Block fromIndex(int index) {
        return BuiltInRegistries.f_256975_.m_7942_(index);
    }
}
