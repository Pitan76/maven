package net.pitan76.mcpitanlib.api.util;

import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.EntityType;

public class EntityTypeUtil {
    public static ResourceLocation toID(EntityType<?> entityType) {
        return BuiltInRegistries.f_256780_.m_7981_(entityType);
    }

    public static EntityType<?> fromId(ResourceLocation identifier) {
        return BuiltInRegistries.f_256780_.m_7745_(identifier);
    }

    public static boolean isExist(ResourceLocation identifier) {
        return BuiltInRegistries.f_256780_.m_7804_(identifier);
    }

    public static CompatIdentifier toCompatID(EntityType<?> entityType) {
        return CompatIdentifier.fromMinecraft(toID(entityType));
    }

    public static EntityType<?> fromId(CompatIdentifier identifier) {
        return fromId(identifier.toMinecraft());
    }

    public static boolean isExist(CompatIdentifier identifier) {
        return isExist(identifier.toMinecraft());
    }

    public static int getRawId(EntityType<?> type) {
        return BuiltInRegistries.f_256780_.m_7447_(type);
    }

    public static EntityType<?> fromIndex(int index) {
        return BuiltInRegistries.f_256780_.m_7942_(index);
    }

    public static Component getName(EntityType<?> entityType) {
        return entityType.m_20676_();
    }

    public static String getTranslationKey(EntityType<?> entityType) {
        return entityType.m_20675_();
    }
}
