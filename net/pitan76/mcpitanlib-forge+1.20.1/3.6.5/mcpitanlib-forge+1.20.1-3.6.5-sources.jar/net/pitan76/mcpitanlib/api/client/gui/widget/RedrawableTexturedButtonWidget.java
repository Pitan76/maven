package net.pitan76.mcpitanlib.api.client.gui.widget;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;

public class RedrawableTexturedButtonWidget extends CompatibleTexturedButtonWidget {
    public ResourceLocation texture;
    public int u;
    public int v;
    public int hoveredVOffset;
    public int textureWidth;
    public int textureHeight;

    public RedrawableTexturedButtonWidget(int x, int y, int width, int height, int u, int v, int hoveredVOffset, ResourceLocation texture, int textureWidth, int textureHeight, OnPress pressAction, Component message) {
        super(x, y, width, height, u, v, hoveredVOffset, texture, textureWidth, textureHeight, pressAction, message);
        this.f_94227_ = textureWidth;
        this.f_94228_ = textureHeight;
        this.f_94224_ = u;
        this.f_94225_ = v;
        this.f_94226_ = hoveredVOffset;
        this.f_94223_ = texture;
    }

    public void m_87963_(GuiGraphics context, int mouseX, int mouseY, float delta) {
        this.m_280322_(context, this.f_94223_, this.m_252754_(), this.m_252907_(), this.f_94224_, this.f_94225_, this.f_94226_, this.f_93618_, this.f_93619_, this.f_94227_, this.f_94228_);
    }

    public void setTexture(ResourceLocation texture) {
        this.f_94223_ = texture;
    }

    public void setU(int u) {
        this.f_94224_ = u;
    }

    public void setV(int v) {
        this.f_94225_ = v;
    }

    public void setHoveredVOffset(int hoveredVOffset) {
        this.f_94226_ = hoveredVOffset;
    }

    public void setTextureWidth(int textureWidth) {
        this.f_94227_ = textureWidth;
    }

    public void setTextureHeight(int textureHeight) {
        this.f_94228_ = textureHeight;
    }
}
