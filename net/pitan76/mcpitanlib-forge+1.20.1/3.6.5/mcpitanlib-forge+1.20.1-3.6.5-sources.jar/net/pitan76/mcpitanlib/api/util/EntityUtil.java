package net.pitan76.mcpitanlib.api.util;

import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.RelativeMovement;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Rotation;
import net.minecraft.world.phys.Vec3;
import net.pitan76.mcpitanlib.api.entity.Player;
import net.pitan76.mcpitanlib.midohra.util.math.BlockPos;
import net.pitan76.mcpitanlib.midohra.util.math.Vector3d;

import java.util.UUID;

public class EntityUtil {
    public static Level getWorld(Entity entity) {
        return entity.m_9236_();
    }

    public static boolean damage(Entity target, DamageSource damageSource, float amount) {
        return target.m_6469_(damageSource, amount);
    }

    public static boolean damageWithThrownProjectile(Entity target, float damageAmount, Entity projectile, Entity attacker) {
        return target.m_6469_(DamageSourceUtil.thrownProjectile(projectile, attacker), damageAmount);
    }

    public static boolean damageWithMobProjectile(Entity target, float damageAmount, Entity projectile, LivingEntity attacker) {
        return target.m_6469_(DamageSourceUtil.mobProjectile(projectile, attacker), damageAmount);
    }

    public static boolean damageWithMobAttack(Entity target, float damageAmount, Entity source, LivingEntity attacker) {
        return target.m_6469_(DamageSourceUtil.mobAttack(attacker, source), damageAmount);
    }

    public static boolean damageWithPlayerAttack(Entity target, float damageAmount, Entity source, Player attacker) {
        return target.m_6469_(DamageSourceUtil.playerAttack(attacker, source), damageAmount);
    }

    public static void discard(Entity entity) {
        entity.m_146870_();
    }

    public static void kill(Entity entity) {
        entity.m_6074_();
    }

    public static void setVelocity(Entity entity, double x, double y, double z) {
        entity.m_20334_(x, y, z);
    }

    public static Vec3 getVelocity(Entity entity) {
        return entity.m_20184_();
    }

    public static void setNoGravity(Entity entity, boolean noGravity) {
        entity.m_20242_(noGravity);
    }

    public static boolean hasNoGravity(Entity entity) {
        return entity.m_20068_();
    }

    public static void setInvulnerable(Entity entity, boolean invulnerable) {
        entity.m_20331_(invulnerable);
    }

    public static boolean isInvulnerable(Entity entity) {
        return entity.m_20147_();
    }

    public static void setSilent(Entity entity, boolean silent) {
        entity.m_20225_(silent);
    }

    public static boolean isSilent(Entity entity) {
        return entity.m_20067_();
    }

    public static void setGlowing(Entity entity, boolean glowing) {
        entity.m_146915_(glowing);
    }

    public static boolean isGlowing(Entity entity) {
        return entity.m_142038_();
    }

    public static void setFire(Entity entity, int seconds) {
        entity.m_20254_(seconds);
    }

    public static void extinguish(Entity entity) {
        entity.m_20095_();
    }

    public static boolean isOnFire(Entity entity) {
        return entity.m_6060_();
    }

    public static void setInvisible(Entity entity, boolean invisible) {
        entity.m_6842_(invisible);
    }

    public static boolean isInvisible(Entity entity) {
        return entity.m_20145_();
    }

    public static void setSneaking(Entity entity, boolean sneaking) {
        entity.m_20260_(sneaking);
    }

    public static boolean isSneaking(Entity entity) {
        return entity.m_6144_();
    }

    public static void setSprinting(Entity entity, boolean sprinting) {
        entity.m_6858_(sprinting);
    }

    public static boolean isSprinting(Entity entity) {
        return entity.m_20142_();
    }

    public static void setSwimming(Entity entity, boolean swimming) {
        entity.m_20282_(swimming);
    }

    public static boolean isSwimming(Entity entity) {
        return entity.m_6069_();
    }

    public static void detach(Entity entity) {
        entity.m_19877_();
    }

    public static void attach(Entity entity, Entity vehicle) {
        entity.m_7998_(vehicle, true);
    }

    public static void detachFromVehicle(Entity entity) {
        entity.m_8127_();
    }

    public static boolean isRiding(Entity entity) {
        return entity.m_20159_();
    }

    public static Entity getVehicle(Entity entity) {
        return entity.m_20202_();
    }

    public static void setVehicle(Entity entity, Entity vehicle) {
        entity.m_7998_(vehicle, true);
    }

    public static void applyRotation(Entity entity, Rotation rotation) {
        entity.m_7890_(rotation);
    }

    public static void setVelocity(Entity entity, Vec3 velocity) {
        entity.m_20256_(velocity);
    }

    public static void setFallDistance(Entity entity, double fallDistance) {
        entity.f_19789_ = (float) fallDistance;
    }

    public static double getFallDistance(Entity entity) {
        return entity.f_19789_;
    }

    public static void setVelocityModified(Entity entity, boolean velocityModified) {
        entity.f_19864_ = velocityModified;
    }

    public static boolean isVelocityModified(Entity entity) {
        return entity.f_19864_;
    }

    public static float getYaw(Entity entity) {
        return entity.m_146908_();
    }

    public static float getPitch(Entity entity) {
        return entity.m_146909_();
    }

    public static void setYaw(Entity entity, float yaw) {
        entity.m_146922_(yaw);
    }

    public static void setPitch(Entity entity, float pitch) {
        entity.m_146926_(pitch);
    }

    public static float getSpeed(Entity entity) {
        return entity.f_146794_;
    }

    public static void setSpeed(Entity entity, float speed) {
        entity.f_146794_ = speed;
    }

    public static boolean isOnGround(Entity entity) {
        return entity.m_20096_();
    }

    public static void setOnGround(Entity entity, boolean onGround) {
        entity.m_6853_(onGround);
    }

    public static boolean isAlive(Entity entity) {
        return entity.m_6084_();
    }

    public static UUID getUuid(Entity entity) {
        return entity.m_20148_();
    }

    public static String getUuidString(Entity entity) {
        return entity.m_20149_();
    }

    public static void setUuid(Entity entity, UUID uuid) {
        entity.m_20084_(uuid);
    }

    public static Component getName(Entity entity) {
        return entity.m_7755_();
    }

    public static Component getDisplayName(Entity entity) {
        return entity.m_5446_();
    }

    public static void setCustomName(Entity entity, Component customName) {
        entity.m_6593_(customName);
    }

    public static Component getCustomName(Entity entity) {
        return entity.m_7770_();
    }

    public static void setCustomNameVisible(Entity entity, boolean visible) {
        entity.m_20340_(visible);
    }

    public static boolean isCustomNameVisible(Entity entity) {
        return entity.m_20151_();
    }

    public static boolean hasCustomName(Entity entity) {
        return entity.m_8077_();
    }

    public static String getNameAsString(Entity entity) {
        return entity.m_7755_().getString();
    }

    public static String getDisplayNameAsString(Entity entity) {
        if (entity.m_5446_() == null)
            return null;
        return entity.m_5446_().getString();
    }

    public static String getCustomNameAsString(Entity entity) {
        if (entity.m_7770_() == null)
            return null;
        return entity.m_7770_().getString();
    }

    public static void setCustomName(Entity entity, String customName) {
        entity.m_6593_(TextUtil.literal(customName));
    }

    public static Vec3 getRotationVector(Entity entity) {
        return entity.m_20154_();
    }

    public static Vec3 getPos(Entity entity) {
        return entity.m_20182_();
    }

    public static Vector3d getPosM(Entity entity) {
        return Vector3d.of(getPos(entity));
    }

    public static void setPos(Entity entity, double x, double y, double z) {
        entity.m_20343_(x, y, z);
    }

    public static void addVelocity(Entity entity, double x, double y, double z) {
        entity.m_5997_(x, y, z);
    }

    public static void addVelocity(Entity entity, Vec3 velocity) {
        entity.m_246865_(velocity);
    }

    public static void addVelocity(Entity entity, Vector3d velocity) {
        addVelocity(entity, velocity.toMinecraft());
    }

    public static void setVelocity(Entity entity, Vector3d velocity) {
        entity.m_20256_(velocity.toMinecraft());
    }

    public static void setPos(Entity entity, BlockPos pos) {
        setPos(entity, pos.getX(), pos.getY(), pos.getZ());
    }

     public static void setPos(Entity entity, Vector3d pos) {
        setPos(entity, pos.getX(), pos.getY(), pos.getZ());
    }

    public static void teleport(Entity entity, ServerLevel world, double x, double y, double z, float yaw, float pitch, boolean resetCamera) {
        entity.m_264318_(world, x, y, z, RelativeMovement.f_263752_, yaw, pitch);
    }

    public static void teleport(Entity entity, ServerLevel world, double x, double y, double z, float yaw, float pitch) {
        teleport(entity, world, x, y, z, yaw, pitch, true);
    }

    public static void teleport(Entity entity, ServerLevel world, double x, double y, double z) {
        teleport(entity, world, x, y, z, entity.m_146908_(), entity.m_146909_(), true);
    }

    public static void teleport(Entity entity, ServerLevel world, Vector3d pos) {
        teleport(entity, world, pos.getX(), pos.getY(), pos.getZ());
    }

    public static void teleport(Entity entity, ServerLevel world, BlockPos pos) {
        teleport(entity, world, pos.getX(), pos.getY(), pos.getZ());
    }

    public static void teleport(Entity entity, double x, double y, double z) {
        if (!(entity.m_9236_() instanceof ServerLevel))
            return;

        teleport(entity, (ServerLevel) entity.m_9236_(), x, y, z, entity.m_146908_(), entity.m_146909_());
    }

    public static void teleport(Entity entity, Vector3d pos) {
        teleport(entity, pos.getX(), pos.getY(), pos.getZ());
    }

    public static void teleport(Entity entity, BlockPos pos) {
        teleport(entity, pos.getX(), pos.getY(), pos.getZ());
    }

    public static void teleport(Entity entity, ServerLevel world, Vector3d pos, float yaw, float pitch, boolean resetCamera) {
        teleport(entity, world, pos.getX(), pos.getY(), pos.getZ(), yaw, pitch, resetCamera);
    }

    public static void teleport(Entity entity, ServerLevel raw, BlockPos pos, float yaw, float pitch, boolean resetCamera) {
        teleport(entity, raw, pos.getX(), pos.getY(), pos.getZ(), yaw, pitch, resetCamera);
    }
}
