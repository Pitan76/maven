package net.pitan76.mcpitanlib.api.item;

import java.util.EnumMap;
import java.util.List;
import java.util.function.Supplier;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.ArmorMaterial;
import net.minecraft.world.item.crafting.Ingredient;

public interface CompatibleArmorMaterial {
    int getDurability(ArmorEquipmentType type);

    int getProtection(ArmorEquipmentType type);

    int getEnchantability();

    SoundEvent getEquipSound();

    Ingredient getRepairIngredient();

    /**
     * @return the name of the material
     */
    default String getName() {
        return getId().m_135815_();
    }

    /**
     * @return the id of the material
     */
    ResourceLocation getId();

    float getToughness();

    float getKnockbackResistance();

    @Deprecated
    default ArmorMaterial build() {
        return new ArmorMaterial() {
            @Override
            public int m_266425_(ArmorItem.Type type) {
                return CompatibleArmorMaterial.this.getDurability(ArmorEquipmentType.of(type));
            }

            @Override
            public int m_7366_(ArmorItem.Type type) {
                return CompatibleArmorMaterial.this.getProtection(ArmorEquipmentType.of(type));
            }

            @Override
            public int m_6646_() {
                return CompatibleArmorMaterial.this.getEnchantability();
            }

            @Override
            public SoundEvent m_7344_() {
                return CompatibleArmorMaterial.this.getEquipSound();
            }

            @Override
            public Ingredient m_6230_() {
                return CompatibleArmorMaterial.this.getRepairIngredient();
            }

            @Override
            public String m_6082_() {
                return CompatibleArmorMaterial.this.getName();
            }

            @Override
            public float m_6651_() {
                return CompatibleArmorMaterial.this.getToughness();
            }

            @Override
            public float m_6649_() {
                return CompatibleArmorMaterial.this.getKnockbackResistance();
            }
        };
    }
}
