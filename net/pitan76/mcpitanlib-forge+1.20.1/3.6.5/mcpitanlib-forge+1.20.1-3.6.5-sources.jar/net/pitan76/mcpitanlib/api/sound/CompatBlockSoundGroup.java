package net.pitan76.mcpitanlib.api.sound;

import net.minecraft.sounds.SoundEvent;
import net.minecraft.world.level.block.SoundType;

public class CompatBlockSoundGroup {
    public static final CompatBlockSoundGroup INTENTIONALLY_EMPTY = of(SoundType.f_56742_);
    public static final CompatBlockSoundGroup WOOD = of(SoundType.f_56736_);
    public static final CompatBlockSoundGroup GRAVEL = of(SoundType.f_56739_);
    public static final CompatBlockSoundGroup GRASS = of(SoundType.f_56740_);
    public static final CompatBlockSoundGroup LILY_PAD = of(SoundType.f_56741_);
    public static final CompatBlockSoundGroup STONE = of(SoundType.f_56742_);
    public static final CompatBlockSoundGroup METAL = of(SoundType.f_56743_);
    public static final CompatBlockSoundGroup GLASS = of(SoundType.f_56744_);
    public static final CompatBlockSoundGroup WOOL = of(SoundType.f_56745_);
    public static final CompatBlockSoundGroup SAND = of(SoundType.f_56746_);
    public static final CompatBlockSoundGroup SNOW = of(SoundType.f_56747_);
    public static final CompatBlockSoundGroup POWDER_SNOW = of(SoundType.f_154681_);
    public static final CompatBlockSoundGroup LADDER = of(SoundType.f_56748_);
    public static final CompatBlockSoundGroup ANVIL = of(SoundType.f_56749_);
    public static final CompatBlockSoundGroup SLIME = of(SoundType.f_56750_);
    public static final CompatBlockSoundGroup HONEY = of(SoundType.f_56751_);
    public static final CompatBlockSoundGroup WET_GRASS = of(SoundType.f_56752_);
    public static final CompatBlockSoundGroup CORAL = of(SoundType.f_56753_);
    public static final CompatBlockSoundGroup BAMBOO = of(SoundType.f_56754_);
    public static final CompatBlockSoundGroup BAMBOO_SAPLING = of(SoundType.f_56755_);
    public static final CompatBlockSoundGroup SCAFFOLDING = of(SoundType.f_56756_);
    public static final CompatBlockSoundGroup SWEET_BERRY_BUSH = of(SoundType.f_56757_);
    public static final CompatBlockSoundGroup CROP = of(SoundType.f_56758_);
    public static final CompatBlockSoundGroup STEM = of(SoundType.f_56759_);
    public static final CompatBlockSoundGroup VINE = of(SoundType.f_56760_);
    public static final CompatBlockSoundGroup NETHER_WART = of(SoundType.f_56761_);
    public static final CompatBlockSoundGroup LANTERN = of(SoundType.f_56762_);
    public static final CompatBlockSoundGroup NETHER_STEM = of(SoundType.f_56763_);
    public static final CompatBlockSoundGroup NYLIUM = of(SoundType.f_56710_);
    public static final CompatBlockSoundGroup FUNGUS = of(SoundType.f_56711_);
    public static final CompatBlockSoundGroup ROOTS = of(SoundType.f_56712_);
    public static final CompatBlockSoundGroup SHROOMLIGHT = of(SoundType.f_56713_);
    public static final CompatBlockSoundGroup WEEPING_VINES = of(SoundType.f_56714_);
    public static final CompatBlockSoundGroup WEEPING_VINES_LOW_PITCH = of(SoundType.f_56715_);
    public static final CompatBlockSoundGroup SOUL_SAND = of(SoundType.f_56716_);
    public static final CompatBlockSoundGroup SOUL_SOIL = of(SoundType.f_56717_);
    public static final CompatBlockSoundGroup BASALT = of(SoundType.f_56718_);
    public static final CompatBlockSoundGroup WART_BLOCK = of(SoundType.f_56719_);
    public static final CompatBlockSoundGroup NETHERRACK = of(SoundType.f_56720_);
    public static final CompatBlockSoundGroup NETHER_BRICKS = of(SoundType.f_56721_);
    public static final CompatBlockSoundGroup NETHER_SPROUTS = of(SoundType.f_56722_);
    public static final CompatBlockSoundGroup NETHER_ORE = of(SoundType.f_56723_);
    public static final CompatBlockSoundGroup BONE = of(SoundType.f_56724_);
    public static final CompatBlockSoundGroup NETHERITE = of(SoundType.f_56725_);
    public static final CompatBlockSoundGroup ANCIENT_DEBRIS = of(SoundType.f_56726_);
    public static final CompatBlockSoundGroup LODESTONE = of(SoundType.f_56727_);
    public static final CompatBlockSoundGroup CHAIN = of(SoundType.f_56728_);
    public static final CompatBlockSoundGroup NETHER_GOLD_ORE = of(SoundType.f_56729_);
    public static final CompatBlockSoundGroup GILDED_BLACKSTONE = of(SoundType.f_56730_);
    public static final CompatBlockSoundGroup CANDLE = of(SoundType.f_154653_);
    public static final CompatBlockSoundGroup AMETHYST_BLOCK = of(SoundType.f_154654_);
    public static final CompatBlockSoundGroup AMETHYST_CLUSTER = of(SoundType.f_154655_);
    public static final CompatBlockSoundGroup SMALL_AMETHYST_BUD = of(SoundType.f_154656_);
    public static final CompatBlockSoundGroup MEDIUM_AMETHYST_BUD = of(SoundType.f_154657_);
    public static final CompatBlockSoundGroup LARGE_AMETHYST_BUD = of(SoundType.f_154658_);
    public static final CompatBlockSoundGroup TUFF = of(SoundType.f_154659_);
    public static final CompatBlockSoundGroup TUFF_BRICKS = of(SoundType.f_56742_);
    public static final CompatBlockSoundGroup POLISHED_TUFF = of(SoundType.f_56742_);
    public static final CompatBlockSoundGroup CALCITE = of(SoundType.f_154660_);
    public static final CompatBlockSoundGroup DRIPSTONE_BLOCK = of(SoundType.f_154661_);
    public static final CompatBlockSoundGroup POINTED_DRIPSTONE = of(SoundType.f_154662_);
    public static final CompatBlockSoundGroup COPPER = of(SoundType.f_154663_);
    public static final CompatBlockSoundGroup COPPER_BULB = of(SoundType.f_56742_);
    public static final CompatBlockSoundGroup COPPER_GRATE = of(SoundType.f_56742_);
    public static final CompatBlockSoundGroup CAVE_VINES = of(SoundType.f_154664_);
    public static final CompatBlockSoundGroup SPORE_BLOSSOM = of(SoundType.f_154665_);
    public static final CompatBlockSoundGroup AZALEA = of(SoundType.f_154666_);
    public static final CompatBlockSoundGroup FLOWERING_AZALEA = of(SoundType.f_154667_);
    public static final CompatBlockSoundGroup MOSS_CARPET = of(SoundType.f_154668_);
    public static final CompatBlockSoundGroup PINK_PETALS = of(SoundType.f_271137_);
    public static final CompatBlockSoundGroup MOSS_BLOCK = of(SoundType.f_154669_);
    public static final CompatBlockSoundGroup BIG_DRIPLEAF = of(SoundType.f_154670_);
    public static final CompatBlockSoundGroup SMALL_DRIPLEAF = of(SoundType.f_154671_);
    public static final CompatBlockSoundGroup ROOTED_DIRT = of(SoundType.f_154672_);
    public static final CompatBlockSoundGroup HANGING_ROOTS = of(SoundType.f_154673_);
    public static final CompatBlockSoundGroup AZALEA_LEAVES = of(SoundType.f_154674_);
    public static final CompatBlockSoundGroup SCULK_SENSOR = of(SoundType.f_154675_);
    public static final CompatBlockSoundGroup SCULK_CATALYST = of(SoundType.f_222472_);
    public static final CompatBlockSoundGroup SCULK = of(SoundType.f_222473_);
    public static final CompatBlockSoundGroup SCULK_VEIN = of(SoundType.f_222474_);
    public static final CompatBlockSoundGroup SCULK_SHRIEKER = of(SoundType.f_222475_);
    public static final CompatBlockSoundGroup GLOW_LICHEN = of(SoundType.f_154676_);
    public static final CompatBlockSoundGroup DEEPSLATE = of(SoundType.f_154677_);
    public static final CompatBlockSoundGroup DEEPSLATE_BRICKS = of(SoundType.f_154678_);
    public static final CompatBlockSoundGroup DEEPSLATE_TILES = of(SoundType.f_154679_);
    public static final CompatBlockSoundGroup POLISHED_DEEPSLATE = of(SoundType.f_154680_);
    public static final CompatBlockSoundGroup FROGLIGHT = of(SoundType.f_222465_);
    public static final CompatBlockSoundGroup FROGSPAWN = of(SoundType.f_222466_);
    public static final CompatBlockSoundGroup MANGROVE_ROOTS = of(SoundType.f_222467_);
    public static final CompatBlockSoundGroup MUDDY_MANGROVE_ROOTS = of(SoundType.f_222468_);
    public static final CompatBlockSoundGroup MUD = of(SoundType.f_222469_);
    public static final CompatBlockSoundGroup MUD_BRICKS = of(SoundType.f_222470_);
    public static final CompatBlockSoundGroup PACKED_MUD = of(SoundType.f_222471_);
    public static final CompatBlockSoundGroup HANGING_SIGN = of(SoundType.f_244174_);
    public static final CompatBlockSoundGroup NETHER_WOOD_HANGING_SIGN = of(SoundType.f_256908_);
    public static final CompatBlockSoundGroup BAMBOO_WOOD_HANGING_SIGN = of(SoundType.f_256995_);
    public static final CompatBlockSoundGroup BAMBOO_WOOD = of(SoundType.f_243772_);
    public static final CompatBlockSoundGroup NETHER_WOOD = of(SoundType.f_244244_);
    public static final CompatBlockSoundGroup CHERRY_WOOD = of(SoundType.f_271497_);
    public static final CompatBlockSoundGroup CHERRY_SAPLING = of(SoundType.f_271370_);
    public static final CompatBlockSoundGroup CHERRY_LEAVES = of(SoundType.f_271239_);
    public static final CompatBlockSoundGroup CHERRY_WOOD_HANGING_SIGN = of(SoundType.f_271094_);
    public static final CompatBlockSoundGroup CHISELED_BOOKSHELF = of(SoundType.f_256956_);
    public static final CompatBlockSoundGroup SUSPICIOUS_SAND = of(SoundType.f_271168_);
    public static final CompatBlockSoundGroup SUSPICIOUS_GRAVEL = of(SoundType.f_276658_);
    public static final CompatBlockSoundGroup DECORATED_POT = of(SoundType.f_271215_);
    public static final CompatBlockSoundGroup DECORATED_POT_SHATTER = of(SoundType.f_276571_);
    public static final CompatBlockSoundGroup TRIAL_SPAWNER = of(SoundType.f_56742_);
    public static final CompatBlockSoundGroup SPONGE = of(SoundType.f_56740_);
    public static final CompatBlockSoundGroup WET_SPONGE = of(SoundType.f_56752_);
    public static final CompatBlockSoundGroup VAULT = of(SoundType.f_56742_);
    public static final CompatBlockSoundGroup HEAVY_CORE = of(SoundType.f_56742_);
    public static final CompatBlockSoundGroup COBWEB = of(SoundType.f_56742_);

    public SoundType blockSoundGroup;

    private final float volume;
    private final float pitch;
    private final SoundEvent breakSound;
    private final SoundEvent stepSound;
    private final SoundEvent placeSound;
    private final SoundEvent hitSound;
    private final SoundEvent fallSound;

    public CompatBlockSoundGroup(SoundType blockSoundGroup) {
        this.blockSoundGroup = blockSoundGroup;

        this.volume = blockSoundGroup.m_56773_();
        this.pitch = blockSoundGroup.m_56774_();
        this.breakSound = blockSoundGroup.m_56775_();
        this.stepSound = blockSoundGroup.m_56776_();
        this.placeSound = blockSoundGroup.m_56777_();
        this.hitSound = blockSoundGroup.m_56778_();
        this.fallSound = blockSoundGroup.m_56779_();
    }

    public CompatBlockSoundGroup(float volume, float pitch, SoundEvent breakSound, SoundEvent stepSound, SoundEvent placeSound, SoundEvent hitSound, SoundEvent fallSound) {
        this.blockSoundGroup = new SoundType(volume, pitch, breakSound, stepSound, placeSound, hitSound, fallSound);

        this.volume = volume;
        this.pitch = pitch;
        this.breakSound = breakSound;
        this.stepSound = stepSound;
        this.placeSound = placeSound;
        this.hitSound = hitSound;
        this.fallSound = fallSound;
    }

    public SoundType get() {
        if (blockSoundGroup == null) {
            return new SoundType(volume, pitch, breakSound, stepSound, placeSound, hitSound, fallSound);
        }
        return blockSoundGroup;
    }

    public static CompatBlockSoundGroup of(SoundType blockSoundGroup) {
        return new CompatBlockSoundGroup(blockSoundGroup);
    }

    public static CompatBlockSoundGroup of(float volume, float pitch, SoundEvent breakSound, SoundEvent stepSound, SoundEvent placeSound, SoundEvent hitSound, SoundEvent fallSound) {
        return new CompatBlockSoundGroup(volume, pitch, breakSound, stepSound, placeSound, hitSound, fallSound);
    }

    public static CompatBlockSoundGroup of(float volume, float pitch, CompatSoundEvent breakSound, CompatSoundEvent stepSound, CompatSoundEvent placeSound, CompatSoundEvent hitSound, CompatSoundEvent fallSound) {
        return new CompatBlockSoundGroup(volume, pitch, breakSound.get(), stepSound.get(), placeSound.get(), hitSound.get(), fallSound.get());
    }

    public float getVolume() {
        return volume;
    }

    public float getPitch() {
        return pitch;
    }

    public SoundEvent getRawBreakSound() {
        return breakSound;
    }

    public SoundEvent getRawStepSound() {
        return stepSound;
    }

    public SoundEvent getRawPlaceSound() {
        return placeSound;
    }

    public SoundEvent getRawHitSound() {
        return hitSound;
    }

    public SoundEvent getRawFallSound() {
        return fallSound;
    }

    public CompatSoundEvent getBreakSound() {
        return CompatSoundEvent.of(breakSound);
    }

    public CompatSoundEvent getStepSound() {
        return CompatSoundEvent.of(stepSound);
    }

    public CompatSoundEvent getPlaceSound() {
        return CompatSoundEvent.of(placeSound);
    }

    public CompatSoundEvent getHitSound() {
        return CompatSoundEvent.of(hitSound);
    }

    public CompatSoundEvent getFallSound() {
        return CompatSoundEvent.of(fallSound);
    }
}
