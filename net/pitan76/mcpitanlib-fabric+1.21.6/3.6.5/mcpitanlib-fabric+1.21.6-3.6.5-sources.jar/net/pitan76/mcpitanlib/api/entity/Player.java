package net.pitan76.mcpitanlib.api.entity;

import dev.architectury.registry.menu.ExtendedMenuProvider;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1268;
import net.minecraft.class_1293;
import net.minecraft.class_1304;
import net.minecraft.class_1656;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1796;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2371;
import net.minecraft.class_243;
import net.minecraft.class_2487;
import net.minecraft.class_2540;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.class_3244;
import net.minecraft.class_3414;
import net.minecraft.class_3419;
import net.minecraft.class_3445;
import net.minecraft.class_3448;
import net.minecraft.class_3908;
import net.minecraft.class_746;
import net.minecraft.class_9279;
import net.minecraft.class_9334;
import net.pitan76.mcpitanlib.api.entity.effect.CompatStatusEffect;
import net.pitan76.mcpitanlib.api.entity.effect.CompatStatusEffectInstance;
import net.pitan76.mcpitanlib.api.gui.ExtendedNamedScreenHandlerFactory;
import net.pitan76.mcpitanlib.api.gui.v2.ExtendedScreenHandlerFactory;
import net.pitan76.mcpitanlib.api.item.ArmorEquipmentType;
import net.pitan76.mcpitanlib.api.item.CompatFoodComponent;
import net.pitan76.mcpitanlib.api.sound.CompatSoundCategory;
import net.pitan76.mcpitanlib.api.sound.CompatSoundEvent;
import net.pitan76.mcpitanlib.api.text.TextComponent;
import net.pitan76.mcpitanlib.api.util.CompatIdentifier;
import net.pitan76.mcpitanlib.api.util.NbtUtil;
import net.pitan76.mcpitanlib.api.util.ScreenHandlerUtil;
import net.pitan76.mcpitanlib.api.util.TextUtil;
import net.pitan76.mcpitanlib.api.util.entity.LivingEntityUtil;
import net.pitan76.mcpitanlib.core.player.ItemCooldown;
import net.pitan76.mcpitanlib.midohra.util.math.Vector3d;

import java.util.*;
import java.util.function.Consumer;

/*
PlayerEntity helper
 */
public class Player {
    private final class_1657 entity;

    public class_1657 getEntity() {
        return entity;
    }

    public class_1657 getPlayerEntity() {
        return getEntity();
    }

    public Player(class_1657 playerEntity) {
        this.entity = playerEntity;
    }

    /**
     * Get player inventory
     * @return PlayerInventory
     */
    public class_1661 getInv() {
        return getEntity().method_31548();
    }

    /**
     * Alias of getInv()
     * @return PlayerInventory
     */
    public class_1661 getInventory() {
        return getInv();
    }

    /**
     * Get armor's item stack list
     * @return DefaultedList<ItemStack>
     */
    public class_2371<class_1799> getArmor() {
        class_2371<class_1799> stacks = class_2371.method_10213(4, class_1799.field_8037);
        stacks.set(0, getInv().method_5438(36));
        stacks.set(1, getInv().method_5438(37));
        stacks.set(2, getInv().method_5438(38));
        stacks.set(3, getInv().method_5438(39));
        return stacks;
    }

    /**
     * Get main's item stack list
     * @return DefaultedList<ItemStack>
     */
    public class_2371<class_1799> getMain() {
        return getInv().method_67533();
    }

    /**
     * Get off hand's item stack list
     * @return DefaultedList<ItemStack>
     */
    public class_2371<class_1799> getOffHand() {
        class_2371<class_1799> stacks = class_2371.method_10213(1, class_1799.field_8037);
        stacks.set(0, getInv().method_5438(class_1661.field_30639));
        return stacks;
    }

    /**
     * Get select slot integer
     * @return int
     */
    public int getSelectSlot() {
        return getInv().method_67532();
    }

    /**
     * Get player inventory size
     * @return player inventory size
     */
    public int getInvSize() {
        return getInv().method_5439();
    }

    public OptionalInt openGuiScreen(class_3908 factory) {
        return getEntity().method_17355(factory);
    }

    public OptionalInt openGuiScreen(class_1937 world, class_2680 state, class_2338 pos) {
        return openGuiScreen(state.method_26196(world, pos));
    }

    public boolean isServerPlayerEntity() {
        return this.getEntity() instanceof class_3222;
    }

    public void openExtendedMenu(class_3908 provider, Consumer<class_2540> bufWriter) {
        if (isServerPlayerEntity())
            ScreenHandlerUtil.openExtendedMenu((class_3222) this.getPlayerEntity(), provider, bufWriter);
    }

    public void openExtendedMenu(ExtendedMenuProvider provider) {
        if (isServerPlayerEntity())
            ScreenHandlerUtil.openExtendedMenu((class_3222) this.getPlayerEntity(), provider);
    }

    public void openExtendedMenu(ExtendedNamedScreenHandlerFactory provider) {
        this.openExtendedMenu((ExtendedMenuProvider) provider);
    }

    public void openMenu(class_3908 provider) {
        if (isServerPlayerEntity())
            ScreenHandlerUtil.openMenu((class_3222) this.getPlayerEntity(), provider);
    }

    public void insertStack(class_1799 stack) {
        getInv().method_7394(stack);
    }

    public void insertStack(int slot, class_1799 stack) {
        getInv().method_7367(slot, stack);
    }

    public void offerOrDrop(class_1799 itemStack) {
        getInv().method_7398(itemStack);
    }

    public void giveStack(class_1799 stack) {
        getEntity().method_7270(stack);
    }

    public String getName() {
        return getEntity().method_5477().getString();
    }

    public UUID getUUID() {
        return getEntity().method_5667();
    }

    public class_1656 getAbilities() {
        return getEntity().method_31549();
    }

    /**
     * Returns whether this player is in creative mode.
     */
    public boolean isCreative() {
        return getAbilities().field_7477;
    }

    public boolean isFlying() {
        return getAbilities().field_7479;
    }

    public boolean isInvulnerable() {
        return getAbilities().field_7480;
    }

    public class_1937 getWorld() {
        return getEntity().method_37908();
    }

    public class_1703 getCurrentScreenHandler() {
        return getEntity().field_7512;
    }

    public boolean isSneaking() {
        return getEntity().method_5715();
    }

    public class_1799 getCursorStack() {
        return getCurrentScreenHandler().method_34255();
    }

    public boolean isClient() {
        return getWorld().method_8608();
    }
    public boolean isServer() {
        return !isClient();
    }

    public void readCustomDataFromNbt(class_2487 nbt) {
        getEntity().method_66653(class_9334.field_49628, class_9279.method_57456(nbt));
    }

    public void writeCustomDataToNbt(class_2487 nbt) {
        class_2487 source = getEntity().method_58694(class_9334.field_49628).method_57461();
        NbtUtil.copyFrom(source, nbt);
    }

    public void sendMessage(class_2561 text) {
        getEntity().method_7353(text, false);
    }

    public void sendActionBar(class_2561 text) {
        getEntity().method_7353(text, true);
    }

    public void equipStack(class_1304 slot, class_1799 stack) {
        getEntity().method_5673(slot, stack);
    }

    public void dropStack(class_1799 stack, boolean throwRandomly, boolean retainOwnership) {
        getEntity().method_7329(stack, throwRandomly, retainOwnership);
    }

    public void dropStack(class_1799 stack, boolean retainOwnership) {
        dropStack(stack, false, retainOwnership);
    }

    public void dropStack(class_1799 stack) {
        dropStack(stack, false, false);
    }

    public class_2338 getBlockPos() {
        return getEntity().method_24515();
    }

    public class_243 getPos() {
        return getEntity().method_19538();
    }

    public class_1799 getStackInHand(class_1268 hand) {
        return this.getEntity().method_5998(hand);
    }

    public void heal(float amount) {
        this.getEntity().method_6025(amount);
    }

    public float getYaw() {
        return this.getEntity().method_36454();
    }

    public float getPitch() {
        return this.getEntity().method_36455();
    }

    public void playSound(class_3414 event, class_3419 category, float volume, float pitch) {
        if (isServerPlayerEntity()) {
            Optional<class_3222> player = getServerPlayer();
            if (player.isPresent()) {
                player.get().method_17356(event, category, volume, pitch);
                return;
            }
        }

        playSound(event, volume, pitch);
    }

    public void playSound(class_3414 event, float volume, float pitch) {
        if (isServerPlayerEntity()) {
            Optional<class_3222> player = getServerPlayer();
            if (player.isPresent()) {
                player.get().method_5783(event, volume, pitch);
                return;
            }
        }

        getEntity().method_5783(event, volume, pitch);
    }

    public void playSound(CompatSoundEvent event, CompatSoundCategory category, float volume, float pitch) {
        playSound(event.get(), category.get(), volume, pitch);
    }

    public void playSound(CompatSoundEvent event, float volume, float pitch) {
        playSound(event.get(), volume, pitch);
    }

    public ItemCooldown itemCooldown = new ItemCooldown(this);

    public ItemCooldown getItemCooldown() {
        return itemCooldown;
    }

    public class_1796 getItemCooldownManager() {
        return getEntity().method_7357();
    }

    public void incrementStat(class_3445<?> stat) {
        getEntity().method_7259(stat);
    }

    public <T> void incrementStat(class_3448<T> type, T object) {
        getEntity().method_7259(type.method_14956(object));
    }

    public void incrementStat(class_2960 id) {
        getEntity().method_7281(id);
    }

    public void incrementStat(CompatIdentifier id) {
        getEntity().method_7281(id.toMinecraft());
    }

    public void teleport(double x, double y, double z) {
        getEntity().method_6082(x, y, z, false);
    }

    public class_1799 getMainHandStack() {
        return getStackInHand(class_1268.field_5808);
    }

    public class_1799 getOffHandStack() {
        return getStackInHand(class_1268.field_5810);
    }

    public class_2350 getHorizontalFacing() {
        return getEntity().method_5735();
    }

    public double getX() {
        return getEntity().method_23317();
    }

    public double getY() {
        return getEntity().method_23318();
    }

    public double getZ() {
        return getEntity().method_23321();
    }

    public boolean isServerPlayer() {
        return getEntity() instanceof class_3222;
    }

    public Optional<class_3222> getServerPlayer() {
        if (isServerPlayer())
            return Optional.of((class_3222) getEntity());

        return Optional.empty();
    }

    @Environment(EnvType.CLIENT)
    public Optional<class_746> getClientPlayer() {
        if (getEntity() instanceof class_746)
            return Optional.of((class_746) getEntity());

        return Optional.empty();
    }

    public void setVelocity(double x, double y, double z) {
        getEntity().method_18800(x, y, z);
    }

    public void setVelocity(class_243 velocity) {
        getEntity().method_18799(velocity);
    }

    public class_243 getVelocity() {
        return getEntity().method_18798();
    }

    public Optional<class_3244> getNetworkHandler() {
        Optional<class_3222> player = getServerPlayer();
        return player.map(sp -> sp.field_13987);
    }

    public boolean hasNetworkHandler() {
        return getNetworkHandler().isPresent();
    }

    public boolean isSpectator() {
        return getEntity().method_7325();
    }

    /**
     * Returns the current {@link class_1799} in the {@link Player}'s hand, or offhand if the
     * main hand is empty.
     *
     * @return {@code ItemStack} that the {@link Player} is holding. Can be {@link null}.
     */
    public Optional<class_1799> getCurrentHandItem() {
        boolean playerIsHoldingInMainHand = !getMainHandStack().method_7960();
        if (playerIsHoldingInMainHand)
            return Optional.ofNullable(getMainHandStack());

        boolean playerIsHoldingInOffHand = !getOffHandStack().method_7960();

        if (playerIsHoldingInOffHand)
            return Optional.ofNullable(getOffHandStack());

        return Optional.empty();
    }

    public void addStatusEffect(CompatStatusEffectInstance effect) {
        getEntity().method_6092(effect.getInstance());
    }

    public void removeStatusEffect(CompatStatusEffect effect) {
        getEntity().method_6016(effect.getEntry(getWorld()));
    }

    public List<CompatStatusEffectInstance> getStatusEffects() {
        List<CompatStatusEffectInstance> compatEffects = new ArrayList<>();

        for (class_1293 effect : getEntity().method_6026()) {
            compatEffects.add(new CompatStatusEffectInstance(effect));
        }

        return compatEffects;
    }

    public void addExperience(int experience) {
        getEntity().method_7255(experience);
    }

    public int getExperienceLevel() {
        return getEntity().field_7520;
    }

    public void addExperienceLevels(int levels) {
        getEntity().method_7316(levels);
    }

    public void setExperienceLevel(int level) {
        getEntity().field_7520 = level;
    }

    public void addScore(int score) {
        getEntity().method_7285(score);
    }

    public int getScore() {
        return getEntity().method_7272();
    }

    public void setScore(int score) {
        getEntity().method_7320(score);
    }

    public int getTotalExperience() {
        return getEntity().field_7495;
    }

    public void setTotalExperience(int experience) {
        getEntity().field_7495 = experience;
    }

    public boolean isSwimming() {
        return getEntity().method_5681();
    }

    public void setStackInHand(class_1268 hand, class_1799 stack) {
        getEntity().method_6122(hand, stack);
    }

    public void setStackInHand(class_1268 hand, net.pitan76.mcpitanlib.midohra.item.ItemStack stack) {
        setStackInHand(hand, stack.toMinecraft());
    }

    public net.pitan76.mcpitanlib.midohra.item.ItemStack getMidohraStackInHand(class_1268 hand) {
        return net.pitan76.mcpitanlib.midohra.item.ItemStack.of(getStackInHand(hand));
    }

    public class_1268 getActiveHand() {
        return getEntity().method_6058();
    }

    public float getBlockBreakingSpeed(class_2680 state) {
        return getEntity().method_7351(state);
    }

    public boolean canHarvest(class_2680 state) {
        return getEntity().method_7305(state);
    }

    public net.pitan76.mcpitanlib.midohra.world.World getMidohraWorld() {
        return net.pitan76.mcpitanlib.midohra.world.World.of(getWorld());
    }

    public void eatFood(class_1799 stack, CompatFoodComponent foodComponent) {
        getEntity().method_7344().method_7579(foodComponent.build());
    }

    public void sendMessage(String message) {
        sendMessage(TextUtil.of(message));
    }

    public void sendActionBar(String message) {
        sendActionBar(TextUtil.of(message));
    }

    public void sendMessagef(String format, Object... args) {
        sendMessage(TextUtil.of(String.format(format, args)));
    }

    public void sendMessage(TextComponent textComponent) {
        sendMessage(textComponent.getText());
    }

    public void sendActionBar(TextComponent textComponent) {
        sendActionBar(textComponent.getText());
    }


    public void openExtendedMenu(ExtendedScreenHandlerFactory provider) {
        this.openExtendedMenu((ExtendedMenuProvider) provider);
    }

    public void offerOrDrop(net.pitan76.mcpitanlib.midohra.item.ItemStack stack) {
        offerOrDrop(stack.toMinecraft());
    }

    public void insertStack(net.pitan76.mcpitanlib.midohra.item.ItemStack stack) {
        insertStack(stack.toMinecraft());
    }

    public void insertStack(int slot, net.pitan76.mcpitanlib.midohra.item.ItemStack stack) {
        insertStack(slot, stack.toMinecraft());
    }

    public void giveStack(net.pitan76.mcpitanlib.midohra.item.ItemStack stack) {
        giveStack(stack.toMinecraft());
    }

    public Vector3d getPosM() {
        return Vector3d.of(getPos());
    }

    public net.pitan76.mcpitanlib.midohra.util.math.BlockPos getBlockPosM() {
        return net.pitan76.mcpitanlib.midohra.util.math.BlockPos.of(getBlockPos());
    }

    public class_1799 getEquippedStack(ArmorEquipmentType type) {
        return LivingEntityUtil.getEquippedStack(getEntity(), type.getSlot());
    }

    public net.pitan76.mcpitanlib.midohra.item.ItemStack getEquippedStackM(ArmorEquipmentType type) {
        return net.pitan76.mcpitanlib.midohra.item.ItemStack.of(getEquippedStack(type));
    }
}