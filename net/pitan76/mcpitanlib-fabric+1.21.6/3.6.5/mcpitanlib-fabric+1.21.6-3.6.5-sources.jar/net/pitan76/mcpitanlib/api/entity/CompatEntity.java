package net.pitan76.mcpitanlib.api.entity;

import net.minecraft.class_11368;
import net.minecraft.class_11372;
import net.minecraft.class_1282;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_2487;
import net.minecraft.class_2596;
import net.minecraft.class_2602;
import net.minecraft.class_2945;
import net.minecraft.class_3218;
import net.pitan76.mcpitanlib.api.event.entity.InitDataTrackerArgs;
import net.pitan76.mcpitanlib.api.event.nbt.ReadNbtArgs;
import net.pitan76.mcpitanlib.api.event.nbt.WriteNbtArgs;
import net.pitan76.mcpitanlib.core.mc1216.NbtDataConverter;
import net.pitan76.mcpitanlib.midohra.util.math.Vector3d;

public class CompatEntity extends class_1297 {
    public CompatEntity(class_1299<?> type, class_1937 world) {
        super(type, world);
    }

    @Deprecated
    @Override
    public void method_5693(class_2945.class_9222 builder) {
        initDataTracker(new InitDataTrackerArgs(builder));
    }

    @Override
    public boolean method_64397(class_3218 world, class_1282 source, float amount) {
        return false;
    }

    public void initDataTracker(InitDataTrackerArgs args) {

    }

    public void readCustomDataFromNbt(ReadNbtArgs nbt) {
        method_5749(nbt.view);
    }

    public void writeCustomDataToNbt(WriteNbtArgs nbt) {
        method_5652(nbt.view);
    }

    @Deprecated
    @Override
    protected void method_5749(class_11368 view) {
        class_2487 nbt = NbtDataConverter.data2nbt(view);
        readCustomDataFromNbt(new ReadNbtArgs(nbt, view));
    }

    @Deprecated
    @Override
    protected void method_5652(class_11372 view) {
        class_2487 nbt = new class_2487();
        writeCustomDataToNbt(new WriteNbtArgs(nbt, view));
        NbtDataConverter.nbt2writeData(nbt, view);
    }

    public class_2596<class_2602> createSpawnPacket() {
        return null;
    }

    public void writeNbt(WriteNbtArgs args) {
        method_5647(args.view);
    }

    public void readNbt(ReadNbtArgs args) {
        method_5651(args.view);
    }

    @Deprecated
    @Override
    public void method_5647(class_11372 view) {
        super.method_5647(view);
        class_2487 nbt = new class_2487();
        writeNbt(new WriteNbtArgs(nbt, view));
        NbtDataConverter.nbt2writeData(nbt, view);
    }

    @Deprecated
    @Override
    public void method_5651(class_11368 view) {
        super.method_5651(view);
        class_2487 nbt = NbtDataConverter.data2nbt(view);
        readNbt(new ReadNbtArgs(nbt, view));
    }

    @Deprecated
    @Override
    public class_1937 method_37908() {
        return callGetWorld();
    }

    public class_1937 callGetWorld() {
        return super.method_37908();
    }

    public class_2338 callGetBlockPos() {
        return method_24515();
    }

    public class_243 callGetPos() {
        return method_19538();
    }

    public boolean hasServerWorld() {
        return callGetWorld() instanceof class_3218;
    }

    public class_3218 getServerWorld() {
        return (class_3218) method_37908();
    }

    public net.pitan76.mcpitanlib.midohra.world.World getMidohraWorld() {
        return net.pitan76.mcpitanlib.midohra.world.World.of(callGetWorld());
    }

    public net.pitan76.mcpitanlib.midohra.util.math.BlockPos getMidohraBlockPos() {
        return net.pitan76.mcpitanlib.midohra.util.math.BlockPos.of(callGetBlockPos());
    }

     public Vector3d getMidohraPos() {
        return Vector3d.of(callGetPos());
     }

     public net.pitan76.mcpitanlib.midohra.world.ServerWorld getMidohraServerWorld() {
         return net.pitan76.mcpitanlib.midohra.world.ServerWorld.of(getServerWorld());
     }
}