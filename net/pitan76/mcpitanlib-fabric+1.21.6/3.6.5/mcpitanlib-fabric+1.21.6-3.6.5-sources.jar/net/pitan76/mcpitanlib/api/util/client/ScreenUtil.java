package net.pitan76.mcpitanlib.api.util.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_10799;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_5244;
import net.minecraft.class_5481;
import net.pitan76.mcpitanlib.api.client.gui.widget.CompatibleTexturedButtonWidget;
import net.pitan76.mcpitanlib.api.client.gui.widget.RedrawableTexturedButtonWidget;
import net.pitan76.mcpitanlib.api.client.render.DrawObjectDM;
import net.pitan76.mcpitanlib.api.text.TextComponent;
import net.pitan76.mcpitanlib.api.util.CompatIdentifier;
import org.jetbrains.annotations.Nullable;

import java.util.List;

@Environment(EnvType.CLIENT)
public class ScreenUtil {
    public static void setBackground(class_2960 GUI, float f, float g, float h, float i) {
        RenderUtil.setShaderToPositionTexProgram();
        RenderUtil.setShaderColor(f, g, h, i);
        RenderUtil.setShaderTexture(0, GUI);

        // GlStateManager.color4f(1.0F, 1.0F, 1.0F, 1.0F);
        // MinecraftClient.getInstance().getTextureManager().bindTexture(GUI);
    }

    public static void setBackground(class_2960 GUI) {
        setBackground(GUI, 1.0F, 1.0F, 1.0F, 1.0F);
    }

    // ～1.19.2
    public static void setRepeatEvents(boolean isRepeatEvents) {
    }

    // ～1.19.4
    public static void setPassEvents(class_437 screen, boolean isPassEvents) {
    }

    public static class_4185 createButtonWidget(int x, int y, int width, int height, class_2561 message, class_4185.class_4241 onPress) {
        return createButtonWidget(x, y, width, height, message, onPress, null);
    }

    public static class_4185 createButtonWidget(int x, int y, int width, int height, class_2561 message, class_4185.class_4241 onPress, @Nullable class_4185.class_7841 tooltipSupplier) {
        class_4185.class_7840 builder = class_4185.method_46430(message, onPress).method_46434(x, y, width , height);
        if (tooltipSupplier != null)
            builder.method_46435(tooltipSupplier);

        return builder.method_46431();
    }

    public static CompatibleTexturedButtonWidget createTexturedButtonWidget(int x, int y, int width, int height, int u, int v, class_2960 texture, class_4185.class_4241 pressAction) {
        return createTexturedButtonWidget(x, y, width, height, u, v, height, texture, pressAction);
    }

    public static CompatibleTexturedButtonWidget createTexturedButtonWidget(int x, int y, int width, int height, int u, int v, int hoveredVOffset, class_2960 texture, class_4185.class_4241 pressAction) {
        return createTexturedButtonWidget(x, y, width, height, u, v, hoveredVOffset, texture, 256, 256, pressAction);
    }

    public static CompatibleTexturedButtonWidget createTexturedButtonWidget(int x, int y, int width, int height, int u, int v, int hoveredVOffset, class_2960 texture, int textureWidth, int textureHeight, class_4185.class_4241 pressAction) {
        return createTexturedButtonWidget(x, y, width, height, u, v, hoveredVOffset, texture, textureWidth, textureHeight, pressAction, Texts.empty());
    }

    public static CompatibleTexturedButtonWidget createTexturedButtonWidget(int x, int y, int width, int height, int u, int v, int hoveredVOffset, class_2960 texture, int textureWidth, int textureHeight, class_4185.class_4241 pressAction, class_2561 message) {
        return new CompatibleTexturedButtonWidget(x, y, width, height, u, v, hoveredVOffset, texture, textureWidth, textureHeight, pressAction, message);
    }

    public static RedrawableTexturedButtonWidget createRedrawableTexturedButtonWidget(int x, int y, int width, int height, int u, int v, class_2960 texture, class_4185.class_4241 pressAction) {
        return createRedrawableTexturedButtonWidget(x, y, width, height, u, v, height, texture, pressAction);
    }

    public static RedrawableTexturedButtonWidget createRedrawableTexturedButtonWidget(int x, int y, int width, int height, int u, int v, int hoveredVOffset, class_2960 texture, class_4185.class_4241 pressAction) {
        return createRedrawableTexturedButtonWidget(x, y, width, height, u, v, hoveredVOffset, texture, 256, 256, pressAction);
    }

    public static RedrawableTexturedButtonWidget createRedrawableTexturedButtonWidget(int x, int y, int width, int height, int u, int v, int hoveredVOffset, class_2960 texture, int textureWidth, int textureHeight, class_4185.class_4241 pressAction) {
        return createRedrawableTexturedButtonWidget(x, y, width, height, u, v, hoveredVOffset, texture, textureWidth, textureHeight, pressAction, Texts.empty());
    }

    public static RedrawableTexturedButtonWidget createRedrawableTexturedButtonWidget(int x, int y, int width, int height, int u, int v, int hoveredVOffset, class_2960 texture, int textureWidth, int textureHeight, class_4185.class_4241 pressAction, class_2561 message) {
        return new RedrawableTexturedButtonWidget(x, y, width, height, u, v, hoveredVOffset, texture, textureWidth, textureHeight, pressAction, message);
    }

    public static CompatibleTexturedButtonWidget createTexturedButtonWidget(int x, int y, int width, int height, int u, int v, CompatIdentifier texture, class_4185.class_4241 pressAction) {
        return createTexturedButtonWidget(x, y, width, height, u, v, height, texture.toMinecraft(), pressAction);
    }

    public static CompatibleTexturedButtonWidget createTexturedButtonWidget(int x, int y, int width, int height, int u, int v, int hoveredVOffset, CompatIdentifier texture, class_4185.class_4241 pressAction) {
        return createTexturedButtonWidget(x, y, width, height, u, v, hoveredVOffset, texture.toMinecraft(), pressAction);
    }

    public static CompatibleTexturedButtonWidget createTexturedButtonWidget(int x, int y, int width, int height, int u, int v, int hoveredVOffset, CompatIdentifier texture, int textureWidth, int textureHeight, class_4185.class_4241 pressAction) {
        return createTexturedButtonWidget(x, y, width, height, u, v, hoveredVOffset, texture.toMinecraft(), textureWidth, textureHeight, pressAction);
    }

    public static CompatibleTexturedButtonWidget createTexturedButtonWidget(int x, int y, int width, int height, int u, int v, int hoveredVOffset, CompatIdentifier texture, int textureWidth, int textureHeight, class_4185.class_4241 pressAction, class_2561 message) {
        return createTexturedButtonWidget(x, y, width, height, u, v, hoveredVOffset, texture.toMinecraft(), textureWidth, textureHeight, pressAction, message);
    }

    public static RedrawableTexturedButtonWidget createRedrawableTexturedButtonWidget(int x, int y, int width, int height, int u, int v, CompatIdentifier texture, class_4185.class_4241 pressAction) {
        return createRedrawableTexturedButtonWidget(x, y, width, height, u, v, texture.toMinecraft(), pressAction);
    }

    public static RedrawableTexturedButtonWidget createRedrawableTexturedButtonWidget(int x, int y, int width, int height, int u, int v, int hoveredVOffset, CompatIdentifier texture, class_4185.class_4241 pressAction) {
        return createRedrawableTexturedButtonWidget(x, y, width, height, u, v, hoveredVOffset, texture.toMinecraft(), pressAction);
    }

    public static RedrawableTexturedButtonWidget createRedrawableTexturedButtonWidget(int x, int y, int width, int height, int u, int v, int hoveredVOffset, CompatIdentifier texture, int textureWidth, int textureHeight, class_4185.class_4241 pressAction) {
        return createRedrawableTexturedButtonWidget(x, y, width, height, u, v, hoveredVOffset, texture.toMinecraft(), textureWidth, textureHeight, pressAction);
    }

    public static RedrawableTexturedButtonWidget createRedrawableTexturedButtonWidget(int x, int y, int width, int height, int u, int v, int hoveredVOffset, CompatIdentifier texture, int textureWidth, int textureHeight, class_4185.class_4241 pressAction, class_2561 message) {
        return createRedrawableTexturedButtonWidget(x, y, width, height, u, v, hoveredVOffset, texture.toMinecraft(), textureWidth, textureHeight, pressAction, message);
    }



    public static class Texts {
        public static class_2561 empty() {
            return class_5244.field_39003;
        }
    }

    public static class TextFieldUtil extends net.pitan76.mcpitanlib.api.util.client.widget.TextFieldUtil {
        // Nothing
    }

    public static class ClickableWidgetUtil extends net.pitan76.mcpitanlib.api.util.client.widget.ClickableWidgetUtil {
        // Nothing
    }

    public static class RendererUtil {
        public static int drawText(class_327 renderer, DrawObjectDM drawObjectDM, class_2561 text, int x, int y, int color) {
            drawObjectDM.getContext().method_51439(renderer, text, x, y, fixColor(color), false);
            return -1;
        }

        public static int drawText(class_327 renderer, DrawObjectDM drawObjectDM, String text, int x, int y, int color) {
            drawObjectDM.getContext().method_51433(renderer, text, x, y, fixColor(color), false);
            return -1;
        }

        public static int drawText(class_327 renderer, DrawObjectDM drawObjectDM, class_5481 text, int x, int y, int color) {
            drawObjectDM.getContext().method_51430(renderer, text, x, y, fixColor(color), false);
            return -1;
        }

        public static void drawTexture(DrawObjectDM drawObjectDM, class_2960 texture, int x, int y, float u, float v, int width, int height, int textureWidth, int textureHeight) {
            drawObjectDM.getContext().method_25290(class_10799.field_56883, texture, x, y, u, v, width, height, textureWidth, textureHeight);
        }

        public static void drawTexture(DrawObjectDM drawObjectDM, class_2960 texture, int x, int y, float u, float v, int width, int height) {
            drawObjectDM.getContext().method_25290(class_10799.field_56883, texture, x, y, u, v, width, height, 256, 256);
        }

        public static class_327 getTextRenderer() {
            return class_310.method_1551().field_1772;
        }

        public static void drawTexture(DrawObjectDM drawObjectDM, CompatIdentifier texture, int x, int y, float u, float v, int width, int height, int textureWidth, int textureHeight) {
            drawTexture(drawObjectDM, texture.toMinecraft(), x, y, u, v, width, height, textureWidth, textureHeight);
        }

        public static void drawTexture(DrawObjectDM drawObjectDM, CompatIdentifier texture, int x, int y, float u, float v, int width, int height) {
            drawTexture(drawObjectDM, texture.toMinecraft(), x, y, u, v, width, height);
        }

        public static int drawText(class_327 renderer, DrawObjectDM drawObjectDM, TextComponent text, int x, int y, int color) {
            return drawText(renderer, drawObjectDM, text.getText(), x, y, color);
        }

        public static int drawText(class_327 renderer, DrawObjectDM drawObjectDM, class_2561 text, int x, int y) {
            return drawText(renderer, drawObjectDM, text, x, y, -12566464);
        }

        public static int drawText(class_327 renderer, DrawObjectDM drawObjectDM, TextComponent text, int x, int y) {
            return drawText(renderer, drawObjectDM, text, x, y, -12566464);
        }

        public static void drawTooltip(DrawObjectDM drawObjectDM, class_327 textRenderer, class_2561 text, int x, int y) {
            drawObjectDM.getContext().method_51438(textRenderer, text, x, y);
        }

        public static void drawTooltip(DrawObjectDM drawObjectDM, class_327 textRenderer, List<class_2561> texts, int x, int y) {
            drawObjectDM.getContext().method_51434(textRenderer, texts, x, y);
        }

        public static void drawBorder(DrawObjectDM drawObjectDM, int x, int y, int width, int height, int color) {
            drawObjectDM.getContext().method_49601(x, y, width, height, color);
        }

        public static void drawTooltip(DrawObjectDM drawObjectDM, class_2561 text, int x, int y) {
            drawObjectDM.getContext().method_51438(getTextRenderer(), text, x, y);
        }

        public static void drawTooltip(DrawObjectDM drawObjectDM, TextComponent text, int x, int y) {
            drawTooltip(drawObjectDM, text.getText(), x, y);
        }

        public static void drawTooltip(DrawObjectDM drawObjectDM, List<class_2561> texts, int x, int y) {
            drawObjectDM.getContext().method_51434(getTextRenderer(), texts, x, y);
        }
    }

    public static int getWidth(class_2561 text) {
        return RendererUtil.getTextRenderer().method_27525(text);
    }

    // RGBからARGBに変換する (1.21.6からは透明になるため)
    private static int fixColor(int color) {
        if ((color >>> 24) == 0) {
            return 0xFF000000 | color;
        } else {
            return color;
        }
    }
}
