package net.pitan76.mcpitanlib.api.block;

import net.minecraft.class_3614;
import net.minecraft.class_3619;
import net.minecraft.class_3620;

public final class CompatibleMaterial {
    public static final CompatibleMaterial AIR;
    public static final CompatibleMaterial STRUCTURE_VOID;
    public static final CompatibleMaterial PORTAL;
    public static final CompatibleMaterial CARPET;
    public static final CompatibleMaterial PLANT;
    public static final CompatibleMaterial UNDERWATER_PLANT;
    public static final CompatibleMaterial REPLACEABLE_PLANT;
    public static final CompatibleMaterial NETHER_SHOOTS;
    public static final CompatibleMaterial REPLACEABLE_UNDERWATER_PLANT;
    public static final CompatibleMaterial WATER;
    public static final CompatibleMaterial BUBBLE_COLUMN;
    public static final CompatibleMaterial LAVA;
    public static final CompatibleMaterial SNOW_LAYER;
    public static final CompatibleMaterial FIRE;
    public static final CompatibleMaterial DECORATION;
    public static final CompatibleMaterial COBWEB;
    public static final CompatibleMaterial SCULK;
    public static final CompatibleMaterial REDSTONE_LAMP;
    public static final CompatibleMaterial ORGANIC_PRODUCT;
    public static final CompatibleMaterial SOIL;
    public static final CompatibleMaterial SOLID_ORGANIC;
    public static final CompatibleMaterial DENSE_ICE;
    public static final CompatibleMaterial AGGREGATE;
    public static final CompatibleMaterial SPONGE;
    public static final CompatibleMaterial SHULKER_BOX;
    public static final CompatibleMaterial WOOD;
    public static final CompatibleMaterial NETHER_WOOD;
    public static final CompatibleMaterial BAMBOO_SAPLING;
    public static final CompatibleMaterial BAMBOO;
    public static final CompatibleMaterial WOOL;
    public static final CompatibleMaterial TNT;
    public static final CompatibleMaterial LEAVES;
    public static final CompatibleMaterial GLASS;
    public static final CompatibleMaterial ICE;
    public static final CompatibleMaterial CACTUS;
    public static final CompatibleMaterial STONE;
    public static final CompatibleMaterial METAL;
    public static final CompatibleMaterial SNOW_BLOCK;
    public static final CompatibleMaterial REPAIR_STATION;
    public static final CompatibleMaterial BARRIER;
    public static final CompatibleMaterial PISTON;
    public static final CompatibleMaterial MOSS_BLOCK;
    public static final CompatibleMaterial GOURD;
    public static final CompatibleMaterial EGG;
    public static final CompatibleMaterial CAKE;
    public static final CompatibleMaterial AMETHYST;
    public static final CompatibleMaterial POWDER_SNOW;
    private final class_3620 color;
    private final class_3619 pistonBehavior;
    private final boolean burnable;
    private final boolean liquid;
    private final boolean replaceable;
    private final boolean solid;
    private class_3614 material;

    public CompatibleMaterial(class_3620 color, boolean liquid, boolean solid, boolean burnable, boolean replaceable, class_3619 pistonBehavior) {
        this.color = color;
        this.liquid = liquid;
        this.solid = solid;
        this.burnable = burnable;
        this.replaceable = replaceable;
        this.pistonBehavior = pistonBehavior;
        this.material = class_3614.field_15914;
    }

    private CompatibleMaterial(class_3614 material, class_3620 color, boolean liquid, boolean solid, boolean burnable, boolean replaceable, class_3619 pistonBehavior) {
        this(material.method_15803(), material.method_15797(), material.method_15799(), material.method_15802(), material.method_15800(), material.method_15798());
        this.material = material;
    }

    @Deprecated
    public class_3614 getMaterial() {
        return material;
    }

    public boolean isLiquid() {
        return this.liquid;
    }

    public boolean isSolid() {
        return this.solid;
    }

    public boolean isBurnable() {
        return this.burnable;
    }

    public boolean isReplaceable() {
        return this.replaceable;
    }

    public class_3619 getPistonBehavior() {
        return this.pistonBehavior;
    }

    public class_3620 getColor() {
        return this.color;
    }

    static {
        AIR = (new Builder(class_3620.field_16008)).allowsMovement().lightPassesThrough().notSolid().replaceable().material(class_3614.field_15959).build();
        STRUCTURE_VOID = (new Builder(class_3620.field_16008)).allowsMovement().lightPassesThrough().notSolid().replaceable().material(class_3614.field_15927).build();
        PORTAL = (new Builder(class_3620.field_16008)).allowsMovement().lightPassesThrough().notSolid().blocksPistons().material(class_3614.field_15919).build();
        CARPET = (new Builder(class_3620.field_15979)).allowsMovement().lightPassesThrough().notSolid().burnable().material(class_3614.field_15957).build();
        PLANT = (new Builder(class_3620.field_16004)).allowsMovement().lightPassesThrough().notSolid().destroyedByPiston().material(class_3614.field_15935).build();
        UNDERWATER_PLANT = (new Builder(class_3620.field_16019)).allowsMovement().lightPassesThrough().notSolid().destroyedByPiston().material(class_3614.field_15947).build();
        REPLACEABLE_PLANT = (new Builder(class_3620.field_16004)).allowsMovement().lightPassesThrough().notSolid().destroyedByPiston().replaceable().burnable().material(class_3614.field_15956).build();
        NETHER_SHOOTS = (new Builder(class_3620.field_16004)).allowsMovement().lightPassesThrough().notSolid().destroyedByPiston().replaceable().material(class_3614.field_26708).build();
        REPLACEABLE_UNDERWATER_PLANT = (new Builder(class_3620.field_16019)).allowsMovement().lightPassesThrough().notSolid().destroyedByPiston().replaceable().material(class_3614.field_15926).build();
        WATER = (new Builder(class_3620.field_16019)).allowsMovement().lightPassesThrough().notSolid().destroyedByPiston().replaceable().liquid().material(class_3614.field_15920).build();
        BUBBLE_COLUMN = (new Builder(class_3620.field_16019)).allowsMovement().lightPassesThrough().notSolid().destroyedByPiston().replaceable().liquid().material(class_3614.field_15915).build();
        LAVA = (new Builder(class_3620.field_16002)).allowsMovement().lightPassesThrough().notSolid().destroyedByPiston().replaceable().liquid().material(class_3614.field_15922).build();
        SNOW_LAYER = (new Builder(class_3620.field_16022)).allowsMovement().lightPassesThrough().notSolid().destroyedByPiston().replaceable().material(class_3614.field_15948).build();
        FIRE = (new Builder(class_3620.field_16008)).allowsMovement().lightPassesThrough().notSolid().destroyedByPiston().replaceable().material(class_3614.field_15943).build();
        DECORATION = (new Builder(class_3620.field_16008)).allowsMovement().lightPassesThrough().notSolid().destroyedByPiston().material(class_3614.field_15924).build();
        COBWEB = (new Builder(class_3620.field_15979)).allowsMovement().lightPassesThrough().destroyedByPiston().material(class_3614.field_15913).build();
        SCULK = (new Builder(class_3620.field_16009)).material(class_3614.field_28242).build();
        REDSTONE_LAMP = (new Builder(class_3620.field_16008)).material(class_3614.field_15918).build();
        ORGANIC_PRODUCT = (new Builder(class_3620.field_15976)).material(class_3614.field_15936).build();
        SOIL = (new Builder(class_3620.field_16000)).material(class_3614.field_15941).build();
        SOLID_ORGANIC = (new Builder(class_3620.field_15999)).material(class_3614.field_15945).build();
        DENSE_ICE = (new Builder(class_3620.field_16016)).material(class_3614.field_15928).build();
        AGGREGATE = (new Builder(class_3620.field_15986)).material(class_3614.field_15916).build();
        SPONGE = (new Builder(class_3620.field_16010)).material(class_3614.field_15917).build();
        SHULKER_BOX = (new Builder(class_3620.field_16014)).material(class_3614.field_17008).build();
        WOOD = (new Builder(class_3620.field_15996)).burnable().material(class_3614.field_15932).build();
        NETHER_WOOD = (new Builder(class_3620.field_15996)).material(class_3614.field_22223).build();
        BAMBOO_SAPLING = (new Builder(class_3620.field_15996)).burnable().destroyedByPiston().allowsMovement().material(class_3614.field_15938).build();
        BAMBOO = (new Builder(class_3620.field_15996)).burnable().destroyedByPiston().material(class_3614.field_15946).build();
        WOOL = (new Builder(class_3620.field_15979)).burnable().material(class_3614.field_15931).build();
        TNT = (new Builder(class_3620.field_16002)).burnable().lightPassesThrough().material(class_3614.field_15955).build();
        LEAVES = (new Builder(class_3620.field_16004)).burnable().lightPassesThrough().destroyedByPiston().material(class_3614.field_15923).build();
        GLASS = (new Builder(class_3620.field_16008)).lightPassesThrough().material(class_3614.field_15942).build();
        ICE = (new Builder(class_3620.field_16016)).lightPassesThrough().material(class_3614.field_15958).build();
        CACTUS = (new Builder(class_3620.field_16004)).lightPassesThrough().destroyedByPiston().material(class_3614.field_15925).build();
        STONE = (new Builder(class_3620.field_16023)).material(class_3614.field_15914).build();
        METAL = (new Builder(class_3620.field_16005)).material(class_3614.field_15953).build();
        SNOW_BLOCK = (new Builder(class_3620.field_16022)).material(class_3614.field_15934).build();
        REPAIR_STATION = (new Builder(class_3620.field_16005)).blocksPistons().material(class_3614.field_15949).build();
        BARRIER = (new Builder(class_3620.field_16008)).blocksPistons().material(class_3614.field_15952).build();
        PISTON = (new Builder(class_3620.field_16023)).blocksPistons().material(class_3614.field_15933).build();
        MOSS_BLOCK = (new Builder(class_3620.field_16004)).destroyedByPiston().material(class_3614.field_15921).build();
        GOURD = (new Builder(class_3620.field_16004)).destroyedByPiston().material(class_3614.field_15954).build();
        EGG = (new Builder(class_3620.field_16004)).destroyedByPiston().material(class_3614.field_15930).build();
        CAKE = (new Builder(class_3620.field_16008)).destroyedByPiston().material(class_3614.field_15937).build();
        AMETHYST = (new Builder(class_3620.field_16014)).material(class_3614.field_27340).build();
        POWDER_SNOW = (new Builder(class_3620.field_16022)).notSolid().allowsMovement().material(class_3614.field_27890).build();
    }

    public static class Builder {
        private class_3619 pistonBehavior;
        private boolean blocksMovement;
        private boolean burnable;
        private boolean liquid;
        private boolean replaceable;
        private boolean solid;
        private final class_3620 color;
        private boolean blocksLight;
        private class_3614 material = class_3614.field_15914;

        public Builder(class_3620 color) {
            this.pistonBehavior = class_3619.field_15974;
            this.blocksMovement = true;
            this.solid = true;
            this.blocksLight = true;
            this.color = color;
        }

        public Builder liquid() {
            this.liquid = true;
            return this;
        }

        public Builder notSolid() {
            this.solid = false;
            return this;
        }

        public Builder allowsMovement() {
            this.blocksMovement = false;
            return this;
        }

        Builder lightPassesThrough() {
            this.blocksLight = false;
            return this;
        }

        protected Builder burnable() {
            this.burnable = true;
            return this;
        }

        public Builder replaceable() {
            this.replaceable = true;
            return this;
        }

        protected Builder destroyedByPiston() {
            this.pistonBehavior = class_3619.field_15971;
            return this;
        }

        protected Builder blocksPistons() {
            this.pistonBehavior = class_3619.field_15972;
            return this;
        }

        protected Builder material(class_3614 material) {
            this.material = material;
            return this;
        }

        public CompatibleMaterial build() {
            return new CompatibleMaterial(material, this.color, this.liquid, this.solid, this.burnable, this.replaceable, this.pistonBehavior);
        }
    }
}
