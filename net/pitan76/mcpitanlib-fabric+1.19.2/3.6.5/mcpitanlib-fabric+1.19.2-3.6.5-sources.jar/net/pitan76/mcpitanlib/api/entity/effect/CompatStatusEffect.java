package net.pitan76.mcpitanlib.api.entity.effect;

import net.minecraft.class_1291;
import net.minecraft.class_1937;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.pitan76.mcpitanlib.api.util.StatusEffectUtil;
import org.jetbrains.annotations.Nullable;

public class CompatStatusEffect {
    private final class_1291 statusEffect;

    @Deprecated
    public CompatStatusEffect(class_1291 statusEffect) {
        this.statusEffect = statusEffect;
    }

    public CompatStatusEffect of(class_2960 identifier) {
        return StatusEffectUtil.getStatusEffect(identifier);
    }

    public class_2960 getId() {
        return class_2378.field_11159.method_10221(statusEffect);
    }

    public String toString() {
        return getId().toString();
    }

    public boolean equals(Object obj) {
        if (obj instanceof CompatStatusEffect) {
            return ((CompatStatusEffect) obj).getId().equals(getId());
        }
        return false;
    }

    public class_1291 getStatusEffect(@Nullable class_1937 world) {
        return statusEffect;
    }
}
