package net.pitan76.mcpitanlib.api.sound;

import net.minecraft.class_3414;

public class CompatSoundEvent {
    public class_3414 soundEvent;

    public CompatSoundEvent(class_3414 soundEvent) {
        this.soundEvent = soundEvent;
    }

    public static CompatSoundEvent of(class_3414 soundEvent) {
        return new CompatSoundEvent(soundEvent);
    }

    public class_3414 get() {
        return soundEvent;
    }
}
