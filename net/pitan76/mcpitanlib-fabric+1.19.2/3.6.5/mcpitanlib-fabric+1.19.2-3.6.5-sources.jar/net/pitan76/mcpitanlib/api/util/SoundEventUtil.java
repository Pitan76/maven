package net.pitan76.mcpitanlib.api.util;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_3414;

public class SoundEventUtil {
    public static class_2960 getId(class_3414 soundEvent) {
        return soundEvent.method_14833();
    }

    public static class_3414 getSoundEvent(class_2960 id) {
        return new class_3414(id);
    }

    public static CompatIdentifier getCompatId(class_3414 soundEvent) {
        return CompatIdentifier.fromMinecraft(getId(soundEvent));
    }

    public static class_3414 getSoundEvent(CompatIdentifier id) {
        return getSoundEvent(id.toMinecraft());
    }

    public static List<class_3414> getAllSoundEvents() {
        return class_2378.field_11156.method_10220().collect(Collectors.toList());
    }

    public static List<class_2960> getAllSoundEventIds() {
        return new ArrayList<>(class_2378.field_11156.method_10235());
    }
}
