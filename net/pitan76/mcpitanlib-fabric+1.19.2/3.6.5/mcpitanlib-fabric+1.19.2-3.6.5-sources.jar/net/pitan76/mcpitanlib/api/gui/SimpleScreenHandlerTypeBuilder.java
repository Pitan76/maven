package net.pitan76.mcpitanlib.api.gui;

import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_3917;
import net.pitan76.mcpitanlib.api.gui.args.CreateMenuEvent;

public class SimpleScreenHandlerTypeBuilder<T extends class_1703> {

    private final Factory<T> factory;

    public SimpleScreenHandlerTypeBuilder(Factory<T> factory) {
        this.factory = factory;
    }

    public SimpleScreenHandlerTypeBuilder(Factory2<T> factory) {
        this.factory = factory;
    }

    public class_3917<T> build() {
        return new class_3917<>(factory::create);
    }

    @FunctionalInterface
    public interface Factory<T extends class_1703> {
        T create(int syncId, class_1661 inventory);
    }

    @FunctionalInterface
    public interface Factory2<T extends class_1703> extends Factory<T> {
        T create(CreateMenuEvent e);

        @Override
        default T create(int syncId, class_1661 inventory) {
            return create(new CreateMenuEvent(syncId, inventory));
        }
    }
}
