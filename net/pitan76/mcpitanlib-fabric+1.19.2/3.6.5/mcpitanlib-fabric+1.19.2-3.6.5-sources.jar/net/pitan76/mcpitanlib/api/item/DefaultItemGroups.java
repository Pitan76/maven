package net.pitan76.mcpitanlib.api.item;

import net.minecraft.class_1761;

public class DefaultItemGroups {
    public static final class_1761 BUILDING_BLOCKS = class_1761.field_7931;
    public static final class_1761 COLORED_BLOCKS = class_1761.field_7931;
    public static final class_1761 NATURAL = class_1761.field_7928;
    public static final class_1761 FUNCTIONAL = class_1761.field_7923;
    public static final class_1761 REDSTONE = class_1761.field_7914;
    public static final class_1761 HOTBAR = class_1761.field_7925;
    public static final class_1761 SEARCH = class_1761.field_7915;
    public static final class_1761 TOOLS = class_1761.field_7930;
    public static final class_1761 COMBAT = class_1761.field_7916;
    public static final class_1761 FOOD_AND_DRINK = class_1761.field_7922;
    public static final class_1761 INGREDIENTS = class_1761.field_7932;
    public static final class_1761 SPAWN_EGGS = class_1761.field_7932;
    public static final class_1761 OPERATOR = class_1761.field_7932;
    public static final class_1761 INVENTORY = class_1761.field_7918;

    // ～1.19.2 Item Group
    public static final class_1761 BREWING = class_1761.field_7924; // if version is 1.19.3, FOOD_AND_DRINK
    public static final class_1761 TRANSPORTATION = class_1761.field_7923; // if version is 1.19.3, FUNCTIONAL
    public static final class_1761 DECORATIONS = class_1761.field_7928; // if version is 1.19.3, NATURAL
    public static final class_1761 MISC = class_1761.field_7932; // if version is 1.19.3, INGREDIENTS
}
