package net.pitan76.mcpitanlib.api.util;

import net.minecraft.class_1282;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.pitan76.mcpitanlib.api.entity.Player;

public class DamageSourceUtil {
    public static class_1282 thrownProjectile(class_1297 projectile, class_1297 attacker, class_1297 source) {
        return thrownProjectile(projectile, attacker);
    }

    public static class_1282 thrownProjectile(class_1297 projectile, class_1297 attacker) {
        return class_1282.method_5524(projectile, attacker);
    }

    public static class_1282 playerAttack(Player attacker, class_1297 source) {
        return playerAttack(attacker);
    }

    public static class_1282 playerAttack(Player attacker) {
        return class_1282.method_5532(attacker.getPlayerEntity());
    }

    public static class_1282 mobAttack(class_1309 attacker, class_1297 source) {
        return mobAttack(attacker);
    }

    public static class_1282 mobAttack(class_1309 attacker) {
        return class_1282.method_5511(attacker);
    }

    public static class_1282 mobProjectile(class_1297 projectile, class_1309 attacker, class_1297 source) {
        return mobProjectile(projectile, attacker);
    }

    public static class_1282 mobProjectile(class_1297 projectile, class_1309 attacker) {
        return class_1282.method_5519(projectile, attacker);
    }

    public static class_1282 fall(class_1297 source) {
        return class_1282.field_5868;
    }
}
