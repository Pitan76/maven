package net.pitan76.mcpitanlib.api.util.screen;

import org.jetbrains.annotations.Nullable;

import java.util.Set;
import net.minecraft.class_1263;
import net.minecraft.class_1703;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_2586;
import net.minecraft.class_3532;

public class ScreenHandlerUtil {
    public static int calcComparatorOutput(@Nullable class_1263 inventory) {
        return class_1703.method_7618(inventory);
    }

    public static int calcComparatorOutput(@Nullable class_2586 blockEntity) {
        return class_1703.method_7608(blockEntity);
    }

    public static int calculateStackSize(Set<class_1735> slots, int mode, class_1799 stack) {
        int stackSize;

        switch (mode) {
            case 0:
                stackSize = class_3532.method_15375((float)stack.method_7947() / (float)slots.size());
                break;
            case 1:
                stackSize = 1;
                break;
            case 2:
                stackSize = stack.method_7914();
                break;
            default:
                stackSize = stack.method_7947();
        }

        return stackSize;
    }

    public static boolean canInsertItemIntoSlot(@Nullable class_1735 slot, class_1799 stack, boolean allowOverflow) {
        return class_1703.method_7592(slot, stack, allowOverflow);
    }
}
