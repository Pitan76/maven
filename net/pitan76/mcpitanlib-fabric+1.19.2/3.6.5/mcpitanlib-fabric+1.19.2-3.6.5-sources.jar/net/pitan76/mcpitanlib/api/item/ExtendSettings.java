package net.pitan76.mcpitanlib.api.item;

import java.util.function.Supplier;
import net.minecraft.class_1761;
import net.minecraft.class_1792;
import net.minecraft.class_2960;

/**
 * Use {@link CompatibleItemSettings} instead.
 */
public class ExtendSettings extends class_1792.class_1793 {

    // ～1.19.2
    public ExtendSettings addGroup(class_1761 itemGroup) {
        super.method_7892(itemGroup);
        return this;
    }

    // 1.19.3～
    // identifier: Item ID
    public ExtendSettings addGroup(class_1761 itemGroup, class_2960 identifier) {
        //CreativeTabRegistry.append(itemGroup, ItemUtil.fromId(identifier));
        return addGroup(itemGroup);
    }

    public ExtendSettings addGroup(Supplier<class_1761> itemGroup, class_2960 identifier) {
        addGroup(itemGroup.get());
        return this;
    }
}
