package net.pitan76.mcpitanlib.api.util;

import dev.architectury.registry.menu.ExtendedMenuProvider;
import dev.architectury.registry.menu.MenuRegistry;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;
import net.minecraft.class_1703;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_2371;
import net.minecraft.class_2378;
import net.minecraft.class_2540;
import net.minecraft.class_3222;
import net.minecraft.class_3908;
import net.minecraft.class_3917;

public class ScreenHandlerUtil {
    public static class_2371<class_1735> getSlots(class_1703 screenHandler) {
        return screenHandler.field_7761;
    }

    public static class_1735 getSlot(class_1703 screenHandler, int index) {
        return screenHandler.method_7611(index);
    }

    public static List<class_3917<?>> getAllScreenHandlerTypes() {
        List<class_3917<?>> screenHandlerTypes = new ArrayList<>();
        for (class_3917<?> screenHandler : class_2378.field_17429) {
            screenHandlerTypes.add(screenHandler);
        }
        return screenHandlerTypes;
    }

    public static void openExtendedMenu(class_3222 player, class_3908 provider, Consumer<class_2540> bufWriter) {
        MenuRegistry.openExtendedMenu(player, provider, bufWriter);
    }

    public static void openExtendedMenu(class_3222 player, ExtendedMenuProvider provider) {
        MenuRegistry.openExtendedMenu(player, provider);
    }

    public static void openMenu(class_3222 player, class_3908 provider) {
        MenuRegistry.openMenu(player, provider);
    }

    public static int getRawId(class_3917<?> type) {
        return class_2378.field_17429.method_10206(type);
    }

    public static class_3917<?> fromIndex(int index) {
        return class_2378.field_17429.method_10200(index);
    }

    public static class_1799 getCursorStack(class_1703 screenHandler) {
        return screenHandler.method_34255();
    }

    public static net.pitan76.mcpitanlib.midohra.item.ItemStack getCursorStackM(class_1703 screenHandler) {
        return net.pitan76.mcpitanlib.midohra.item.ItemStack.of(getCursorStack(screenHandler));
    }

    public static void setCursorStack(class_1703 screenHandler, class_1799 stack) {
        screenHandler.method_34254(stack);
    }

    public static void setCursorStackM(class_1703 screenHandler, net.pitan76.mcpitanlib.midohra.item.ItemStack stack) {
        setCursorStack(screenHandler, stack.toMinecraft());
    }
}
