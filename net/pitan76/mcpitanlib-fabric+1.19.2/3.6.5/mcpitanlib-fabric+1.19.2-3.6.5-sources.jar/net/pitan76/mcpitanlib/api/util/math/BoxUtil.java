package net.pitan76.mcpitanlib.api.util.math;

import net.minecraft.class_2338;
import net.minecraft.class_238;

public class BoxUtil {
    public static class_238 createBox(double x1, double y1, double z1, double x2, double y2, double z2) {
        return new class_238(x1, y1, z1, x2, y2, z2);
    }

    public static class_238 createBox(double x, double y, double z, double size) {
        return new class_238(x, y, z, x + size, y + size, z + size);
    }

    public static class_238 createBox(double size) {
        return new class_238(0, 0, 0, size, size, size);
    }

    public static class_238 createBox(double x1, double y1, double z1, double x2, double y2, double z2, double size) {
        return new class_238(x1, y1, z1, x2 + size, y2 + size, z2 + size);
    }

    public static class_238 createBox(class_2338 pos) {
        return new class_238(pos);
    }

    public static class_238 createBox(class_2338 pos1, class_2338 pos2) {
        return new class_238(pos1, pos2);
    }

    public static class_238 createBox(class_2338 pos, int size) {
        return createBox(pos, pos.method_10069(size, size, size));
    }

    public static class_238 createBox(class_2338 pos, int sizeX, int sizeY, int sizeZ) {
        return createBox(pos, pos.method_10069(sizeX, sizeY, sizeZ));
    }

    public static class_238 createBoxCenter(class_2338 pos, int size) {
        return createBox(pos.method_10069(-size, -size, -size), pos.method_10069(size, size, size));
    }

    public static class_238 expand(class_238 box, double x, double y, double z) {
        return new class_238(box.field_1323 - x, box.field_1322 - y, box.field_1321 - z, box.field_1320 + x, box.field_1325 + y, box.field_1324 + z);
    }

    public static class_238 expand(class_238 box, double size) {
        return expand(box, size, size, size);
    }

    public static class_238 union(class_238 box1, class_238 box2) {
        return box1.method_991(box2);
    }
}
