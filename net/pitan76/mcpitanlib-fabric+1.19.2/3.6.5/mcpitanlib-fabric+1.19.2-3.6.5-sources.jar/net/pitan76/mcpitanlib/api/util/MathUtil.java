package net.pitan76.mcpitanlib.api.util;

import net.minecraft.class_1158;
import net.minecraft.class_1160;
import net.pitan76.mcpitanlib.api.util.math.random.CompatRandom;

public class MathUtil {

    public static CompatRandom createRandom(long seed) {
        return CompatRandom.of(seed);
    }

    public static CompatRandom createRandom() {
        return CompatRandom.of();
    }

    @Deprecated
    public static class_1158 getRotationDegrees(RotationAxisType type, float deg) {
        return type.axis.method_23214(deg);
    }

    public static class RotationAxisType {

        public static RotationAxisType POSITIVE_X = new RotationAxisType(class_1160.field_20703);
        public static RotationAxisType POSITIVE_Y = new RotationAxisType(class_1160.field_20705);
        public static RotationAxisType POSITIVE_Z = new RotationAxisType(class_1160.field_20707);

        protected final class_1160 axis;
        protected RotationAxisType(class_1160 axis) {
            this.axis = axis;
        }
    }
}
