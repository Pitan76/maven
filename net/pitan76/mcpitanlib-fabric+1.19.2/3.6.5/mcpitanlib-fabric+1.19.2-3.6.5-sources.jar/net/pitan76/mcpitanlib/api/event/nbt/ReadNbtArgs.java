package net.pitan76.mcpitanlib.api.event.nbt;

import net.minecraft.class_2487;
import net.pitan76.mcpitanlib.api.registry.CompatRegistryLookup;

public class ReadNbtArgs extends NbtRWArgs {

    public ReadNbtArgs(class_2487 nbt) {
        super(nbt);
    }

    public ReadNbtArgs(class_2487 nbt, CompatRegistryLookup registryLookup) {
        super(nbt, registryLookup);
    }

    @Override
    public boolean isViewEmpty() {
        return false;
    }

    @Override
    public NbtRWArgs copy() {
        return new ReadNbtArgs(nbt.method_10553(), registryLookup);
    }

    public ReadNbtArgs(net.pitan76.mcpitanlib.midohra.nbt.NbtCompound nbt, CompatRegistryLookup registryLookup) {
        this(nbt.toMinecraft(), registryLookup);
    }

    public ReadNbtArgs(net.pitan76.mcpitanlib.midohra.nbt.NbtCompound nbt) {
        this(nbt.toMinecraft());
    }
}
