package net.pitan76.mcpitanlib.api.client.render;

import net.minecraft.class_2561;
import net.minecraft.class_437;
import net.minecraft.class_4587;
import net.pitan76.mcpitanlib.api.text.TextComponent;
import net.pitan76.mcpitanlib.api.util.CompatIdentifier;
import net.pitan76.mcpitanlib.api.util.client.ScreenUtil.RendererUtil;

public class DrawObjectDM {
    private class_4587 stack;

    private class_437 screen = null;

    public DrawObjectDM(class_4587 stack) {
        this.stack = stack;
    }

    public DrawObjectDM(class_4587 stack, class_437 screen) {
        this(stack);
        this.screen = screen;
    }

    public class_4587 getStack() {
        return stack;
    }

    public class_437 getScreen() {
        return screen;
    }

    public void setStack(class_4587 stack) {
        this.stack = stack;
    }

    public void setScreen(class_437 screen) {
        this.screen = screen;
    }

    public boolean hasScreen() {
        return screen != null;
    }

    public void drawTexture(CompatIdentifier texture, int x, int y, float u, float v, int width, int height) {
        RendererUtil.drawTexture(this, texture, x, y, u, v, width, height);
    }

    public void drawTexture(CompatIdentifier texture, int x, int y, float u, float v, int width, int height, int textureWidth, int textureHeight) {
        RendererUtil.drawTexture(this, texture, x, y, u, v, width, height, textureWidth, textureHeight);
    }

    public void drawText(class_2561 text, int x, int y) {
        RendererUtil.drawText(RendererUtil.getTextRenderer(), this, text, x, y);
    }

    public void drawTooltip(class_2561 text, int x, int y) {
        RendererUtil.drawTooltip(this, text, x, y);
    }

    public void drawText(TextComponent text, int x, int y) {
        RendererUtil.drawText(RendererUtil.getTextRenderer(), this, text, x, y);
    }

    public void drawTooltip(TextComponent text, int x, int y) {
        RendererUtil.drawTooltip(this, text, x, y);
    }

    public void drawBorder(int x, int y, int width, int height, int color) {
        RendererUtil.drawBorder(this, x, y, width, height, color);
    }

    public int getWidth() {
        return hasScreen() ? screen.field_22789 : -1;
    }

    public int getHeight() {
        return hasScreen() ? screen.field_22790 : -1;
    }
}
