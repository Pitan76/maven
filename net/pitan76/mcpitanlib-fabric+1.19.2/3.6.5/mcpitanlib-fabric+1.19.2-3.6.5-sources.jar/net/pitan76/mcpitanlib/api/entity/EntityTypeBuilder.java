package net.pitan76.mcpitanlib.api.entity;

import com.google.common.collect.ImmutableSet;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1311;
import net.minecraft.class_2248;
import net.minecraft.class_4048;
import net.pitan76.mcpitanlib.MCPitanLib;

public class EntityTypeBuilder<T extends class_1297> {

    private class_1311 spawnGroup;
    private ExtendEntityType.EntityFactory<T> factory;
    private class_4048 entityDimensions;
    private boolean saveable;
    private boolean summonable;
    private boolean fireImmune;
    private boolean spawnableFarFromPlayer;
    private ImmutableSet<class_2248> canSpawnBlocks;
    private int maxTrackDistance;
    private int trackTickInterval;
    private Boolean alwaysUpdateVelocity = null;
    private String translationKey = "entity." + MCPitanLib.MOD_ID;

    @Deprecated
    // Recommend: create()
    public EntityTypeBuilder() {
        setSaveable(true);
        setSummonable(true);
        setFireImmune(false);
        setChangingDimensions(-1.0f, -1.0f);
        spawnableFarFromPlayer = false;
        maxTrackDistance = 5;
        trackTickInterval = 3;
        canSpawnBlocks = ImmutableSet.of();
    }

    @Deprecated
    public EntityTypeBuilder(class_1311 spawnGroup, ExtendEntityType.EntityFactory<T> factory) {
        this();
        this.spawnGroup = spawnGroup;
        this.factory = factory;
    }

    public static <T extends class_1297> EntityTypeBuilder<T> create() {
        return new EntityTypeBuilder<>();
    }

    public static <T extends class_1297> EntityTypeBuilder<T> create(class_1311 spawnGroup, ExtendEntityType.EntityFactory<T> factory) {
        return new EntityTypeBuilder<>(spawnGroup, factory);
    }

    public class_1299<T> build() {
        return new ExtendEntityType<>(factory, spawnGroup, saveable, summonable, fireImmune, spawnableFarFromPlayer, canSpawnBlocks, entityDimensions, maxTrackDistance, trackTickInterval, translationKey, alwaysUpdateVelocity);
    }

    public EntityTypeBuilder<T> setSpawnGroup(class_1311 spawnGroup) {
        this.spawnGroup = spawnGroup;
        return this;
    }

    public EntityTypeBuilder<T> setEntityFactory(ExtendEntityType.EntityFactory<T> factory) {
        this.factory = factory;
        return this;
    }

    public EntityTypeBuilder<T> setDimensions(class_4048 entityDimensions) {
        this.entityDimensions = entityDimensions;
        return this;
    }

    public EntityTypeBuilder<T> setFixedDimensions(float width, float height) {
        return setDimensions(class_4048.method_18385(width, height));
    }

    public EntityTypeBuilder<T> setChangingDimensions(float width, float height) {
        return setDimensions(class_4048.method_18384(width, height));
    }

    public EntityTypeBuilder<T> setSaveable(boolean saveable) {
        this.saveable = saveable;
        return this;
    }

    public EntityTypeBuilder<T> setSummonable(boolean summonable) {
        this.summonable = summonable;
        return this;
    }

    public EntityTypeBuilder<T> setFireImmune(boolean fireImmune) {
        this.fireImmune = fireImmune;
        return this;
    }

    public EntityTypeBuilder<T> setSpawnableFarFromPlayer(boolean spawnableFarFromPlayer) {
        this.spawnableFarFromPlayer = spawnableFarFromPlayer;
        return this;
    }

    public EntityTypeBuilder<T> setCanSpawnBlocks(ImmutableSet<class_2248> canSpawnBlocks) {
        this.canSpawnBlocks = canSpawnBlocks;
        return this;
    }

    public EntityTypeBuilder<T> setMaxTrackDistance(int maxTrackDistance) {
        this.maxTrackDistance = maxTrackDistance;
        return this;
    }

    public EntityTypeBuilder<T> setTrackTickInterval(int trackTickInterval) {
        this.trackTickInterval = trackTickInterval;
        return this;
    }

    public EntityTypeBuilder<T> setAlwaysUpdateVelocity(Boolean alwaysUpdateVelocity) {
        this.alwaysUpdateVelocity = alwaysUpdateVelocity;
        return this;
    }

    public void setTranslationKey(String translationKey) {
        this.translationKey = translationKey;
    }
}
