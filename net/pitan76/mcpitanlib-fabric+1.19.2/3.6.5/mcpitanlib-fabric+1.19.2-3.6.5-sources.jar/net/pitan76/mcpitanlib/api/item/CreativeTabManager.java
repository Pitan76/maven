package net.pitan76.mcpitanlib.api.item;

import net.minecraft.class_1761;
import net.minecraft.class_1799;
import net.minecraft.class_2371;
import net.minecraft.class_2960;
import net.pitan76.mcpitanlib.api.util.ItemUtil;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Supplier;

public class CreativeTabManager {
    private static List<BookingItem> bookingItems = new ArrayList<>();
    private static List<BookingStack> bookingStacks = new ArrayList<>();

    // グループ予約済みアイテム
    public static class BookingItem {
        @Deprecated
        public class_1761 itemGroup;

        public Supplier<class_1761> itemGroupSupplier;
        public class_2960 identifier;

        @Deprecated
        private BookingItem(class_1761 itemGroup, class_2960 identifier) {
            this.itemGroup = itemGroup;
            this.identifier = identifier;
        }

        private BookingItem(Supplier<class_1761> itemGroup, class_2960 identifier) {
            this.itemGroupSupplier = itemGroup;
            this.identifier = identifier;
        }

        public class_1761 getItemGroup() {
            if (itemGroupSupplier != null)
                return itemGroupSupplier.get();
            return itemGroup;
        }
    }

    // グループ予約済みアイテムスタック
    public static class BookingStack {
        @Deprecated
        public class_1761 itemGroup;

        public Supplier<class_1761> itemGroupSupplier;
        public class_1799 stack;

        @Deprecated
        private BookingStack(class_1761 itemGroup, class_1799 stack) {
            this.itemGroup = itemGroup;
            this.stack = stack;
        }

        private BookingStack(Supplier<class_1761> itemGroup, class_1799 stack) {
            this.itemGroupSupplier = itemGroup;
            this.stack = stack;
        }

        public class_1761 getItemGroup() {
            if (itemGroupSupplier != null)
                return itemGroupSupplier.get();
            return itemGroup;
        }
    }

    public static void allRegister() {
        if (!bookingItems.isEmpty()) {
            for (BookingItem bookingItem : bookingItems) {
                bookingItem.getItemGroup().method_7738(class_2371.method_10212(class_1799.field_8037, new class_1799(ItemUtil.fromId(bookingItem.identifier))));
            }
            bookingItems = new ArrayList<>();
        }

        if (!bookingStacks.isEmpty()) {
            for (BookingStack bookingStack : bookingStacks) {
                bookingStack.getItemGroup().method_7738(class_2371.method_10212(class_1799.field_8037, bookingStack.stack));
            }
            bookingStacks = new ArrayList<>();
        }
    }

    public static void register(class_2960 identifier) {
        if (bookingItems.isEmpty()) return;
        for (BookingItem bookingItem : bookingItems) {
            if (!bookingItem.identifier.toString().equals(identifier.toString())) continue;
            bookingItem.getItemGroup().method_7738(class_2371.method_10212(class_1799.field_8037, new class_1799(ItemUtil.fromId(bookingItem.identifier))));
            bookingItems.remove(bookingItem);
            break;
        }
    }

    @Deprecated
    public static void addItem(class_1761 itemGroup, class_2960 identifier) {
        bookingItems.add(new BookingItem(itemGroup, identifier));
    }

    @Deprecated
    public static void addStack(class_1761 itemGroup, class_1799 stack) {
        bookingStacks.add(new BookingStack(itemGroup, stack));
    }

    public static void addItem(Supplier<class_1761> itemGroup, class_2960 identifier) {
        bookingItems.add(new BookingItem(itemGroup, identifier));
    }

    public static void addStack(Supplier<class_1761> itemGroup, class_1799 stack) {
        bookingStacks.add(new BookingStack(itemGroup, stack));
    }
}
