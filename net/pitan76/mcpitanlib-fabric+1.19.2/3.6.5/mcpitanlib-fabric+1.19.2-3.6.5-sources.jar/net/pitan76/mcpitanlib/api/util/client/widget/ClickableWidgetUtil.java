package net.pitan76.mcpitanlib.api.util.client.widget;

import net.minecraft.class_339;
import net.pitan76.mcpitanlib.api.client.render.handledscreen.RenderArgs;

public class ClickableWidgetUtil {
    public static void render(class_339 widget, RenderArgs args) {
        widget.method_25394(args.drawObjectDM.getStack(), args.mouseX, args.mouseY, args.delta);
    }
}
