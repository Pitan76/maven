package net.pitan76.mcpitanlib.api.client.gui.widget;

import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_4587;
import net.pitan76.mcpitanlib.api.util.client.RenderUtil;

public class RedrawableTexturedButtonWidget extends CompatibleTexturedButtonWidget {
    public class_2960 texture;
    public int u;
    public int v;
    public int hoveredVOffset;
    public int textureWidth;
    public int textureHeight;

    public RedrawableTexturedButtonWidget(int x, int y, int width, int height, int u, int v, int hoveredVOffset, class_2960 texture, int textureWidth, int textureHeight, class_4241 pressAction, class_2561 message) {
        super(x, y, width, height, u, v, hoveredVOffset, texture, textureWidth, textureHeight, pressAction, message);
        this.textureWidth = textureWidth;
        this.textureHeight = textureHeight;
        this.u = u;
        this.v = v;
        this.hoveredVOffset = hoveredVOffset;
        this.texture = texture;
    }

    public void method_25359(class_4587 matrices, int mouseX, int mouseY, float delta) {
        RenderUtil.setShaderToPositionTexProgram();
        RenderUtil.setShaderTexture(0, this.texture);
        int i = this.v;
        if (!this.method_37303()) {
            i += this.hoveredVOffset * 2;
        } else if (this.method_25367()) {
            i += this.hoveredVOffset;
        }

        RenderUtil.enableDepthTest();
        method_25290(matrices, this.field_22760, this.field_22761, (float)this.u, (float)i, this.field_22758, this.field_22759, this.textureWidth, this.textureHeight);

        if (this.field_22762) {
            this.method_25352(matrices, mouseX, mouseY);
        }
    }

    public void setTexture(class_2960 texture) {
        this.texture = texture;
    }

    public void setU(int u) {
        this.u = u;
    }

    public void setV(int v) {
        this.v = v;
    }

    public void setHoveredVOffset(int hoveredVOffset) {
        this.hoveredVOffset = hoveredVOffset;
    }

    public void setTextureWidth(int textureWidth) {
        this.textureWidth = textureWidth;
    }

    public void setTextureHeight(int textureHeight) {
        this.textureHeight = textureHeight;
    }
}
