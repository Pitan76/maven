package net.pitan76.mcpitanlib.api.item;

import dev.architectury.registry.CreativeTabRegistry;
import net.minecraft.class_1761;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.pitan76.mcpitanlib.api.util.CompatIdentifier;

import java.util.HashMap;
import java.util.Map;
import java.util.function.Supplier;

public class CreativeTabBuilder {
    @Deprecated
    public static final Map<class_2960, class_1761> itemGroupMap = new HashMap<>();

    @Deprecated
    public static final Map<class_2960, CreativeTabBuilder> itemGroupBuilderMap = new HashMap<>();

    private final class_2960 identifier;
    private class_2561 displayName = null;
    private Supplier<class_1799> iconSupplier = null;
    private boolean noRenderedName = false;
    private boolean noScrollbar = false;
    private boolean special = false;
    private String texture;

    @Deprecated
    // Recommend: create(identifier)
    public CreativeTabBuilder(class_2960 identifier) {
        this.identifier = identifier;
        itemGroupBuilderMap.put(identifier, this);
    }

    public static CreativeTabBuilder create(class_2960 identifier) {
        return new CreativeTabBuilder(identifier);
    }

    public static CreativeTabBuilder create(CompatIdentifier identifier) {
        return create(identifier.toMinecraft());
    }

    public CreativeTabBuilder setDisplayName(class_2561 text) {
        this.displayName = text;
        return this;
    }

    /**
     * Set icon
     * @param iconSupplier Icon supplier
     * @return CreativeTabBuilder
     */
    public CreativeTabBuilder setIcon(Supplier<class_1799> iconSupplier) {
        this.iconSupplier = iconSupplier;
        return this;
    }

    /**
     * Set icon (Already registered item only)
     * @param item Item
     * @return CreativeTabBuilder
     */
    public CreativeTabBuilder setIcon(class_1792 item) {
        return setIcon(() -> new class_1799(item));
    }

    public void noRenderedName() {
        this.noRenderedName = true;
    }

    public void noScrollbar() {
        this.noScrollbar = true;
    }

    public void special() {
        this.special = true;
    }

    public void setTexture(String texture) {
        this.texture = texture;
    }

    /**
     * Build ItemGroup (If loader is forge, not recommended)
     * @return ItemGroup
     */
    public class_1761 build() {
        if (itemGroupMap.containsKey(identifier)) return itemGroupMap.get(identifier);
        class_1761 itemGroup = CreativeTabRegistry.create(identifier, iconSupplier);
        if (displayName != null) itemGroup.method_7739(displayName.getString());
        if (noRenderedName) itemGroup.method_7739("");
        if (noScrollbar) itemGroup.method_7749();
        if (special) itemGroup.method_7752();
        if (texture != null) itemGroup.method_7753(texture);
        itemGroupMap.put(identifier, itemGroup);
        return itemGroup;
    }

    public class_2960 getIdentifier() {
        return identifier;
    }
}
