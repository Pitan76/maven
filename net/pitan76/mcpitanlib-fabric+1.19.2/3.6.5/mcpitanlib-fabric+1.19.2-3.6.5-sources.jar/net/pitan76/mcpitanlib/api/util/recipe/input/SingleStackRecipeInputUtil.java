package net.pitan76.mcpitanlib.api.util.recipe.input;

import net.minecraft.class_1263;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.pitan76.mcpitanlib.api.recipe.input.CompatRecipeInput;
import net.pitan76.mcpitanlib.api.util.ItemStackUtil;

import java.util.Optional;

public class SingleStackRecipeInputUtil {
    public static Optional<class_1263> get(CompatRecipeInput<?> input) {
        if (input.getInput() instanceof class_1263) {
            return Optional.of( input.getInput());
        }
        return Optional.empty();
    }

    public static CompatRecipeInput<?> create(class_1263 input) {
        return new CompatRecipeInput<>(input);
    }

    public static CompatRecipeInput<?> create(class_1799 stack) {
        return new CompatRecipeInput<>(new class_1263() {

            private class_1799 itemStack = stack;

            @Override
            public void method_5448() {
                itemStack = ItemStackUtil.empty();
            }

            @Override
            public int method_5439() {
                return 1;
            }

            @Override
            public boolean method_5442() {
                return false;
            }

            @Override
            public class_1799 method_5438(int slot) {
                if (slot == 0)
                    return itemStack;
                return ItemStackUtil.empty();
            }

            @Override
            public class_1799 method_5434(int slot, int amount) {
                if (slot == 0) {
                    class_1799 stack = itemStack;
                    ItemStackUtil.decrementCount(stack, amount);
                    return stack;
                }
                return ItemStackUtil.empty();
            }

            @Override
            public class_1799 method_5441(int slot) {
                if (slot == 0) {
                    class_1799 stack = itemStack;
                    itemStack = ItemStackUtil.empty();
                    return stack;
                }
                return ItemStackUtil.empty();
            }

            @Override
            public void method_5447(int slot, class_1799 stack) {
                if (slot == 0)
                    itemStack = stack;
            }

            @Override
            public void method_5431() {

            }

            @Override
            public boolean method_5443(class_1657 player) {
                return false;
            }
        });
    }

    public static class_1799 getStack(CompatRecipeInput<?> input) {
        Optional<class_1263> recipeInput = get(input);
        if (!recipeInput.isPresent()) return ItemStackUtil.empty();

        return recipeInput.get().method_5438(0);
    }
}
