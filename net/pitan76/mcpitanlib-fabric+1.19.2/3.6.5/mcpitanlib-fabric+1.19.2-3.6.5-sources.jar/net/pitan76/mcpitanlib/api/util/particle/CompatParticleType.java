package net.pitan76.mcpitanlib.api.util.particle;

import net.minecraft.class_2378;
import net.minecraft.class_2396;
import net.minecraft.class_2960;
import net.pitan76.mcpitanlib.api.util.CompatIdentifier;

public class CompatParticleType {
    private final class_2396<?> particleType;

    public CompatParticleType(class_2396<?> particleType) {
        this.particleType = particleType;
    }

    public static CompatParticleType of(class_2396<?> particleType) {
        return new CompatParticleType(particleType);
    }

    public class_2396<?> getRaw() {
        return particleType;
    }

    public boolean shouldAlwaysSpawn() {
        return particleType.method_10299();
    }

    public class_2960 getId() {
        return class_2378.field_11141.method_10221(particleType);
    }

    public CompatIdentifier getCompatId() {
        return CompatIdentifier.fromMinecraft(getId());
    }

    @Override
    public int hashCode() {
        return particleType.hashCode();
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        CompatParticleType other = (CompatParticleType) obj;
        return particleType.equals(other.particleType);
    }
}
