package net.pitan76.mcpitanlib.api.util.client;

import com.mojang.authlib.GameProfile;
import net.minecraft.class_1041;
import net.minecraft.class_1060;
import net.minecraft.class_239;
import net.minecraft.class_310;
import net.minecraft.class_312;
import net.minecraft.class_327;
import net.minecraft.class_3300;
import net.minecraft.class_3695;
import net.minecraft.class_437;
import net.minecraft.class_638;
import net.minecraft.class_746;
import net.minecraft.class_757;
import net.minecraft.class_761;
import net.minecraft.class_918;
import net.pitan76.mcpitanlib.api.client.option.GameOptionsWrapper;
import net.pitan76.mcpitanlib.api.entity.Player;

import java.io.File;
import java.util.Optional;

public class ClientUtil {
    public static void setScreen(class_437 screen) {
        getClient().method_1507(screen);
    }

    public static class_437 getScreen() {
        return getClient().field_1755;
    }

    public static Player getPlayer() {
        return new Player(getClientPlayer());
    }

    public static class_746 getClientPlayer() {
        return getClient().field_1724;
    }

    public static class_310 getClient() {
        return class_310.method_1551();
    }

    public static class_327 getTextRenderer() {
        return getClient().field_1772;
    }

    public static class_918 getItemRenderer() {
        return getClient().method_1480();
    }

    public static class_3300 getResourceManager() {
        return getClient().method_1478();
    }

    public static class_1060 getTextureManager() {
        return getClient().method_1531();
    }

    public static class_638 getWorld() {
        return getClient().field_1687;
    }

    public static class_757 getGameRenderer() {
        return getClient().field_1773;
    }

    public static Optional<Long> getTime() {
        if (getClient().field_1687 == null) return Optional.empty();
        return Optional.of(getClient().field_1687.method_8510());
    }

    public static long getRenderTime() {
        return (long) getClient().method_1488();
    }

    public static class_239 getTarget() {
        return getClient().field_1765;
    }

    public static class_761 getWorldRenderer() {
        return getClient().field_1769;
    }

    public static File getRunDirectory() {
        return getClient().field_1697;
    }

    public static class_3695 getProfiler() {
        return getClient().method_16011();
    }

    public static GameProfile getGameProfile() {
        if (getClient().field_1724 == null) return null;
        return getClient().field_1724.method_7334();
    }

    public static class_1041 getWindow() {
        return getClient().method_22683();
    }

    public static class_312 getMouse() {
        return getClient().field_1729;
    }

    public static boolean isInSingleplayer() {
        return getClient().method_1542();
    }

    public static boolean isPaused() {
        return getClient().method_1493();
    }

    public static GameOptionsWrapper getOptions() {
        return new GameOptionsWrapper(getClient().field_1690);
    }
}
