package net.pitan76.mcpitanlib.api.item;

import net.minecraft.class_1304;
import net.minecraft.class_1741;
import net.minecraft.class_1856;
import net.minecraft.class_2960;
import net.minecraft.class_3414;

public interface CompatibleArmorMaterial {
    int getDurability(ArmorEquipmentType type);

    int getProtection(ArmorEquipmentType type);

    int getEnchantability();

    class_3414 getEquipSound();

    class_1856 getRepairIngredient();

    /**
     * @return the name of the material
     */
    default String getName() {
        return getId().method_12832();
    }

    /**
     * @return the id of the material
     */
    class_2960 getId();

    float getToughness();

    float getKnockbackResistance();

    @Deprecated
    default class_1741 build() {
        return new class_1741() {
            @Override
            public int method_7696(class_1304 slot) {
                return CompatibleArmorMaterial.this.getDurability(ArmorEquipmentType.of(slot));
            }

            @Override
            public int method_7697(class_1304 slot) {
                return CompatibleArmorMaterial.this.getProtection(ArmorEquipmentType.of(slot));
            }

            @Override
            public int method_7699() {
                return CompatibleArmorMaterial.this.getEnchantability();
            }

            @Override
            public class_3414 method_7698() {
                return CompatibleArmorMaterial.this.getEquipSound();
            }

            @Override
            public class_1856 method_7695() {
                return CompatibleArmorMaterial.this.getRepairIngredient();
            }

            @Override
            public String method_7694() {
                return CompatibleArmorMaterial.this.getName();
            }

            @Override
            public float method_7700() {
                return CompatibleArmorMaterial.this.getToughness();
            }

            @Override
            public float method_24355() {
                return CompatibleArmorMaterial.this.getKnockbackResistance();
            }
        };
    }
}
