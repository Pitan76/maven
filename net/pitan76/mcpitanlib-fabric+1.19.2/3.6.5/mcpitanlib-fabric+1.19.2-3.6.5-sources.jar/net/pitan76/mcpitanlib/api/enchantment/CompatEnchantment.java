package net.pitan76.mcpitanlib.api.enchantment;

import net.minecraft.class_1799;
import net.minecraft.class_1887;
import net.minecraft.class_1890;
import net.minecraft.class_1937;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.pitan76.mcpitanlib.api.util.EnchantmentUtil;
import org.jetbrains.annotations.Nullable;

public class CompatEnchantment {
    private final class_1887 enchantment;

    @Deprecated
    public CompatEnchantment(class_1887 enchantment) {
        this.enchantment = enchantment;
    }

    public CompatEnchantment of(class_2960 identifier) {
        return EnchantmentUtil.getEnchantment(identifier);
    }

    public class_2960 getId() {
        return class_2378.field_11160.method_10221(enchantment);
    }

    public String toString() {
        return getId().toString();
    }

    public boolean equals(Object obj) {
        if (obj instanceof CompatEnchantment) {
            return ((CompatEnchantment) obj).getId().equals(getId());
        }
        return false;
    }

    public class_1887 getEnchantment(@Nullable class_1937 world) {
        return enchantment;
    }

    public int getLevel(class_1799 stack, @Nullable class_1937 world) {
        return class_1890.method_8225(enchantment, stack);
    }
}
