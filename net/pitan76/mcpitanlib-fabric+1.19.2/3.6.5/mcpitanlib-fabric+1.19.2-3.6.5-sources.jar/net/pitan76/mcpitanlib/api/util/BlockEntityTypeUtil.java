package net.pitan76.mcpitanlib.api.util;

import net.minecraft.class_2378;
import net.minecraft.class_2591;
import net.minecraft.class_2960;

public class BlockEntityTypeUtil {
    public static class_2960 toID(class_2591<?> entityType) {
        return class_2378.field_11137.method_10221(entityType);
    }

    public static class_2591<?> fromId(class_2960 identifier) {
        return class_2378.field_11137.method_10223(identifier);
    }

    public static boolean isExist(class_2960 identifier) {
        return class_2378.field_11137.method_10250(identifier);
    }

    public static CompatIdentifier toCompatID(class_2591<?> entityType) {
        return CompatIdentifier.fromMinecraft(toID(entityType));
    }

    public static class_2591<?> fromId(CompatIdentifier identifier) {
        return fromId(identifier.toMinecraft());
    }

    public static boolean isExist(CompatIdentifier identifier) {
        return isExist(identifier.toMinecraft());
    }

    public static int getRawId(class_2591<?> type) {
        return class_2378.field_11137.method_10206(type);
    }

    public static class_2591<?> fromIndex(int index) {
        return class_2378.field_11137.method_10200(index);
    }
}
