package net.pitan76.mcpitanlib.api.util.client.render;

import net.minecraft.class_1159;
import net.minecraft.class_4581;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4608;
import net.pitan76.mcpitanlib.api.client.render.DrawObjectMV;

public class VertexConsumerUtil {
    public static class_4588 vertex(class_4588 vertexConsumer, float x, float y, float z) {
        return vertexConsumer.method_22912(x, y, z);
    }

    public static class_4588 vertex(class_4588 vertexConsumer, class_4587 stack, float x, float y, float z) {
        return vertexConsumer.method_22918(stack.method_23760().method_23761(), x, y, z);
    }

    public static class_4588 normal(class_4588 vertexConsumer, float x, float y, float z) {
        return vertexConsumer.method_22914(x, y, z);
    }

    public static class_4588 color(class_4588 vertexConsumer, float red, float green, float blue, float alpha) {
        return vertexConsumer.method_22915(red, green, blue, alpha);
    }

    public static class_4588 color(class_4588 vertexConsumer, int red, int green, int blue, int alpha) {
        return vertexConsumer.method_1336(red, green, blue, alpha);
    }

    public static class_4588 colorARGB(class_4588 vertexConsumer, int argb) {
        return vertexConsumer.method_39415(argb);
    }

    public static class_4588 colorRGB(class_4588 vertexConsumer, int rgb) {
        int argb = (rgb & 0xFF0000) | ((rgb & 0x00FF00) >> 8) | ((rgb & 0x0000FF) << 8) | (rgb & 0xFF000000);
        return colorARGB(vertexConsumer, argb);
    }

    public static class_4588 light(class_4588 vertexConsumer, int light) {
        return vertexConsumer.method_22916(light);
    }

    public static class_4588 overlay(class_4588 vertexConsumer, int overlay) {
        return vertexConsumer.method_22922(overlay);
    }

    public static class_4588 overlayDefaultUV(class_4588 vertexConsumer) {
        return vertexConsumer.method_22922(class_4608.field_21444);
    }

    public static DrawObjectMV vertex(DrawObjectMV drawObject, float x, float y, float z) {
        vertex(drawObject.getBuffer(), drawObject.getStack(), x, y, z);
        return drawObject;
    }

    public static DrawObjectMV normal(DrawObjectMV drawObject, float x, float y, float z) {
        normal(drawObject.getBuffer(), x, y, z);
        return drawObject;
    }

    public static DrawObjectMV color(DrawObjectMV drawObject, float red, float green, float blue, float alpha) {
        color(drawObject.getBuffer(), red, green, blue, alpha);
        return drawObject;
    }

    public static DrawObjectMV color(DrawObjectMV drawObject, int red, int green, int blue, int alpha) {
        color(drawObject.getBuffer(), red, green, blue, alpha);
        return drawObject;
    }

    public static DrawObjectMV colorARGB(DrawObjectMV drawObject, int argb) {
        colorARGB(drawObject.getBuffer(), argb);
        return drawObject;
    }

    public static DrawObjectMV colorRGB(DrawObjectMV drawObject, int rgb) {
        colorRGB(drawObject.getBuffer(), rgb);
        return drawObject;
    }

    public static DrawObjectMV light(DrawObjectMV drawObject, int light) {
        light(drawObject.getBuffer(), light);
        return drawObject;
    }

    public static DrawObjectMV overlay(DrawObjectMV drawObject, int overlay) {
        overlay(drawObject.getBuffer(), overlay);
        return drawObject;
    }

    public static DrawObjectMV overlayDefaultUV(DrawObjectMV drawObject) {
        overlayDefaultUV(drawObject.getBuffer());
        return drawObject;
    }

    public static class_4588 texture(class_4588 vertexConsumer, float u, float v) {
        return vertexConsumer.method_22913(u, v);
    }

    public static class_4588 vertex(class_4588 vertexConsumer, class_1159 matrix4f, float x, float y, float z) {
        return vertexConsumer.method_22918(matrix4f, x, y, z);
    }

    public static class_4588 normal(class_4588 vertexConsumer, class_4587 stack, float x, float y, float z) {
        return vertexConsumer.method_23763(stack.method_23760().method_23762(), x, y, z);
    }

    public static class_4588 next(class_4588 vertexConsumer) {
        vertexConsumer.method_1344();
        return vertexConsumer;
    }

    public static void renderQuad(class_4588 vertexConsumer, class_4587 stack, class_1159 matrix4f, class_4581 matrix3f,
                            float x1, float y1, float z1, float x2, float y2, float z2,
                            float normalX, float normalY, float normalZ, int r, int g, int b, int alpha, int u, int v, int overlay, int light) {

        float[][] vertexes = new float[4][3];

        if (Math.abs(normalY) > 0.5f) {
            if (normalY > 0) {
                vertexes = new float[][]{
                        {x1, y1, z1},
                        {x1, y1, z2},
                        {x2, y1, z2},
                        {x2, y1, z1}
                };

            } else {
                vertexes = new float[][]{
                        {x1, y1, z1},
                        {x2, y1, z1},
                        {x2, y1, z2},
                        {x1, y1, z2}
                };
            }
        } else if (Math.abs(normalZ) > 0.5f) {
            if (normalZ > 0) {
                vertexes = new float[][]{
                        {x1, y1, z1},
                        {x2, y1, z1},
                        {x2, y2, z1},
                        {x1, y2, z1}
                };
            } else {
                vertexes = new float[][]{
                        {x1, y1, z1},
                        {x1, y2, z1},
                        {x2, y2, z1},
                        {x2, y1, z1}
                };
            }
        } else if (Math.abs(normalX) > 0.5f) {
            if (normalX > 0) {
                vertexes = new float[][]{
                        {x1, y1, z1},
                        {x1, y2, z1},
                        {x1, y2, z2},
                        {x1, y1, z2}
                };
            } else {
                vertexes = new float[][]{
                        {x1, y1, z1},
                        {x1, y1, z2},
                        {x1, y2, z2},
                        {x1, y2, z1}
                };
            }
        }

        for (float[] vertex : vertexes) {
            if (vertex.length != 3) continue;

            vertex(vertexConsumer, matrix4f, vertex[0], vertex[1], vertex[2]);
            color(vertexConsumer, r, g, b, alpha);
            texture(vertexConsumer, u, v);
            light(vertexConsumer, light);
            normal(vertexConsumer, stack, normalX, normalY, normalZ);
            next(vertexConsumer);
        }
    }

    public static void renderQuad(DrawObjectMV drawObject, class_1159 matrix4f, class_4581 matrix3f,
                            float x1, float y1, float z1, float x2, float y2, float z2,
                            float normalX, float normalY, float normalZ, int r, int g, int b, int alpha, int u, int v, int overlay, int light) {
        renderQuad(drawObject.getBuffer(), drawObject.getStack(), matrix4f, matrix3f,
                x1, y1, z1, x2, y2, z2,
                normalX, normalY, normalZ, r, g, b, alpha, u, v, overlay, light);

    }

    public static void renderQuad(DrawObjectMV drawObject,
                            float x1, float y1, float z1, float x2, float y2, float z2,
                            float normalX, float normalY, float normalZ, int r, int g, int b, int alpha, int u, int v, int overlay, int light) {

        class_1159 matrix4f = drawObject.getMatrix4f();
        class_4581 matrix3f = drawObject.getMatrix3f();

        renderQuad(drawObject.getBuffer(), drawObject.getStack(), matrix4f, matrix3f,
                x1, y1, z1, x2, y2, z2,
                normalX, normalY, normalZ, r, g, b, alpha, u, v, overlay, light);

    }
}

