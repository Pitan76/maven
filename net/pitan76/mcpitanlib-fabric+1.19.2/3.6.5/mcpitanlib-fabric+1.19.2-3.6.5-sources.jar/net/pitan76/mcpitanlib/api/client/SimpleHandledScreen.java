package net.pitan76.mcpitanlib.api.client;

import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_364;
import net.minecraft.class_4068;
import net.minecraft.class_4587;
import net.minecraft.class_465;
import net.minecraft.class_6379;
import net.minecraft.class_757;
import net.minecraft.class_918;
import net.minecraft.client.render.*;
import net.pitan76.mcpitanlib.api.client.gui.widget.CompatibleTexturedButtonWidget;
import net.pitan76.mcpitanlib.api.client.render.DrawObjectDM;
import net.pitan76.mcpitanlib.api.client.render.handledscreen.*;
import net.pitan76.mcpitanlib.api.client.render.screen.RenderBackgroundTextureArgs;
import net.pitan76.mcpitanlib.api.util.client.ScreenUtil;
import net.pitan76.mcpitanlib.api.util.CompatIdentifier;
import net.pitan76.mcpitanlib.api.util.IdentifierUtil;
import net.pitan76.mcpitanlib.api.util.client.ClientUtil;
import net.pitan76.mcpitanlib.api.util.client.RenderUtil;
import net.pitan76.mcpitanlib.core.datafixer.Pair;

@Deprecated
public abstract class SimpleHandledScreen extends class_465<class_1703> {

    public int field_22789, field_22790, field_2792, field_2779, field_2776, field_2800;
    public class_1703 field_2797;
    public class_327 field_22793;
    public class_918 field_22788;

    public class_2561 field_22785;
    public class_310 field_22787;

    public SimpleHandledScreen(class_1703 handler, class_1661 inventory, class_2561 title) {
        super(handler, inventory, title);
        fixScreen();
        this.field_2797 = handler;
        this.field_22785 = title;

    }

    public <T extends class_364 & class_4068 & class_6379> T addDrawableChild_compatibility(T drawableElement) {
        return super.method_37063(drawableElement);
        // addButton
    }

    public <T extends class_364 & class_6379> T addSelectableChild_compatibility(T selectableElement) {
        return super.method_25429(selectableElement);
    }

    public CompatibleTexturedButtonWidget addDrawableCTBW(CompatibleTexturedButtonWidget widget) {
        return addDrawableChild_compatibility(widget);
    }

    @Deprecated
    @Override
    protected void method_2389(class_4587 stack, float delta, int mouseX, int mouseY) {
        DrawObjectDM drawObjectDM = new DrawObjectDM(stack, this);
        drawBackgroundOverride(new DrawBackgroundArgs(drawObjectDM, delta, mouseX, mouseY));
    }

    public abstract void drawBackgroundOverride(DrawBackgroundArgs args);

    @Deprecated
    @Override
    protected void method_2388(class_4587 stack, int mouseX, int mouseY) {
        DrawObjectDM drawObjectDM = new DrawObjectDM(stack, this);
        drawForegroundOverride(new DrawForegroundArgs(drawObjectDM, mouseX, mouseY));
    }

    protected void drawForegroundOverride(DrawForegroundArgs args) {
        super.method_2388(args.drawObjectDM.getStack(), args.mouseX, args.mouseY);
    }

    public void callDrawTexture(DrawObjectDM drawObjectDM, class_2960 texture, int x, int y, int u, int v, int width, int height) {
        ScreenUtil.setBackground(texture);
        method_25302(drawObjectDM.getStack(), x, y, u, v, width, height);
    }

    public void callDrawTexture(DrawObjectDM drawObjectDM, CompatIdentifier texture, int x, int y, int u, int v, int width, int height) {
        callDrawTexture(drawObjectDM, texture.toMinecraft(), x, y, u, v, width, height);
    }

    @Deprecated
    public void callRenderBackground(DrawObjectDM drawObjectDM) {
        super.method_25420(drawObjectDM.getStack());
        callRenderBackground(new RenderArgs(drawObjectDM, 0, 0, 0));
    }


    public void callRenderBackground(RenderArgs args) {
        super.method_25420(args.drawObjectDM.getStack());
    }

    public void callDrawMouseoverTooltip(DrawMouseoverTooltipArgs args) {
        super.method_2380(args.drawObjectDM.getStack(), args.mouseX, args.mouseY);
    }

    public void renderOverride(RenderArgs args) {
        super.method_25394(args.drawObjectDM.getStack(), args.mouseX, args.mouseY, args.delta);
    }

    public void resizeOverride(class_310 client, int width, int height) {
    }

    public void initOverride() {
    }

    @Deprecated
    @Override
    protected void method_25426() {
        super.method_25426();
        fixScreen();
        initOverride();
    }

    @Deprecated
    @Override
    public void method_25410(class_310 client, int width, int height) {
        super.method_25410(client, width, height);
        fixScreen();
        resizeOverride(client, width, height);
    }

    public void fixScreen() {
        this.field_2792 = getBackgroundWidth();
        this.field_2779 = getBackgroundHeight();
        this.field_2776 = super.field_2776; //(this.width - this.backgroundWidth) / 2;
        this.field_2800 = super.field_2800; //(this.height - this.backgroundHeight) / 2;
        this.field_22793 = super.field_22793;
        this.field_22788 = super.field_22788;
        this.field_22789 = super.field_22789;
        this.field_22790 = super.field_22790;
        if (super.field_22787 == null)
            this.field_22787 = class_310.method_1551();
        else
            this.field_22787 = super.field_22787;
    }

    public void setX(int x) {
        this.field_2776 = x;
        super.field_2776 = x;
    }

    public void setY(int y) {
        this.field_2800 = y;
        super.field_2800 = y;
    }

    public void setTextRenderer(class_327 textRenderer) {
        this.field_22793 = textRenderer;
        super.field_22793 = textRenderer;
    }

    public void setItemRenderer(class_918 itemRenderer) {
        this.field_22788 = itemRenderer;
        super.field_22788 = itemRenderer;
    }

    public void setWidth(int width) {
        this.field_22789 = width;
        super.field_22789 = width;
    }

    public void setBackgroundWidth(int backgroundWidth) {
        this.field_2792 = backgroundWidth;
        super.field_2792 = backgroundWidth;
    }

    public void setBackgroundHeight(int backgroundHeight) {
        this.field_2779 = backgroundHeight;
        super.field_2779 = backgroundHeight;
    }

    public void setHeight(int height) {
        this.field_22790 = height;
        super.field_22790 = height;
    }

    public int getBackgroundWidth() {
        return super.field_2792;
    }

    public int getBackgroundHeight() {
        return super.field_2779;
    }

    @Deprecated
    @Override
    public void method_25394(class_4587 stack, int mouseX, int mouseY, float delta) {
        DrawObjectDM drawObjectDM = new DrawObjectDM(stack, this);
        renderOverride(new RenderArgs(drawObjectDM, mouseX, mouseY, delta));
    }

    public boolean keyReleased(KeyEventArgs args) {
        return super.method_16803(args.keyCode, args.scanCode, args.modifiers);
    }

    public boolean keyPressed(KeyEventArgs args) {
        return super.method_25404(args.keyCode, args.scanCode, args.modifiers);
    }

    public void renderBackgroundTexture(RenderBackgroundTextureArgs args) {
        if (getBackgroundTexture() == null) {
            super.method_25434(args.getvOffset());
            return;
        }

        RenderSystem.setShader(class_757::method_34543);
        RenderSystem.setShaderTexture(0, getBackgroundTexture());
        RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);

        callDrawTexture(args.drawObjectDM, getBackgroundTexture(), 0, 0, 0, 0, this.field_22789, this.field_22790);
    }

    @Deprecated
    @Override
    public boolean method_16803(int keyCode, int scanCode, int modifiers) {
        return this.keyReleased(new KeyEventArgs(keyCode, scanCode, modifiers));
    }

    @Deprecated
    @Override
    public boolean method_25404(int keyCode, int scanCode, int modifiers) {
        return this.keyPressed(new KeyEventArgs(keyCode, scanCode, modifiers));
    }

    @Deprecated
    @Override
    public void method_25434(int vOffset) {
        this.renderBackgroundTexture(new RenderBackgroundTextureArgs(new DrawObjectDM(null, this), vOffset));
    }

    public void closeOverride() {
        super.method_25419();
    }

    public void removedOverride() {
        super.method_25432();
    }

    @Override
    public void method_25419() {
        closeOverride();
    }

    @Override
    public void method_25432() {
        removedOverride();
    }

    public class_2960 getBackgroundTexture() {
        return IdentifierUtil.from(getCompatBackgroundTexture());
    }

    public CompatIdentifier getCompatBackgroundTexture() {
        return null;
    }

    public void setTitleX(int x) {
        this.field_25267 = x;
    }

    public void setTitleY(int y) {
        this.field_25268 = y;
    }

    public void setTitlePos(int x, int y) {
        setTitleX(x);
        setTitleY(y);
    }

    public void setTitleXCenter() {
        if (field_22793 == null)
            field_22793 = ClientUtil.getTextRenderer();

        setTitleX(field_2792 / 2 - field_22793.method_27525(field_22785) / 2);
    }

    public int getTitleX() {
        return field_25267;
    }

    public int getTitleY() {
        return field_25268;
    }

    @Deprecated
    @Override
    public class_2561 method_25440() {
        return callGetTitle();
    }

    public class_2561 callGetTitle() {
        return super.method_25440();
    }

    public Pair<Integer, Integer> getTitlePosP() {
        return new Pair<>(getTitleX(), getTitleY());
    }

    public int getPlayerInvTitleX() {
        return field_25269;
    }

    public int getPlayerInvTitleY() {
        return field_25270;
    }

    public void setPlayerInvTitleX(int x) {
        field_25269 = x;
    }

    public void setPlayerInvTitleY(int y) {
        field_25270 = y;
    }

    public void setPlayerInvTitle(int x, int y) {
        setPlayerInvTitleX(x);
        setPlayerInvTitleY(y);
    }
}
