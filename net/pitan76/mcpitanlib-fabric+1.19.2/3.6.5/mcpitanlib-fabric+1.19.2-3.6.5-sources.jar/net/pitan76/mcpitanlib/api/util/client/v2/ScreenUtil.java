package net.pitan76.mcpitanlib.api.util.client.v2;

import net.minecraft.class_364;
import net.minecraft.class_437;

public class ScreenUtil extends net.pitan76.mcpitanlib.api.util.client.ScreenUtil {

    public static void setFocus(class_437 screen, boolean focus) {
    }

    public static void setFocus(class_437 screen, class_364 element) {
        screen.method_25395(element);
    }

    public static boolean isFocused(class_437 screen) {
        return false;
    }

    public static void setDragging(class_437 screen, boolean dragging) {
        screen.method_25398(dragging);
    }

    public static boolean isDragging(class_437 screen) {
        return screen.method_25397();
    }

    public static int getWidth(class_437 screen) {
        return screen.field_22789;
    }

    public static int getHeight(class_437 screen) {
        return screen.field_22790;
    }
}
