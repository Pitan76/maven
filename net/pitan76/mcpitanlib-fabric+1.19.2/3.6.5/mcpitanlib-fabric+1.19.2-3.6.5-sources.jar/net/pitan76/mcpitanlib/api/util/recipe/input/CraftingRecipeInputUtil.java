package net.pitan76.mcpitanlib.api.util.recipe.input;

import net.minecraft.class_1662;
import net.minecraft.class_1715;
import net.minecraft.class_1799;
import net.pitan76.mcpitanlib.api.recipe.input.CompatRecipeInput;
import net.pitan76.mcpitanlib.api.util.ItemStackUtil;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class CraftingRecipeInputUtil {
    public static Optional<class_1715> get(CompatRecipeInput<?> input) {
        if (input.getInput() instanceof class_1715) {
            return Optional.of((class_1715) input.getInput());
        }
        return Optional.empty();
    }

    public static CompatRecipeInput<?> create(class_1715 input) {
        return new CompatRecipeInput<>(input);
    }

    public static CompatRecipeInput<?> create(int width, int height, List<class_1799> stacks) {

        class_1715 inventory = new class_1715(null, width, height);

        int size = stacks.size();
        for (int i = 0; i < size; i++) {
            inventory.method_5447(i, stacks.get(i));
        }

        return new CompatRecipeInput<>(inventory);
    }

    public static class_1799 getStack(class_1715 input, int x, int y) {
        return input.method_5438(x + y * input.method_17398());
    }

    public static class_1799 getStack(CompatRecipeInput<?> input, int x, int y) {
        Optional<class_1715> recipeInput = get(input);
        if (!recipeInput.isPresent()) return ItemStackUtil.empty();

        return getStack(recipeInput.get(), x, y);
    }

    public static net.pitan76.mcpitanlib.midohra.item.ItemStack getMidohraStack(CompatRecipeInput<?> input, int x, int y) {
        return net.pitan76.mcpitanlib.midohra.item.ItemStack.of(getStack(input, x, y));
    }

    public static class_1662 getRecipeMatcher(class_1715 input) {
        return null;
    }

    public static class_1662 getRecipeMatcher(CompatRecipeInput<?> input) {
        Optional<class_1715> recipeInput = get(input);
        if (!recipeInput.isPresent()) return null;

        return getRecipeMatcher(recipeInput.get());
    }

    public static List<class_1799> getStacks(class_1715 input) {
        List<class_1799> stacks = new ArrayList<>();
        int size = input.method_5439();
        for (int i = 0; i < size; i++) {
            stacks.add(input.method_5438(i));
        }
        return stacks;
    }

    public static List<class_1799> getStacks(CompatRecipeInput<?> input) {
        Optional<class_1715> recipeInput = get(input);
        if (!recipeInput.isPresent()) return null;

        return getStacks(recipeInput.get());
    }

    public static int getWidth(class_1715 input) {
        return input.method_17398();
    }

    public static int getWidth(CompatRecipeInput<?> input) {
        Optional<class_1715> recipeInput = get(input);
        if (!recipeInput.isPresent()) return -1;

        return getWidth(recipeInput.get());
    }

    public static int getHeight(class_1715 input) {
        return input.method_17397();
    }

    public static int getHeight(CompatRecipeInput<?> input) {
        Optional<class_1715> recipeInput = get(input);
        if (!recipeInput.isPresent()) return -1;

        return getHeight(recipeInput.get());
    }

    public static int getStackCount(class_1715 input) {
        return input.method_5439();
    }

    public static int getStackCount(CompatRecipeInput<?> input) {
        Optional<class_1715> recipeInput = get(input);
        if (!recipeInput.isPresent()) return -1;

        return getStackCount(recipeInput.get());
    }
}
