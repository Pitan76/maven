package net.pitan76.mcpitanlib.api.util.entity;

import net.minecraft.class_1297;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.pitan76.mcpitanlib.api.entity.Player;
import net.pitan76.mcpitanlib.api.sound.CompatSoundCategory;
import net.pitan76.mcpitanlib.api.sound.CompatSoundEvent;

import java.util.Optional;

public class ServerPlayerUtil {
    public static boolean teleport(class_3222 serverPlayerEntity, class_3218 serverWorld, double x, double y, double z, float yaw, float pitch, boolean resetCamera) {
        if (!resetCamera) {
            class_1297 cameraEntity = serverPlayerEntity.method_14242();
            teleport(serverPlayerEntity, serverWorld, x, y, z, yaw, pitch);
            serverPlayerEntity.method_14224(cameraEntity);
        }

        teleport(serverPlayerEntity, serverWorld, x, y, z, yaw, pitch);
        return true;
    }

    public static boolean teleport(class_3222 serverPlayerEntity, class_3218 serverWorld, double x, double y, double z, float yaw, float pitch) {
        serverPlayerEntity.method_14251(serverWorld, x, y, z, yaw, pitch);
        return true;
    }

    public static boolean teleport(class_3222 serverPlayerEntity, class_3218 serverWorld, double x, double y, double z) {
        return teleport(serverPlayerEntity, serverWorld, x, y, z, serverPlayerEntity.method_36454(), serverPlayerEntity.method_36455());
    }
    public static boolean teleport(class_3222 serverPlayerEntity, net.pitan76.mcpitanlib.midohra.world.ServerWorld serverWorld, double x, double y, double z, float yaw, float pitch, boolean resetCamera) {
        return teleport(serverPlayerEntity, serverWorld.getRaw(), x, y, z, yaw, pitch, resetCamera);
    }

    public static boolean teleport(class_3222 serverPlayerEntity, net.pitan76.mcpitanlib.midohra.world.ServerWorld serverWorld, double x, double y, double z, float yaw, float pitch) {
        return teleport(serverPlayerEntity, serverWorld, x, y, z, yaw, pitch, false);
    }

    public static boolean teleport(class_3222 serverPlayerEntity, net.pitan76.mcpitanlib.midohra.world.ServerWorld serverWorld, double x, double y, double z) {
        return teleport(serverPlayerEntity, serverWorld, x, y, z, serverPlayerEntity.method_36454(), serverPlayerEntity.method_36455());
    }

    public static boolean teleport(Player player, net.pitan76.mcpitanlib.midohra.world.ServerWorld serverWorld, double x, double y, double z, float yaw, float pitch, boolean resetCamera) {
        Optional<class_3222> optionalServerPlayer = player.getServerPlayer();
        if (!optionalServerPlayer.isPresent()) return false;

        return teleport(optionalServerPlayer.get(), serverWorld, x, y, z, yaw, pitch, resetCamera);
    }

    public static boolean teleport(Player player, net.pitan76.mcpitanlib.midohra.world.ServerWorld serverWorld, double x, double y, double z, float yaw, float pitch) {
        return teleport(player, serverWorld, x, y, z, yaw, pitch, false);
    }

    public static boolean teleport(Player player, net.pitan76.mcpitanlib.midohra.world.ServerWorld serverWorld, double x, double y, double z) {
        return teleport(player, serverWorld, x, y, z, player.getYaw(), player.getPitch());
    }

    public static boolean teleport(class_3222 serverPlayerEntity, double x, double y, double z, boolean particleEffects) {
        return serverPlayerEntity.method_6082(x, y, z, particleEffects);
    }

    public static boolean teleport(class_3222 serverPlayerEntity, double x, double y, double z) {
        return teleport(serverPlayerEntity, x, y, z, false);
    }

    public static boolean teleport(Player player, double x, double y, double z, boolean particleEffects) {
        Optional<class_3222> optionalServerPlayer = player.getServerPlayer();
        if (!optionalServerPlayer.isPresent()) return false;

        return teleport(optionalServerPlayer.get(), x, y, z, particleEffects);
    }

    public static boolean teleport(Player player, double x, double y, double z) {
        return teleport(player, x, y, z, false);
    }

    public static void playSound(class_3222 serverPlayerEntity, CompatSoundEvent soundEvent, CompatSoundCategory category, float volume, float pitch) {
        serverPlayerEntity.method_17356(soundEvent.get(), category.get(), volume, pitch);
    }

    public static void playSound(class_3222 serverPlayerEntity, CompatSoundEvent soundEvent, float volume, float pitch) {
        serverPlayerEntity.method_5783(soundEvent.get(), volume, pitch);
    }

    public static void playSound(class_3222 serverPlayerEntity, CompatSoundEvent soundEvent) {
        serverPlayerEntity.method_5783(soundEvent.get(), 1.0F, 1.0F);
    }

    public static void playSound(Player player, CompatSoundEvent soundEvent, CompatSoundCategory category, float volume, float pitch) {
        Optional<class_3222> optionalServerPlayer = player.getServerPlayer();
        if (!optionalServerPlayer.isPresent()) return;

        playSound(optionalServerPlayer.get(), soundEvent, category, volume, pitch);
    }

    public static void playSound(Player player, CompatSoundEvent soundEvent, float volume, float pitch) {
        Optional<class_3222> optionalServerPlayer = player.getServerPlayer();
        if (!optionalServerPlayer.isPresent()) return;

        playSound(optionalServerPlayer.get(), soundEvent, volume, pitch);
    }

    public static void playSound(Player player, CompatSoundEvent soundEvent) {
        Optional<class_3222> optionalServerPlayer = player.getServerPlayer();
        if (!optionalServerPlayer.isPresent()) return;

        playSound(optionalServerPlayer.get(), soundEvent);
    }
}
