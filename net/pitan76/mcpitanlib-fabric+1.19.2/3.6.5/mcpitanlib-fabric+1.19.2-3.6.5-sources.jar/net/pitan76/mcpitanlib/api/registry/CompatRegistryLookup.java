package net.pitan76.mcpitanlib.api.registry;

import net.minecraft.class_2487;
import net.pitan76.mcpitanlib.api.event.nbt.NbtRWArgs;
import net.pitan76.mcpitanlib.api.event.nbt.ReadNbtArgs;
import net.pitan76.mcpitanlib.api.event.nbt.WriteNbtArgs;

public class CompatRegistryLookup {

    public CompatRegistryLookup() {

    }

    public NbtRWArgs getNbtRWArgs(class_2487 nbt) {
        return new NbtRWArgs(nbt);
    }

    public WriteNbtArgs createWriteNbtArgs(class_2487 nbt) {
        return new WriteNbtArgs(nbt);
    }

    public ReadNbtArgs createReadNbtArgs(class_2487 nbt) {
        return new ReadNbtArgs(nbt);
    }
}
