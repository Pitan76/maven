package net.pitan76.mcpitanlib.api.block.v2;

import com.mojang.serialization.Codec;
import net.minecraft.class_1767;
import net.minecraft.class_2248;
import net.minecraft.class_2498;
import net.minecraft.class_2680;
import net.minecraft.class_3620;
import net.minecraft.class_4970;
import net.pitan76.mcpitanlib.api.block.CompatibleMaterial;
import net.pitan76.mcpitanlib.api.sound.CompatBlockSoundGroup;
import net.pitan76.mcpitanlib.api.util.CompatIdentifier;
import net.pitan76.mcpitanlib.api.util.color.CompatDyeColor;
import net.pitan76.mcpitanlib.api.util.color.CompatMapColor;

import java.util.function.Function;
import java.util.function.ToIntFunction;

@SuppressWarnings("deprecation")
public class CompatibleBlockSettings extends net.pitan76.mcpitanlib.api.block.CompatibleBlockSettings {
    protected CompatIdentifier identifier = null;
    public boolean changedTranslationKey = false;

    public static final Codec<CompatibleBlockSettings> CODEC = Codec.unit(CompatibleBlockSettings::new);

    @Deprecated
    protected CompatibleBlockSettings() {
        super();
    }

    public CompatibleBlockSettings(CompatIdentifier identifier) {
        super();
        setId(identifier);
    }

    public static CompatibleBlockSettings of(CompatIdentifier id) {
        return new CompatibleBlockSettings(id);
    }

    @Deprecated
    public CompatibleBlockSettings setId(CompatIdentifier identifier) {
        this.identifier = identifier;
        return this;
    }

    private static CompatibleBlockSettings copy(CompatibleMaterial material, CompatibleBlockSettings settings) {
        settings.mapColor(material.getColor());
        return settings;
    }

    public CompatibleBlockSettings(CompatIdentifier id, CompatibleMaterial material, class_3620 mapColor) {
        this(id);
        copy(material, this);
        mapColor(mapColor);
    }

    public CompatibleBlockSettings(CompatIdentifier id, CompatibleMaterial material, class_1767 dyeColor) {
        this(id);
        copy(material, this);
        mapColor(dyeColor);
    }

    public CompatibleBlockSettings(CompatIdentifier id, CompatibleMaterial material) {
        this(id);
        copy(material, this);
    }

    public CompatibleBlockSettings(CompatIdentifier id, CompatibleMaterial material, Function<class_2680, class_3620> mapColor) {
        this(id);
        copy(material, this);
        mapColor(mapColor);
    }

    public static CompatibleBlockSettings of(CompatIdentifier id, CompatibleMaterial material, class_3620 mapColor) {
        return new CompatibleBlockSettings(id, material, mapColor);
    }

    public static CompatibleBlockSettings of(CompatIdentifier id, CompatibleMaterial material, class_1767 dyeColor) {
        return new CompatibleBlockSettings(id, material, dyeColor);
    }

    public static CompatibleBlockSettings of(CompatIdentifier id, CompatibleMaterial material) {
        return new CompatibleBlockSettings(id, material);
    }

    public static CompatibleBlockSettings of(CompatIdentifier id, CompatibleMaterial material, Function<class_2680, class_3620> mapColor) {
        return new CompatibleBlockSettings(id, material, mapColor);
    }

    public CompatibleBlockSettings(CompatIdentifier id, class_4970 block) {
        super(block);
        setId(id);
    }

    public static CompatibleBlockSettings copy(CompatIdentifier id, class_4970 block) {
        return new CompatibleBlockSettings(id, block);
    }

    public CompatibleBlockSettings air() {
        super.air();
        return this;
    }

    public CompatibleBlockSettings blockVision(class_4970.class_4973 predicate) {
        super.blockVision(predicate);
        return this;
    }

    public CompatibleBlockSettings postProcess(class_4970.class_4973 predicate) {
        super.postProcess(predicate);
        return this;
    }

    public CompatibleBlockSettings solidBlock(class_4970.class_4973 predicate) {
        super.solidBlock(predicate);
        return this;
    }

    public CompatibleBlockSettings suffocates(class_4970.class_4973 predicate) {
        super.suffocates(predicate);
        return this;
    }

    public CompatibleBlockSettings mapColor(class_3620 color) {
        super.mapColor(color);
        return this;
    }

    public CompatibleBlockSettings mapColor(class_1767 color) {
        super.mapColor(color);
        return this;
    }

    public CompatibleBlockSettings mapColor(CompatMapColor color) {
        super.mapColor(color.getColor());
        return this;
    }

    public CompatibleBlockSettings mapColor(CompatDyeColor color) {
        super.mapColor(color.getColor());
        return this;
    }

    public CompatibleBlockSettings mapColor(Function<class_2680, class_3620> color) {
        super.mapColor(color);
        return this;
    }

    public CompatibleBlockSettings compatMapColor(Function<net.pitan76.mcpitanlib.midohra.block.BlockState, CompatMapColor> color) {
        super.mapColor(state -> color.apply(net.pitan76.mcpitanlib.midohra.block.BlockState.of(state)).getColor());
        return this;
    }

    @Deprecated
    public CompatibleBlockSettings dropsLike(class_2248 source) {
        super.dropsLike(source);
        return this;
    }

    public CompatibleBlockSettings breakInstantly() {
        super.breakInstantly();
        return this;
    }

    public CompatibleBlockSettings dropsNothing() {
        super.dropsNothing();
        return this;
    }

    public CompatibleBlockSettings dynamicBounds() {
        super.dynamicBounds();
        return this;
    }

    public CompatibleBlockSettings hardness(float hardness) {
        super.hardness(hardness);
        return this;
    }

    public CompatibleBlockSettings noBlockBreakParticles() {
        super.noBlockBreakParticles();
        return this;
    }

    public CompatibleBlockSettings requiresTool() {
        super.requiresTool();
        return this;
    }

    public CompatibleBlockSettings noCollision() {
        super.noCollision();
        return this;
    }

    public CompatibleBlockSettings nonOpaque() {
        super.nonOpaque();
        return this;
    }

    public CompatibleBlockSettings resistance(float resistance) {
        super.resistance(resistance);
        return this;
    }

    public CompatibleBlockSettings strength(float strength) {
        super.strength(strength);
        return this;
    }

    public CompatibleBlockSettings strength(float hardness, float resistance) {
        super.strength(hardness, resistance);
        return this;
    }

    public CompatibleBlockSettings ticksRandomly() {
        super.ticksRandomly();
        return this;
    }

    public CompatibleBlockSettings sounds(CompatBlockSoundGroup blockSoundGroup) {
        super.sounds(blockSoundGroup);
        return this;
    }

    public CompatibleBlockSettings luminance(ToIntFunction<class_2680> luminance) {
        super.luminance(luminance);
        return this;
    }

    public CompatibleBlockSettings jumpVelocityMultiplier(float jumpVelocityMultiplier) {
        super.jumpVelocityMultiplier(jumpVelocityMultiplier);
        return this;
    }

    public CompatibleBlockSettings slipperiness(float slipperiness) {
        super.slipperiness(slipperiness);
        return this;
    }

    public CompatibleBlockSettings velocityMultiplier(float velocityMultiplier) {
        super.velocityMultiplier(velocityMultiplier);
        return this;
    }

    public CompatibleBlockSettings emissiveLighting(class_4970.class_4973 predicate) {
        super.emissiveLighting(predicate);
        return this;
    }

    public CompatibleBlockSettings offset(class_4970.class_2250 offsetType) {
        super.offset(offsetType);
        return this;
    }

    public CompatibleBlockSettings allowsSpawning(class_4970.class_4972<net.minecraft.class_1299<?>> predicate) {
        super.allowsSpawning(predicate);
        return this;
    }

    public class_4970.class_2251 build() {
        super.build();
        return settings;
    }

    @Deprecated
    @Override
    public CompatibleBlockSettings sounds(class_2498 blockSoundGroup) {
        super.sounds(blockSoundGroup);
        return this;
    }


}
