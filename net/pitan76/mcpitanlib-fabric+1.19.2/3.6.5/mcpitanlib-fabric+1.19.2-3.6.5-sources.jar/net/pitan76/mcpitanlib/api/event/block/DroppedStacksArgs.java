package net.pitan76.mcpitanlib.api.event.block;

import net.minecraft.class_181;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_47;
import net.pitan76.mcpitanlib.api.event.BaseEvent;

public class DroppedStacksArgs extends BaseEvent {
    public class_2680 state;
    public class_47.class_48 builder;

    public DroppedStacksArgs(class_2680 state, class_47.class_48 builder) {
        this.state = state;
        this.builder = builder;
    }

    public class_2680 getState() {
        return state;
    }

    @Deprecated
    public class_47.class_48 getBuilder() {
        return builder;
    }

    public class_2586 getBlockEntity() {
        return builder.method_308(class_181.field_1228);
    }
}
