package net.pitan76.mcpitanlib.api.util.client;

import net.minecraft.class_312;

public class MouseUtil {

    public static class_312 getMouse() {
        return ClientUtil.getMouse();
    }

    public static double getMouseX() {
        return getMouse().method_1603();
    }

    public static double getMouseY() {
        return getMouse().method_1604();
    }

    public static boolean isCursorLocked() {
        return getMouse().method_1613();
    }

    public static void lockCursor() {
        getMouse().method_1612();
    }

    public static void unlockCursor() {
        getMouse().method_1610();
    }

    public static void tick() {
        getMouse().method_1606();
    }

    public static boolean wasLeftButtonClicked() {
        return getMouse().method_1608();
    }

    public static boolean wasRightButtonClicked() {
        return getMouse().method_1609();
    }

    public static boolean wasMiddleButtonClicked() {
        return getMouse().method_35707();
    }
}
