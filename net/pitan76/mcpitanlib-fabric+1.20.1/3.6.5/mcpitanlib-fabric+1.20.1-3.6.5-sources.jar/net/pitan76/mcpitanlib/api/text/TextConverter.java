package net.pitan76.mcpitanlib.api.text;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_5250;

public class TextConverter {

    public static class_5250 convert(String string) {
        return convert(string, false);
    }

    /**
     * Convert string to MutableText with formatting
     *
     * @param text String
     * @param translatable boolean
     * @return MutableText
     */
    public static class_5250 convert(String text, boolean translatable) {
        String[] splits = split(text);
        class_5250 result = class_2561.method_43470("");
        class_124[] currentFormatting = {};

        for (String part : splits) {
            // Section
            if (part.startsWith("§") && part.length() == 2) {
                char code = part.charAt(1);
                // Reset
                if (code == 'r') {
                    currentFormatting = new class_124[]{};
                    continue;
                }

                class_124 format = class_124.method_544(code);
                if (format == null)
                    continue;

                // Bold, Italic, Underline, Strikethrough, Obfuscated
                if (code >= 'k' && code <= 'o') {
                    ArrayList<class_124> list = new ArrayList<>(Arrays.asList(currentFormatting));
                    list.add(format);
                    currentFormatting = list.toArray(new class_124[0]);
                    continue;
                }

                // Color
                currentFormatting = new class_124[]{format};
                continue;
            }

            // Translatable
            if (translatable) {
                Pattern pattern = Pattern.compile("\\{(.+?)\\}");
                Matcher matcher = pattern.matcher(part);
                class_5250 tempText = class_2561.method_43470("");
                int lastIndex = 0;

                while (matcher.find()) {
                    // {translatable key} より前の文字列を追加
                    if (matcher.start() > lastIndex) {
                        tempText.method_10852(class_2561.method_43470(part.substring(lastIndex, matcher.start())).method_27695(currentFormatting));
                    }

                    // {translatable key} を追加
                    String key = matcher.group(1);
                    tempText.method_10852(class_2561.method_43471(key).method_27695(currentFormatting));

                    lastIndex = matcher.end();
                }

                // 最後の文字列を追加
                if (lastIndex < part.length()) {
                    tempText.method_10852(class_2561.method_43470(part.substring(lastIndex)).method_27695(currentFormatting));
                }

                result.method_10852(tempText);
                continue;
            }

            result.method_10852(class_2561.method_43470(part).method_27695(currentFormatting));
        }

        return result;
    }

    public static String[] split(String text) {
        Matcher matcher = Pattern.compile("(?i)§[0-9a-fk-or]|[^§]+").matcher(text);
        List<String> parts = new ArrayList<>();

        while (matcher.find())
            parts.add(matcher.group());

        return parts.toArray(new String[0]);
    }
}
