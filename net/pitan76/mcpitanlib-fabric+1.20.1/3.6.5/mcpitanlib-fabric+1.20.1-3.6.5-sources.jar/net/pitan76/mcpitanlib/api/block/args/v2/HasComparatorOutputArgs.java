package net.pitan76.mcpitanlib.api.block.args.v2;

import net.minecraft.class_2680;
import net.pitan76.mcpitanlib.api.event.BaseEvent;

public class HasComparatorOutputArgs extends BaseEvent {
    public class_2680 state;

    public HasComparatorOutputArgs(class_2680 state) {
        this.state = state;
    }

    public class_2680 getState() {
        return state;
    }
}
