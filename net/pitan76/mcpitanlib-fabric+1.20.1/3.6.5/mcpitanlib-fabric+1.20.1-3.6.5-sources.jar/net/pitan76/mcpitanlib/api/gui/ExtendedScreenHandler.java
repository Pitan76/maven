package net.pitan76.mcpitanlib.api.gui;

import net.minecraft.class_2540;
import net.minecraft.class_3917;
import org.jetbrains.annotations.Nullable;

public class ExtendedScreenHandler extends SimpleScreenHandler {
    protected ExtendedScreenHandler(@Nullable class_3917<?> type, int syncId, class_2540 buf) {
        this(type, syncId);
    }

    protected ExtendedScreenHandler(@Nullable class_3917<?> type, int syncId) {
        super(type, syncId);
    }
}
