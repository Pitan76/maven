package net.pitan76.mcpitanlib.api.tag.v2.typed;

import net.minecraft.class_3611;
import net.minecraft.class_6862;
import net.pitan76.mcpitanlib.api.tag.v2.CompatTagKey;
import net.pitan76.mcpitanlib.api.tag.v2.CompatTagKeyType;
import net.pitan76.mcpitanlib.api.util.CompatIdentifier;

public class FluidTagKey extends CompatTagKey<class_3611> {
    @Deprecated
    public FluidTagKey(class_6862<class_3611> tagKey) {
        super(tagKey);
    }

    public static FluidTagKey of(CompatIdentifier identifier) {
        return new FluidTagKey(class_6862.method_40092(CompatTagKeyType.FLUID.getRegistryKey(), identifier.toMinecraft()));
    }
}
