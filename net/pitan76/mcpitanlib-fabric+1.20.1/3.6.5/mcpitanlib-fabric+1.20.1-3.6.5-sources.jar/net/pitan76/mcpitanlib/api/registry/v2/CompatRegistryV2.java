package net.pitan76.mcpitanlib.api.registry.v2;

import net.minecraft.class_1291;
import net.minecraft.class_1299;
import net.minecraft.class_1703;
import net.minecraft.class_1761;
import net.minecraft.class_1792;
import net.minecraft.class_1887;
import net.minecraft.class_2248;
import net.minecraft.class_2396;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_2960;
import net.minecraft.class_3414;
import net.minecraft.class_3611;
import net.minecraft.class_3917;
import net.pitan76.mcpitanlib.api.block.ExtendBlock;
import net.pitan76.mcpitanlib.api.enchantment.CompatEnchantment;
import net.pitan76.mcpitanlib.api.entity.effect.CompatStatusEffect;
import net.pitan76.mcpitanlib.api.gui.ExtendedScreenHandlerTypeBuilder;
import net.pitan76.mcpitanlib.api.gui.SimpleScreenHandlerTypeBuilder;
import net.pitan76.mcpitanlib.api.item.CreativeTabBuilder;
import net.pitan76.mcpitanlib.api.item.ExtendItem;
import net.pitan76.mcpitanlib.api.registry.CompatRegistry;
import net.pitan76.mcpitanlib.api.registry.FuelRegistry;
import net.pitan76.mcpitanlib.api.registry.result.RegistryResult;
import net.pitan76.mcpitanlib.api.registry.result.SupplierResult;
import net.pitan76.mcpitanlib.api.sound.CompatSoundEvent;
import net.pitan76.mcpitanlib.api.sound.RegistryResultCompatSoundEvent;
import net.pitan76.mcpitanlib.api.tile.BlockEntityTypeBuilder;
import net.pitan76.mcpitanlib.api.util.CompatIdentifier;
import net.pitan76.mcpitanlib.midohra.world.chunk.ChunkTicketType;

import java.util.function.Supplier;

public class CompatRegistryV2 {

    public final CompatRegistry cr1;

    @Deprecated
    public CompatRegistryV2(CompatRegistry compatRegistry) {
        this.cr1 = compatRegistry;
    }

    /**
     * Create a new CompatRegistryV2
     * @param MOD_ID The mod id
     * @return The new CompatRegistryV2
     */
    public static CompatRegistryV2 create(String MOD_ID) {
        CompatRegistry cr1 = CompatRegistry.create(MOD_ID);
        return new CompatRegistryV2(cr1);
    }

    public static CompatRegistryV2 create(CompatRegistry compatRegistry) {
        return new CompatRegistryV2(compatRegistry);
    }

    /**
     * Register an item
     * @param id The item id
     * @param supplier The item supplier
     * @return The registry result
     */
    public RegistryResult<class_1792> registerItem(CompatIdentifier id, Supplier<class_1792> supplier) {
        return cr1.registerItem(id.toMinecraft(), supplier);
    }

    public Supplier<ExtendItem> registerExtendItem(CompatIdentifier id, Supplier<ExtendItem> supplier) {
        RegistryResult<class_1792> result = registerItem(id, supplier::get);
        return () -> (ExtendItem) result.get();
    }

    /**
     * Register a block
     * @param id The block id
     * @param supplier The block supplier
     * @return The registry result
     */
    public RegistryResult<class_2248> registerBlock(CompatIdentifier id, Supplier<class_2248> supplier) {
        return cr1.registerBlock(id.toMinecraft(), supplier);
    }

    public Supplier<ExtendBlock> registerExtendBlock(CompatIdentifier id, Supplier<ExtendBlock> supplier) {
        RegistryResult<class_2248> result = registerBlock(id, supplier::get);
        return () -> (ExtendBlock) result.get();
    }

    public RegistryResult<class_3917<?>> registerScreenHandlerType(CompatIdentifier id, Supplier<class_3917<?>> supplier) {
        return cr1.registerScreenHandlerType(id.toMinecraft(), supplier);
    }

    public <T extends class_1703> Supplier<class_3917<T>> registerScreenHandlerTypeSavingGenerics(CompatIdentifier id, Supplier<class_3917<T>> supplier) {
        RegistryResult<class_3917<?>> result =  cr1.registerScreenHandlerType(id.toMinecraft(), supplier::get);
        return () -> (class_3917<T>) result.getOrNull();
    }

    public <T extends class_1703> SupplierResult<class_3917<T>> registerScreenHandlerType(CompatIdentifier id, SimpleScreenHandlerTypeBuilder<T> builder) {
        return SupplierResult.of(registerScreenHandlerTypeSavingGenerics(id, builder::build));
    }

    public <T extends class_1703> SupplierResult<class_3917<T>> registerScreenHandlerType(CompatIdentifier id, ExtendedScreenHandlerTypeBuilder<T> builder) {
        return SupplierResult.of(registerScreenHandlerTypeSavingGenerics(id, builder::build));
    }

    public RegistryResult<class_2591<?>> registerBlockEntityType(CompatIdentifier id, Supplier<class_2591<?>> supplier) {
        return cr1.registerBlockEntityType(id.toMinecraft(), supplier);
    }

    public <T extends class_2586> SupplierResult<class_2591<T>> registerBlockEntityType(CompatIdentifier id, BlockEntityTypeBuilder<T> builder) {
        RegistryResult<class_2591<?>> result = cr1.registerBlockEntityType(id.toMinecraft(), builder::build);
        return SupplierResult.of(() -> (class_2591<T>) result.getOrNull());
    }

    public RegistryResult<class_1299<?>> registerEntity(CompatIdentifier id, Supplier<class_1299<?>> supplier) {
        return cr1.registerEntity(id.toMinecraft(), supplier);
    }

    public RegistryResult<class_3414> registerSoundEvent(CompatIdentifier id) {
        return cr1.registerSoundEvent(id.toMinecraft());
    }

    public RegistryResult<class_3414> registerSoundEvent(CompatIdentifier id, float distanceToTravel) {
        return cr1.registerSoundEvent(id.toMinecraft(), distanceToTravel);
    }

    public CompatSoundEvent registerCompatSoundEvent(CompatIdentifier id) {
        return RegistryResultCompatSoundEvent.of(registerSoundEvent(id));
    }

    public CompatSoundEvent registerCompatSoundEvent(CompatIdentifier id, float distanceToTravel) {
        return RegistryResultCompatSoundEvent.of(registerSoundEvent(id, distanceToTravel));
    }

    public RegistryResult<class_3611> registerFluid(CompatIdentifier id, Supplier<class_3611> supplier) {
        return cr1.registerFluid(id.toMinecraft(), supplier);
    }

    public RegistryResult<class_2396<?>> registerParticleType(CompatIdentifier id, Supplier<class_2396<?>> supplier) {
        return cr1.registerParticleType(id.toMinecraft(), supplier);
    }

    public RegistryResult<class_1887> registerEnchantment(CompatIdentifier id, Supplier<CompatEnchantment> supplier) {
        return cr1.registerEnchantment(id.toMinecraft(), () -> supplier.get().getEnchantment(null));
    }

    public RegistryResult<class_1291> registryStatusEffect(CompatIdentifier id, Supplier<CompatStatusEffect> supplier) {
        return cr1.registerStatusEffect(id.toMinecraft(), () -> supplier.get().getStatusEffect(null));
    }

    public RegistryResult<class_1761> registerItemGroup(CompatIdentifier id, Supplier<class_1761> supplier) {
        return cr1.registerItemGroup(id.toMinecraft(), supplier);
    }

    public RegistryResult<class_1761> registerItemGroup(CompatIdentifier id, CreativeTabBuilder builder) {
        return cr1.registerItemGroup(id.toMinecraft(), builder);
    }

    public RegistryResult<class_1761> registerItemGroup(CreativeTabBuilder builder) {
        return cr1.registerItemGroup(builder.getIdentifier(), builder);
    }

    public RegistryResult<ChunkTicketType<?>> registerChunkTicketType(class_2960 id, Supplier<ChunkTicketType<?>> supplier) {
        return SupplierResult.of(supplier);
    }

    public RegistryResult<ChunkTicketType<?>> registerChunkTicketType(CompatIdentifier id, Supplier<ChunkTicketType<?>> supplier) {
        return registerChunkTicketType(id.toMinecraft(), supplier);
    }

    public void registerFuel(Supplier<class_1792> itemSupplier, int time) {
        FuelRegistry.register(itemSupplier::get, time, cr1.getNamespace());
    }

    public void allRegister() {
        cr1.allRegister();
        FuelRegistry.allRegister(cr1.getNamespace());
    }
}
