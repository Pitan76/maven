package net.pitan76.mcpitanlib.api.network.v2;

import net.minecraft.class_1937;
import net.minecraft.class_2540;
import net.minecraft.class_3222;
import net.minecraft.server.MinecraftServer;
import net.pitan76.mcpitanlib.api.entity.Player;
import net.pitan76.mcpitanlib.api.network.PacketByteUtil;
import net.pitan76.mcpitanlib.api.network.v2.args.ServerReceiveEvent;
import net.pitan76.mcpitanlib.api.util.CompatIdentifier;
import net.pitan76.mcpitanlib.midohra.network.CompatPacketByteBuf;
import net.pitan76.mcpitanlib.midohra.server.MCServer;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.function.Consumer;

public class ServerNetworking {
    public static void send(class_3222 serverPlayerEntity, CompatIdentifier id, class_2540 buf) {
        net.pitan76.mcpitanlib.api.network.ServerNetworking.send(serverPlayerEntity, id.toMinecraft(), buf);
    }

    public static void sendByServerPlayerEntity(Iterable<class_3222> players, CompatIdentifier id, class_2540 buf) {
        net.pitan76.mcpitanlib.api.network.ServerNetworking.send(players, id.toMinecraft(), buf);
    }

    public static void send(Player player, CompatIdentifier id, class_2540 buf) {
        Optional<class_3222> optional = player.getServerPlayer();
        if (optional.isEmpty()) return;

        send(optional.get(), id, buf);
    }

    public static void send(Iterable<Player> players, CompatIdentifier id, class_2540 buf) {
        List<class_3222> list = new ArrayList<>();
        for (Player player : players) {
            Optional<class_3222> optional = player.getServerPlayer();
            optional.ifPresent(list::add);
        }

        sendByServerPlayerEntity(list, id, buf);
    }

    public static void sendAll(MinecraftServer server, CompatIdentifier id, class_2540 buf) {
        net.pitan76.mcpitanlib.api.network.ServerNetworking.sendAll(server, id.toMinecraft(), buf);
    }

    public static void sendAll(class_1937 world, CompatIdentifier id, class_2540 buf) {
        sendAll(world.method_8503(), id, buf);
    }

    public static void registerReceiver(CompatIdentifier id, Consumer<ServerReceiveEvent> consumer) {
        net.pitan76.mcpitanlib.api.network.ServerNetworking.registerReceiver(id.toMinecraft(), (server, player, buf) -> {
            consumer.accept(new ServerReceiveEvent(server, player, buf));
        });
    }

    public static void send(class_3222 serverPlayerEntity, CompatIdentifier id, CompatPacketByteBuf buf) {
        send(serverPlayerEntity, id, buf.getRaw());
    }

    public static void send(Player player, CompatIdentifier id, CompatPacketByteBuf buf) {
        send(player, id, buf.getRaw());
    }

    public static void send(Iterable<Player> players, CompatIdentifier id, CompatPacketByteBuf buf) {
        send(players, id, buf.getRaw());
    }

    public static void sendAll(MinecraftServer server, CompatIdentifier id, CompatPacketByteBuf buf) {
        sendAll(server, id, buf.getRaw());
    }

    public static void sendAll(class_1937 world, CompatIdentifier id, CompatPacketByteBuf buf) {
        sendAll(world.method_8503(), id, buf.getRaw());
    }

    public static void send(class_3222 serverPlayerEntity, CompatIdentifier id) {
        send(serverPlayerEntity, id, PacketByteUtil.create());
    }

    public static void send(Player player, CompatIdentifier id) {
        send(player, id, PacketByteUtil.create());
    }

    public static void send(Iterable<Player> players, CompatIdentifier id) {
        send(players, id, PacketByteUtil.create());
    }

    public static void sendAll(MinecraftServer server, CompatIdentifier id) {
        sendAll(server, id, PacketByteUtil.create());
    }

    public static void sendAll(class_1937 world, CompatIdentifier id) {
        sendAll(world.method_8503(), id, PacketByteUtil.create());
    }

    public static void sendAll(MCServer server, CompatIdentifier id, CompatPacketByteBuf buf) {
        sendAll(server.getRaw(), id, buf);
    }

    public static void sendAll(MCServer server, CompatIdentifier id) {
        sendAll(server.getRaw(), id);
    }

    public static void sendAll(net.pitan76.mcpitanlib.midohra.world.World world, CompatIdentifier id, CompatPacketByteBuf buf) {
        sendAll(world.getRaw(), id, buf);
    }

    public static void sendAll(net.pitan76.mcpitanlib.midohra.world.World world, CompatIdentifier id) {
        sendAll(world.getRaw(), id);
    }
}
