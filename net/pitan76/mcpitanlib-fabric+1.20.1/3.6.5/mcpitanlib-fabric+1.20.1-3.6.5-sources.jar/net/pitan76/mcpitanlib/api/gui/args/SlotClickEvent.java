package net.pitan76.mcpitanlib.api.gui.args;

import net.minecraft.class_1713;
import net.pitan76.mcpitanlib.api.entity.Player;
import net.pitan76.mcpitanlib.api.gui.slot.CompatSlotActionType;

public class SlotClickEvent {
    public int slot;
    public int button;
    public class_1713 actionType;
    public Player player;

    public SlotClickEvent(int slot, int button, class_1713 actionType, Player player) {
        this.slot = slot;
        this.button = button;
        this.actionType = actionType;
        this.player = player;
    }

    public int getSlot() {
        return slot;
    }

    public int getButton() {
        return button;
    }

    public class_1713 getRawActionType() {
        return actionType;
    }

    public CompatSlotActionType getActionType() {
        return CompatSlotActionType.of(actionType);
    }

    public Player getPlayer() {
        return player;
    }

    public boolean isClient() {
        return player.isClient();
    }

    public boolean isServer() {
        return player.isServer();
    }

    public boolean isSwapAction() {
        return actionType == class_1713.field_7791;
    }

    public boolean isPickupAction() {
        return actionType == class_1713.field_7790;
    }

    public boolean isQuickCraftAction() {
        return actionType == class_1713.field_7789;
    }

    public boolean isQuickMoveAction() {
        return actionType == class_1713.field_7794;
    }

    public boolean isThrowAction() {
        return actionType == class_1713.field_7795;
    }
}
