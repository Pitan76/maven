package net.pitan76.mcpitanlib.api.event.block;

import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.pitan76.mcpitanlib.api.entity.Player;
import net.pitan76.mcpitanlib.api.event.BaseEvent;
import net.pitan76.mcpitanlib.api.util.WorldUtil;

public class BlockBreakStartEvent extends BaseEvent {

    public class_2680 state;
    public class_1937 world;
    public class_2338 pos;
    public Player player;

    public BlockBreakStartEvent(class_2680 state, class_1937 world, class_2338 pos, Player player) {
        this.state = state;
        this.world = world;
        this.pos = pos;
        this.player = player;
    }

    public boolean isClient() {
        return WorldUtil.isClient(world);
    }

    public class_2680 getState() {
        return state;
    }

    public class_1937 getWorld() {
        return world;
    }

    public class_2338 getPos() {
        return pos;
    }

    public Player getPlayer() {
        return player;
    }

    public class_2338 getPlayerPos() {
        return player.getBlockPos();
    }

    public class_1799 getPlayerMainHandStack() {
        return player.getMainHandStack();
    }

    public class_1799 getPlayerOffHandStack() {
        return player.getOffHandStack();
    }

    public class_2586 getBlockEntity() {
        return WorldUtil.getBlockEntity(getWorld(), getPos());
    }
}
