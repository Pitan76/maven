package net.pitan76.mcpitanlib.api.util.client;

import net.minecraft.class_1074;
import net.minecraft.class_1076;
import net.pitan76.mcpitanlib.midohra.resource.ResourceManager;

public class LanguageUtil {
    public static boolean hasTranslation(String key) {
        return class_1074.method_4663(key);
    }

    public static String translate(String key) {
        return class_1074.method_4662(key);
    }

    public static String translate(String key, Object... args) {
        return class_1074.method_4662(key, args);
    }

    public static String translateWithFallback(String key, String fallback) {
        return class_1074.method_4663(key) ? class_1074.method_4662(key) : fallback;
    }

    public static String translateWithFallback(String key, String fallback, Object... args) {
        return class_1074.method_4663(key) ? class_1074.method_4662(key, args) : fallback;
    }

    public static class_1076 getLanguageManager() {
        return ClientUtil.getClient().method_1526();
    }

    public static String getLanguage() {
        return getLanguageManager().method_4669();
    }

    public static void setLanguage(String language) {
        getLanguageManager().method_4667(language);
    }

    public static void reload(net.minecraft.class_3300 resourceManager) {
        getLanguageManager().method_14491(resourceManager);
    }

    public static void reload(ResourceManager resourceManager) {
        reload(resourceManager.getRaw());
    }
}
