package net.pitan76.mcpitanlib.api.block.args;

import net.minecraft.class_2350;
import net.minecraft.class_2470;
import net.minecraft.class_2680;
import net.pitan76.mcpitanlib.midohra.holder.BlockStatePropertyHolder;

public class RotateArgs implements BlockStatePropertyHolder {

    public class_2680 state;
    public class_2470 rotation;

    public RotateArgs(class_2680 state, class_2470 rotation) {
        this.state = state;
        this.rotation = rotation;
    }

    public class_2680 getRawBlockState() {
        return state;
    }

    public class_2470 getRawRotation() {
        return rotation;
    }

    @Override
    public net.pitan76.mcpitanlib.midohra.block.BlockState getBlockState() {
        return net.pitan76.mcpitanlib.midohra.block.BlockState.of(state);
    }

    public class_2350 rotate(class_2350 direction) {
        return rotation.method_10503(direction);
    }

    public net.pitan76.mcpitanlib.midohra.util.math.Direction rotate(net.pitan76.mcpitanlib.midohra.util.math.Direction direction) {
        return net.pitan76.mcpitanlib.midohra.util.math.Direction.of(rotation.method_10503(direction.toMinecraft()));
    }
}
