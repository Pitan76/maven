package net.pitan76.mcpitanlib.api.gui.inventory;

import net.minecraft.class_1262;
import net.minecraft.class_1263;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_2371;

public interface IInventory extends class_1263 {

    class_2371<class_1799> getItems();

    static IInventory of(class_2371<class_1799> items) {
        return () -> items;
    }

    static IInventory ofSize(int size) {
        return of(class_2371.method_10213(size, class_1799.field_8037));
    }

    @Override
    default int method_5439() {
        return getItems().size();
    }

    @Override
    default boolean method_5442() {
        for (int i = 0; i < method_5439(); i++) {
            class_1799 stack = method_5438(i);
            if (!stack.method_7960()) {
                return false;
            }
        }
        return true;
    }

    @Override
    default class_1799 method_5438(int slot) {
        return getItems().get(slot);
    }

    @Override
    default class_1799 method_5434(int slot, int count) {
        class_1799 result = class_1262.method_5430(getItems(), slot, count);
        if (!result.method_7960()) {
            method_5431();
        }
        return result;
    }

    @Override
    default class_1799 method_5441(int slot) {
        return class_1262.method_5428(getItems(), slot);
    }

    @Override
    default void method_5447(int slot, class_1799 stack) {
        getItems().set(slot, stack);
        if (stack.method_7947() > method_5444()) {
            stack.method_7939(method_5444());
        }
    }

    @Override
    default void method_5448() {
        getItems().clear();
    }

    @Override
    default void method_5431() {
    }

    @Override
    default boolean method_5443(class_1657 player) {
        return true;
    }
}