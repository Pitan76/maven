package net.pitan76.mcpitanlib.api.util;

import net.minecraft.class_124;
import net.minecraft.class_2558;
import net.minecraft.class_2568;
import net.minecraft.class_2583;

public class StyleUtil {
    public static class_2583 emptyStyle() {
        return class_2583.field_24360;
    }

    public static class_2583 withColor(class_2583 style, int color) {
        return style.method_36139(color);
    }

    public static class_2583 withBold(class_2583 style, boolean bold) {
        return style.method_10982(bold);
    }

    public static class_2583 withItalic(class_2583 style, boolean italic) {
        return style.method_10978(italic);
    }

    public static class_2583 withUnderline(class_2583 style, boolean underline) {
        return style.method_30938(underline);
    }

    public static class_2583 withStrikethrough(class_2583 style, boolean strikethrough) {
        return style.method_36140(strikethrough);
    }

    public static class_2583 withObfuscated(class_2583 style, boolean obfuscated) {
        return style.method_36141(obfuscated);
    }

    public static class_2583 withInsertion(class_2583 style, String insertion) {
        return style.method_10975(insertion);
    }

    public static class_2583 withClickEvent(class_2583 style, class_2558 clickEvent) {
        return style.method_10958(clickEvent);
    }

    public static class_2583 withHoverEvent(class_2583 style, class_2568 hoverEvent) {
        return style.method_10949(hoverEvent);
    }

    public static class_2583 withFont(class_2583 style, CompatIdentifier font) {
        return style.method_27704(font.toMinecraft());
    }

    public static class_2583 withFormatting(class_2583 style, class_124 formatting) {
        return style.method_27706(formatting);
    }

    public static class_2583 withExclusiveFormatting(class_2583 style, class_124 formatting) {
        return style.method_27707(formatting);
    }
}
