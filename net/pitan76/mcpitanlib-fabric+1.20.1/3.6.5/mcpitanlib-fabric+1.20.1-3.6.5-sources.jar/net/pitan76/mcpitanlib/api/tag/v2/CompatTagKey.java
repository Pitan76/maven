package net.pitan76.mcpitanlib.api.tag.v2;

import net.minecraft.class_6880;
import net.pitan76.mcpitanlib.api.tag.TagKey;
import net.pitan76.mcpitanlib.api.util.CompatIdentifier;

public class CompatTagKey<T> extends TagKey<T> {
    @Deprecated
    public CompatTagKey(net.minecraft.class_6862<T> tagKey) {
        super(tagKey);
    }

    @Deprecated
    public static <T> CompatTagKey<T> of(net.minecraft.class_6862<T> tagKey) {
        return new CompatTagKey<>(tagKey);
    }

    public static <T> CompatTagKey<T> of(CompatTagKeyType<T> type, CompatIdentifier identifier) {
        return of(net.minecraft.class_6862.method_40092(type.getRegistryKey(), identifier.toMinecraft()));
    }

    public boolean isOf(T value) {
        return class_6880.method_40223(value).method_40220(getTagKey());
    }

    public CompatIdentifier getId() {
        return CompatIdentifier.fromMinecraft(getTagKey().comp_327());
    }
}
