package net.pitan76.mcpitanlib.api.event.entity;

import net.minecraft.class_239;
import net.minecraft.class_243;
import net.pitan76.mcpitanlib.midohra.util.hit.HitResultType;

public class CollisionEvent {

    public class_239 hitResult;

    public CollisionEvent(class_239 hitResult) {
        this.hitResult = hitResult;
    }

    public class_239 getHitResult() {
        return hitResult;
    }

    public class_239.class_240 getType() {
        return hitResult.method_17783();
    }

    public class_243 getPos() {
        return hitResult.method_17784();
    }

    public net.pitan76.mcpitanlib.midohra.util.hit.HitResult getHitResultM() {
        return net.pitan76.mcpitanlib.midohra.util.hit.HitResult.of(getHitResult());
    }

    public HitResultType getHitResultTypeM() {
        return HitResultType.from(getType());
    }
}
