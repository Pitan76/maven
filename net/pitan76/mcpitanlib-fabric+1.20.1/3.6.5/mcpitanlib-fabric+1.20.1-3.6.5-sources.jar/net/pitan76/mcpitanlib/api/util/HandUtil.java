package net.pitan76.mcpitanlib.api.util;

import net.minecraft.class_1268;
import net.minecraft.class_1304;

public class HandUtil {
    public static class_1268 getOppositeHand(class_1268 hand) {
        return hand == class_1268.field_5808 ? class_1268.field_5810 : class_1268.field_5808;
    }

    public static class_1304 getEquipmentSlot(class_1268 hand) {
        return hand == class_1268.field_5808 ? class_1304.field_6173 : class_1304.field_6171;
    }

    public static class_1268 getHand(class_1304 slot) {
        return slot == class_1304.field_6173 ? class_1268.field_5808 : class_1268.field_5810;
    }

    public static class_1268 getHand(boolean mainHand) {
        return mainHand ? class_1268.field_5808 : class_1268.field_5810;
    }

    public static boolean isMainHand(class_1268 hand) {
        return hand == class_1268.field_5808;
    }

    public static boolean isOffHand(class_1268 hand) {
        return hand == class_1268.field_5810;
    }

    public static boolean isMainHand(class_1304 slot) {
        return slot == class_1304.field_6173;
    }

    public static boolean isOffHand(class_1304 slot) {
        return slot == class_1304.field_6171;
    }
}
