package net.pitan76.mcpitanlib.api.state.property;

public class BooleanProperty implements IProperty<Boolean> {

    private final net.minecraft.class_2746 property;

    public BooleanProperty(String name) {
        this(net.minecraft.class_2746.method_11825(name));
    }

    public BooleanProperty(net.minecraft.class_2746 property) {
        this.property = property;
    }

    public static BooleanProperty of(String name) {
        return new BooleanProperty(name);
    }

    public static BooleanProperty of(net.minecraft.class_2746 property) {
        return new BooleanProperty(property);
    }

    @Override
    public net.minecraft.class_2746 getProperty() {
        return property;
    }
}
