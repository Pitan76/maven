package net.pitan76.mcpitanlib.api.tile;

import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_5558;
import net.pitan76.mcpitanlib.api.event.tile.TileTickEvent;

public interface ExtendBlockEntityTicker<T extends class_2586> extends class_5558<T> {
    @Override
    default void tick(class_1937 world, class_2338 pos, class_2680 state, T blockEntity) {
        tick(new TileTickEvent<>(world, pos, state, blockEntity));
    }

    void tick(TileTickEvent<T> event);
}
