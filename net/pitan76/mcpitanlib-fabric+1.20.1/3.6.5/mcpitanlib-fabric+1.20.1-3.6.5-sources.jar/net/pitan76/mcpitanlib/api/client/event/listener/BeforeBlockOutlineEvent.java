package net.pitan76.mcpitanlib.api.client.event.listener;

import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_239;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_3965;
import net.minecraft.class_4184;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_761;
import net.pitan76.mcpitanlib.midohra.client.render.CameraWrapper;
import net.pitan76.mcpitanlib.midohra.util.hit.HitResultType;

import java.util.Optional;

public class BeforeBlockOutlineEvent {
    public WorldRenderContext context;
    public class_239 hitResult;

    public BeforeBlockOutlineEvent(WorldRenderContext context, class_239 hitResult) {
        this.context = context;
        this.hitResult = hitResult;
    }

    public class_239 getHitResult() {
        return hitResult;
    }

    public WorldRenderContext getContext() {
        return context;
    }

    public class_761 getWorldRenderer() {
        return context.getWorldRenderer();
    }

    public Optional<class_2680> getBlockState() {
        return Optional.ofNullable(getWorld().method_8320(getBlockPos().orElse(null)));
    }

    public class_1937 getWorld() {
        return context.getWorld();
    }

    public Optional<class_2338> getBlockPos() {
        return Optional.ofNullable(((class_3965) hitResult).method_17777());
    }

    public boolean isBlockType() {
        return getHitResultType() == class_239.class_240.field_1332;
    }

    public class_239.class_240 getHitResultType() {
        return hitResult.method_17783();
    }

    @Deprecated
    public class_4184 getCamera() {
        return context.getCamera();
    }

    public CameraWrapper getCameraWrapper() {
        return CameraWrapper.of(getCamera());
    }

    public Optional<class_265> getOutlineShape() {
        return context.getOutlineShape();
    }

    public class_4587 getMatrixStack() {
        return context.getMatrixStack();
    }

    public void push() {
        context.push();
    }

    public void translate(double x, double y, double z) {
        context.translate(x, y, z);
    }

    public void pop() {
        context.pop();
    }

    public Optional<class_4588> getVertexConsumer() {
        return context.getVertexConsumer();
    }

    public void drawBox(float red, float green, float blue, float alpha) {
        context.drawBox(red, green, blue, alpha);
    }

    public void drawBox(class_238 box, float red, float green, float blue, float alpha) {
        context.drawBox(box, red, green, blue, alpha);
    }

    public net.pitan76.mcpitanlib.midohra.util.hit.HitResult getHitResultM() {
        return net.pitan76.mcpitanlib.midohra.util.hit.HitResult.of(hitResult);
    }

    public HitResultType getHitResultTypeM() {
        return HitResultType.from(hitResult.method_17783());
    }

    public class_2680 getBlockState2() {
        return getWorld().method_8320(getHitResultM().asBlockHitResult().get().getBlockPos());
    }

    public net.pitan76.mcpitanlib.midohra.block.BlockState getBlockStateM() {
        return net.pitan76.mcpitanlib.midohra.block.BlockState.of(getBlockState2());
    }
}
