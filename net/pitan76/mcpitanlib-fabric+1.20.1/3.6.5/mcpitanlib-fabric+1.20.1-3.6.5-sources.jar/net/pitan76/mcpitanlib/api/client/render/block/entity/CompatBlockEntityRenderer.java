package net.pitan76.mcpitanlib.api.client.render.block.entity;

import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_827;
import net.pitan76.mcpitanlib.api.client.render.block.entity.event.BlockEntityRenderEvent;
import net.pitan76.mcpitanlib.api.tile.CompatBlockEntity;

@Deprecated
public interface CompatBlockEntityRenderer<T extends CompatBlockEntity> extends class_827<T> {
    void render(BlockEntityRenderEvent<T> event);

    @Override
    default void render(T entity, float tickDelta, class_4587 matrices, class_4597 vertexConsumers, int light, int overlay) {
        render(new BlockEntityRenderEvent<>(this, entity, tickDelta, matrices, vertexConsumers, light, overlay));
    }

    default boolean rendersOutsideBoundingBoxOverride(T blockEntity) {
        return class_827.super.method_3563(blockEntity);
    }

    default int getRenderDistanceOverride() {
        return class_827.super.method_33893();
    }

    @Deprecated
    @Override
    default boolean rendersOutsideBoundingBox(T blockEntity) {
        return rendersOutsideBoundingBoxOverride(blockEntity);
    }

    @Deprecated
    @Override
    default int method_33893() {
        return getRenderDistanceOverride();
    }
}
