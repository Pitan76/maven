package net.pitan76.mcpitanlib.api.event.v0.event;

import com.google.common.collect.ImmutableMap;
import com.google.gson.JsonElement;
import net.minecraft.class_1860;
import net.minecraft.class_2960;
import net.minecraft.class_3300;
import net.minecraft.class_3695;
import net.minecraft.class_3956;
import net.pitan76.mcpitanlib.api.recipe.CompatibleRecipeEntry;
import net.pitan76.mcpitanlib.api.recipe.v2.CompatRecipeEntry;
import net.pitan76.mcpitanlib.api.recipe.v3.CompatRecipe;

import java.util.Map;

public class RecipeManagerEvent {
    public Map<class_2960, JsonElement> jsonMap;
    public class_3300 resourceManager;
    public class_3695 profiler;

    @Deprecated
    public Map<class_3956<?>, ImmutableMap.Builder<class_2960, class_1860<?>>> map;

    public RecipeManagerEvent(Map<class_2960, JsonElement> map, class_3300 resourceManager, class_3695 profiler, Map<class_3956<?>, ImmutableMap.Builder<class_2960, class_1860<?>>> map2) {
        this.jsonMap = map;
        this.resourceManager = resourceManager;
        this.profiler = profiler;
        this.map = map2;
    }

    public Map<class_2960, JsonElement> getJsonMap() {
        return jsonMap;
    }

    @Deprecated
    public Map<class_3956<?>, ImmutableMap.Builder<class_2960, class_1860<?>>> getMap() {
        return map;
    }

    public class_3695 getProfiler() {
        return profiler;
    }

    public class_3300 getResourceManager() {
        return resourceManager;
    }

    public net.pitan76.mcpitanlib.midohra.resource.ResourceManager getResourceManagerM() {
        return net.pitan76.mcpitanlib.midohra.resource.ResourceManager.of(resourceManager);
    }

    public void putCompatibleRecipeEntry(class_2960 id, CompatibleRecipeEntry entry) {
        map.get(entry.getType()).put(id, entry.getRecipe());
    }

    public void putCompatibleRecipeEntry(CompatibleRecipeEntry entry) {
        map.get(entry.getType()).put(entry.getId(), entry.getRecipe());
    }

    public void putCompatibleRecipeEntry(CompatRecipeEntry<?> entry) {
        map.get(entry.getType()).put(entry.getId(), entry.getRecipe());
    }

    public void putRecipeEntry(net.pitan76.mcpitanlib.midohra.recipe.entry.RecipeEntry entry) {
        map.get(entry.getRawRecipeType()).put(entry.getId().toMinecraft(), entry.toMinecraft());
    }

    public void putRecipe(CompatRecipe recipe) {
        map.get(recipe.getType()).put(recipe.getId(), recipe.getRecipeEntry().getRecipe());
    }
}
