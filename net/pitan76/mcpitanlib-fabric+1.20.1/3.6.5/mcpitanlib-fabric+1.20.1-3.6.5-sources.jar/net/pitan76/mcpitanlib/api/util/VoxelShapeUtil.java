package net.pitan76.mcpitanlib.api.util;

import net.minecraft.class_238;
import net.minecraft.class_259;
import net.minecraft.class_265;

public class VoxelShapeUtil {
    public static class_265 union(class_265 shape,class_265... shapes) {
        return class_259.method_17786(shape, shapes);
    }

    public static class_265 cuboid(double x1, double y1, double z1, double x2, double y2, double z2) {
        return class_259.method_1081(x1, y1, z1, x2, y2, z2);
    }

    public static class_265 cuboid(double x, double y, double z, double size) {
        return class_259.method_1081(x, y, z, x + size, y + size, z + size);
    }

    public static class_265 cuboid(double size) {
        return class_259.method_1081(0, 0, 0, size, size, size);
    }

    public static class_265 centeredCuboid(double x, double y, double z, double size) {
        return class_259.method_1081(x - size / 2, y - size / 2, z - size / 2, x + size / 2, y + size / 2, z + size / 2);
    }

    public static class_265 empty() {
        return class_259.method_1073();
    }

    public static class_265 fullCube() {
        return class_259.method_1077();
    }

    public static class_265 blockCuboid(double minX, double minY, double minZ, double maxX, double maxY, double maxZ) {
        return class_259.method_1081(minX / 16.0, minY / 16.0, minZ / 16.0, maxX / 16.0, maxY / 16.0, maxZ / 16.0);
    }

    public static class_238 getBoundingBox(class_265 shape) {
        return shape.method_1107();
    }
}
