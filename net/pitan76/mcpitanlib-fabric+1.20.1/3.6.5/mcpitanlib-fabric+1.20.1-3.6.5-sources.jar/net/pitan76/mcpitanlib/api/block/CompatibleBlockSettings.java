package net.pitan76.mcpitanlib.api.block;

import net.minecraft.class_1767;
import net.minecraft.class_2248;
import net.minecraft.class_2498;
import net.minecraft.class_2680;
import net.minecraft.class_3620;
import net.minecraft.class_4970;
import net.pitan76.mcpitanlib.api.sound.CompatBlockSoundGroup;

import java.util.function.Function;
import java.util.function.ToIntFunction;

@Deprecated
public class CompatibleBlockSettings {

    protected final class_4970.class_2251 settings;

    public CompatibleBlockSettings() {
        this.settings = class_4970.class_2251.method_9637();
    }

    @Deprecated
    public static CompatibleBlockSettings of() {
        return new CompatibleBlockSettings();
    }

    @Deprecated
    private static CompatibleBlockSettings copyCompatibleMaterial(CompatibleMaterial material, CompatibleBlockSettings settings) {
        settings.mapColor(material.getColor());
        if (material.isLiquid())
            settings.settings.method_51177();
        if (material.isSolid())
            settings.settings.method_51369();
        if (material.isReplaceable())
            settings.settings.method_51371();
        if (material.isSolid())
            settings.settings.method_51369();
        if (material.isBurnable())
            settings.settings.method_50013();
        settings.settings.method_50012(material.getPistonBehavior());
        return settings;
    }

    public CompatibleBlockSettings(CompatibleMaterial material, class_3620 mapColor) {
        this.settings = class_4970.class_2251.method_9637();
        copyCompatibleMaterial(material, this);
        mapColor(mapColor);
    }

    public CompatibleBlockSettings(CompatibleMaterial material, class_1767 dyeColor) {
        this.settings = class_4970.class_2251.method_9637();
        copyCompatibleMaterial(material, this);
        mapColor(dyeColor);
    }

    public CompatibleBlockSettings(CompatibleMaterial material) {
        this.settings = class_4970.class_2251.method_9637();
        copyCompatibleMaterial(material, this);
    }

    public CompatibleBlockSettings(CompatibleMaterial material, Function<class_2680, class_3620> mapColor) {
        this.settings = class_4970.class_2251.method_9637();
        copyCompatibleMaterial(material, this);
        mapColor(mapColor);
    }

    @Deprecated
    public static CompatibleBlockSettings of(CompatibleMaterial material, class_3620 mapColor) {
        return new CompatibleBlockSettings(material, mapColor);
    }

    @Deprecated
    public static CompatibleBlockSettings of(CompatibleMaterial material, class_1767 dyeColor) {
        return new CompatibleBlockSettings(material, dyeColor);
    }

    @Deprecated
    public static CompatibleBlockSettings of(CompatibleMaterial material) {
        return new CompatibleBlockSettings(material);
    }

    @Deprecated
    public static CompatibleBlockSettings of(CompatibleMaterial material, Function<class_2680, class_3620> mapColor) {
        return new CompatibleBlockSettings(material, mapColor);
    }

    public CompatibleBlockSettings(class_4970 block) {
        this.settings = class_4970.class_2251.method_9630(block);
    }

    @Deprecated
    public static CompatibleBlockSettings copy(class_4970 block) {
        return new CompatibleBlockSettings(block);
    }

    public CompatibleBlockSettings air() {
        settings.method_26250();
        return this;
    }

    public CompatibleBlockSettings blockVision(class_4970.class_4973 predicate) {
        settings.method_26245(predicate);
        return this;
    }

    public CompatibleBlockSettings postProcess(class_4970.class_4973 predicate) {
        settings.method_26247(predicate);
        return this;
    }

    public CompatibleBlockSettings solidBlock(class_4970.class_4973 predicate) {
        settings.method_26236(predicate);
        return this;
    }

    public CompatibleBlockSettings suffocates(class_4970.class_4973 predicate) {
        settings.method_26243(predicate);
        return this;
    }

    public CompatibleBlockSettings mapColor(class_3620 color) {
        settings.method_31710(color);
        return this;
    }

    public CompatibleBlockSettings mapColor(class_1767 color) {
        settings.method_51517(color);
        return this;
    }

    public CompatibleBlockSettings mapColor(Function<class_2680, class_3620> color) {
        settings.method_51520(color);
        return this;
    }

    @Deprecated
    public CompatibleBlockSettings dropsLike(class_2248 source) {
        return this;
    }

    public CompatibleBlockSettings breakInstantly() {
        settings.method_9618();
        return this;
    }

    public CompatibleBlockSettings dropsNothing() {
        settings.method_42327();
        return this;
    }

    public CompatibleBlockSettings dynamicBounds() {
        settings.method_9624();
        return this;
    }

    public CompatibleBlockSettings hardness(float hardness) {
        settings.method_36557(hardness);
        return this;
    }

    public CompatibleBlockSettings noBlockBreakParticles() {
        settings.method_45477();
        return this;
    }

    public CompatibleBlockSettings requiresTool() {
        settings.method_29292();
        return this;
    }

    public CompatibleBlockSettings noCollision() {
        settings.method_9634();
        return this;
    }

    public CompatibleBlockSettings nonOpaque() {
        settings.method_22488();
        return this;
    }

    public CompatibleBlockSettings resistance(float resistance) {
        settings.method_36558(resistance);
        return this;
    }

    public CompatibleBlockSettings strength(float strength) {
        settings.method_9632(strength);
        return this;
    }

    public CompatibleBlockSettings strength(float hardness, float resistance) {
        settings.method_9629(hardness, resistance);
        return this;
    }

    public CompatibleBlockSettings ticksRandomly() {
        settings.method_9640();
        return this;
    }

    public CompatibleBlockSettings sounds(class_2498 blockSoundGroup) {
        settings.method_9626(blockSoundGroup);
        return this;
    }

    public CompatibleBlockSettings sounds(CompatBlockSoundGroup blockSoundGroup) {
        return sounds(blockSoundGroup.get());
    }

    public CompatibleBlockSettings luminance(ToIntFunction<class_2680> luminance) {
        settings.method_9631(luminance);
        return this;
    }

    public CompatibleBlockSettings jumpVelocityMultiplier(float jumpVelocityMultiplier) {
        settings.method_23352(jumpVelocityMultiplier);
        return this;
    }

    public CompatibleBlockSettings slipperiness(float slipperiness) {
        settings.method_9628(slipperiness);
        return this;
    }

    public CompatibleBlockSettings velocityMultiplier(float velocityMultiplier) {
        settings.method_23351(velocityMultiplier);
        return this;
    }

    public CompatibleBlockSettings emissiveLighting(class_4970.class_4973 predicate) {
        settings.method_26249(predicate);
        return this;
    }

    public CompatibleBlockSettings offset(class_4970.class_2250 offsetType) {
        settings.method_49229(offsetType);
        return this;
    }

    public CompatibleBlockSettings allowsSpawning(class_4970.class_4972<net.minecraft.class_1299<?>> predicate) {
        settings.method_26235(predicate);
        return this;
    }

    public class_4970.class_2251 build() {
        return settings;

    }
}
