package net.pitan76.mcpitanlib.api.recipe.input;

import net.minecraft.class_1263;
import net.minecraft.class_1799;

public class CompatRecipeInput<I extends class_1263> {
    protected I input;

    public CompatRecipeInput(I input) {
        this.input = input;
    }

    public I getInput() {
        return input;
    }

    public class_1799 getStack(int slot) {
        return input.method_5438(slot);
    }

    public net.pitan76.mcpitanlib.midohra.item.ItemStack getMidohraStack(int slot) {
        return net.pitan76.mcpitanlib.midohra.item.ItemStack.of(getStack(slot));
    }

    public int getSize() {
        return input.method_5439();
    }

    public boolean isEmpty() {
        return input.method_5442();
    }
}
