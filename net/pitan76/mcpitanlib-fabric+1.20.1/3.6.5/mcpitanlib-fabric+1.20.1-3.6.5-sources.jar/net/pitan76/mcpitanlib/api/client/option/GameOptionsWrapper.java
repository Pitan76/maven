package net.pitan76.mcpitanlib.api.client.option;

import net.minecraft.class_315;

public class GameOptionsWrapper {
    public final class_315 raw;

    public GameOptionsWrapper(class_315 options) {
        this.raw = options;
    }

    public class_315 getRaw() {
        return raw;
    }

    public void write() {
        raw.method_1640();
    }
}
