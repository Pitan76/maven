package net.pitan76.mcpitanlib.api.event.item;

import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.pitan76.mcpitanlib.api.entity.Player;
import org.jetbrains.annotations.Nullable;

public class CraftEvent {

    public class_1799 stack;
    public class_1937 world;
    public Player player;

    public CraftEvent(class_1799 stack, class_1937 world, Player player) {
        this.stack = stack;
        this.world = world;
        this.player = player;
    }

    public CraftEvent(class_1799 stack, class_1937 world, class_1657 player) {
        this.stack = stack;
        this.world = world;
        this.player = new Player(player);
    }

    public CraftEvent(class_1799 stack, class_1937 world) {
        this.stack = stack;
        this.world = world;
    }

    public class_1799 getStack() {
        return stack;
    }

    public class_1937 getWorld() {
        return world;
    }

    @Nullable
    public Player getPlayer() {
        return player;
    }

    public boolean isClient() {
        return world.method_8608();
    }
}
