package net.pitan76.mcpitanlib.api.util.nbt;

import net.minecraft.class_1799;
import net.minecraft.class_2371;
import net.pitan76.mcpitanlib.api.event.nbt.ReadNbtArgs;
import net.pitan76.mcpitanlib.api.event.nbt.WriteNbtArgs;
import net.pitan76.mcpitanlib.api.util.InventoryUtil;
import net.pitan76.mcpitanlib.api.util.collection.ItemStackList;

public class InvRWUtil {
    public static void putInv(WriteNbtArgs args, class_2371<class_1799> stacks) {
        InventoryUtil.writeNbt(args.getRegistryLookup(), args.getNbt(), stacks);
    }

    public static void getInv(ReadNbtArgs args, class_2371<class_1799> stacks) {
        InventoryUtil.readNbt(args.getRegistryLookup(), args.getNbt(), stacks);
    }

    public static void putInv(WriteNbtArgs args, ItemStackList stacks) {
        putInv(args, (class_2371<class_1799>) stacks);
    }

    public static void getInv(ReadNbtArgs args, ItemStackList stacks) {
        getInv(args, (class_2371<class_1799>) stacks);
    }
}
