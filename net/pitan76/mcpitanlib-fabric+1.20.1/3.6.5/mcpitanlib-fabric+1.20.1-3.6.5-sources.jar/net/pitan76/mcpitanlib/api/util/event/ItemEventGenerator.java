package net.pitan76.mcpitanlib.api.util.event;

import net.minecraft.class_1792;
import net.pitan76.mcpitanlib.api.event.item.ItemUseEvent;
import net.pitan76.mcpitanlib.api.util.CompatActionResult;

public class ItemEventGenerator {
    public static CompatActionResult onRightClick(class_1792 item, ItemUseEvent e) {
        return CompatActionResult.create(item.method_7836(e.world, e.user.getPlayerEntity(), e.hand).method_5467());
    }
}
