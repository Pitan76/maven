package net.pitan76.mcpitanlib.api.extra.transfer.util;

import net.fabricmc.fabric.api.transfer.v1.fluid.FluidVariant;
import net.fabricmc.fabric.api.transfer.v1.fluid.base.SingleFluidStorage;
import net.fabricmc.fabric.api.transfer.v1.transaction.Transaction;
import net.minecraft.class_1937;
import net.minecraft.class_2487;
import net.minecraft.class_3610;
import net.pitan76.mcpitanlib.api.event.nbt.NbtRWArgs;
import net.pitan76.mcpitanlib.api.registry.CompatRegistryLookup;

public class FluidStorageUtil {
    public static SingleFluidStorage withFixedCapacity(long capacity, Runnable onChange) {
        return SingleFluidStorage.withFixedCapacity(capacity, onChange);
    }

    public static void readNbt(SingleFluidStorage storage, NbtRWArgs args) {
        storage.readNbt(args.getNbt());
    }

    public static void writeNbt(SingleFluidStorage storage, NbtRWArgs args) {
        storage.writeNbt(args.getNbt());
    }

    public static void readNbt(SingleFluidStorage storage, class_2487 nbt, CompatRegistryLookup registryLookup) {
        storage.readNbt(nbt);
    }

    public static void writeNbt(SingleFluidStorage storage, class_2487 nbt, CompatRegistryLookup registryLookup) {
        storage.writeNbt(nbt);
    }

    /**
     * @deprecated Use {@link #readNbt(SingleFluidStorage, NbtRWArgs)} instead
     */
    @Deprecated
    public static void readNbt(SingleFluidStorage storage, class_2487 nbt, class_1937 world) {
        storage.readNbt(nbt);
    }

    /**
     * @deprecated Use {@link #writeNbt(SingleFluidStorage, NbtRWArgs)} instead
     */
    @Deprecated
    public static void writeNbt(SingleFluidStorage storage, class_2487 nbt, class_1937 world) {
        storage.writeNbt(nbt);
    }

    public static long getAmount(SingleFluidStorage storage) {
        return storage.getAmount();
    }

    public static long getCapacity(SingleFluidStorage storage) {
        return storage.getCapacity();
    }

    public static FluidVariant getResource(SingleFluidStorage storage) {
        return storage.getResource();
    }

    public static boolean isResourceBlank(SingleFluidStorage storage) {
        return storage.isResourceBlank();
    }

    public static long insert(SingleFluidStorage storage, FluidVariant insertedVariant, long maxAmount, Transaction transaction) {
        return storage.insert(insertedVariant, maxAmount, transaction);
    }

    public static long extract(SingleFluidStorage storage, FluidVariant extractedVariant, long maxAmount, Transaction transaction) {
        return storage.extract(extractedVariant, maxAmount, transaction);
    }

    public static void insert(SingleFluidStorage storage, class_3610 fluidState, long maxAmount) {
        try (Transaction transaction = Transaction.openOuter()) {
            insert(storage, FluidVariant.of(fluidState.method_15772()), maxAmount, transaction);
            transaction.commit();
        }
    }

    public static void extract(SingleFluidStorage storage, class_3610 fluidState, long maxAmount) {
        try (Transaction transaction = Transaction.openOuter()) {
            extract(storage, FluidVariant.of(fluidState.method_15772()), maxAmount, transaction);
            transaction.commit();
        }
    }

    public static boolean isEmpty(SingleFluidStorage storage) {
        return getAmount(storage) == 0;
    }

    public static boolean isFull(SingleFluidStorage storage) {
        return getAmount(storage) >= getCapacity(storage);
    }
}
