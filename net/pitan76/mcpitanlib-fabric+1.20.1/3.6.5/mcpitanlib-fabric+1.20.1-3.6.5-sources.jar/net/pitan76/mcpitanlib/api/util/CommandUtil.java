package net.pitan76.mcpitanlib.api.util;

import com.mojang.brigadier.arguments.*;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import net.minecraft.class_1297;
import net.minecraft.class_1792;
import net.minecraft.class_2186;
import net.minecraft.class_2248;
import net.minecraft.class_2257;
import net.minecraft.class_2287;
import net.pitan76.mcpitanlib.api.event.ServerCommandEvent;

public class CommandUtil {
    public static class_1792 getItemArgument(String name, ServerCommandEvent e) {
        return class_2287.method_9777(e.getContext(), name).method_9785();
    }

    public static class_2248 getBlockArgument(String name, ServerCommandEvent e) {
        return class_2257.method_9655(e.getContext(), name).method_9494().method_26204();
    }

    public static Integer getIntegerArgument(String name, ServerCommandEvent e) {
        return IntegerArgumentType.getInteger(e.getContext(), name);
    }

    public static Double getDoubleArgument(String name, ServerCommandEvent e) {
        return DoubleArgumentType.getDouble(e.getContext(), name);
    }

    public static Float getFloatArgument(String name, ServerCommandEvent e) {
        return FloatArgumentType.getFloat(e.getContext(), name);
    }

    public static Long getLongArgument(String name, ServerCommandEvent e) {
        return LongArgumentType.getLong(e.getContext(), name);
    }

    public static Boolean getBooleanArgument(String name, ServerCommandEvent e) {
        return BoolArgumentType.getBool(e.getContext(), name);
    }

    public static String getStringArgument(String name, ServerCommandEvent e) {
        return StringArgumentType.getString(e.getContext(), name);
    }

    public static class_1297 getEntityArgument(String name, ServerCommandEvent e) {
        try {
            return class_2186.method_9313(e.getContext(), name);
        } catch (CommandSyntaxException ex) {
            return null;
        }
    }
}
