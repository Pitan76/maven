package net.pitan76.mcpitanlib.api.network.v2.args;

import net.minecraft.class_1937;
import net.minecraft.class_2540;
import net.minecraft.class_310;
import net.minecraft.class_746;
import net.pitan76.mcpitanlib.api.entity.Player;
import net.pitan76.mcpitanlib.midohra.network.CompatPacketByteBuf;

public class ClientReceiveEvent {
    public class_310 client;
    public class_746 clientPlayer;
    public Player player;
    public class_2540 buf;

    public ClientReceiveEvent(class_310 client, class_746 player, class_2540 buf) {
        this.client = client;
        this.clientPlayer = player;
        this.player = new Player(player);
        this.buf = buf;
    }

    public class_746 getClientPlayer() {
        return clientPlayer;
    }

    public Player getPlayer() {
        return player;
    }

    public class_310 getClient() {
        return client;
    }

    public class_2540 getBuf() {
        return buf;
    }

    public CompatPacketByteBuf getCompatBuf() {
        return CompatPacketByteBuf.of(buf);
    }

    public class_1937 getWorld() {
        return getPlayer().getWorld();
    }

    public net.pitan76.mcpitanlib.midohra.world.World getMidohraWorld() {
        return net.pitan76.mcpitanlib.midohra.world.World.of(getWorld());
    }
}
