package net.pitan76.mcpitanlib.api.event.tile;

import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.pitan76.mcpitanlib.midohra.block.BlockWrapper;
import net.pitan76.mcpitanlib.midohra.block.entity.BlockEntityWrapper;
import net.pitan76.mcpitanlib.midohra.holder.BlockStatePropertyHolder;
import net.pitan76.mcpitanlib.midohra.world.IWorldView;

public class TileTickEvent<T extends class_2586> implements BlockStatePropertyHolder {
    public class_1937 world;
    public class_2338 pos;
    public class_2680 state;
    public T blockEntity;

    public TileTickEvent(class_1937 world, class_2338 pos, class_2680 state, T blockEntity) {
        this.world = world;
        this.pos = pos;
        this.state = state;
        this.blockEntity = blockEntity;
    }

    public boolean isClient() {
        return world.method_8608();
    }

    public boolean isServer() {
        return !isClient();
    }

    public boolean hasWorld() {
        return world != null;
    }

    public class_1937 getWorld() {
        return world;
    }

    public class_2338 getPos() {
        return pos;
    }

    public class_2680 getState() {
        if (state == null)
            state = getWorldView().getBlockState(getPos());

        return state;
    }

    public T getBlockEntity() {
        return blockEntity;
    }

    public net.pitan76.mcpitanlib.midohra.world.World getMidohraWorld() {
        return net.pitan76.mcpitanlib.midohra.world.World.of(getWorld());
    }

    public net.pitan76.mcpitanlib.midohra.util.math.BlockPos getMidohraPos() {
        return net.pitan76.mcpitanlib.midohra.util.math.BlockPos.of(getPos());
    }

    public net.pitan76.mcpitanlib.midohra.block.BlockState getMidohraState() {
        if (state == null)
            return getWorldView().getBlockState(getMidohraPos());

        return net.pitan76.mcpitanlib.midohra.block.BlockState.of(getState());
    }

    public BlockEntityWrapper getBlockEntityWrapper() {
        return BlockEntityWrapper.of(getBlockEntity());
    }

    public IWorldView getWorldView() {
        return getMidohraWorld();
    }

    @Override
    public net.pitan76.mcpitanlib.midohra.block.BlockState getBlockState() {
        return getMidohraState();
    }

    public class_2248 getBlock() {
        return getState().method_26204();
    }

    public BlockWrapper getBlockWrapper() {
        return BlockWrapper.of(getBlock());
    }
}
