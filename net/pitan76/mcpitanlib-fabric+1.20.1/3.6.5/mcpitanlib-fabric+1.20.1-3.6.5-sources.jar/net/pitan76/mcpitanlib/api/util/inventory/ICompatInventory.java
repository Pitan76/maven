package net.pitan76.mcpitanlib.api.util.inventory;

import net.minecraft.class_1263;
import net.minecraft.class_1799;
import net.pitan76.mcpitanlib.api.entity.Player;

public interface ICompatInventory extends class_1263 {
    default void callSetStack(int slot, class_1799 stack) {
        method_5447(slot, stack);
    }

    default class_1799 callGetStack(int slot) {
        return method_5438(slot);
    }

    default int callSize() {
        return method_5439();
    }

    default boolean callIsEmpty() {
        return method_5442();
    }

    default class_1799 callRemoveStack(int slot, int amount) {
        return method_5434(slot, amount);
    }

    default class_1799 callRemoveStack(int slot) {
        return method_5441(slot);
    }

    default void callClear() {
        method_5448();
    }

    default void callMarkDirty() {
        method_5431();
    }

    default boolean callCanPlayerUse(net.minecraft.class_1657 player) {
        return method_5443(player);
    }

    default boolean canPlayerUse(Player player) {
        return method_5443(player.getEntity());
    }


    default void callSetStack(int slot, net.pitan76.mcpitanlib.midohra.item.ItemStack stack) {
        method_5447(slot, stack.toMinecraft());
    }

    default net.pitan76.mcpitanlib.midohra.item.ItemStack callGetStackAsMidohra(int slot) {
        return net.pitan76.mcpitanlib.midohra.item.ItemStack.of(method_5438(slot));
    }

    default int callGetMaxCountPerStack() {
        return method_5444();
    }
}
