package net.pitan76.mcpitanlib.api.util.math.random;

public class CompatRandom {
    private java.util.Random javaRandom;
    private net.minecraft.class_5819 mcRandom;

    public CompatRandom(java.util.Random javaRandom) {
        this.javaRandom = javaRandom;
    }

    public CompatRandom(net.minecraft.class_5819 mcRandom) {
        this.mcRandom = mcRandom;
    }

    @Deprecated
    public CompatRandom() {
        this.mcRandom = net.minecraft.class_5819.method_43047();
    }

    @Deprecated
    public CompatRandom(long seed) {
        this.mcRandom = net.minecraft.class_5819.method_43049(seed);
    }

    public static CompatRandom of(long seed) {
        return new CompatRandom(seed);
    }

    public static CompatRandom of() {
        return new CompatRandom();
    }

    public void setSeed(long seed) {
        if (javaRandom != null) {
            javaRandom.setSeed(seed);
        } else {
            mcRandom.method_43052(seed);
        }
    }

    public void skip(int count) {
        if (javaRandom != null) {
            for (int i = 0; i < count; i++) {
                javaRandom.nextInt();
            }
        } else {
            mcRandom.method_33650(count);
        }
    }

    public void split() {
        if (javaRandom != null) {
            javaRandom.nextInt();
        } else {
            mcRandom.method_38420();
        }
    }

    public int nextInt() {
        if (javaRandom != null) {
            return javaRandom.nextInt();
        } else {
            return mcRandom.method_43054();
        }
    }

    public int nextInt(int bound) {
        if (javaRandom != null) {
            return javaRandom.nextInt(bound);
        } else {
            return mcRandom.method_43048(bound);
        }
    }

    public long nextLong() {
        if (javaRandom != null) {
            return javaRandom.nextLong();
        } else {
            return mcRandom.method_43055();
        }
    }

    public double nextDouble() {
        if (javaRandom != null) {
            return javaRandom.nextDouble();
        } else {
            return mcRandom.method_43058();
        }
    }

    public double nextGaussian() {
        if (javaRandom != null) {
            return javaRandom.nextGaussian();
        } else {
            return mcRandom.method_43059();
        }
    }

    public float nextFloat() {
        if (javaRandom != null) {
            return javaRandom.nextFloat();
        } else {
            return mcRandom.method_43057();
        }
    }

    public int nextBetween(int min, int max) {
        if (javaRandom != null) {
            return min + javaRandom.nextInt(max - min);
        } else {
            return min + mcRandom.method_43048(max - min);
        }
    }

    public int nextBetweenExclusive(int min, int max) {
        if (javaRandom != null) {
            return min + javaRandom.nextInt(max - min - 1);
        } else {
            return min + mcRandom.method_43048(max - min - 1);
        }
    }

    public boolean nextBoolean() {
        if (javaRandom != null) {
            return javaRandom.nextBoolean();
        } else {
            return mcRandom.method_43056();
        }
    }

    @Deprecated
    public java.util.Random getJavaRandom() {
        return javaRandom;
    }

    @Deprecated
    public net.minecraft.class_5819 getMcRandom() {
        return mcRandom;
    }
}
