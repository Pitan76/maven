package net.pitan76.mcpitanlib.api.network;

import dev.architectury.networking.NetworkManager;
import net.minecraft.class_2540;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_746;

import static dev.architectury.networking.NetworkManager.Side.S2C;

public class ClientNetworking {
    public static void send(class_2960 identifier, class_2540 buf) {
        NetworkManager.sendToServer(identifier, buf);
    }

    public static void registerReceiver(class_2960 identifier, ClientNetworkHandler handler) {
        NetworkManager.registerReceiver(S2C, identifier, ((buf, context) -> handler.receive(class_310.method_1551(), class_310.method_1551().field_1724, buf)));
    }

    @FunctionalInterface
    public interface ClientNetworkHandler {
        void receive(class_310 client, class_746 player, class_2540 buf);
    }
}
