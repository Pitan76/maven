package net.pitan76.mcpitanlib.api.tag.v2.typed;

import net.minecraft.class_2248;
import net.minecraft.class_6862;
import net.pitan76.mcpitanlib.api.tag.v2.CompatTagKey;
import net.pitan76.mcpitanlib.api.tag.v2.CompatTagKeyType;
import net.pitan76.mcpitanlib.api.util.CompatIdentifier;
import net.pitan76.mcpitanlib.api.util.block.BlockUtil;

import java.util.List;

public class BlockTagKey extends CompatTagKey<class_2248> {
    @Deprecated
    public BlockTagKey(class_6862<class_2248> tagKey) {
        super(tagKey);
    }

    public static BlockTagKey of(CompatIdentifier identifier) {
        return new BlockTagKey(class_6862.method_40092(CompatTagKeyType.BLOCK.getRegistryKey(), identifier.toMinecraft()));
    }

    public List<class_2248> values() {
        return BlockUtil.getInTag(this);
    }
}
