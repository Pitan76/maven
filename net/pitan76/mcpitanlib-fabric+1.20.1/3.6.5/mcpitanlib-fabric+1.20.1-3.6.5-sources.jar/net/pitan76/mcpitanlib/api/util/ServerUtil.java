package net.pitan76.mcpitanlib.api.util;

import net.minecraft.class_1937;
import net.minecraft.class_3324;
import net.minecraft.server.MinecraftServer;
import net.pitan76.mcpitanlib.api.entity.Player;

public class ServerUtil {
    public static MinecraftServer getServer(class_1937 world) {
        return world.method_8503();
    }

    public static String getIP(MinecraftServer server) {
        return server.method_3819();
    }

    public static int getPort(MinecraftServer server) {
        return server.method_3756();
    }

    public static String getMotd(MinecraftServer server) {
        return server.method_3818();
    }

    public static String getServerModName(MinecraftServer server) {
        return server.getServerModName();
    }

    public static int getMaxPlayerCount(MinecraftServer server) {
        return server.method_3802();
    }

    public static int getCurrentPlayerCount(MinecraftServer server) {
        return server.method_3788();
    }

    public static boolean isOnlineMode(MinecraftServer server) {
        return server.method_3828();
    }

    public static boolean isServerRunning(MinecraftServer server) {
        return server.method_3806();
    }

    public static boolean isServerDedicated(MinecraftServer server) {
        return server.method_3816();
    }

    public static boolean isSingleplayer(MinecraftServer server) {
        return server.method_3724();
    }

    public static class_3324 getPlayerManager(MinecraftServer server) {
        return server.method_3760();
    }

    public static MinecraftServer getServer(Player player) {
        return getServer(player.getWorld());
    }

    public static void execute(MinecraftServer server, Runnable runnable) {
        server.execute(runnable);
    }
}
