package net.pitan76.mcpitanlib.api.util;

import net.minecraft.class_2680;
import net.minecraft.class_3486;
import net.minecraft.class_3610;
import net.minecraft.class_3611;
import net.pitan76.mcpitanlib.midohra.fluid.FluidWrapper;
import net.pitan76.mcpitanlib.midohra.util.math.BlockPos;
import net.pitan76.mcpitanlib.midohra.world.World;

public class FluidStateUtil {
    public static boolean isWater(class_3610 state) {
        return state.method_15767(class_3486.field_15517);
    }

    public static boolean isLava(class_3610 state) {
        return state.method_15767(class_3486.field_15518);
    }

    @Deprecated
    public static class_3610 getFluidState(class_2680 state) {
        return state.method_26227();
    }

    public static class_3610 getDefaultState(class_3611 state) {
        return state.method_15785();
    }

    public static class_3611 getFluid(class_3610 state) {
        return state.method_15772();
    }

    public static FluidWrapper getFluidWrapper(class_3610 state) {
        return FluidWrapper.of(getFluid(state));
    }

    public static FluidWrapper getFluidWrapper(class_2680 state) {
        return getFluidWrapper(getFluidState(state));
    }

    public static FluidWrapper getFluidWrapper(net.pitan76.mcpitanlib.midohra.block.BlockState state) {
        return getFluidWrapper(state.toMinecraft());
    }

    public static FluidWrapper getFluidWrapper(World world, BlockPos pos) {
        return getFluidWrapper(world.getBlockState(pos));
    }
}
