package net.pitan76.mcpitanlib.api.tag;

import net.minecraft.class_1299;
import net.minecraft.class_1792;
import net.minecraft.class_2248;
import net.minecraft.class_2960;
import net.minecraft.class_3611;
import net.minecraft.class_6880;
import net.minecraft.class_7924;
import net.pitan76.mcpitanlib.api.util.*;

public class TagKey<T> {
    private final net.minecraft.class_6862<T> tagKey;

    @Deprecated
    public TagKey(net.minecraft.class_6862<T> tagKey) {
        this.tagKey = tagKey;
    }

    public static TagKey<?> create(Type type, class_2960 identifier) {
        return switch (type) {
            case BLOCK -> new TagKey<>(net.minecraft.class_6862.method_40092(class_7924.field_41254, identifier));
            case ITEM -> new TagKey<>(net.minecraft.class_6862.method_40092(class_7924.field_41197, identifier));
            case FLUID -> new TagKey<>(net.minecraft.class_6862.method_40092(class_7924.field_41270, identifier));
            case ENTITY_TYPE -> new TagKey<>(net.minecraft.class_6862.method_40092(class_7924.field_41266, identifier));
        };
    }

    public static TagKey<?> create(Type type, CompatIdentifier id) {
        return create(type, id.toMinecraft());
    }

    @Deprecated
    public net.minecraft.class_6862<T> getTagKey() {
        return tagKey;
    }

    public enum Type {
        BLOCK,
        ITEM,
        FLUID,
        ENTITY_TYPE,
    }

    public boolean isOf(T value) {
        if (value instanceof class_1792)
            return getTagKey() == net.minecraft.class_6862.method_40092(class_7924.field_41197, ItemUtil.toID((class_1792) value));
        if (value instanceof class_2248)
            return getTagKey() == net.minecraft.class_6862.method_40092(class_7924.field_41254, BlockUtil.toID((class_2248) value));
        if (value instanceof class_3611)
            return getTagKey() == net.minecraft.class_6862.method_40092(class_7924.field_41270, FluidUtil.toID((class_3611) value));
        if (value instanceof class_1299<?>)
            return getTagKey() == net.minecraft.class_6862.method_40092(class_7924.field_41266, EntityTypeUtil.toID((class_1299<?>) value));

        return class_6880.method_40223(value).method_40220(getTagKey());
    }
}
