package net.pitan76.mcpitanlib.api.util.v2;

import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_2248;
import net.minecraft.class_2960;
import net.pitan76.mcpitanlib.api.tag.TagKey;
import net.pitan76.mcpitanlib.api.util.BlockUtil;

import java.util.ArrayList;
import java.util.List;

public class BlockUtilV2 {
    /**
     * Check if the block is in the tag. (MCPitanLib TagKey)
     * @param block Block to check.
     * @param tagKey TagKey of the tag.
     * @return If the block is in the tag.
     */
    public static boolean isIn(class_2248 block, TagKey<class_2248> tagKey) {
        if (block.method_40142().method_40220(tagKey.getTagKey())) return true;
        return tagKey.isOf(block);
    }

    /**
     * Check if two blocks are equal.
     * @param block Block to compare.
     * @param block2 Block to compare.
     * @return If two blocks are equal.
     */
    public static boolean isEqual(class_2248 block, class_2248 block2) {
        return block == block2;
    }

    /**
     * Get all blocks in the tag.
     * @param tagKey TagKey of the tag.
     * @return List of blocks in the tag.
     */
    public static List<class_2248> getBlocks(TagKey<class_2248> tagKey) {
        return getBlocks(tagKey, BlockUtil.getAllBlocks());
    }
    /**
     * Get given the list of blocks in the tag.
     * @param tagKey TagKey of the tag.
     * @param blocks List of blocks to search.
     * @return List of blocks in the tag.
     */
    public static List<class_2248> getBlocks(TagKey<class_2248> tagKey, List<class_2248> blocks) {
        List<class_2248> result = new ArrayList<>();
        for (class_2248 block : blocks) {
            if (!BlockUtil.isIn(block, tagKey)) continue;
            result.add(block);
        }
        return result;
    }

    /**
     * Get all blocks in the tag.
     * @param identifier Identifier of the tag.
     * @return List of blocks in the tag.
     */
    public static List<class_2248> getBlocks(class_2960 identifier) {
        return getBlocks((TagKey<class_2248>) TagKey.create(TagKey.Type.BLOCK, identifier));
    }

    /**
     * Get given the list of blocks in the tag.
     * @param identifier Identifier of the tag.
     * @param blocks List of blocks to search.
     * @return List of blocks in the tag.
     */
    public static List<class_2248> getBlocks(class_2960 identifier, List<class_2248> blocks) {
        return getBlocks((TagKey<class_2248>) TagKey.create(TagKey.Type.BLOCK, identifier), blocks);
    }

    /**
     * Get all blocks in the tag.
     * @param id String of the tag.
     * @return List of blocks in the tag.
     */
    public static List<class_2248> getBlocks(String id) {
        return getBlocks(new class_2960(id));
    }

    /**
     * Get given the list of blocks in the tag.
     * @param id String of the tag.
     * @param blocks List of blocks to search.
     * @return List of blocks in the tag.
     */

    public static List<class_2248> getBlocks(String id, List<class_2248> blocks) {
        return getBlocks(new class_2960(id), blocks);
    }

    /**
     * Check if the block is in the tag.
     * @param block Block to check.
     * @param identifier Identifier of the tag.
     * @return If the block is in the tag.
     */
    public static boolean isBlockInTag(class_2248 block, class_2960 identifier) {
        return BlockUtil.isIn(block, (TagKey<class_2248>) TagKey.create(TagKey.Type.BLOCK, identifier));
    }

    /**
     * Check if the block is in the tag.
     * @param block Block to check.
     * @param id String of the tag.
     * @return If the block is in the tag.
     */
    public static boolean isBlockInTag(class_2248 block, String id) {
        return isBlockInTag(block, new class_2960(id));
    }

    public static class_2248 fromItem(class_1792 item) {
        return class_2248.method_9503(item);
    }

    public static class_2248 fromItem(class_1799 stack) {
        return fromItem(stack.method_7909());
    }
}
