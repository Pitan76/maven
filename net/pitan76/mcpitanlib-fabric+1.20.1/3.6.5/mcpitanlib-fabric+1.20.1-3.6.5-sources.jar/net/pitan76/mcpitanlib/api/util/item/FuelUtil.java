package net.pitan76.mcpitanlib.api.util.item;

import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.pitan76.mcpitanlib.core.registry.FuelRegistry;

public class FuelUtil {

    public static int getTime(class_1937 world, class_1799 stack) {
        return FuelRegistry.get(world, stack);
    }

    public static boolean isFuel(class_1937 world, class_1799 stack) {
        return FuelRegistry.isFuel(world, stack);
    }
}
