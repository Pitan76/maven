package net.pitan76.mcpitanlib.api.util;

import net.minecraft.class_1269;
import net.pitan76.mcpitanlib.api.event.result.EventResult;
import net.pitan76.mcpitanlib.midohra.item.ItemStack;

import java.util.Optional;

public class CompatActionResult {
    public static final CompatActionResult SUCCESS = new CompatActionResult(class_1269.field_5812, EventResult.success());
    public static final CompatActionResult PASS = new CompatActionResult(class_1269.field_5811, EventResult.pass());
    public static final CompatActionResult FAIL = new CompatActionResult(class_1269.field_5814, EventResult.fail());
    public static final CompatActionResult CONSUME = new CompatActionResult(class_1269.field_21466, EventResult.success());
    public static final CompatActionResult PASS_TO_DEFAULT_BLOCK_ACTION = new CompatActionResult(class_1269.field_5811, EventResult.pass());
    public static final CompatActionResult SUCCESS_SERVER = new CompatActionResult(class_1269.field_5812, EventResult.success());
    public static final CompatActionResult STOP = new CompatActionResult(class_1269.field_5814, EventResult.stop());

    private final class_1269 actionResult;
    private final EventResult eventResult;

    protected CompatActionResult(class_1269 actionResult, EventResult eventResult) {
        this.actionResult = actionResult;
        this.eventResult = eventResult;
    }

    public class_1269 toActionResult() {
        return actionResult;
    }

    public EventResult toEventResult() {
        return eventResult;
    }

    public Optional<ItemStack> getNewMidohraHandStack() {
        return getNewHandStack().map(ItemStack::of);
    }

    public Optional<net.minecraft.class_1799> getNewHandStack() {
        return Optional.empty();
    }

    public static CompatActionResult of(class_1269 result) {
        if (result == class_1269.field_5812)
            return SUCCESS;

        if (result == class_1269.field_5811)
            return PASS;

        if (result == class_1269.field_5814)
            return FAIL;

        if (result == class_1269.field_21466)
            return CONSUME;

        return PASS;
    }

    public static CompatActionResult of(EventResult result) {
        if (result == EventResult.success())
            return SUCCESS;

        if (result == EventResult.pass())
            return PASS;

        if (result == EventResult.fail())
            return FAIL;

        if (result == EventResult.stop())
            return STOP;

        return PASS;
    }

    @Deprecated
    public static CompatActionResult create(class_1269 result, EventResult eventResult) {
        return new CompatActionResult(result, eventResult);
    }

    /**
     * @deprecated Use {@link #of(class_1269)} instead.
     */
    @Deprecated
    public static CompatActionResult create(class_1269 result) {
        return of(result);
    }

    @Deprecated
    public static CompatActionResult create2(class_1269 result) {
        return create(result, EventResult.stop());
    }

    @Override
    public boolean equals(Object obj) {
        if (super.equals(obj)) return true;
        if (!(obj instanceof CompatActionResult)) return false;
        if (actionResult.equals(((CompatActionResult) obj).actionResult)) {
            return eventResult.equals(((CompatActionResult) obj).eventResult);
        }

        return false;
    }

    public String getName() {
        if (this == SUCCESS) return "SUCCESS";
        if (this == PASS) return "PASS";
        if (this == FAIL) return "FAIL";
        if (this == CONSUME) return "CONSUME";
        if (this == PASS_TO_DEFAULT_BLOCK_ACTION) return "PASS_TO_DEFAULT_BLOCK_ACTION";
        if (this == SUCCESS_SERVER) return "SUCCESS_SERVER";
        if (this == STOP) return "STOP";

        return "UNKNOWN";
    }
}
