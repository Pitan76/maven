package net.pitan76.mcpitanlib.api.util.collection;

import net.minecraft.class_2371;

public class DefaultedListUtil {

    public static <E> class_2371<E> of() {
        return class_2371.method_10211();
    }

    public static <E> class_2371<E> ofSize(int size, E defaultElement) {
        return class_2371.method_10213(size, defaultElement);
    }

}
