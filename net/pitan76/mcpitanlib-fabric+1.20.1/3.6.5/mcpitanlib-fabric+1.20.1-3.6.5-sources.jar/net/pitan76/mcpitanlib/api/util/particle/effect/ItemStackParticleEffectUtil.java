package net.pitan76.mcpitanlib.api.util.particle.effect;

import net.minecraft.class_1799;
import net.minecraft.class_2392;
import net.minecraft.class_2396;
import net.minecraft.class_2398;

// Use: ParticleEffectUtil
public class ItemStackParticleEffectUtil {

    public ItemStackParticleEffectUtil() {
        // Empty constructor
    }

    public class_2392 create(class_2396<class_2392> type, class_1799 stack) {
        return new class_2392(type, stack);
    }

    public class_2392 createTypedItem(class_1799 stack) {
        return new class_2392(class_2398.field_11218, stack);
    }
}
