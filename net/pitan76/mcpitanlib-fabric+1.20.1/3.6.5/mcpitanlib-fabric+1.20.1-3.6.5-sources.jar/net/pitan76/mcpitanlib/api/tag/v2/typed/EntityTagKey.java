package net.pitan76.mcpitanlib.api.tag.v2.typed;

import net.minecraft.class_1299;
import net.minecraft.class_6862;
import net.pitan76.mcpitanlib.api.tag.v2.CompatTagKey;
import net.pitan76.mcpitanlib.api.tag.v2.CompatTagKeyType;
import net.pitan76.mcpitanlib.api.util.CompatIdentifier;

import java.util.List;

public class EntityTagKey extends CompatTagKey<class_1299<?>> {
    @Deprecated
    public EntityTagKey(class_6862<class_1299<?>> tagKey) {
        super(tagKey);
    }

    public static EntityTagKey of(CompatIdentifier identifier) {
        return new EntityTagKey(class_6862.method_40092(CompatTagKeyType.ENTITY_TYPE.getRegistryKey(), identifier.toMinecraft()));
    }
}
