package net.pitan76.mcpitanlib.api.event.item;

import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.pitan76.mcpitanlib.api.entity.Player;
import net.pitan76.mcpitanlib.api.util.WorldUtil;

public class CanMineArgs {
    public class_2680 state;
    public class_1937 world;
    public class_2338 pos;

    @Deprecated
    public Player miner;

    @Deprecated
    public class_1799 stack;

    public class_1309 entity;

    public CanMineArgs(class_2680 state, class_1937 world, class_2338 pos, class_1657 miner) {
        this.state = state;
        this.world = world;
        this.pos = pos;
        this.miner = new Player(miner);
        this.entity = miner;
    }

    public CanMineArgs(class_1799 stack, class_2680 state, class_1937 world, class_2338 pos, class_1309 entity) {
        this.stack = stack;
        this.state = state;
        this.world = world;
        this.pos = pos;
        this.entity = entity;

        if (entity instanceof class_1657) {
            this.miner = new Player((class_1657) entity);
        }
    }

    public class_2680 getState() {
        return state;
    }

    public class_1937 getWorld() {
        return world;
    }

    public class_2338 getPos() {
        return pos;
    }

    public Player getMiner() {
        return miner;
    }

    public boolean isExistMiner() {
        return miner.getEntity() != null;
    }

    public boolean isClient() {
        return WorldUtil.isClient(world);
    }

    public class_1799 getStack() {
        return stack != null ? stack : entity.method_6047();
    }

    public class_1309 getEntity() {
        return entity;
    }
}
