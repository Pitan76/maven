package net.pitan76.mcpitanlib.api.client.render.block.entity.event;

import net.minecraft.class_824;
import net.pitan76.mcpitanlib.api.util.client.ClientUtil;

public class CompatBlockEntityRendererConstructArgs {
    public final class_824 dispatcher;

    public CompatBlockEntityRendererConstructArgs(class_824 dispatcher) {
        this.dispatcher = dispatcher;
    }

    public CompatBlockEntityRendererConstructArgs() {
        this(ClientUtil.getClient().method_31975());
    }
}
