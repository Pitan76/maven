package net.pitan76.mcpitanlib.api.item.args;

import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.pitan76.mcpitanlib.api.entity.Player;

import java.util.Optional;

public class StoppedUsingArgs {

    public class_1799 stack;
    public class_1937 world;
    public class_1309 user;
    public int remainingUseTicks;

    public StoppedUsingArgs(class_1799 stack, class_1937 world, class_1309 user, int remainingUseTicks) {
        this.stack = stack;
        this.world = world;
        this.user = user;
        this.remainingUseTicks = remainingUseTicks;
    }

    public StoppedUsingArgs(class_1799 stack, class_1937 world, class_1309 user) {
        this(stack, world, user, 0);
    }

    public StoppedUsingArgs(class_1799 stack, class_1937 world, Player player, int remainingUseTicks) {
        this(stack, world, player.getEntity(), remainingUseTicks);
    }

    public StoppedUsingArgs(class_1799 stack, class_1937 world, Player player) {
        this(stack, world, player, 0);
    }

    public class_1799 getStack() {
        return stack;
    }

    public net.pitan76.mcpitanlib.midohra.item.ItemStack getMidohraStack() {
        return net.pitan76.mcpitanlib.midohra.item.ItemStack.of(stack);
    }

    public class_1937 getWorld() {
        return world;
    }

    public class_1309 getUser() {
        return user;
    }

    public int getRemainingUseTicks() {
        return remainingUseTicks;
    }

    public boolean hasRemainingUseTicks() {
        return remainingUseTicks > 0;
    }

    public boolean hasNoRemainingUseTicks() {
        return !hasRemainingUseTicks();
    }

    public boolean isClient() {
        return world.method_8608();
    }

    public boolean isServer() {
        return !isClient();
    }

    public boolean isPlayer() {
        return user instanceof class_1657;
    }

    public Optional<Player> getPlayer() {
        return isPlayer() ? Optional.of(new Player((class_1657) user)) : Optional.empty();
    }
}
