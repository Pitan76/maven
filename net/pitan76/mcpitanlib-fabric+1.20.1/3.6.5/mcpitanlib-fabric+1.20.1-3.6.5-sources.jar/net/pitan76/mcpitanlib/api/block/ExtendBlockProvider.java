package net.pitan76.mcpitanlib.api.block;

import net.minecraft.class_1703;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.pitan76.mcpitanlib.api.event.block.*;
import net.pitan76.mcpitanlib.api.event.block.result.BlockBreakResult;
import net.pitan76.mcpitanlib.api.event.item.ItemAppendTooltipEvent;
import net.pitan76.mcpitanlib.api.util.CompatActionResult;
import net.pitan76.mcpitanlib.api.util.TextUtil;

import java.util.List;

public interface ExtendBlockProvider {

    /**
     * get collision voxel shape
     * @param event CollisionShapeEvent
     * @param options Options
     * @return VoxelShape
     */
    default class_265 getCollisionShape(CollisionShapeEvent event, Options options) {
        options.cancel = false;
        return null;
    }

    /**
     * get outline voxel shape
     * @param event OutlineShapeEvent
     * @param options Options
     * @return VoxelShape
     */
    default class_265 getOutlineShape(OutlineShapeEvent event, Options options) {
        options.cancel = false;
        return null;
    }

    /**
     * block scheduled tick event
     * @param event BlockScheduledTickEvent
     * @param options Options
     */
    default void scheduledTick(BlockScheduledTickEvent event, Options options) {
        options.cancel = false;
    }

    /**
     * block right click event
     * @param event BlockUseEvent
     * @param options Options
     * @return ActionResult
     */
    default CompatActionResult onRightClick(BlockUseEvent event, Options options) {
        options.cancel = false;
        return null;
    }

    /**
     * screen handler create event
     * @param event ScreenHandlerCreateEvent
     * @param options Options
     * @return ScreenHandler
     */
    default class_1703 createScreenHandler(ScreenHandlerCreateEvent event, Options options) {
        options.cancel = false;
        return null;
    }

    /**
     * get screen title
     * @return Text
     */
    default class_2561 getScreenTitle() {
        return TextUtil.literal("");
    }

    /**
     * block placed event
     * @param event BlockPlacedEvent
     * @param options Options
     */
    default void onPlaced(BlockPlacedEvent event, Options options) {
        options.cancel = false;
    }

    /**
     * block break event
     * @param event BlockBreakEvent
     * @param options Options
     * @return BlockBreakResult
     */
    default BlockBreakResult onBreak(BlockBreakEvent event, Options options) {
        options.cancel = false;
        return null;
    }

    /**
     * block state replaced event
     * @param event StateReplacedEvent
     * @param options Options
     */
    default void onStateReplaced(StateReplacedEvent event, Options options) {
        options.cancel = false;
    }

    /**
     * get pick stack
     * @param event PickStackEvent
     * @param options Options
     * @return ItemStack
     */
    default class_1799 getPickStack(PickStackEvent event, Options options) {
        options.cancel = false;
        return null;
    }

    /**
     * get placement state
     * @param args PlacementStateArgs
     * @param options Options
     */
    default class_2680 getPlacementState(PlacementStateArgs args, Options options) {
        options.cancel = false;
        return null;
    }

    /**
     * append properties
     * @param args AppendPropertiesArgs
     * @param options Options
     */
    default void appendProperties(AppendPropertiesArgs args, Options options) {
        options.cancel = false;
    }

    /**
     * get dropped stacks
     * @param args DroppedStacksArgs
     * @param options Options
     * @return List<ItemStack>
     */
    default List<class_1799> getDroppedStacks(DroppedStacksArgs args, Options options) {
        options.cancel = false;
        return null;
    }

    default void appendTooltip(ItemAppendTooltipEvent event, Options options) {
        options.cancel = false;
    }

    default Boolean canPathfindThrough(CanPathfindThroughArgs args, Options options) {
        options.cancel = false;
        return null;
    }

    public static class Options {
        public boolean cancel = true;
    }
}
