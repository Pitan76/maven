package net.pitan76.mcpitanlib.api.item;

import java.util.function.Supplier;
import net.minecraft.class_1761;
import net.minecraft.class_1792;
import net.minecraft.class_2960;

/**
 * Use {@link CompatibleItemSettings} instead.
 */
public class ExtendSettings extends class_1792.class_1793 {

    // ～1.19.2
    @Deprecated
    public ExtendSettings addGroup(class_1761 itemGroup) {
        return this;
    }

    // 1.19.3～
    // identifier: Item ID
    @Deprecated
    public ExtendSettings addGroup(class_1761 itemGroup, class_2960 identifier) {
        this.arch$tab(itemGroup);
        CreativeTabManager.addItem(itemGroup, identifier);
        return this;
    }

    @Deprecated
    public ExtendSettings addGroup(Supplier<class_1761> itemGroup, class_2960 identifier) {
        CreativeTabManager.addItem(itemGroup, identifier);
        return this;
    }
}
