package net.pitan76.mcpitanlib.api.state.property;

import net.minecraft.class_2680;
import net.minecraft.class_2769;
import net.pitan76.mcpitanlib.api.event.block.AppendPropertiesArgs;

public interface IProperty<T extends Comparable<T>> {
    default void apply(AppendPropertiesArgs args) {
        args.addProperty(getProperty());
    }

    default T get(class_2680 state) {
        return state.method_11654(getProperty());
    }

    default class_2680 with(class_2680 state, T value) {
        return state.method_11657(getProperty(), value);
    }

    default boolean contains(class_2680 state) {
        return state.method_28498(getProperty());
    }

    default class_2680 cycle(class_2680 state) {
        return state.method_28493(getProperty());
    }

    default String getName() {
        return getProperty().method_11899();
    }

    class_2769<T> getProperty();

    default net.pitan76.mcpitanlib.midohra.block.BlockState with(net.pitan76.mcpitanlib.midohra.block.BlockState state, T value) {
        return state.with(getProperty(), value);
    }

    default T get(net.pitan76.mcpitanlib.midohra.block.BlockState state) {
        return state.get(getProperty());
    }

    default boolean contains(net.pitan76.mcpitanlib.midohra.block.BlockState state) {
        return state.contains(getProperty());
    }

    default net.pitan76.mcpitanlib.midohra.block.BlockState cycle(net.pitan76.mcpitanlib.midohra.block.BlockState state) {
        return state.cycle(getProperty());
    }
}
