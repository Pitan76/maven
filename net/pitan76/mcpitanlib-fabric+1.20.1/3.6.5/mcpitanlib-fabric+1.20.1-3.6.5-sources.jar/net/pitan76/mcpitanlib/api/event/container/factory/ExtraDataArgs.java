package net.pitan76.mcpitanlib.api.event.container.factory;

import net.minecraft.class_2540;
import net.minecraft.class_3222;
import net.pitan76.mcpitanlib.api.entity.Player;
import net.pitan76.mcpitanlib.api.event.BaseEvent;
import net.pitan76.mcpitanlib.api.network.PacketByteUtil;

public class ExtraDataArgs extends BaseEvent {
    public class_2540 buf;
    public class_3222 player;

    public ExtraDataArgs(class_2540 buf, class_3222 player) {
        super();
        this.buf = buf;
        this.player = player;
    }

    public ExtraDataArgs() {
        super();
    }

    public ExtraDataArgs(class_2540 buf) {
        super();
        this.buf = buf;
    }

    public boolean hasPlayer() {
        return player != null;
    }

    public boolean hasBuf() {
        return buf != null;
    }

    public class_2540 getBuf() {
        return buf;
    }

    public class_3222 getPlayer() {
        return player;
    }

    public Player getCompatPlayer() {
        return new Player(player);
    }

    /**
     * @param obj The object to write
     * @see PacketByteUtil#writeVar(class_2540, Object)
     */
    public void writeVar(Object obj) {
        PacketByteUtil.writeVar(getBuf(), obj);
    }
}
