package net.pitan76.mcpitanlib.api.entity.attribute;

import net.minecraft.class_1320;

public class CompatEntityAttribute {
    public final class_1320 raw;

    @Deprecated
    public CompatEntityAttribute(class_1320 attribute) {
        this.raw = attribute;
    }

    @Deprecated
    public class_1320 raw() {
        return raw;
    }

    public String getId() {
        return raw.method_26830();
    }

    public class_1320 getValue() {
        return raw();
    }

    public boolean isNull() {
        return raw == null;
    }

    @Deprecated
    public static CompatEntityAttribute of(class_1320 attribute) {
        return new CompatEntityAttribute(attribute);
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (!(obj instanceof CompatEntityAttribute)) return false;
        CompatEntityAttribute that = (CompatEntityAttribute) obj;
        return raw.equals(that.raw);
    }

    @Override
    public int hashCode() {
        if (raw == null) return super.hashCode();
        return raw.hashCode();
    }
}
