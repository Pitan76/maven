package net.pitan76.mcpitanlib.api.event.entity;

import net.minecraft.class_1297;
import net.minecraft.class_239;
import net.minecraft.class_3966;
import net.pitan76.mcpitanlib.midohra.entity.EntityWrapper;
import net.pitan76.mcpitanlib.midohra.util.hit.HitResultType;

public class EntityHitEvent {

    public class_3966 entityHitResult;

    public EntityHitEvent(class_3966 result) {
        this.entityHitResult = result;
    }

    public class_3966 getEntityHitResult() {
        return entityHitResult;
    }

    public class_1297 getEntity() {
        return entityHitResult.method_17782();
    }

    public class_239.class_240 getType() {
        return entityHitResult.method_17783();
    }

    public EntityWrapper getEntityWrapper() {
        return EntityWrapper.of(getEntity());
    }

    public HitResultType getTypeM() {
        return HitResultType.from(getType());
    }
}
