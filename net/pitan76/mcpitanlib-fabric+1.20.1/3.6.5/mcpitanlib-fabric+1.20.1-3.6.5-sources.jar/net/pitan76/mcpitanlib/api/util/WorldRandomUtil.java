package net.pitan76.mcpitanlib.api.util;

import net.minecraft.class_1937;

public class WorldRandomUtil {
    public static int nextInt(class_1937 world) {
        return world.method_8409().method_43054();
    }

    public static int nextInt(class_1937 world, int bound) {
        return world.method_8409().method_43048(bound);
    }

    public static long nextLong(class_1937 world) {
        return world.method_8409().method_43055();
    }

    public static double nextDouble(class_1937 world) {
        return world.method_8409().method_43058();
    }

    public static double nextGaussian(class_1937 world) {
        return world.method_8409().method_43059();
    }

    public static float nextFloat(class_1937 world) {
        return world.method_8409().method_43057();
    }

    public static int nextBetween(class_1937 world, int min, int max) {
        return world.method_8409().method_39332(min, max);
    }

    public static int nextBetweenExclusive(class_1937 world, int min, int max) {
        return world.method_8409().method_43051(min, max);
    }
}
