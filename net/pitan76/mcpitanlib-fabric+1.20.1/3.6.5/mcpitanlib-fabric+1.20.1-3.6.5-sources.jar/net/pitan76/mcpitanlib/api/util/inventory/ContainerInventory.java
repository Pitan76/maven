package net.pitan76.mcpitanlib.api.util.inventory;

import net.minecraft.class_1703;

public class ContainerInventory<T extends class_1703> extends CompatInventory {

    public final T screenHandler;

    public ContainerInventory(T screenHandler, int size) {
        super(size);
        this.screenHandler = screenHandler;
    }

    public T getScreenHandler() {
        return screenHandler;
    }
}
