package net.pitan76.mcpitanlib.api.util;

import net.minecraft.class_1799;
import net.minecraft.class_1856;
import net.minecraft.class_2371;
import net.minecraft.class_2960;
import net.pitan76.mcpitanlib.api.recipe.CompatibleRecipeEntry;
import net.pitan76.mcpitanlib.api.recipe.v3.CompatRecipe;
import net.pitan76.mcpitanlib.midohra.recipe.entry.RecipeEntry;

public class CompatibleRecipeEntryUtil {
    public static CompatibleRecipeEntry createShapelessRecipe(class_2960 id, String group, RecipeUtil.CompatibilityCraftingRecipeCategory category, class_1799 output, class_2371<class_1856> input) {
        return new CompatibleRecipeEntry(id, group, category, RecipeUtil.createShapelessRecipe(id, group, category, output, input));
    }

    public static CompatibleRecipeEntry createShapelessRecipe(CompatIdentifier id, String group, RecipeUtil.CompatibilityCraftingRecipeCategory category, class_1799 output, class_2371<class_1856> input) {
        return createShapelessRecipe(id.toMinecraft(), group, category, output, input);
    }

    public static RecipeEntry createShapelessRecipeM(CompatIdentifier id, String group, RecipeUtil.CompatibilityCraftingRecipeCategory category, class_1799 output, class_2371<class_1856> input) {
        return RecipeEntry.of(RecipeUtil.createShapelessRecipe(id.toMinecraft(), group, category, output, input), id);
    }

    public static CompatRecipe createShapelessAsCompatRecipe(CompatIdentifier id, String group, RecipeUtil.CompatibilityCraftingRecipeCategory category, class_1799 output, class_2371<class_1856> input) {
        return new CompatRecipe(RecipeUtil.createShapelessRecipe(id.toMinecraft(), group, category, output, input), id.toMinecraft());
    }
}
