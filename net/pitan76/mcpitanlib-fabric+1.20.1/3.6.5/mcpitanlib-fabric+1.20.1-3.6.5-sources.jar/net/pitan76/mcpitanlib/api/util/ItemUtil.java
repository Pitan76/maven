package net.pitan76.mcpitanlib.api.util;

import net.minecraft.class_1747;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_2248;
import net.minecraft.class_2960;
import net.pitan76.mcpitanlib.api.item.CompatibleItemSettings;
import net.pitan76.mcpitanlib.api.tag.TagKey;
import net.pitan76.mcpitanlib.api.util.v1.ItemUtilV1;
import net.pitan76.mcpitanlib.api.util.v2.ItemUtilV2;

import java.util.List;

@Deprecated
public class ItemUtil {

    /**
     * Get item from Identifier.
     * @param id Identifier of the item.
     * @return Item of the Identifier.
     */
    public static class_1792 item(class_2960 id) {
        return ItemUtilV1.item(id);
    }

    /**
     * Check if two items are equal.
     * @param item Item to compare.
     * @param item2 Item to compare.
     * @return If two items are equal.
     */
    public static boolean isEqual(class_1792 item, class_1792 item2) {
        return ItemUtilV1.isEqual(item, item2);
    }

    /**
     * Check if the item is of the given item.
     * @param stack ItemStack to check.
     * @param item Item to check.
     * @return If the item is of the given item.
     */
    public static boolean isOf(class_1799 stack, class_1792 item) {
        return ItemUtilV1.isOf(stack, item);
    }

    /**
     * Check if the item is in the tag. (MCPitanLib TagKey)
     * @param stack ItemStack to check.
     * @param tagKey TagKey of the tag.
     * @return If the item is in the tag.
     */
    public static boolean isIn(class_1799 stack, TagKey<class_1792> tagKey) {
        return ItemUtilV1.isIn(stack, tagKey);
    }

    /**
     * Check if the item is in the tag. (MCPitanLib TagKey)
     * @param item Item to check.
     * @param tagKey TagKey of the tag.
     * @return If the item is in the tag.
     */
    public static boolean isIn(class_1792 item, TagKey<class_1792> tagKey) {
        return ItemUtilV1.isIn(item, tagKey);
    }

    /**
     * Check if the item is existed.
     * @param identifier Identifier of the item.
     * @return If the item is existed.
     */
    public static boolean isExist(class_2960 identifier) {
        return ItemUtilV1.isExist(identifier);
    }

    /**
     * Get Identifier from Item.
     * @param item Item to get Identifier.
     * @return Identifier of the Item.
     */
    public static class_2960 toID(class_1792 item) {
        return ItemUtilV1.toID(item);
    }

    /**
     * Get item from Identifier.
     * @param identifier Identifier of the item.
     * @return Item of the Identifier.
     */
    public static class_1792 fromId(class_2960 identifier) {
        return ItemUtilV1.fromId(identifier);
    }

    /**
     * Get CompatIdentifier from Item.
     * @param item Item to get CompatIdentifier.
     * @return CompatIdentifier of the Item.
     */
    public static CompatIdentifier toCompatID(class_1792 item) {
        return CompatIdentifier.fromMinecraft(toID(item));
    }

    /**
     * Get item from CompatIdentifier.
     * @param identifier CompatIdentifier of the item.
     * @return Item of the CompatIdentifier.
     */
    public static class_1792 fromId(CompatIdentifier identifier) {
        return fromId(identifier.toMinecraft());
    }

    /**
     * Check if the item is existed.
     * @param identifier CompatIdentifier of the item.
     * @return If the item is existed.
     */
    public static boolean isExist(CompatIdentifier identifier) {
        return isExist(identifier.toMinecraft());
    }

    /**
     * Create BlockItem from Block and Item.Settings.
     * @param block Block to create BlockItem.
     * @param settings Item.Settings to create BlockItem.
     * @return BlockItem created from Block and Item.Settings.
     */
    @Deprecated
    public static class_1747 ofBlock(class_2248 block, class_1792.class_1793 settings) {
        return ItemUtilV1.ofBlock(block, settings);
    }

    /**
     * Create BlockItem from Block and CompatibleItemSettings.
     * @param block Block to create BlockItem.
     * @param settings CompatibleItemSettings to create BlockItem.
     * @return BlockItem created from Block and CompatibleItemSettings.
     */
    public static class_1747 ofBlock(class_2248 block, CompatibleItemSettings settings) {
        return ItemUtilV1.ofBlock(block, settings);
    }

    /**
     * Create Item from Item.Settings.
     * @param settings Item.Settings to create Item.
     * @return Item created from Item.Settings.
     */
    @Deprecated
    public static class_1792 of(class_1792.class_1793 settings) {
        return ItemUtilV1.of(settings);
    }

    /**
     * Create Item from CompatibleItemSettings.
     * @param settings CompatibleItemSettings to create Item.
     * @return Item created from CompatibleItemSettings.
     */
    public static class_1792 of(CompatibleItemSettings settings) {
        return ItemUtilV1.of(settings);
    }

    /**
     * Get all items.
     * @return List of all items.
     */
    public static List<class_1792> getAllItems() {
        return ItemUtilV1.getAllItems();
    }

    /**
     * Get raw id of the item.
     * @param item Item to get raw id.
     * @return Raw id of the item.
     */
    public static int getRawId(class_1792 item) {
        return ItemUtilV1.getRawId(item);
    }

    /**
     * Get item from index.
     * @param index Index of the item.
     * @return Item of the index.
     */
    public static class_1792 fromIndex(int index) {
        return ItemUtilV1.fromIndex(index);
    }

    /**
     * Get all items in the tag. (MCPitanLib TagKey)
     * @param tagKey TagKey of the tag.
     * @return List of items in the tag.
     */
    public static List<class_1792> getItems(TagKey<class_1792> tagKey) {
        return ItemUtilV2.getItems(tagKey);
    }

    /**
     * Get given the list of items in the tag. (MCPitanLib TagKey)
     * @param tagKey TagKey of the tag.
     * @param items List of items to search.
     * @return List of items in the tag.
     */
    public static List<class_1792> getItems(TagKey<class_1792> tagKey, List<class_1792> items) {
        return ItemUtilV2.getItems(tagKey, items);
    }

    /**
     * Get all items in the tag.
     * @param identifier Identifier of the tag.
     * @return List of items in the tag.
     */
    public static List<class_1792> getItems(class_2960 identifier) {
        return ItemUtilV2.getItems(identifier);
    }

    /**
     * Get given the list of items in the tag.
     * @param identifier Identifier of the tag.
     * @param items List of items to search.
     * @return List of items in the tag.
     */
    public static List<class_1792> getItems(class_2960 identifier, List<class_1792> items) {
        return ItemUtilV2.getItems(identifier, items);
    }

    public static List<class_1792> getItems(CompatIdentifier identifier) {
        return getItems(identifier.toMinecraft());
    }

    public static List<class_1792> getItems(CompatIdentifier identifier, List<class_1792> items) {
        return getItems(identifier.toMinecraft(), items);
    }

    /**
     * Get all items in the tag.
     * @param id String of the tag.
     * @return List of items in the tag.
     */
    public static List<class_1792> getItems(String id) {
        return ItemUtilV2.getItems(id);
    }

    /**
     * Get given the list of items in the tag.
     * @param id String of the tag.
     * @param items List of items to search.
     * @return List of items in the tag.
     */
    public static List<class_1792> getItems(String id, List<class_1792> items) {
        return ItemUtilV2.getItems(id, items);
    }

    /**
     * Check if the item is in the tag.
     * @param item Item to check.
     * @param identifier Identifier of the tag.
     * @return If the item is in the tag.
     */
    public static boolean isItemInTag(class_1792 item, class_2960 identifier) {
        return ItemUtilV2.isItemInTag(item, identifier);
    }

    public static boolean isItemInTag(class_1792 item, CompatIdentifier identifier) {
        return isItemInTag(item, identifier.toMinecraft());
    }

    /**
     * Check if the item is in the tag.
     * @param item Item to check.
     * @param id String of the tag.
     * @return If the item is in the tag.
     */
    public static boolean isItemInTag(class_1792 item, String id) {
        return ItemUtilV2.isItemInTag(item, id);
    }
}
