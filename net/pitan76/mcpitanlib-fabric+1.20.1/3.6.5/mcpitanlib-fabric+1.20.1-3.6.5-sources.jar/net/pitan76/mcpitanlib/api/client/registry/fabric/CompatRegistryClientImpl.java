package net.pitan76.mcpitanlib.api.client.registry.fabric;

import net.fabricmc.fabric.api.client.rendering.v1.ColorProviderRegistry;
import net.minecraft.class_2248;
import net.minecraft.class_322;

public class CompatRegistryClientImpl {

    public static void registerColorProviderBlock(class_322 provider, class_2248... blocks) {
        if (blocks == null || blocks.length == 0) {
            ColorProviderRegistry.BLOCK.register(provider);
        } else {
            ColorProviderRegistry.BLOCK.register(provider, blocks);
        }
    }
}
