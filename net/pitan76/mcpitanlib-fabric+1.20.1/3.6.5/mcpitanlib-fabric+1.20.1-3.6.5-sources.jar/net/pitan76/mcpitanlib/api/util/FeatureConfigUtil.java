package net.pitan76.mcpitanlib.api.util;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import net.minecraft.class_2248;
import net.minecraft.class_2680;
import net.minecraft.class_2975;
import net.minecraft.class_3031;
import net.minecraft.class_3124;
import net.minecraft.class_3481;
import net.minecraft.class_3798;
import net.minecraft.class_3825;

public class FeatureConfigUtil {

    /**
     * Create a new ConfiguredFeature
     * @param oreFeatureConfig The ore feature config
     * @return The new ConfiguredFeature
     */
    public static class_2975<?, ?> createConfiguredFeature(class_3124 oreFeatureConfig) {
        return new class_2975<>(class_3031.field_13517, oreFeatureConfig);
    }

    /**
     * Create a new OreFeatureConfig
     * @param test The rule test
     * @param state The block state
     * @param size The size
     * @return The new OreFeatureConfig
     */
    public static class_3124 createOreFeatureConfig(class_3825 test, class_2680 state, int size) {
        return new class_3124(test, state, size);
    }

    /**
     * Create a new OreFeatureConfig
     * @param test The rule test
     * @param block The block
     * @param size The size
     * @return The new OreFeatureConfig
     */
    public static class_3124 createOreFeatureConfig(class_3825 test, class_2248 block, int size) {
        return createOreFeatureConfig(test, block.method_9564(), size);
    }

    /**
     * Create a new OreFeatureConfig
     * @param targets The targets
     * @param size The size
     * @return The new OreFeatureConfig
     */
    public static class_3124 createOreFeatureConfig(List<class_3124.class_5876> targets, int size) {
        return new class_3124(targets, size);
    }

    /**
     * Create a new OreFeatureConfig
     * @param targetMap The target map
     * @param size The size
     * @return The new OreFeatureConfig
     */
    public static class_3124 createOreFeatureConfig(Map<class_3825, class_2680> targetMap, int size) {
        List<class_3124.class_5876> targets = new ArrayList<>();
        targetMap.forEach((ruleTest, blockState) -> targets.add(class_3124.method_33994(ruleTest, blockState)));
        return createOreFeatureConfig(targets, size);
    }

    /**
     * Create a new OreFeatureConfig
     * @param state The block state
     * @param size The size
     * @return The new OreFeatureConfig
     */
    public static class_3124 createStoneOreFeatureConfig(class_2680 state, int size) {
        class_3825 ruleTest = new class_3798(class_3481.field_25806);
        return createOreFeatureConfig(ruleTest, state, size);
    }
}
