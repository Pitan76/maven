package net.pitan76.mcpitanlib.api.world;

import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.pitan76.mcpitanlib.api.util.WorldUtil;

public class ExtendWorld {
    public class_1937 world;
    public ExtendWorld(class_1937 world) {
        this.world = world;
    }

    public boolean isDay() {
        return WorldUtil.isDay(world);
    }

    public boolean isThundering() {
        return WorldUtil.isThundering(world);
    }

    public boolean isSkyVisible(class_2338 pos) {
        return WorldUtil.isSkyVisible(world, pos);
    }

    public boolean isRaining() {
        return WorldUtil.isRaining(world);
    }

    public boolean hasSkyLight() {
        return WorldUtil.hasSkyLight(world);
    }
    
    public boolean isNight() {
        return WorldUtil.isNight(world);
    }

    public boolean isClient() {
        return WorldUtil.isClient(world);
    }

    public boolean isServer() {
        return WorldUtil.isServer(world);
    }

    public class_1937 getMinecraftWorld() {
        return world;
    }
}
