package net.pitan76.mcpitanlib.api.util;

import net.minecraft.class_1282;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.pitan76.mcpitanlib.api.entity.Player;

public class DamageSourceUtil {
    public static class_1282 thrownProjectile(class_1297 projectile, class_1297 attacker, class_1297 source) {
        return source.method_48923().method_48811(projectile, attacker);
    }

    public static class_1282 thrownProjectile(class_1297 projectile, class_1297 attacker) {
        return thrownProjectile(projectile, attacker, projectile);
    }

    public static class_1282 playerAttack(Player attacker, class_1297 source) {
        return source.method_48923().method_48802(attacker.getPlayerEntity());
    }

    public static class_1282 playerAttack(Player attacker) {
        return playerAttack(attacker, attacker.getPlayerEntity());
    }

    public static class_1282 mobAttack(class_1309 attacker, class_1297 source) {
        return source.method_48923().method_48812(attacker);
    }

    public static class_1282 mobAttack(class_1309 attacker) {
        return mobAttack(attacker, attacker);
    }

    public static class_1282 mobProjectile(class_1297 projectile, class_1309 attacker, class_1297 source) {
        return source.method_48923().method_48800(projectile, attacker);
    }

    public static class_1282 mobProjectile(class_1297 projectile, class_1309 attacker) {
        return mobProjectile(projectile, attacker, projectile);
    }

    public static class_1282 fall(class_1297 source) {
        return source.method_48923().method_48827();
    }
}
