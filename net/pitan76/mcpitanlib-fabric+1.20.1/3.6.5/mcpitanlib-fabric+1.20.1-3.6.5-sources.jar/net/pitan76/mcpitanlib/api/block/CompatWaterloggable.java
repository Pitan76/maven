package net.pitan76.mcpitanlib.api.block;

import net.minecraft.class_3414;
import net.minecraft.class_3737;
import net.pitan76.mcpitanlib.api.sound.CompatSoundEvent;

import java.util.Optional;

public interface CompatWaterloggable extends class_3737 {

    @Override
    default Optional<class_3414> method_32351() {
        return getCompactBucketFillSound()
                .map(CompatSoundEvent::get);
    }

    default Optional<CompatSoundEvent> getCompactBucketFillSound() {
        return class_3737.super.method_32351()
                .map(CompatSoundEvent::of);
    }
}
