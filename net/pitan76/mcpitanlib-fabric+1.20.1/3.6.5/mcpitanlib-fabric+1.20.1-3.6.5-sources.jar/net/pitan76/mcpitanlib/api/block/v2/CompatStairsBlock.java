package net.pitan76.mcpitanlib.api.block.v2;

import net.minecraft.class_1922;
import net.minecraft.class_2338;
import net.minecraft.class_2510;
import net.minecraft.class_265;
import net.minecraft.class_2760;
import net.minecraft.class_2778;
import net.minecraft.class_3726;
import net.pitan76.mcpitanlib.api.block.args.v2.CollisionShapeEvent;
import net.pitan76.mcpitanlib.api.block.args.v2.OutlineShapeEvent;
import net.pitan76.mcpitanlib.api.state.property.*;
import net.pitan76.mcpitanlib.midohra.block.BlockState;

public class CompatStairsBlock extends net.pitan76.mcpitanlib.api.block.CompatStairsBlock {

    public static final DirectionProperty FACING = CompatProperties.ofDir(class_2510.field_11571);
    public static final EnumProperty<class_2760> HALF = CompatProperties.of(class_2510.field_11572);
    public static final EnumProperty<class_2778> SHAPE = CompatProperties.of(class_2510.field_11565);
    public static final BooleanProperty WATERLOGGED = CompatProperties.of(class_2510.field_11573);

    public static final BlockHalfProperty COMPAT_HALF = BlockHalfProperty.ofRaw(class_2510.field_11572);
    public static final StairShapeProperty COMPAT_SHAPE = StairShapeProperty.ofRaw(class_2510.field_11565);

    public CompatStairsBlock(net.minecraft.class_2680 baseBlockState, CompatibleBlockSettings settings) {
        super(baseBlockState, settings);
    }

    public CompatStairsBlock(BlockState baseBlockState, CompatibleBlockSettings settings) {
        this(baseBlockState.toMinecraft(), settings);
    }

    public class_265 getOutlineShape(OutlineShapeEvent e) {
        return super.method_9530(e.state.toMinecraft(), e.world.getRaw(), e.pos.toMinecraft(), e.context);
    }

    public class_265 getCollisionShape(CollisionShapeEvent e) {
        return super.method_9549(e.state.toMinecraft(), e.world.getRaw(), e.pos.toMinecraft(), e.context);
    }

    @Deprecated
    @Override
    public class_265 getOutlineShape(net.pitan76.mcpitanlib.api.event.block.OutlineShapeEvent e) {
        return getOutlineShape(new OutlineShapeEvent(e.state, e.world, e.pos, e.context));
    }

    @Deprecated
    @Override
    public class_265 method_9530(net.minecraft.class_2680 state, class_1922 world, class_2338 pos, class_3726 context) {
        return getOutlineShape(new OutlineShapeEvent(state, world, pos, context));
    }

    @Deprecated
    @Override
    public class_265 getOutlineShape(OutlineShapeEvent e, Options options) {
        return super.getOutlineShape(e, options);
    }

    @Override
    public class_265 method_9549(net.minecraft.class_2680 state, class_1922 world, class_2338 pos, class_3726 context) {
        return getCollisionShape(new CollisionShapeEvent(state, world, pos, context));
    }

    @Deprecated
    @Override
    public class_265 getCollisionShape(CollisionShapeEvent event, Options options) {
        return super.getCollisionShape(event, options);
    }
}
