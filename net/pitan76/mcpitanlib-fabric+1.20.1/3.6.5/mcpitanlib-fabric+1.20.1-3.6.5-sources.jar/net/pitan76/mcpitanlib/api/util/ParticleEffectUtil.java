package net.pitan76.mcpitanlib.api.util;

import net.minecraft.class_2394;
import net.minecraft.class_2396;
import net.pitan76.mcpitanlib.api.util.particle.effect.ItemStackParticleEffectUtil;

public class ParticleEffectUtil {
    public static ItemStackParticleEffectUtil itemStack = new ItemStackParticleEffectUtil();

    public static class_2396<?> getType(class_2394 effect) {
        return effect.method_10295();
    }
}
