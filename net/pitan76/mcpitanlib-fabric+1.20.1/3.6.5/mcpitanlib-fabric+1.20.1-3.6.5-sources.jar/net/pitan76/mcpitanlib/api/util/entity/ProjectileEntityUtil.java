package net.pitan76.mcpitanlib.api.util.entity;

import net.minecraft.class_1297;
import net.minecraft.class_1676;

public class ProjectileEntityUtil {
    public static void setVelocity(class_1676 projectileEntity, class_1297 shooter, float pitch, float yaw, float roll, float speed, float divergence) {
        projectileEntity.method_24919(shooter, pitch, yaw, roll, speed, divergence);
    }

    public static void setVelocity(class_1676 projectileEntity, double x, double y, double z, float power, float uncertainty) {
        projectileEntity.method_7485(x, y, z, power, uncertainty);
    }
}
