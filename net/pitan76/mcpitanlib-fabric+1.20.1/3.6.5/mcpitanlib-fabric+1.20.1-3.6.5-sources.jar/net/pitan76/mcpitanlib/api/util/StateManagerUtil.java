package net.pitan76.mcpitanlib.api.util;

import com.google.common.collect.ImmutableList;
import net.minecraft.class_2688;
import net.minecraft.class_2689;

public class StateManagerUtil {
    public static <T, S extends class_2688<T, S>> S getDefaultState(class_2689<T, S> manager) {
        return manager.method_11664();
    }

    public <T, S extends class_2688<T, S>> ImmutableList<S> getStates(class_2689<T, S> manager) {
        return manager.method_11662();
    }
}
