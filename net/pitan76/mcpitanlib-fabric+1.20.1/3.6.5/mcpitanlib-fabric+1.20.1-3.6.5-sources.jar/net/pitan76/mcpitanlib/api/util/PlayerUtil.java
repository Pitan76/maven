package net.pitan76.mcpitanlib.api.util;

import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.server.MinecraftServer;
import net.pitan76.mcpitanlib.api.entity.Player;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class PlayerUtil {

    public static Player getPlayerByUUID(MinecraftServer server, UUID uuid) {
        return new Player(server.method_3760().method_14602(uuid));
    }

    public static Player getPlayerByName(MinecraftServer server, String name) {
        return new Player(server.method_3760().method_14566(name));
    }

    public static List<Player> getPlayersByIP(MinecraftServer server, String ip) {
        List<Player> players = new ArrayList<>();
        for (class_1657 p: server.method_3760().method_14559(ip)) {
            players.add(new Player(p));
        }
        return players;
    }

    public static List<Player> getPlayers(MinecraftServer server) {
        List<Player> players = new ArrayList<>();
        for (class_1657 p : server.method_3760().method_14571()) {
            players.add(new Player(p));
        }
        return players;
    }

    public static Player getPlayerByUUID(class_1937 world, UUID uuid) {
        return getPlayerByUUID(world.method_8503(), uuid);
    }

    public static Player getPlayerByName(class_1937 world, String name) {
        return getPlayerByName(world.method_8503(), name);
    }

    public static boolean isExistByUUID(MinecraftServer server, UUID uuid) {
        return server.method_3760().method_14602(uuid) != null;
    }

    public static boolean isExistByUUID(class_1937 world, UUID uuid) {
        return isExistByUUID(world.method_8503(), uuid);
    }

    public static boolean isExistByName(MinecraftServer server, String name) {
        return server.method_3760().method_14566(name) != null;
    }

    public static boolean isExistByName(class_1937 world, String name) {
        return isExistByName(world.method_8503(), name);
    }

    public static boolean isExistByIP(MinecraftServer server, String ip) {
        return !server.method_3760().method_14559(ip).isEmpty();
    }

    public static boolean isExistByIP(class_1937 world, String ip) {
        return isExistByIP(world.method_8503(), ip);
    }
    
    public static void sendMessage(Player player, String message) {
        player.sendMessage(TextUtil.literal(message));
    }

    public static float getYaw(Player player) {
        return player.getYaw();
    }

    public static float getPitch(Player player) {
        return player.getPitch();
    }

    public static class_2338 getBlockPos(Player player) {
        return player.getBlockPos();
    }

    public static class_1937 getWorld(Player player) {
        return player.getWorld();
    }

    public static boolean isClient(Player player) {
        return player.isClient();
    }

    public static void teleport(Player player, double x, double y, double z) {
        player.teleport(x, y, z);
    }
}
