package net.pitan76.mcpitanlib.api.text;

import net.minecraft.class_124;
import net.pitan76.mcpitanlib.api.util.CompatStringIdentifiable;

public class CompatFormatting implements CompatStringIdentifiable {
    private final class_124 formatting;

    public static final CompatFormatting BLACK = of(class_124.field_1074);
    public static final CompatFormatting DARK_BLUE = of(class_124.field_1058);
    public static final CompatFormatting DARK_GREEN = of(class_124.field_1077);
    public static final CompatFormatting DARK_AQUA = of(class_124.field_1062);
    public static final CompatFormatting DARK_RED = of(class_124.field_1079);
    public static final CompatFormatting DARK_PURPLE = of(class_124.field_1064);
    public static final CompatFormatting GOLD = of(class_124.field_1065);
    public static final CompatFormatting GRAY = of(class_124.field_1080);
    public static final CompatFormatting DARK_GRAY = of(class_124.field_1063);
    public static final CompatFormatting BLUE = of(class_124.field_1078);
    public static final CompatFormatting GREEN = of(class_124.field_1060);
    public static final CompatFormatting AQUA = of(class_124.field_1075);
    public static final CompatFormatting RED = of(class_124.field_1061);
    public static final CompatFormatting LIGHT_PURPLE = of(class_124.field_1076);
    public static final CompatFormatting YELLOW = of(class_124.field_1054);
    public static final CompatFormatting WHITE = of(class_124.field_1068);
    public static final CompatFormatting OBFUSCATED = of(class_124.field_1051);
    public static final CompatFormatting BOLD = of(class_124.field_1067);
    public static final CompatFormatting STRIKETHROUGH = of(class_124.field_1055);
    public static final CompatFormatting UNDERLINE = of(class_124.field_1073);
    public static final CompatFormatting ITALIC = of(class_124.field_1056);
    public static final CompatFormatting RESET = of(class_124.field_1070);

    public CompatFormatting(class_124 formatting) {
        this.formatting = formatting;
    }

    public static CompatFormatting of(class_124 formatting) {
        return new CompatFormatting(formatting);
    }

    public class_124 getRaw() {
        return formatting;
    }

    @Override
    public String asString_compat() {
        return formatting.method_15434();
    }

    public boolean isColor() {
        return formatting.method_543();
    }

    public boolean isModifier() {
        return formatting.method_542();
    }

    public char getCode() {
        return formatting.method_36145();
    }

    public Integer getColorValue() {
        return formatting.method_532();
    }

    public int getColorIndex() {
        return formatting.method_536();
    }

    @Override
    public String toString() {
        return formatting.toString();
    }

    @Override
    public int hashCode() {
        return formatting.hashCode();
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        CompatFormatting other = (CompatFormatting) obj;
        return formatting.equals(other.formatting);
    }
}
