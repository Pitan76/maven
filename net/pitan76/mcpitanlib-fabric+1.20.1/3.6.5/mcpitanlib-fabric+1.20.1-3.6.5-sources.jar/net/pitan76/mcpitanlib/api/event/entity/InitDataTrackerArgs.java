package net.pitan76.mcpitanlib.api.event.entity;

import net.minecraft.class_2940;
import net.minecraft.class_2945;

public class InitDataTrackerArgs {
    public class_2945 tracker;

    public InitDataTrackerArgs(class_2945 tracker) {
        this.tracker = tracker;
    }

    public <T> void set(class_2940<T> data, T value) {
        tracker.method_12778(data, value);
    }

    public <T> void addTracking(class_2940<T> data, T value) {
        if (tracker != null) {
            set(data, value);
            return;
        }
    }
}
