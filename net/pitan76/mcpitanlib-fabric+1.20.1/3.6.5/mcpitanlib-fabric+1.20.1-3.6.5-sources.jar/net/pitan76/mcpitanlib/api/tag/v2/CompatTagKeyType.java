package net.pitan76.mcpitanlib.api.tag.v2;

import net.minecraft.class_1299;
import net.minecraft.class_1792;
import net.minecraft.class_2248;
import net.minecraft.class_2378;
import net.minecraft.class_2591;
import net.minecraft.class_3611;
import net.minecraft.class_3917;
import net.minecraft.class_5321;
import net.minecraft.class_7924;
import net.pitan76.mcpitanlib.api.util.CompatIdentifier;

public class CompatTagKeyType<T> {
    public static final CompatTagKeyType<class_2248> BLOCK = of(class_7924.field_41254);
    public static final CompatTagKeyType<class_1792> ITEM = new CompatTagKeyType<>(class_7924.field_41197);
    public static final CompatTagKeyType<class_3611> FLUID = new CompatTagKeyType<>(class_7924.field_41270);
    public static final CompatTagKeyType<class_1299<?>> ENTITY_TYPE = new CompatTagKeyType<>(class_7924.field_41266);
    public static final CompatTagKeyType<class_2591<?>> BLOCK_ENTITY_TYPE = new CompatTagKeyType<>(class_7924.field_41255);
    public static final CompatTagKeyType<class_3917<?>> SCREEN_HANDLER = new CompatTagKeyType<>(class_7924.field_41207);

    public final CompatIdentifier id;

    protected CompatTagKeyType(CompatIdentifier id) {
        this.id = id;
    }

    public static <T> CompatTagKeyType<T> of(CompatIdentifier id) {
        return new CompatTagKeyType<>(id);
    }

    // RegistryKey
    private class_5321<class_2378<T>> key;

    protected CompatTagKeyType(class_5321<class_2378<T>> key) {
        this.id = CompatIdentifier.fromMinecraft(key.method_41185());
        this.key = key;
    }

    public static <T> CompatTagKeyType<T> of(class_5321<class_2378<T>> key) {
        return new CompatTagKeyType<>(key);
    }

    @Deprecated
    public class_5321<class_2378<T>> getRegistryKey() {
        return key;
    }
}
