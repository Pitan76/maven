package net.pitan76.mcpitanlib.api.entity;

import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_2487;
import net.minecraft.class_2596;
import net.minecraft.class_2602;
import net.minecraft.class_3218;
import net.pitan76.mcpitanlib.api.event.entity.InitDataTrackerArgs;
import net.pitan76.mcpitanlib.api.event.nbt.ReadNbtArgs;
import net.pitan76.mcpitanlib.api.event.nbt.WriteNbtArgs;
import net.pitan76.mcpitanlib.midohra.util.math.Vector3d;

public class CompatEntity extends class_1297 {
    public CompatEntity(class_1299<?> type, class_1937 world) {
        super(type, world);
    }

    @Deprecated
    @Override
    public void method_5693() {
        initDataTracker(new InitDataTrackerArgs(field_6011));
    }

    public void initDataTracker(InitDataTrackerArgs args) {

    }

    public void readCustomDataFromNbt(ReadNbtArgs nbt) {

    }

    public void writeCustomDataToNbt(WriteNbtArgs nbt) {

    }

    @Deprecated
    @Override
    public void method_5749(class_2487 nbt) {
        readCustomDataFromNbt(new ReadNbtArgs(nbt));
    }

    @Deprecated
    @Override
    public void method_5652(class_2487 nbt) {
        writeCustomDataToNbt(new WriteNbtArgs(nbt));
    }

    public class_2596<class_2602> method_18002() {
        return null;
    }

    public void writeNbt(WriteNbtArgs args) {
        super.method_5647(args.getNbt());
    }

    public void readNbt(ReadNbtArgs args) {
        super.method_5651(args.getNbt());
    }

    @Deprecated
    @Override
    public class_2487 method_5647(class_2487 nbt) {
        writeNbt(new WriteNbtArgs(nbt));
        return nbt;
    }

    @Deprecated
    @Override
    public void method_5651(class_2487 nbt) {
        readNbt(new ReadNbtArgs(nbt));
    }

    @Deprecated
    @Override
    public class_1937 method_37908() {
        return callGetWorld();
    }

    public class_1937 callGetWorld() {
        return super.method_37908();
    }

    public class_2338 callGetBlockPos() {
        return method_24515();
    }

    public class_243 callGetPos() {
        return method_19538();
    }

    public boolean hasServerWorld() {
        return callGetWorld() instanceof class_3218;
    }

    public class_3218 getServerWorld() {
        return (class_3218) method_37908();
    }

    public net.pitan76.mcpitanlib.midohra.world.World getMidohraWorld() {
        return net.pitan76.mcpitanlib.midohra.world.World.of(callGetWorld());
    }

    public net.pitan76.mcpitanlib.midohra.util.math.BlockPos getMidohraBlockPos() {
        return net.pitan76.mcpitanlib.midohra.util.math.BlockPos.of(callGetBlockPos());
    }

     public Vector3d getMidohraPos() {
        return Vector3d.of(callGetPos());
     }

     public net.pitan76.mcpitanlib.midohra.world.ServerWorld getMidohraServerWorld() {
         return net.pitan76.mcpitanlib.midohra.world.ServerWorld.of(getServerWorld());
     }
}