package net.pitan76.mcpitanlib.api.client;

import net.minecraft.class_2561;
import net.minecraft.class_315;
import net.minecraft.class_437;

public class SimpleOptionsScreen extends SimpleScreen {

    protected final class_437 parent;
    protected final class_315 gameOptions;

    public SimpleOptionsScreen(class_2561 title, class_437 parent, class_315 gameOptions) {
        super(title);
        this.parent = parent;
        this.gameOptions = gameOptions;
    }

    @Override
    public void method_25432() {
        field_22787.field_1690.method_1640();
    }

    @Override
    public void method_25419() {
        field_22787.method_1507(this.parent);
    }
}
