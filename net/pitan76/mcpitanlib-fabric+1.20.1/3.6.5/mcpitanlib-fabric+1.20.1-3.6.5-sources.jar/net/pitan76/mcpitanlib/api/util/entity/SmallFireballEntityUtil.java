package net.pitan76.mcpitanlib.api.util.entity;

import net.minecraft.class_1677;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_243;

public class SmallFireballEntityUtil {
    public static class_1677 create(class_1937 world, double x, double y, double z, double velocityX, double velocityY, double velocityZ) {
        return new class_1677(world, x, y, z, velocityX, velocityY, velocityZ);
    }

    public static class_1677 create(class_1937 world, double x, double y, double z, class_243 velocity) {
        return create(world, x, y, z, velocity.field_1352, velocity.field_1351, velocity.field_1350);
    }

    public static void setVelocity(class_1677 entity, double x, double y, double z, float velocity, float divergence) {
        entity.method_7485(x, y, z, velocity, divergence);
    }

    public static void setItem(class_1677 entity, class_1799 stack) {
        entity.method_16936(stack);
    }

    public static class_1799 getItem(class_1677 entity) {
        return entity.method_7495();
    }
}
