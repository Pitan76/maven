package net.pitan76.mcpitanlib.api.util.math;

import net.minecraft.class_2382;

public class Vec3iUtil {
    public static class_2382 create(int x, int y, int z) {
        return new class_2382(x, y, z);
    }

    public static class_2382 add(class_2382 a, class_2382 b) {
        return a.method_35853(b);
    }

    public static class_2382 subtract(class_2382 a, class_2382 b) {
        return a.method_35852(b);
    }

    public static class_2382 multiply(class_2382 a, int b) {
        return a.method_35862(b);
    }

    public static class_2382 cross(class_2382 a, class_2382 b) {
        return a.method_10259(b);
    }

    public static class_2382 add(class_2382 a, int x, int y, int z) {
        return a.method_34592(x, y, z);
    }

    public static class_2382 subtract(class_2382 a, int x, int y, int z) {
        return a.method_34592(-x, -y, -z);
    }
}
