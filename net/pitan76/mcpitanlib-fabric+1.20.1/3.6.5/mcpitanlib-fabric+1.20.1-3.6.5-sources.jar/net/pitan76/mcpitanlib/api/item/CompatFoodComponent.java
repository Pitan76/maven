package net.pitan76.mcpitanlib.api.item;

import com.mojang.datafixers.util.Pair;
import net.minecraft.class_1293;
import net.minecraft.class_4174;
import net.pitan76.mcpitanlib.api.entity.effect.CompatStatusEffectInstance;

import java.util.ArrayList;
import java.util.List;

public class CompatFoodComponent {
    private int hunger;
    private float saturation;
    private boolean meat;
    private boolean alwaysEdible;
    private boolean snack;
    private final List<Pair<class_1293, Float>> statusEffects = new ArrayList<>();

    private class_4174 latestComponent = null;

    public static CompatFoodComponent create() {
        return new CompatFoodComponent();
    }

    public CompatFoodComponent setHunger(int hunger) {
        this.hunger = hunger;
        return this;
    }

    public CompatFoodComponent setSaturation(float saturation) {
        this.saturation = saturation;
        return this;
    }

    public CompatFoodComponent setAlwaysEdible() {
        this.alwaysEdible = true;
        return this;
    }

    public CompatFoodComponent setSnack() {
        this.snack = true;
        return this;
    }

    public CompatFoodComponent setMeat() {
        this.meat = true;
        return this;
    }

    @Deprecated
    public CompatFoodComponent addStatusEffect(class_1293 effect, float chance) {
        statusEffects.add(Pair.of(effect, chance));
        return this;
    }

    public CompatFoodComponent addStatusEffect(CompatStatusEffectInstance instance, float chance) {
        return addStatusEffect(instance.getInstance(), chance);
    }

    public class_4174.class_4175 getVanillaBuilder() {
        class_4174.class_4175 builder = new class_4174.class_4175();
        builder.method_19238(hunger).method_19237(saturation);
        if (alwaysEdible) builder.method_19240();
        if (snack) builder.method_19241();
        if (meat) builder.method_19236();
        for (Pair<class_1293, Float> pair : statusEffects) {
            builder.method_19239(pair.getFirst(), pair.getSecond());
        }
        return builder;
    }

    public class_4174 build() {
        return vanillaBuild();
    }

    public class_4174 vanillaBuild() {
        if (latestComponent != null) return latestComponent;

        latestComponent = getVanillaBuilder().method_19242();
        return latestComponent;
    }

    // ----

    public int getHunger() {
        return hunger;
    }

    public float getSaturation() {
        return saturation;
    }

    public boolean isMeat() {
        return meat;
    }

    public boolean isSnack() {
        return snack;
    }

    public boolean isAlwaysEdible() {
        return alwaysEdible;
    }

    @Deprecated
    public List<Pair<class_1293, Float>> getStatusEffects() {
        return statusEffects;
    }

    public List<Pair<CompatStatusEffectInstance, Float>> getCompatStatusEffects() {
        List<Pair<CompatStatusEffectInstance, Float>> compatStatusEffects = new ArrayList<>();
        for (Pair<class_1293, Float> pair : statusEffects) {
            compatStatusEffects.add(Pair.of(new CompatStatusEffectInstance(pair.getFirst()), pair.getSecond()));
        }
        return compatStatusEffects;
    }
}
