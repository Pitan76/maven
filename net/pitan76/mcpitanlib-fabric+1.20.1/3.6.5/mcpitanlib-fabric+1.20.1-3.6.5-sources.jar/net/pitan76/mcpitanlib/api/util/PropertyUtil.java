package net.pitan76.mcpitanlib.api.util;

import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_2741;
import net.minecraft.class_2746;
import net.minecraft.class_2754;
import net.minecraft.class_2758;
import net.minecraft.class_2760;
import net.minecraft.class_2769;
import net.minecraft.class_2778;
import net.minecraft.class_3542;
import net.minecraft.state.property.*;
import net.pitan76.mcpitanlib.api.event.block.AppendPropertiesArgs;
import net.pitan76.mcpitanlib.api.state.property.CompatProperties;
import net.pitan76.mcpitanlib.api.state.property.DirectionProperty;

public class PropertyUtil {
    public static class_2746 createBooleanProperty(String name) {
        return class_2746.method_11825(name);
    }

    public static DirectionProperty createDirectionProperty(String name) {
        return DirectionProperty.of(name);
    }

    public static class_2758 createIntProperty(String name, int min, int max) {
        return class_2758.method_11867(name, min, max);
    }

    public static <T extends Enum<T> & class_3542> class_2754<T> createEnumProperty(String name, Class<T> type) {
        return class_2754.method_11850(name, type);
    }

    public static class_2680 with(class_2680 state, class_2746 property, boolean value) {
        return state.method_11657(property, value);
    }

    public static class_2680 with(class_2680 state, class_2758 property, int value) {
        return state.method_11657(property, value);
    }

    public static class_2680 with(class_2680 state, DirectionProperty property, class_2350 value) {
        return property.with(state, value);
    }

    public static boolean get(class_2680 state, class_2746 property) {
        return state.method_11654(property);
    }

    public static int get(class_2680 state, class_2758 property) {
        return state.method_11654(property);
    }

    public static class_2350 get(class_2680 state, DirectionProperty property) {
        return property.get(state);
    }

    public static net.pitan76.mcpitanlib.midohra.util.math.Direction getAsMidohra(class_2680 state, DirectionProperty property) {
        return net.pitan76.mcpitanlib.midohra.util.math.Direction.of(property.get(state));
    }

    public static class_2350 getFacing(class_2680 state) {
        return facing().get(state);
    }

    public static class_2350 getHorizontalFacing(class_2680 state) {
        return horizontalFacing().get(state);
    }

    public static int getPower(class_2680 state) {
        return state.method_11654(power());
    }

    public static boolean isPowered(class_2680 state) {
        return state.method_11654(powered());
    }

    public static void append(AppendPropertiesArgs args, class_2769<?>... properties) {
        args.addProperty(properties);
    }

    public static void appendFacing(AppendPropertiesArgs args) {
        facing().apply(args);
    }

    public static void appendHorizontalFacing(AppendPropertiesArgs args) {
        horizontalFacing().apply(args);
    }

    public static void appendPower(AppendPropertiesArgs args) {
        args.addProperty(power());
    }

    public static void appendPowered(AppendPropertiesArgs args) {
        args.addProperty(powered());
    }

    public static class_2758 power() {
        return class_2741.field_12511;
    }

    public static class_2746 powered() {
        return class_2741.field_12484;
    }

    public static DirectionProperty facing() {
        return CompatProperties.FACING;
    }

    public static DirectionProperty horizontalFacing() {
        return CompatProperties.HORIZONTAL_FACING;
    }

    public static class_2754<class_2350.class_2351> axis() {
        return class_2741.field_12496;
    }

    public static class_2754<class_2760> blockHalf() {
        return class_2741.field_12518;
    }

    public static class_2754<class_2778> stairShape() {
        return class_2741.field_12503;
    }

    public static class_2746 lit() {
        return class_2741.field_12548;
    }

    public static class_2746 waterlogged() {
        return class_2741.field_12508;
    }

    public static class_2746 attached() {
        return class_2741.field_12493;
    }

    public static class_2746 hanging() {
        return class_2741.field_16561;
    }

    public static class_2746 bottom() {
        return class_2741.field_16562;
    }

    public static class_2746 conditional() {
        return class_2741.field_12486;
    }

    public static class_2746 inWall() {
        return class_2741.field_12491;
    }

    public static class_2746 open() {
        return class_2741.field_12537;
    }

    public static class_2746 occupied() {
        return class_2741.field_12528;
    }

    public static boolean contains(class_2680 state, class_2769<?> property) {
        return state.method_28498(property);
    }
}
