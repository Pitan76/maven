package net.pitan76.mcpitanlib.api.event.block;

import java.util.function.Function;
import net.minecraft.class_265;
import net.minecraft.class_2680;

public class ShapesForStatesArgs {
    public Function<class_2680, class_265> stateToShape;

    public ShapesForStatesArgs(Function<class_2680, class_265> stateToShape) {
        this.stateToShape = stateToShape;
    }

    public Function<class_2680, class_265> getStateToShape() {
        return stateToShape;
    }

    public class_265 getShape(class_2680 state) {
        return stateToShape.apply(state);
    }
}
