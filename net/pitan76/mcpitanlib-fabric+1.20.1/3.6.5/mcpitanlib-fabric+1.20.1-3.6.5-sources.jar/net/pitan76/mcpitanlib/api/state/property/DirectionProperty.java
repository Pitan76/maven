package net.pitan76.mcpitanlib.api.state.property;

import net.minecraft.class_2350;
import net.minecraft.class_2754;
import net.minecraft.class_2769;
import net.pitan76.mcpitanlib.midohra.block.BlockState;

import java.util.function.Predicate;

public class DirectionProperty implements IProperty<class_2350> {

    private final class_2754<class_2350> property;

    public DirectionProperty(String name, Predicate<class_2350> filter) {
        this(class_2754.method_11848(name, class_2350.class, filter));
    }

    public DirectionProperty(String name) {
        this(name, direction -> true);
    }

    public DirectionProperty(class_2754<class_2350> property) {
        this.property = property;
    }

    public static DirectionProperty of(String name) {
        return new DirectionProperty(name);
    }

    public static DirectionProperty of(String name, Predicate<class_2350> filter) {
        return new DirectionProperty(name, filter);
    }

    public net.pitan76.mcpitanlib.midohra.util.math.Direction getAsMidohra(BlockState state) {
        return net.pitan76.mcpitanlib.midohra.util.math.Direction.of(get(state.toMinecraft()));
    }

    public BlockState with(BlockState state, net.pitan76.mcpitanlib.midohra.util.math.Direction value) {
        return BlockState.of(with(state.toMinecraft(), value.toMinecraft()));
    }

    public BlockState cycle(BlockState state) {
        return BlockState.of(cycle(state.toMinecraft()));
    }

    @Override
    public class_2769<class_2350> getProperty() {
        return property;
    }
}
