package net.pitan76.mcpitanlib.api.util.block.properties;

import net.minecraft.class_2760;
import net.pitan76.mcpitanlib.api.util.CompatStringIdentifiable;

public class CompatBlockHalf implements CompatStringIdentifiable {
    private final class_2760 blockHalf;

    public static final CompatBlockHalf TOP = of(class_2760.field_12619);
    public static final CompatBlockHalf BOTTOM = of(class_2760.field_12617);

    public CompatBlockHalf(class_2760 blockHalf) {
        this.blockHalf = blockHalf;
    }

    public static CompatBlockHalf of(class_2760 blockHalf) {
        return new CompatBlockHalf(blockHalf);
    }

    public class_2760 getBlockHalf() {
        return blockHalf;
    }

    public String getName() {
        return blockHalf.name();
    }

    @Override
    public String asString_compat() {
        return getName();
    }

    @Override
    public int hashCode() {
        return blockHalf.hashCode();
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        CompatBlockHalf other = (CompatBlockHalf) obj;
        return blockHalf == other.blockHalf;
    }
}
