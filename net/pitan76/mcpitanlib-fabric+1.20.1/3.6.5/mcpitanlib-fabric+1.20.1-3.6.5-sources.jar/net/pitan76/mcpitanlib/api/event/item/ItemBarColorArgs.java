package net.pitan76.mcpitanlib.api.event.item;

import net.minecraft.class_1799;

public class ItemBarColorArgs {

    public class_1799 stack;

    public ItemBarColorArgs(class_1799 stack) {
        this.stack = stack;
    }

    public class_1799 getStack() {
        return stack;
    }
}
