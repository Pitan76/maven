package net.pitan76.mcpitanlib.api.event.item;

import net.minecraft.class_1268;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.pitan76.mcpitanlib.api.entity.Player;
import net.pitan76.mcpitanlib.api.event.BaseEvent;
import net.pitan76.mcpitanlib.api.util.CompatActionResult;
import net.pitan76.mcpitanlib.midohra.item.ItemWrapper;

public class ItemUseOnEntityEvent extends BaseEvent {

    public class_1799 stack;
    public Player user;
    public class_1309 entity;
    public class_1268 hand;

    public ItemUseOnEntityEvent(class_1799 stack, class_1657 user, class_1309 entity, class_1268 hand) {
        this.stack = stack;
        this.user = new Player(user);
        this.hand = hand;
        this.entity = entity;
    }

    public ItemUseOnEntityEvent(class_1799 stack, Player user, class_1309 entity, class_1268 hand) {
        this.stack = stack;
        this.user = user;
        this.hand = hand;
        this.entity = entity;
    }

    public class_1799 getStack() {
        return stack;
    }

    public class_1268 getHand() {
        return hand;
    }

    public Player getUser() {
        return user;
    }

    public class_1309 getEntity() {
        return entity;
    }

    public boolean isClient() {
        return user.isClient();
    }

    public CompatActionResult success() {
        return CompatActionResult.SUCCESS;
    }

    public CompatActionResult fail() {
        return CompatActionResult.FAIL;
    }

    public CompatActionResult pass() {
        return CompatActionResult.PASS;
    }

    public CompatActionResult consume() {
        return CompatActionResult.CONSUME;
    }

    public boolean isSneaking() {
        return user.isSneaking();
    }

    public net.pitan76.mcpitanlib.midohra.item.ItemStack getStackM() {
        return net.pitan76.mcpitanlib.midohra.item.ItemStack.of(stack);
    }

    public class_1792 getItem() {
        return stack.method_7909();
    }

    public ItemWrapper getItemWrapper() {
        return ItemWrapper.of(getItem());
    }
}
