package net.pitan76.mcpitanlib.api.util;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.server.MinecraftServer;
import net.pitan76.mcpitanlib.api.entity.Player;
import net.pitan76.mcpitanlib.core.command.CommandResult;

public class CommandManagerUtil {
    public static class_2170 getCommandManager(MinecraftServer server) {
        return server.method_3734();
    }

    public static CommandResult execute(MinecraftServer server, String command) {
        CommandDispatcher<class_2168> dispatcher = getCommandManager(server).method_9235();
        class_2168 source = server.method_3739();

        if (command.startsWith("/")) {
            command = command.substring(1);
        }

        CommandResult cr = new CommandResult();
        cr.setSuccess(false);
        cr.setSource(source);

        try {
            int result = dispatcher.execute(command, source);
            cr.setResult(result);
            cr.setSuccess(true);
        } catch (CommandSyntaxException e) {
            cr.setMessage(e.getMessage());
            cr.setErrorType(CommandResult.ErrorType.COMMAND_SYNTAX_ERROR);
        } catch (RuntimeException e) {
            cr.setMessage(e.getMessage());
            cr.setErrorType(CommandResult.ErrorType.RUNTIME_ERROR);
        }

        return cr;
    }

    public static CommandResult execute(class_2168 source, String command) {
        CommandDispatcher<class_2168> dispatcher = source.method_9211().method_3734().method_9235();

        if (command.startsWith("/")) {
            command = command.substring(1);
        }

        CommandResult cr = new CommandResult();
        cr.setSuccess(false);
        cr.setSource(source);

        try {
            int result = dispatcher.execute(command, source);
            cr.setResult(result);
            cr.setSuccess(true);
        } catch (CommandSyntaxException e) {
            cr.setMessage(e.getMessage());
            cr.setErrorType(CommandResult.ErrorType.COMMAND_SYNTAX_ERROR);
        } catch (RuntimeException e) {
            cr.setMessage(e.getMessage());
            cr.setErrorType(CommandResult.ErrorType.RUNTIME_ERROR);
        }

        return cr;
    }

    public static CommandResult execute(Player player, String command) {
        return execute(getCommandSource(player), command);
    }

    public static class_2168 getCommandSource(MinecraftServer server) {
        return server.method_3739();
    }

    public static class_2168 getCommandSource(Player player) {
        return player.getEntity().method_5671();
    }

    public static class_2168 withLevel(class_2168 source, int level) {
        return source.method_9206(level);
    }
}
