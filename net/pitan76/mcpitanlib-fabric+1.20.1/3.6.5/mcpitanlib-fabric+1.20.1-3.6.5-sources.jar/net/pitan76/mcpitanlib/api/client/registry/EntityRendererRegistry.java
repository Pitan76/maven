package net.pitan76.mcpitanlib.api.client.registry;

import java.util.function.Supplier;
import net.minecraft.class_1299;
import net.minecraft.class_897;
import net.minecraft.class_953;

public class EntityRendererRegistry {
    public static void registerEntityRendererAsFlyingItem(Supplier<class_1299<?>> entityType) {
        CompatRegistryClient.registerEntityRenderer(entityType, (ctx -> (class_897) new class_953<>(ctx)));
    }
}
