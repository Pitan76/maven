package net.pitan76.mcpitanlib.api.util.screen;

import org.jetbrains.annotations.Nullable;

import java.util.Set;
import net.minecraft.class_1263;
import net.minecraft.class_1703;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_2586;

public class ScreenHandlerUtil {
    public static int calcComparatorOutput(@Nullable class_1263 inventory) {
        return class_1703.method_7618(inventory);
    }

    public static int calcComparatorOutput(@Nullable class_2586 blockEntity) {
        return class_1703.method_7608(blockEntity);
    }

    public static int calculateStackSize(Set<class_1735> slots, int mode, class_1799 stack) {
        return class_1703.method_7617(slots, mode, stack);
    }

    public static boolean canInsertItemIntoSlot(@Nullable class_1735 slot, class_1799 stack, boolean allowOverflow) {
        return class_1703.method_7592(slot, stack, allowOverflow);
    }
}
