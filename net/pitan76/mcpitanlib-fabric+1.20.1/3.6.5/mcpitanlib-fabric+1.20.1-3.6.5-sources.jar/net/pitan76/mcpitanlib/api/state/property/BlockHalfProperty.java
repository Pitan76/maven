package net.pitan76.mcpitanlib.api.state.property;

import net.minecraft.class_2760;
import net.pitan76.mcpitanlib.api.util.block.properties.CompatBlockHalf;
import net.pitan76.mcpitanlib.midohra.block.BlockState;

import java.util.function.Predicate;

public class BlockHalfProperty extends EnumProperty<class_2760> {

    public BlockHalfProperty(String name, Class<class_2760> type) {
        super(name, type);
    }

    public BlockHalfProperty(String name, Class<class_2760> type, Predicate<class_2760> filter) {
        super(name, type, filter);
    }

    public BlockHalfProperty(net.minecraft.class_2754<class_2760> property) {
        super(property);
    }

    public static BlockHalfProperty ofRaw(net.minecraft.class_2754<class_2760> property) {
        return new BlockHalfProperty(property);
    }

    public BlockState with(BlockState state, CompatBlockHalf value) {
        return super.with(state, value.getBlockHalf());
    }

    public CompatBlockHalf getCompat(BlockState state) {
        return CompatBlockHalf.of(super.get(state));
    }
}
