package net.pitan76.mcpitanlib.api.util.world;

import net.minecraft.class_1937;
import net.minecraft.class_3215;
import net.minecraft.class_3218;
import net.pitan76.mcpitanlib.midohra.util.math.BlockPos;

public class ChunkManagerUtil {

    public static void markForUpdate(class_3215 manager, BlockPos pos) {
        markForUpdate(manager, pos.toRaw());
    }

    public static void markForUpdate(class_3215 manager, net.minecraft.class_2338 pos) {
        manager.method_14128(pos);
    }

    public static void markForUpdate(class_3218 world, net.minecraft.class_2338 pos) {
       markForUpdate(ServerWorldUtil.getChunkManager(world), pos);
    }

    public static void markForUpdate(class_1937 world, net.minecraft.class_2338 pos) {
        if (!(world instanceof class_3218)) return;
        markForUpdate((class_3218) world, pos);
    }
}
