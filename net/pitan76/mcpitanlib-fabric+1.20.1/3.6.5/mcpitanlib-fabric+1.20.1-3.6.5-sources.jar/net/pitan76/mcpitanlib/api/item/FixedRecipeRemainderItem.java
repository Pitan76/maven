package net.pitan76.mcpitanlib.api.item;

import net.minecraft.class_1799;

public interface FixedRecipeRemainderItem {
    class_1799 getFixedRecipeRemainder(class_1799 stack);
}
