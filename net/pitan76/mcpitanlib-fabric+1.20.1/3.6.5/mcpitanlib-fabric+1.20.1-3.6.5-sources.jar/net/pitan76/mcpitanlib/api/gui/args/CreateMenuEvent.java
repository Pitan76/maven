package net.pitan76.mcpitanlib.api.gui.args;

import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1937;
import net.pitan76.mcpitanlib.api.entity.Player;

public class CreateMenuEvent {
    public int syncId;
    public class_1661 playerInventory;
    public class_1657 player;

    public CreateMenuEvent(int syncId, class_1661 playerInventory, class_1657 player) {
        this.syncId = syncId;
        this.playerInventory = playerInventory;
        this.player = player;
    }

    public CreateMenuEvent(int syncId, class_1661 playerInventory) {
        this.syncId = syncId;
        this.playerInventory = playerInventory;
        this.player = playerInventory.field_7546;
    }

    public CreateMenuEvent(int syncId, Player player) {
        this.syncId = syncId;
        this.playerInventory = player.getInv();
        this.player = player.getEntity();
    }

    public int getSyncId() {
        return syncId;
    }

    public class_1661 getPlayerInventory() {
        return playerInventory;
    }

    public class_1657 getPlayerEntity() {
        return player;
    }

    public Player getPlayer() {
        return new Player(player);
    }

    public boolean isExistPlayer() {
        return player != null;
    }

    public boolean isClient() {
        return getPlayer().isClient();
    }

    public class_1937 getWorld() {
        return getPlayer().getWorld();
    }
}
