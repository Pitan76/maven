package net.pitan76.mcpitanlib.api.util;

import net.minecraft.class_1799;
import net.minecraft.class_1887;
import net.minecraft.class_1890;
import net.minecraft.class_1937;
import net.minecraft.class_2487;
import net.minecraft.class_2960;
import net.minecraft.class_7923;
import net.pitan76.mcpitanlib.api.enchantment.CompatEnchantment;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class EnchantmentUtil {
    public static CompatEnchantment getEnchantment(class_2960 identifier) {
        return new CompatEnchantment(class_7923.field_41176.method_10223(identifier));
    }

    public static class_2960 getId(CompatEnchantment enchantment) {
        return enchantment.getId();
    }

    public static int getLevel(CompatEnchantment enchantment, class_1799 stack, @Nullable class_1937 world) {
        return enchantment.getLevel(stack, world);
    }

    // CompatIdentifier
    public static CompatEnchantment getEnchantment(CompatIdentifier identifier) {
        return getEnchantment(identifier.toMinecraft());
    }

    public static CompatIdentifier getCompatId(CompatEnchantment enchantment) {
        return CompatIdentifier.fromMinecraft(enchantment.getId());
    }

    public static List<CompatEnchantment> getEnchantments(class_1799 stack) {
        List<CompatEnchantment> enchantments = new ArrayList<>();

        class_1890.method_8222(stack).forEach((key, value) -> {
            enchantments.add(new CompatEnchantment(key));
        });

        return enchantments;
    }

    public static boolean hasEnchantment(class_1799 stack) {
        return stack.method_7942();
    }

    public static Map<CompatEnchantment, Integer> getEnchantment(class_1799 stack, @Nullable class_1937 world) {
        Map<CompatEnchantment, Integer> enchantments = new HashMap<>();

        List<CompatEnchantment> enchantmentList = getEnchantments(stack);
        enchantmentList.forEach((enchantment) -> {
            enchantments.put(enchantment, getLevel(enchantment, stack, world));
        });

        return enchantments;
    }

    public static void setEnchantment(class_1799 stack, Map<CompatEnchantment, Integer> enchantments, @Nullable class_1937 world) {
        Map<class_1887, Integer> enchantmentMap = new HashMap<>();

        enchantments.forEach((key, value) -> enchantmentMap.put(key.getEnchantment(world), value));

        class_1890.method_8214(enchantmentMap, stack);
    }

    public static void removeEnchantment(class_1799 stack) {
        if (!stack.method_7985()) return;
        class_2487 nbt = stack.method_7969();
        if (nbt.method_10545("enchantments"))
            stack.method_7983("enchantments");
        if (nbt.method_10545("stored_enchantments"))
            stack.method_7983("stored_enchantments");
        if (nbt.method_10545("Enchantments"))
            stack.method_7983("Enchantments");
        if (nbt.method_10545("StoredEnchantments"))
            stack.method_7983("StoredEnchantments");
    }
}
