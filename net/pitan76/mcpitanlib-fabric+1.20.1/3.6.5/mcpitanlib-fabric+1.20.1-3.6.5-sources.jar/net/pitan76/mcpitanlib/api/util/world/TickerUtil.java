package net.pitan76.mcpitanlib.api.util.world;

import net.minecraft.class_1297;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_5558;
import net.pitan76.mcpitanlib.api.util.WorldUtil;
import net.pitan76.mcpitanlib.midohra.block.entity.BlockEntityWrapper;

public class TickerUtil {
    public static <T extends class_2586> void tick(T blockEntity, class_1937 world, class_2338 pos, class_2680 state) {
        if (isTicker(blockEntity))
            ((class_5558<T>) blockEntity).tick(world, pos, state, blockEntity);
    }

    public static <T extends class_2586> void tick(T blockEntity, class_1937 world, class_2338 pos) {
        tick(blockEntity, world, pos, WorldUtil.getBlockState(world, pos));
    }

    public static <T extends class_2586> void tick(T blockEntity) {
        tick(blockEntity, blockEntity.method_10997(), blockEntity.method_11016());
    }

    public static <T extends class_1297> void tick(T entity) {
        entity.method_5773();
    }

    public static boolean isTicker(class_2586 blockEntity) {
        return blockEntity instanceof class_5558;
    }

    public static <T extends class_2586> void tick(T blockEntity, net.pitan76.mcpitanlib.midohra.world.World world, net.pitan76.mcpitanlib.midohra.util.math.BlockPos pos, net.pitan76.mcpitanlib.midohra.block.BlockState state) {
        tick(blockEntity, world.toMinecraft(), pos.toMinecraft(), state.toMinecraft());
    }

    public static <T extends class_2586> void tick(T blockEntity, net.pitan76.mcpitanlib.midohra.world.World world, net.pitan76.mcpitanlib.midohra.util.math.BlockPos pos) {
        tick(blockEntity, world.toMinecraft(), pos.toMinecraft());
    }

    public static void tick(BlockEntityWrapper blockEntity) {
        tick(blockEntity.get());
    }

    public static void tick(BlockEntityWrapper blockEntity, net.pitan76.mcpitanlib.midohra.world.World world, net.pitan76.mcpitanlib.midohra.util.math.BlockPos pos, net.pitan76.mcpitanlib.midohra.block.BlockState state) {
        tick(blockEntity.get(), world.toMinecraft(), pos.toMinecraft(), state.toMinecraft());
    }

    public static void tick(BlockEntityWrapper blockEntity, net.pitan76.mcpitanlib.midohra.world.World world, net.pitan76.mcpitanlib.midohra.util.math.BlockPos pos) {
        tick(blockEntity.get(), world.toMinecraft(), pos.toMinecraft());
    }
}
