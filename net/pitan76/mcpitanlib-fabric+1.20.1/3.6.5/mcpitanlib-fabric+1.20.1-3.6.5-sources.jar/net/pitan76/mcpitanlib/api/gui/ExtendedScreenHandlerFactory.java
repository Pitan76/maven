package net.pitan76.mcpitanlib.api.gui;

import dev.architectury.registry.menu.ExtendedMenuProvider;
import net.minecraft.class_2540;
import net.minecraft.class_2561;
import net.pitan76.mcpitanlib.api.event.container.factory.DisplayNameArgs;
import net.pitan76.mcpitanlib.api.event.container.factory.ExtraDataArgs;

@Deprecated
public interface ExtendedScreenHandlerFactory extends ExtendedMenuProvider {
    @Override
    default class_2561 method_5476() {
        return getDisplayName(new DisplayNameArgs());
    }

    @Override
    default void saveExtraData(class_2540 buf) {
        writeExtraData(new ExtraDataArgs(buf));
    }

    class_2561 getDisplayName(DisplayNameArgs args);

    void writeExtraData(ExtraDataArgs args);
}
