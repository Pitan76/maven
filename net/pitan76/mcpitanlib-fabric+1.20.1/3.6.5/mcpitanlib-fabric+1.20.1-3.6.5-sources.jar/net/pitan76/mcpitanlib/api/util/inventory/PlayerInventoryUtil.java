package net.pitan76.mcpitanlib.api.util.inventory;

import net.minecraft.class_1661;
import net.minecraft.class_1799;
import net.minecraft.class_2371;
import net.pitan76.mcpitanlib.api.entity.Player;

public class PlayerInventoryUtil {
    public static Player getPlayer(class_1661 playerInventory) {
        return new Player(playerInventory.field_7546);
    }

    public static int getSelectedSlot(class_1661 playerInventory) {
        return playerInventory.field_7545;
    }

    public static void setSelectedSlot(class_1661 playerInventory, int slot) {
        playerInventory.field_7545 = slot;
    }

    public static void dropAllItems(class_1661 inv) {
        inv.method_7388();
    }

    public static class_2371<class_1799> getMain(class_1661 inv) {
        return inv.field_7547;
    }

    public static class_2371<class_1799> getArmor(class_1661 inv) {
        return inv.field_7548;
    }

    public static class_2371<class_1799> getOffHand(class_1661 inv) {
        return inv.field_7544;
    }

    public static class_1799 getMainHandStack(class_1661 inv) {
        return inv.method_7391();
    }
}
