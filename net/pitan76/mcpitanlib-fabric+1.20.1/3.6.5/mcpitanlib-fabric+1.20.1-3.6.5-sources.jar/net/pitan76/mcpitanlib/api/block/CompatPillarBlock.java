package net.pitan76.mcpitanlib.api.block;

import net.minecraft.class_1750;
import net.minecraft.class_2248;
import net.minecraft.class_2350;
import net.minecraft.class_2465;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.pitan76.mcpitanlib.api.block.v2.CompatBlockProvider;
import net.pitan76.mcpitanlib.api.block.v2.CompatibleBlockSettings;
import net.pitan76.mcpitanlib.api.event.block.AppendPropertiesArgs;
import net.pitan76.mcpitanlib.api.event.block.PlacementStateArgs;
import net.pitan76.mcpitanlib.api.state.property.CompatProperties;
import net.pitan76.mcpitanlib.api.state.property.EnumProperty;
import net.pitan76.mcpitanlib.core.serialization.CompatMapCodec;

public class CompatPillarBlock extends class_2465 implements CompatBlockProvider {

    public static final EnumProperty<class_2350.class_2351> AXIS = CompatProperties.of(class_2465.field_11459);

    public CompatibleBlockSettings settings;

    @Override
    public CompatibleBlockSettings getCompatSettings() {
        return settings;
    }

    public CompatPillarBlock(class_2251 settings) {
        super(settings);
    }

    public CompatPillarBlock(CompatibleBlockSettings settings) {
        this(settings.build());
        this.settings = settings;
    }

    public void appendProperties(AppendPropertiesArgs args) {
        super.method_9515(args.builder);
    }

    public class_2680 getPlacementState(PlacementStateArgs args) {
        return super.method_9605(args.ctx);
    }

    @Deprecated
    @Override
    public void method_9515(class_2689.class_2690<class_2248, class_2680> builder) {
        appendProperties(new AppendPropertiesArgs(builder));
    }

    @Deprecated
    @Override
    public class_2680 method_9605(class_1750 ctx) {
        return getPlacementState(new PlacementStateArgs(ctx));
    }

    // ExtendBlockProvider
    @Deprecated
    @Override
    public void appendProperties(AppendPropertiesArgs args, Options options) {
        CompatBlockProvider.super.appendProperties(args, options);
    }

    @Deprecated
    @Override
    public class_2680 getPlacementState(PlacementStateArgs args, Options options) {
        return CompatBlockProvider.super.getPlacementState(args, options);
    }

    public CompatMapCodec<? extends class_2465> getCompatCodec() {
        return CompatMapCodec.of();
    }
}
