package net.pitan76.mcpitanlib.api.item.args;

import net.minecraft.class_1799;

public class RarityArgs {
    public class_1799 stack;

    public RarityArgs(class_1799 stack) {
        this.stack = stack;
    }

    public class_1799 getStack() {
        return stack;
    }

    public net.pitan76.mcpitanlib.midohra.item.ItemStack getMidohraStack() {
        return net.pitan76.mcpitanlib.midohra.item.ItemStack.of(stack);
    }
}
