package net.pitan76.mcpitanlib.api.transfer.fluid.v1;

import dev.architectury.injectables.annotations.ExpectPlatform;
import net.minecraft.class_3611;

public class FluidStorageUtil {
    @ExpectPlatform
    public static IFluidStorage withFixedCapacity(long capacity, Runnable onChange) {
        throw new AssertionError();
    }

    @ExpectPlatform
    public static IFluidVariant getVariant(class_3611 fluid) {
        throw new AssertionError();
    }
}
