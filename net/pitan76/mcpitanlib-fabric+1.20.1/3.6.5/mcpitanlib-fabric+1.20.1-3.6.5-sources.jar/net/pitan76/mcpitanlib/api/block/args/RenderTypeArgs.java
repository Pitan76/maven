package net.pitan76.mcpitanlib.api.block.args;

import net.minecraft.class_2680;
import net.pitan76.mcpitanlib.midohra.holder.BlockStatePropertyHolder;

public class RenderTypeArgs implements BlockStatePropertyHolder {
    public class_2680 state;

    public RenderTypeArgs(class_2680 state) {
        this.state = state;
    }

    public class_2680 getRawBlockState() {
        return state;
    }

    @Override
    public net.pitan76.mcpitanlib.midohra.block.BlockState getBlockState() {
        return net.pitan76.mcpitanlib.midohra.block.BlockState.of(getRawBlockState());
    }
}
