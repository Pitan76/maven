package net.pitan76.mcpitanlib.api.util;

import net.minecraft.class_7833;
import net.pitan76.mcpitanlib.api.util.math.random.CompatRandom;
import org.joml.Quaternionf;

public class MathUtil {

    public static CompatRandom createRandom(long seed) {
        return CompatRandom.of(seed);
    }

    public static CompatRandom createRandom() {
        return CompatRandom.of();
    }

    @Deprecated
    public static Quaternionf getRotationDegrees(RotationAxisType type, float deg) {
        return type.axis.rotationDegrees(deg);
    }

    public static class RotationAxisType {

        public static RotationAxisType POSITIVE_X = new RotationAxisType(class_7833.field_40714);
        public static RotationAxisType POSITIVE_Y = new RotationAxisType(class_7833.field_40716);
        public static RotationAxisType POSITIVE_Z = new RotationAxisType(class_7833.field_40718);

        protected final class_7833 axis;
        protected RotationAxisType(class_7833 axis) {
            this.axis = axis;
        }
    }
}
