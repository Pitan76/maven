package net.pitan76.mcpitanlib.api.command.argument;

import net.minecraft.class_1297;
import net.minecraft.class_2186;
import net.pitan76.mcpitanlib.api.event.EntityCommandEvent;
import net.pitan76.mcpitanlib.api.event.ServerCommandEvent;

public abstract class EntityCommand extends RequiredCommand<class_1297> {
    @Override
    public class_2186 getArgumentType() {
        return class_2186.method_9309();
    }

    public abstract void execute(EntityCommandEvent event);

    @Override
    public void execute(ServerCommandEvent event) {
        execute((EntityCommandEvent) event);
    }
}
