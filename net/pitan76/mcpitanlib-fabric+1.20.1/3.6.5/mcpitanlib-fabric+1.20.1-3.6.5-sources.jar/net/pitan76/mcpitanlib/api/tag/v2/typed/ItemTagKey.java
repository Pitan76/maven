package net.pitan76.mcpitanlib.api.tag.v2.typed;

import net.minecraft.class_1792;
import net.minecraft.class_1856;
import net.minecraft.class_6862;
import net.pitan76.mcpitanlib.api.tag.v2.CompatTagKey;
import net.pitan76.mcpitanlib.api.tag.v2.CompatTagKeyType;
import net.pitan76.mcpitanlib.api.util.CompatIdentifier;
import net.pitan76.mcpitanlib.api.util.IngredientUtil;
import net.pitan76.mcpitanlib.api.util.item.ItemUtil;

import java.util.List;

public class ItemTagKey extends CompatTagKey<class_1792> {
    @Deprecated
    public ItemTagKey(class_6862<class_1792> tagKey) {
        super(tagKey);
    }

    public static ItemTagKey of(CompatIdentifier identifier) {
        return new ItemTagKey(net.minecraft.class_6862.method_40092(CompatTagKeyType.ITEM.getRegistryKey(), identifier.toMinecraft()));
    }

    public class_1856 asIngredient() {
        return IngredientUtil.fromTagByIdentifier(getTagKey().comp_327());
    }

    public List<class_1792> values() {
        return ItemUtil.getInTag(this);
    }
}
