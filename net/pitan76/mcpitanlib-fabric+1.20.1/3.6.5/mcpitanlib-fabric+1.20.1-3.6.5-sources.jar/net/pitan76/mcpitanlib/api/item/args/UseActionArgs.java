package net.pitan76.mcpitanlib.api.item.args;

import net.minecraft.class_1799;

public class UseActionArgs {
    public class_1799 stack;

    public UseActionArgs(class_1799 stack) {
        this.stack = stack;
    }

    public static UseActionArgs of(class_1799 stack) {
        return new UseActionArgs(stack);
    }

    public static UseActionArgs of(net.pitan76.mcpitanlib.midohra.item.ItemStack stack) {
        return of(stack.toMinecraft());
    }

    public class_1799 getStack() {
        return stack;
    }

    public net.pitan76.mcpitanlib.midohra.item.ItemStack getMidohraStack() {
        return net.pitan76.mcpitanlib.midohra.item.ItemStack.of(stack);
    }
}
