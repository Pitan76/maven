package net.pitan76.mcpitanlib.api.util.entity;

import net.minecraft.class_1680;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.pitan76.mcpitanlib.api.util.ItemStackUtil;

public class SnowballEntityUtil {
    public static class_1680 create(class_1937 world, double x, double y, double z) {
        return new class_1680(world, x, y, z);
    }

    public static class_1680 create(class_1937 world, double x, double y, double z, class_1799 stack) {
        class_1680 entity = create(world, x, y, z);
        entity.method_16940(stack);
        return entity;
    }

    public static void setVelocity(class_1680 entity, double x, double y, double z, float velocity, float divergence) {
        entity.method_7485(x, y, z, velocity, divergence);
    }

    public static void setItem(class_1680 entity, class_1799 stack) {
        entity.method_16940(stack);
    }

    public static class_1799 getItem(class_1680 entity) {
        return entity.method_7495();
    }
}
