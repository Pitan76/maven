package net.pitan76.mcpitanlib.api.event.block;

import net.minecraft.class_1922;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.pitan76.mcpitanlib.api.event.BaseEvent;

public class TileCreateEvent extends BaseEvent {

    // ～1.16.5
    private class_1922 blockView;

    public TileCreateEvent(class_1922 blockView) {
        this.blockView = blockView;
        this.blockPos = null;
        this.blockState = null;
    }

    public class_1922 getBlockView() {
        return blockView;
    }

    public void setBlockView(class_1922 blockView) {
        this.blockView = blockView;
    }

    public boolean hasBlockView() {
        return (blockView != null);
    }
    // ----

    // 1.17～
    private class_2338 blockPos;
    private class_2680 blockState;

    public TileCreateEvent(class_2338 blockPos, class_2680 blockState) {
        this.blockView = null;
        this.blockPos = blockPos;
        this.blockState = blockState;
    }

    public class_2338 getBlockPos() {
        return blockPos;
    }

    public void setBlockPos(class_2338 blockPos) {
        this.blockPos = blockPos;
    }

    public boolean hasBlockPos() {
        return (blockPos != null);
    }

    public class_2680 getBlockState() {
        return blockState;
    }

    public void setBlockState(class_2680 blockState) {
        this.blockState = blockState;
    }

    public boolean hasBlockState() {
        return (blockState != null);
    }
    // ----
}