package net.pitan76.mcpitanlib.api.network.v2.args;

import net.minecraft.class_1937;
import net.minecraft.class_2540;
import net.minecraft.class_3222;
import net.minecraft.server.MinecraftServer;
import net.pitan76.mcpitanlib.api.entity.Player;
import net.pitan76.mcpitanlib.midohra.network.CompatPacketByteBuf;
import net.pitan76.mcpitanlib.midohra.server.MCServer;

public class ServerReceiveEvent {
    public MinecraftServer server;
    public class_3222 serverPlayer;
    public Player player;
    public class_2540 buf;

    public ServerReceiveEvent(MinecraftServer server, class_3222 player, class_2540 buf) {
        this.server = server;
        this.serverPlayer = player;
        this.player = new Player(player);
        this.buf = buf;
    }

    public class_3222 getServerPlayer() {
        return serverPlayer;
    }

    public Player getPlayer() {
        return player;
    }

    public MinecraftServer getServer() {
        return server;
    }

    public class_2540 getBuf() {
        return buf;
    }

    public class_1937 getWorld() {
        return getPlayer().getWorld();
    }

    public net.pitan76.mcpitanlib.midohra.world.World getMidohraWorld() {
        return net.pitan76.mcpitanlib.midohra.world.World.of(getWorld());
    }

    public MCServer getMidohraServer() {
        return MCServer.of(server);
    }

    public CompatPacketByteBuf getCompatBuf() {
        return CompatPacketByteBuf.of(buf);
    }

    public void execute(Runnable runnable) {
        server.execute(runnable);
    }
}
