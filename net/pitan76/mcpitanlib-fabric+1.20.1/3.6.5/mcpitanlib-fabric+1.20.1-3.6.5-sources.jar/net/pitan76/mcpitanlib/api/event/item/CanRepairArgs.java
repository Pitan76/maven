package net.pitan76.mcpitanlib.api.event.item;

import net.minecraft.class_1799;
import net.pitan76.mcpitanlib.api.event.BaseEvent;

public class CanRepairArgs extends BaseEvent {
    public class_1799 stack;
    public class_1799 ingredient;

    public CanRepairArgs(class_1799 stack, class_1799 ingredient) {
        this.stack = stack;
        this.ingredient = ingredient;
    }

    public class_1799 getStack() {
        return stack;
    }

    public class_1799 getIngredient() {
        return ingredient;
    }
}
