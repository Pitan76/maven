package net.pitan76.mcpitanlib.api.gui;

import dev.architectury.registry.menu.ExtendedMenuProvider;
import net.minecraft.class_1270;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_2540;
import net.minecraft.class_2561;
import org.jetbrains.annotations.Nullable;

@Deprecated
public class ExtendedNamedScreenHandlerFactory implements ExtendedMenuProvider {

    private final class_2561 name;
    private final class_1270 baseFactory;
    private final PacketByteBufFactory bufFactory;

    public ExtendedNamedScreenHandlerFactory(class_2561 name, class_1270 baseFactory, PacketByteBufFactory bufFactory) {
        this.name = name;
        this.baseFactory = baseFactory;
        this.bufFactory = bufFactory;
    }

    @Override
    public void saveExtraData(class_2540 buf) {
        bufFactory.saveExtraData(buf);
    }

    @Override
    public class_2561 method_5476() {
        return name;
    }

    @Nullable
    @Override
    public class_1703 createMenu(int syncId, class_1661 inv, class_1657 player) {
        return baseFactory.createMenu(syncId, inv, player);

    }

    @FunctionalInterface
    public interface PacketByteBufFactory {
        void saveExtraData(class_2540 buf);
    }
}
