package net.pitan76.mcpitanlib.api.entity.attribute;

import net.minecraft.class_1322;

public class AttrModifierOperation {
    private final class_1322.class_1323 raw;

    public static final AttrModifierOperation ADD = new AttrModifierOperation(class_1322.class_1323.field_6328);
    public static final AttrModifierOperation MUL_TOTAL = new AttrModifierOperation(class_1322.class_1323.field_6331);
    public static final AttrModifierOperation MUL_BASE = new AttrModifierOperation(class_1322.class_1323.field_6330);

    @Deprecated
    public AttrModifierOperation(class_1322.class_1323 raw) {
        this.raw = raw;
    }

    public static AttrModifierOperation of(class_1322.class_1323 raw) {
        if (raw == class_1322.class_1323.field_6328) {
            return ADD;
        } else if (raw == class_1322.class_1323.field_6331) {
            return MUL_TOTAL;
        } else if (raw == class_1322.class_1323.field_6330) {
            return MUL_BASE;
        }

        return new AttrModifierOperation(raw);
    }

    public class_1322.class_1323 raw() {
        return raw;
    }

    public String getName() {
        return raw().name();
    }

    public int getId() {
        return raw().method_6191();
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (!(obj instanceof AttrModifierOperation)) return false;
        AttrModifierOperation that = (AttrModifierOperation) obj;
        return raw().equals(that.raw());
    }

    @Override
    public int hashCode() {
        if (raw() == null) return super.hashCode();
        return raw().hashCode();
    }
}
