package net.pitan76.mcpitanlib.api.item.v2;

import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1799;
import net.minecraft.class_1814;
import net.minecraft.class_1839;
import net.minecraft.class_1937;
import net.pitan76.mcpitanlib.api.event.item.CanRepairArgs;
import net.pitan76.mcpitanlib.api.event.item.EnchantabilityArgs;
import net.pitan76.mcpitanlib.api.event.item.EnchantableArgs;
import net.pitan76.mcpitanlib.api.event.item.InventoryTickEvent;
import net.pitan76.mcpitanlib.api.item.ExtendItem;
import net.pitan76.mcpitanlib.api.item.args.RarityArgs;
import net.pitan76.mcpitanlib.api.item.args.StoppedUsingArgs;
import net.pitan76.mcpitanlib.api.item.args.UseActionArgs;
import net.pitan76.mcpitanlib.api.item.consume.CompatUseAction;
import net.pitan76.mcpitanlib.api.tag.item.RepairIngredientTag;
import net.pitan76.mcpitanlib.api.util.CompatRarity;
import net.pitan76.mcpitanlib.core.Dummy;
import net.pitan76.mcpitanlib.midohra.item.ItemWrapper;
import org.jetbrains.annotations.Nullable;

public class CompatItem extends ExtendItem {

    public CompatibleItemSettings settings;

    public CompatItem(CompatibleItemSettings settings) {
        super(settings);
        this.settings = settings;
    }

    public CompatibleItemSettings getCompatSettings() {
        return settings;
    }

    public ItemWrapper getWrapper() {
        return ItemWrapper.of(this);
    }

    @Deprecated
    @Override
    public class_1839 method_7853(class_1799 stack) {
        return getUseAction(new UseActionArgs(stack)).getUseAction();
    }

    public CompatUseAction getUseAction(UseActionArgs args) {
        return CompatUseAction.of(super.method_7853(args.stack));
    }

    @Deprecated
    @Override
    public class_1814 method_7862(class_1799 stack) {
        return getRarity(new RarityArgs(stack)).getRarity();
    }

    public CompatRarity getRarity(RarityArgs args) {
        return settings.rarity;
    }

    @Override
    public boolean isEnchantable(EnchantableArgs args) {
        return settings.enchantability != -1;
    }

    @Override
    public int getEnchantability(EnchantabilityArgs args) {
        return settings.enchantability;
    }

    @Override
    public boolean canRepair(CanRepairArgs args) {
        RepairIngredientTag tag = settings.repairIngredientTag;
        return tag != null && tag.contains(args.stack);
    }

    @Override
    public boolean hasRecipeRemainder(Dummy dummy) {
        return settings.recipeRemainder != null;
    }

    @Override
    protected String method_7869() {
        if (settings.changedTranslationKey)
            return settings.translationKey;

        return super.method_7869();
    }

    @Deprecated
    @Override
    public void method_7840(class_1799 stack, class_1937 world, class_1309 user, int remainingUseTicks) {
        onStoppedUsing(new StoppedUsingArgs(stack, world, user, remainingUseTicks));
    }

    public boolean onStoppedUsing(StoppedUsingArgs args) {
        super.method_7840(args.stack, args.world, args.user, args.remainingUseTicks);
        return false;
    }

    @Deprecated
    @Override
    public void method_7888(class_1799 stack, class_1937 world, class_1297 entity, int slot, boolean selected) {
        inventoryTick(new InventoryTickEvent(stack, world, entity, slot, selected));
    }

    public void inventoryTick(InventoryTickEvent e) {
        super.method_7888(e.stack, e.world, e.entity, e.slot, e.selected);
    }
}
