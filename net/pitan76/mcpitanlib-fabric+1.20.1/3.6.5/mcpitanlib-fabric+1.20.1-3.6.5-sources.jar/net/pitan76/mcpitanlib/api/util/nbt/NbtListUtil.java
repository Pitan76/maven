package net.pitan76.mcpitanlib.api.util.nbt;

import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2520;
import net.pitan76.mcpitanlib.api.util.NbtUtil;

import java.util.Optional;
import java.util.stream.Stream;

public class NbtListUtil {
    public static class_2499 create() {
        return NbtUtil.createNbtList();
    }

    public static class_2499 copy(class_2499 list) {
        return list.method_10612();
    }

    public static Stream<class_2520> stream(class_2499 list) {
        return list.stream();
    }

    public static Optional<String> getStringOptional(class_2499 list, int index) {
        if (index < 0 || index >= list.size())
            return Optional.empty();

        return Optional.of(list.method_10608(index));
    }

    public static class_2520 get(class_2499 list, int index) {
        return list.method_10534(index);
    }

    public static class_2520 getOrDefault(class_2499 list, int index, class_2520 defaultValue) {
        class_2520 nbt = get(list, index);
        return nbt == null ? defaultValue : nbt;
    }

    public static void set(class_2499 list, int index, class_2520 value) {
        list.method_10606(index, value);
    }

    public static void add(class_2499 list, class_2520 value) {
        list.add(value);
    }

    public static void set(class_2499 list, int index, String value) {
        set(list, index, NbtUtil.createString(value));
    }

    public static boolean has(class_2499 list, class_2520 value) {
        return list.contains(value);
    }

    public static int size(class_2499 list) {
        return list.size();
    }

    public static void remove(class_2499 list, int index) {
        list.method_10536(index);
    }

    public static void clear(class_2499 list) {
        list.clear();
    }

    public static boolean isEmpty(class_2499 list) {
        return list.isEmpty();
    }

    public static String getString(class_2499 list, int index) {
        return getStringOptional(list, index).orElse("");
    }

    public static void setString(class_2499 list, int index, String value) {
        list.method_10606(index, NbtUtil.createString(value));
    }

    public static void addString(class_2499 list, String value) {
        list.add(NbtUtil.createString(value));
    }

    public static class_2499 getList(class_2499 list, int index) {
        return list.method_10603(index);
    }

    public static class_2487 getCompound(class_2499 list, int index) {
        return list.method_10602(index);
    }
}
