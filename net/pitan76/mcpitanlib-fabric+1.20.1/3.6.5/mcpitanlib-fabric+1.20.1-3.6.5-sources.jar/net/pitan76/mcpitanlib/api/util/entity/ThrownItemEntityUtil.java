package net.pitan76.mcpitanlib.api.util.entity;

import net.minecraft.class_1297;
import net.minecraft.class_1799;
import net.minecraft.class_3857;
import net.pitan76.mcpitanlib.api.entity.CompatThrownItemEntity;

public class ThrownItemEntityUtil {
    public static class_1799 getItem(class_3857 entity) {
        return entity.method_7495();
    }

    public static void setItem(class_3857 entity, class_1799 stack) {
        entity.method_16940(stack);
    }

    public static class_1799 getStack(class_3857 entity) {
        return entity.method_7495();
    }

    public static void setVelocity(class_3857 entity, class_1297 shooter, float pitch, float yaw, float roll, float speed, float divergence) {
        ProjectileEntityUtil.setVelocity(entity, shooter, pitch, yaw, roll, speed, divergence);
    }

    public static void setVelocity(CompatThrownItemEntity entity, class_1297 shooter, float pitch, float yaw, float roll, float speed, float divergence) {
        ProjectileEntityUtil.setVelocity(entity, shooter, pitch, yaw, roll, speed, divergence);
    }

    public static void setVelocity(class_3857 entity, double x, double y, double z, float power, float uncertainty) {
        ProjectileEntityUtil.setVelocity(entity, x, y, z, power, uncertainty);
    }

    public static void setVelocity(CompatThrownItemEntity entity, double x, double y, double z, float power, float uncertainty) {
        ProjectileEntityUtil.setVelocity(entity, x, y, z, power, uncertainty);
    }
}
