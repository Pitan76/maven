package net.pitan76.mcpitanlib.api.command.argument;

import net.minecraft.class_1297;
import net.minecraft.class_2186;
import net.pitan76.mcpitanlib.api.event.PlayerCommandEvent;
import net.pitan76.mcpitanlib.api.event.ServerCommandEvent;

public abstract class PlayerCommand extends RequiredCommand<class_1297> {
    @Override
    public class_2186 getArgumentType() {
        return class_2186.method_9305();
    }

    public abstract void execute(PlayerCommandEvent event);

    @Override
    public void execute(ServerCommandEvent event) {
        execute((PlayerCommandEvent) event);
    }
}
