package net.pitan76.mcpitanlib.api.client.registry;

import dev.architectury.registry.client.keymappings.KeyMappingRegistry;
import net.minecraft.class_2960;
import net.minecraft.class_304;
import net.pitan76.mcpitanlib.api.event.v0.ClientTickEventRegistry;
import net.pitan76.mcpitanlib.api.network.ClientNetworking;
import net.pitan76.mcpitanlib.api.network.PacketByteUtil;

public class KeybindingRegistry {
    public static void register(class_304 keyBinding) {
        KeyMappingRegistry.register(keyBinding);
    }

    public static void register(class_304 keyBinding, ClientTickEventRegistry.Client client) {
        register(keyBinding);
        ClientTickEventRegistry.registerPost(client);
    }

    public static void registerOnLevel(class_304 keyBinding, ClientTickEventRegistry.ClientLevel level) {
        register(keyBinding);
        ClientTickEventRegistry.registerLevelPost(level);
    }

    public static void registerWithNetwork(class_304 keyBinding, class_2960 identifier) {
        register(keyBinding, client -> {
            if (keyBinding.method_1436())
                ClientNetworking.send(identifier, PacketByteUtil.create());
        });
    }

    public static void registerOnLevelWithNetwork(class_304 keyBinding, class_2960 identifier) {
        registerOnLevel(keyBinding, client -> {
            if (keyBinding.method_1436())
                ClientNetworking.send(identifier, PacketByteUtil.create());
        });
    }
}
