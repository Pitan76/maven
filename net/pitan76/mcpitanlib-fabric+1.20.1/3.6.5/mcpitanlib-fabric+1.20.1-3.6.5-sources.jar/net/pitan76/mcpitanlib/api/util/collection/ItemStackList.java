package net.pitan76.mcpitanlib.api.util.collection;

import com.google.common.collect.Lists;
import net.minecraft.class_1263;
import net.minecraft.class_1799;
import net.minecraft.class_2371;
import net.pitan76.mcpitanlib.api.gui.inventory.IInventory;
import net.pitan76.mcpitanlib.api.util.ItemStackUtil;
import org.apache.commons.lang3.Validate;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class ItemStackList extends class_2371<class_1799> {

    public ItemStackList(List<class_1799> delegate, @Nullable class_1799 initialElement) {
        super(delegate, initialElement);
    }

    public static ItemStackList method_10211() {
        return new ItemStackList(Lists.newArrayList(), ItemStackUtil.empty());
    }

    public static ItemStackList method_37434(int size) {
        return ofSize(size, ItemStackUtil.empty());
    }

    public static ItemStackList ofSize(int size, class_1799 defaultStack) {
        Validate.notNull(defaultStack);
        class_1799[] objects = new class_1799[size];
        Arrays.fill(objects, defaultStack);
        return new ItemStackList(Arrays.asList(objects), defaultStack);
    }

    public static ItemStackList copyOf(class_1799 defaultStack, class_1799... stacks) {
        return new ItemStackList(Arrays.asList(stacks), defaultStack);
    }

    public static class_1263 toInventory(class_2371<class_1799> list) {
        return IInventory.of(list);
    }

    public static class_2371<class_1799> toDefaultedList(class_1263 inventory) {
        class_2371<class_1799> list = class_2371.method_10213(inventory.method_5439(), ItemStackUtil.empty());
        for (int i = 0; i < inventory.method_5439(); i++) {
            list.set(i, inventory.method_5438(i));
        }

        return list;
    }

    public static ItemStackList fromInventory(class_1263 inventory) {
        return new ItemStackList(toDefaultedList(inventory), ItemStackUtil.empty());
    }

    public class_1263 toInventory() {
        return toInventory(this);
    }

    public class_2371<class_1799> defaultedList() {
        return this;
    }

    public static ItemStackList of(class_2371<class_1799> defaultedList) {
        ItemStackList stacks = ItemStackList.method_37434(defaultedList.size());
        for (int i = 0; i < defaultedList.size(); i++) {
            stacks.set(i , defaultedList.get(i));
        }

        return stacks;
    }

    public static ItemStackList of(class_1799 stack) {
        return ItemStackList.ofSize(1, stack);
    }

    // Midohra
    public List<net.pitan76.mcpitanlib.midohra.item.ItemStack> toMidohra() {
        List<net.pitan76.mcpitanlib.midohra.item.ItemStack> stacks = new ArrayList<>();
        for (class_1799 stack : this) {
            stacks.add(net.pitan76.mcpitanlib.midohra.item.ItemStack.of(stack));
        }

        return stacks;
    }

    public @NotNull net.pitan76.mcpitanlib.midohra.item.ItemStack getAsMidohra(int index) {
        return net.pitan76.mcpitanlib.midohra.item.ItemStack.of(get(index));
    }

    public net.pitan76.mcpitanlib.midohra.item.ItemStack getFirstAsMidohra() {
        return getAsMidohra(0);
    }

    public net.pitan76.mcpitanlib.midohra.item.ItemStack getLastAsMidohra() {
        return getAsMidohra(size() - 1);
    }

    public boolean add(net.pitan76.mcpitanlib.midohra.item.ItemStack stack) {
        return add(stack.toMinecraft());
    }

    public boolean addAll(List<net.pitan76.mcpitanlib.midohra.item.ItemStack> stacks) {
        boolean changed = false;
        for (net.pitan76.mcpitanlib.midohra.item.ItemStack stack : stacks) {
            changed |= add(stack);
        }

        return changed;
    }

    public boolean addAll(net.pitan76.mcpitanlib.midohra.item.ItemStack... stacks) {
        return addAll(Arrays.asList(stacks));
    }

    public boolean remove(net.pitan76.mcpitanlib.midohra.item.ItemStack stack) {
        return remove(stack.toMinecraft());
    }

    public boolean removeAll(List<net.pitan76.mcpitanlib.midohra.item.ItemStack> stacks) {
        boolean changed = false;
        for (net.pitan76.mcpitanlib.midohra.item.ItemStack stack : stacks) {
            changed |= remove(stack);
        }

        return changed;
    }

    public boolean removeAll(net.pitan76.mcpitanlib.midohra.item.ItemStack... stacks) {
        return removeAll(Arrays.asList(stacks));
    }

    public boolean contains(net.pitan76.mcpitanlib.midohra.item.ItemStack stack) {
        return contains(stack.toMinecraft());
    }

    public boolean containsAll(List<net.pitan76.mcpitanlib.midohra.item.ItemStack> stacks) {
        for (net.pitan76.mcpitanlib.midohra.item.ItemStack stack : stacks) {
            if (!contains(stack)) {
                return false;
            }
        }

        return true;
    }

    public boolean containsAll(net.pitan76.mcpitanlib.midohra.item.ItemStack... stacks) {
        return containsAll(Arrays.asList(stacks));
    }

    public boolean containsAny(List<net.pitan76.mcpitanlib.midohra.item.ItemStack> stacks) {
        for (net.pitan76.mcpitanlib.midohra.item.ItemStack stack : stacks) {
            if (contains(stack)) {
                return true;
            }
        }

        return false;
    }

    public boolean containsAny(net.pitan76.mcpitanlib.midohra.item.ItemStack... stacks) {
        return containsAny(Arrays.asList(stacks));
    }

    public boolean equals(List<net.pitan76.mcpitanlib.midohra.item.ItemStack> stacks) {
        if (size() != stacks.size()) {
            return false;
        }

        for (int i = 0; i < size(); i++) {
            if (!get(i).equals(stacks.get(i).toMinecraft())) {
                return false;
            }
        }

        return true;
    }

    public boolean equals(net.pitan76.mcpitanlib.midohra.item.ItemStack... stacks) {
        return equals(Arrays.asList(stacks));
    }

    public static ItemStackList of(List<net.pitan76.mcpitanlib.midohra.item.ItemStack> stacks) {
        ItemStackList list = ItemStackList.method_37434(stacks.size());
        for (int i = 0; i < stacks.size(); i++) {
            list.set(i, stacks.get(i).toMinecraft());
        }

        return list;
    }

    public static ItemStackList of(net.pitan76.mcpitanlib.midohra.item.ItemStack... stacks) {
        return ItemStackList.of(Arrays.asList(stacks));
    }

    public static ItemStackList of(net.pitan76.mcpitanlib.midohra.item.ItemStack stack) {
        return of(stack, 1);
    }

    public static ItemStackList of(net.pitan76.mcpitanlib.midohra.item.ItemStack stack, int size) {
        return ItemStackList.ofSize(size, stack.toMinecraft());
    }

    public static ItemStackList of2(List<class_1799> stacks) {
        ItemStackList list = ItemStackList.method_37434(stacks.size());
        for (int i = 0; i < stacks.size(); i++)
            list.set(i, stacks.get(i));

        return list;
    }

    public void set(int index, net.pitan76.mcpitanlib.midohra.item.ItemStack stack) {
        set(index, stack.toMinecraft());
    }

    public boolean isEmpty(int index) {
        return get(index).method_7960();
    }
}
