package net.pitan76.mcpitanlib.api.util;

import net.minecraft.class_1922;
import net.minecraft.class_2338;
import net.minecraft.class_2586;
import net.minecraft.class_2680;

public class BlockViewUtil {
    public static class_2680 getBlockState(class_1922 blockView, class_2338 pos) {
        return blockView.method_8320(pos);
    }

    public static class_2586 getBlockEntity(class_1922 blockView, class_2338 pos) {
        return blockView.method_8321(pos);
    }

    public static boolean hasBlockEntity(class_1922 blockView, class_2338 pos) {
        return getBlockEntity(blockView, pos) != null;
    }

    public static boolean isAir(class_1922 blockView, class_2338 pos) {
        return getBlockState(blockView, pos).method_26215();
    }
}
