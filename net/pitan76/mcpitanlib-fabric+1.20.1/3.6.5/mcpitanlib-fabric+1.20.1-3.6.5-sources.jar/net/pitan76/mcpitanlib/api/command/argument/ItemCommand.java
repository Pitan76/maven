package net.pitan76.mcpitanlib.api.command.argument;

import net.minecraft.class_1792;
import net.minecraft.class_2287;
import net.pitan76.mcpitanlib.api.command.CommandRegistry;
import net.pitan76.mcpitanlib.api.event.ItemCommandEvent;
import net.pitan76.mcpitanlib.api.event.ServerCommandEvent;

public abstract class ItemCommand extends RequiredCommand<class_1792> {
    @Override
    public class_2287 getArgumentType() {
        return class_2287.method_9776(CommandRegistry.latestCommandRegistryAccess);
    }

    public abstract void execute(ItemCommandEvent event);

    @Override
    public void execute(ServerCommandEvent event) {
        execute((ItemCommandEvent) event);
    }
}
