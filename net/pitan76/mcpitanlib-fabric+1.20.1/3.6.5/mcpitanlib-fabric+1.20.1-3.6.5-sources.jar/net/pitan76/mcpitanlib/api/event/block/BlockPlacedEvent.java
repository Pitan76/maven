package net.pitan76.mcpitanlib.api.event.block;

import net.minecraft.class_1309;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.pitan76.mcpitanlib.api.event.BaseEvent;
import net.pitan76.mcpitanlib.api.util.WorldUtil;
import net.pitan76.mcpitanlib.midohra.block.BlockWrapper;
import net.pitan76.mcpitanlib.midohra.block.entity.BlockEntityWrapper;
import net.pitan76.mcpitanlib.midohra.world.IWorldView;

public class BlockPlacedEvent extends BaseEvent {

    public class_1937 world;
    public class_2338 pos;
    public class_2680 state;
    public class_1309 placer;
    public class_1799 stack;

    public BlockPlacedEvent(class_1937 world, class_2338 pos, class_2680 state, class_1309 placer, class_1799 itemStack) {
        this.world = world;
        this.pos = pos;
        this.state = state;
        this.placer = placer;
        this.stack = itemStack;
    }

    public class_2680 getState() {
        return state;
    }

    public class_2338 getPos() {
        return pos;
    }

    public class_1937 getWorld() {
        return world;
    }

    public class_1799 getStack() {
        return stack;
    }

    public class_1309 getPlacer() {
        return placer;
    }

    public boolean isClient() {
        return world.method_8608();
    }

    public class_2586 getBlockEntity() {
        return WorldUtil.getBlockEntity(getWorld(), getPos());
    }

    public net.pitan76.mcpitanlib.midohra.world.World getMidohraWorld() {
        return net.pitan76.mcpitanlib.midohra.world.World.of(world);
    }

    public IWorldView getWorldView() {
        return getMidohraWorld();
    }

    public net.pitan76.mcpitanlib.midohra.block.BlockState getMidohraState() {
        return net.pitan76.mcpitanlib.midohra.block.BlockState.of(state);
    }

    public net.pitan76.mcpitanlib.midohra.util.math.BlockPos getMidohraPos() {
        return net.pitan76.mcpitanlib.midohra.util.math.BlockPos.of(pos);
    }

    public BlockWrapper getBlockWrapper() {
        return BlockWrapper.of(state.method_26204());
    }

    public BlockEntityWrapper getBlockEntityWrapper() {
        return BlockEntityWrapper.of(getBlockEntity());
    }
}
