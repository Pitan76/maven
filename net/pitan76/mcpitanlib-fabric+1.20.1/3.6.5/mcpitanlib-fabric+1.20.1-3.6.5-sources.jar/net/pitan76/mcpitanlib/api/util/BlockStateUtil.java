package net.pitan76.mcpitanlib.api.util;

import net.minecraft.class_1268;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1922;
import net.minecraft.class_1936;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2470;
import net.minecraft.class_2498;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2769;
import net.minecraft.class_3218;
import net.minecraft.class_3610;
import net.minecraft.class_3611;
import net.minecraft.class_3965;
import net.pitan76.mcpitanlib.api.entity.Player;
import net.pitan76.mcpitanlib.api.sound.CompatBlockSoundGroup;
import net.pitan76.mcpitanlib.api.util.block.BlockHitResultUtil;
import net.pitan76.mcpitanlib.midohra.block.BlockWrapper;

public class BlockStateUtil {
    public static class_2248 getBlock(class_2680 state) {
        return state.method_26204();
    }

    public static boolean isAir(class_2680 state) {
        return state.method_26215();
    }

    public static boolean isOpaque(class_2680 state) {
        return state.method_26225();
    }

    public static class_2498 getSoundGroup(class_2680 state) {
        return state.method_26231();
    }

    public static CompatBlockSoundGroup getCompatSoundGroup(class_2680 state) {
        return CompatBlockSoundGroup.of(getSoundGroup(state));
    }

    public static class_2680 getDefaultState(class_2248 block) {
        return block.method_9564();
    }

    public static class_2689<class_2248, class_2680> getStateManager(class_2248 block) {
        return block.method_9595();
    }

    public static <T extends Comparable<T>, V extends T> class_2680 with(class_2680 state, class_2769<T> property, V value) {
        return state.method_11657(property, value);
    }

    public static void neighborUpdate(class_2680 state, class_1937 world, class_2338 pos, class_2248 block, class_2338 fromPos, boolean notify) {
        state.method_26181(world, pos, block, fromPos, notify);
    }

    public static void updateNeighbors(class_2680 state, class_1936 world, class_2338 pos, int flags) {
        state.method_30101(world, pos, flags);
    }

    public static boolean hasRandomTicks(class_2680 state) {
        return state.method_26229();
    }

    public static void randomTick(class_2680 state, class_3218 world, class_2338 pos) {
        state.method_26199(world, pos, world.field_9229);
    }

    public static CompatActionResult onUse(class_2680 state, class_1937 world, Player player, class_3965 hitResult) {
        class_1268 hand = player.getMainHandStack().method_7960() ? class_1268.field_5810 : class_1268.field_5808;
        return CompatActionResult.create(state.method_26174(world, player.getEntity(), hand, hitResult));
    }

    public static CompatActionResult onUse(class_2680 state, class_1937 world, Player player, class_2350 dir, class_2338 blockPos) {
        return onUse(state, world, player, BlockHitResultUtil.create(player.getPos(), dir, blockPos));
    }

    public static CompatActionResult onUseWithItem(class_2680 state, class_1799 stack, class_1937 world, class_1657 player, class_1268 hand, class_3965 hit) {
        return CompatActionResult.create(state.method_26174(world, player, hand, hit));
    }

    public static CompatActionResult onUseWithItem_actionResult(class_2680 state, class_1799 stack, class_1937 world, class_1657 player, class_1268 hand, class_3965 hit) {
        return onUseWithItem(state, stack, world, player, hand, hit);
    }

    public static class_3610 getFluidState(class_2680 state) {
        return state.method_26227();
    }

    public static class_3611 getFluid(class_2680 state) {
        return getFluidState(state).method_15772();
    }

    public static class_2680 rotate(class_2680 state, class_2470 rotation) {
        return state.method_26186(rotation);
    }

    public static net.pitan76.mcpitanlib.midohra.block.BlockState getMidohraDefaultState(class_2248 block) {
        return net.pitan76.mcpitanlib.midohra.block.BlockState.of(getDefaultState(block));
    }

    public static net.pitan76.mcpitanlib.midohra.block.BlockState getDefaultState(BlockWrapper block) {
        return block.getDefaultState();
    }

    public static float getHardness(class_2680 state, class_1922 world, class_2338 pos) {
        return state.method_26214(world, pos);
    }

    public static float getHardness(class_2680 state, class_1937 world, class_2338 pos) {
        return state.method_26214(world, pos);
    }

    public static int getLuminance(class_2680 state) {
        return state.method_26213();
    }

    public static int getOpacity(class_2680 state) {
        return state.method_26193(null, null);
    }

    public static int getComparatorOutput(class_2680 state, class_1937 world, class_2338 pos) {
        return state.method_26176(world, pos);
    }

    public static float getHardness(net.pitan76.mcpitanlib.midohra.block.BlockState state, net.pitan76.mcpitanlib.midohra.world.BlockView world, net.pitan76.mcpitanlib.midohra.util.math.BlockPos pos) {
        return getHardness(state.toMinecraft(), world.getRaw(), pos.toMinecraft());
    }

    public static int getLuminance(net.pitan76.mcpitanlib.midohra.block.BlockState state) {
        return getLuminance(state.toMinecraft());
    }

    public static int getOpacity(net.pitan76.mcpitanlib.midohra.block.BlockState state) {
        return getOpacity(state.toMinecraft());
    }

    public static int getComparatorOutput(net.pitan76.mcpitanlib.midohra.block.BlockState state, net.pitan76.mcpitanlib.midohra.world.World world, net.pitan76.mcpitanlib.midohra.util.math.BlockPos pos) {
        return getComparatorOutput(state.toMinecraft(), world.getRaw(), pos.toMinecraft());
    }

    public static boolean canPlaceAt(class_2680 state, class_2338 pos, class_1937 world) {
        return state.method_26184(world, pos);
    }

    public static boolean canPlaceAt(net.pitan76.mcpitanlib.midohra.block.BlockState state, net.pitan76.mcpitanlib.midohra.util.math.BlockPos pos, net.pitan76.mcpitanlib.midohra.world.World world) {
        return canPlaceAt(state.toMinecraft(), pos.toMinecraft(), world.getRaw());
    }

    public static boolean hasRandomTicks(net.pitan76.mcpitanlib.midohra.block.BlockState state) {
        return hasRandomTicks(state.toMinecraft());
    }

    public static void randomTick(net.pitan76.mcpitanlib.midohra.block.BlockState state, class_3218 world, net.pitan76.mcpitanlib.midohra.util.math.BlockPos pos) {
        randomTick(state.toMinecraft(), world, pos.toMinecraft());
    }

    public static void randomTick(net.pitan76.mcpitanlib.midohra.block.BlockState state, net.pitan76.mcpitanlib.midohra.world.ServerWorld world, net.pitan76.mcpitanlib.midohra.util.math.BlockPos pos) {
        randomTick(state.toMinecraft(), world.getRaw(), pos.toMinecraft());
    }
}
