package net.pitan76.mcpitanlib.api.event.item;

import net.minecraft.class_1282;
import net.minecraft.class_1297;

public class BonusAttackDamageArgs {

    public class_1297 target;
    public float baseAttackDamage;
    public class_1282 damageSource;

    public BonusAttackDamageArgs(class_1297 target, float baseAttackDamage, class_1282 damageSource) {
        this.target = target;
        this.baseAttackDamage = baseAttackDamage;
        this.damageSource = damageSource;
    }

    public class_1297 getTarget() {
        return target;
    }

    public float getBaseAttackDamage() {
        return baseAttackDamage;
    }

    public class_1282 getDamageSource() {
        return damageSource;
    }
}
