package net.pitan76.mcpitanlib.api.util.math;

import net.minecraft.class_2350;

public class DirectionUtil {

    public static class_2350 north() {
        return class_2350.field_11043;
    }

    public static class_2350 south() {
        return class_2350.field_11035;
    }

    public static class_2350 east() {
        return class_2350.field_11034;
    }

    public static class_2350 west() {
        return class_2350.field_11039;
    }

    public static class_2350 up() {
        return class_2350.field_11036;
    }

    public static class_2350 down() {
        return class_2350.field_11033;
    }

    public static class_2350 getOpposite(class_2350 direction) {
        return direction.method_10153();
    }
}
