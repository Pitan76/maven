package net.pitan76.mcpitanlib.api.event.block;

import net.minecraft.class_1922;
import net.minecraft.class_2338;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_4538;
import org.jetbrains.annotations.Nullable;

public class PickStackEvent {

    @Deprecated
    public class_4538 worldView;

    @Deprecated
    public class_1922 blockView;

    public class_2338 pos;
    public class_2680 state;

    public boolean includeData = true;

    public PickStackEvent(class_4538 world, class_2338 pos, class_2680 state) {
        this.worldView = world;
        this.pos = pos;
        this.state = state;
    }

    public PickStackEvent(class_1922 world, class_2338 pos, class_2680 state) {
        this.blockView = world;
        this.pos = pos;
        this.state = state;
    }

    public class_2680 getState() {
        return state;
    }

    public class_2338 getPos() {
        return pos;
    }

    @Nullable
    public class_1922 getBlockView() {
        return blockView;
    }

    @Nullable
    public class_4538 getWorldView() {
        return worldView;
    }

    /**
     * check if the block has a block entity
     * @return boolean
     */
    public boolean hasBlockEntity() {
        return getBlockEntity() != null;
    }

    /**
     * @return BlockEntity
     */
    public class_2586 getBlockEntity() {
        if (blockView != null)
            return blockView.method_8321(pos);
        if (worldView != null)
            return worldView.method_8321(pos);
        return null;
    }

    public boolean isClient() {
        if (blockView != null)
            return getBlockEntity().method_10997().method_8608();
        if (worldView != null)
            return worldView.method_8608();

        try {
            net.minecraft.class_310.method_1551();
            return true;
        } catch (Error e) {
            return false;
        }
    }

    public void setIncludeData(boolean includeData) {
        this.includeData = includeData;
    }

    public boolean isIncludeData() {
        return includeData;
    }
}
