package net.pitan76.mcpitanlib.api.gui.inventory.sided.args;

import net.minecraft.class_1799;
import net.minecraft.class_2350;
import org.jetbrains.annotations.Nullable;

public class CanInsertArgs {
    public int slot;
    public class_1799 stack;

    @Nullable
    public class_2350 dir;

    public CanInsertArgs(int slot, class_1799 stack, @Nullable class_2350 dir) {
        this.slot = slot;
        this.stack = stack;
        this.dir = dir;
    }

    public int getSlot() {
        return slot;
    }

    public class_1799 getStack() {
        return stack;
    }

    public @Nullable class_2350 getDir() {
        return dir;
    }

    public net.pitan76.mcpitanlib.midohra.item.ItemStack getStack_midohra() {
        return net.pitan76.mcpitanlib.midohra.item.ItemStack.of(getStack());
    }
}
