package net.pitan76.mcpitanlib.api.event.result;

import dev.architectury.event.CompoundEventResult;
import net.minecraft.class_1269;
import net.minecraft.class_1799;
import net.pitan76.mcpitanlib.api.util.CompatActionResult;
import net.pitan76.mcpitanlib.api.util.StackActionResult;

public class TypedEventResult<T> {
    protected final dev.architectury.event.CompoundEventResult<T> result;

    protected TypedEventResult(dev.architectury.event.CompoundEventResult<T> result) {
        this.result = result;
    }

    public static <T> TypedEventResult<T> success(T value) {
        return new TypedEventResult<>(CompoundEventResult.interruptTrue(value));
    }

    public static <T> TypedEventResult<T> stop(T value) {
        return new TypedEventResult<>(CompoundEventResult.interruptDefault(value));
    }

    public static <T> TypedEventResult<T> pass() {
        return new TypedEventResult<>(CompoundEventResult.pass());
    }

    public static <T> TypedEventResult<T> fail(T value) {
        return new TypedEventResult<>(CompoundEventResult.interruptFalse(value));
    }

    @Deprecated
    public dev.architectury.event.CompoundEventResult<T> getResult() {
        return result;
    }

    public class_1269 toActionResult() {
        return result.result().asMinecraft();
    }

    public CompatActionResult toCompatActionResult() {
        return CompatActionResult.of(result.result().asMinecraft());
    }

    public CompatActionResult toCompatActionResult(class_1799 stack) {
        if (result.object() != stack)
            return toCompatActionResult();

        if (toActionResult() == class_1269.field_5812)
            return StackActionResult.success(stack);

        if (toActionResult() == class_1269.field_21466)
            return StackActionResult.consume(stack);

        return toCompatActionResult();
    }

    public CompatActionResult toCompatActionResult(net.pitan76.mcpitanlib.midohra.item.ItemStack stack) {
        return toCompatActionResult(stack.toMinecraft());
    }
}
