package net.pitan76.mcpitanlib.api.event.block;

import net.minecraft.class_1263;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.pitan76.mcpitanlib.api.event.BaseEvent;
import net.pitan76.mcpitanlib.api.util.WorldUtil;
import net.pitan76.mcpitanlib.midohra.block.BlockWrapper;
import net.pitan76.mcpitanlib.midohra.block.entity.BlockEntityWrapper;
import net.pitan76.mcpitanlib.midohra.world.IWorldView;

public class StateReplacedEvent extends BaseEvent {

    public class_2680 state;
    public class_1937 world;
    public class_2338 pos;
    public class_2680 newState;
    public boolean moved;

    // Captured at construction time so getBlockEntity() works even after the world (1.21.x)
    private final class_2586 cachedBlockEntity;

    public StateReplacedEvent(class_2680 state, class_1937 world, class_2338 pos, class_2680 newState, boolean moved) {
        this.state = state;
        this.world = world;
        this.pos = pos;
        this.newState = newState;
        this.moved = moved;

        this.cachedBlockEntity = WorldUtil.hasBlockEntity(world, pos) ? WorldUtil.getBlockEntity(world, pos) : null;
    }

    public class_2680 getState() {
        return state;
    }

    public class_1937 getWorld() {
        return world;
    }

    public class_2338 getPos() {
        return pos;
    }

    public class_2680 getNewState() {
        return newState;
    }

    public boolean isMoved() {
        return moved;
    }

    public boolean isClient() {
        return world.method_8608();
    }

    /**
     * check if the block is the same state
     * @return boolean
     */
    public boolean isSameState() {
        return state.method_27852(newState.method_26204());
    }

    /**
     * check if the block has a block entity
     * @return boolean
     */
    public boolean hasBlockEntity() {
        return getBlockEntity() != null;
    }

    /**
     * get the block entity
     * <p>
     * The block entity is captured at event creation time, so this returns a valid
     * reference even in MC 1.21.x where the world removes the BE before
     * onStateReplaced is invoked.
     * @return BlockEntity
     */
    public class_2586 getBlockEntity() {
        if (cachedBlockEntity != null) return cachedBlockEntity;
        return WorldUtil.getBlockEntity(world, pos);
    }

    /**
     * spawn the drops in the container
     */
    public void spawnDropsInContainer() {
        if (isSameState() || !hasInventory()) return;

        ItemScattererUtil.spawn(getWorld(), getPos(), getBlockEntity());
        updateComparators();
    }

    public boolean hasInventory() {
        return getBlockEntity() instanceof class_1263;
    }

    /**
     * update the comparators
     */
    public void updateComparators() {
        WorldUtil.updateComparators(getWorld(), getPos(), getState().method_26204());
    }

    public net.pitan76.mcpitanlib.midohra.world.World getMidohraWorld() {
        return net.pitan76.mcpitanlib.midohra.world.World.of(world);
    }

    public IWorldView getWorldView() {
        return getMidohraWorld();
    }

    public net.pitan76.mcpitanlib.midohra.block.BlockState getMidohraState() {
        return net.pitan76.mcpitanlib.midohra.block.BlockState.of(state);
    }

    public net.pitan76.mcpitanlib.midohra.util.math.BlockPos getMidohraPos() {
        return net.pitan76.mcpitanlib.midohra.util.math.BlockPos.of(pos);
    }

    public BlockWrapper getBlockWrapper() {
        return BlockWrapper.of(state.method_26204());
    }

    public BlockEntityWrapper getBlockEntityWrapper() {
        return BlockEntityWrapper.of(getBlockEntity());
    }
}
