package net.pitan76.mcpitanlib.api.event.v0.event;

import net.minecraft.class_1268;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.pitan76.mcpitanlib.api.entity.Player;
import net.pitan76.mcpitanlib.api.util.BlockStateUtil;
import net.pitan76.mcpitanlib.api.util.WorldUtil;

public class ClickBlockEvent {
    public Player player;
    public class_1268 hand;
    public class_2338 pos;
    public class_2350 direction;

    public ClickBlockEvent(Player player, class_1268 hand, class_2338 pos, class_2350 direction) {
        this.player = player;
        this.hand = hand;
        this.pos = pos;
        this.direction = direction;
    }

    public ClickBlockEvent(class_1657 player, class_1268 hand, class_2338 pos, class_2350 direction) {
        this.player = new Player(player);
        this.hand = hand;
        this.pos = pos;
        this.direction = direction;
    }

    public Player getPlayer() {
        return player;
    }

    public class_1268 getHand() {
        return hand;
    }

    public class_2338 getPos() {
        return pos;
    }

    public class_2350 getDirection() {
        return direction;
    }

    public boolean isExistPlayer() {
        return player.getEntity() != null;
    }

    public class_1799 getStackInHand() {
        return player.getStackInHand(hand);
    }

    public boolean isEmptyStackInHand() {
        return getStackInHand().method_7960();
    }

    public class_1937 getWorld() {
        return player.getWorld();
    }

    public class_2680 getBlockState() {
        return WorldUtil.getBlockState(getWorld(), getPos());
    }

    public class_2248 getBlock() {
        return BlockStateUtil.getBlock(getBlockState());
    }




}
