package net.pitan76.mcpitanlib.api.event.block;

import net.minecraft.class_2248;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2769;
import net.pitan76.mcpitanlib.api.event.BaseEvent;
import net.pitan76.mcpitanlib.api.state.property.IProperty;
import net.pitan76.mcpitanlib.api.util.DirectionBoolPropertyUtil;

public class AppendPropertiesArgs extends BaseEvent {
    public class_2689.class_2690<class_2248, class_2680> builder;

    public AppendPropertiesArgs(class_2689.class_2690<class_2248, class_2680> builder) {
        this.builder = builder;
    }

    public class_2689.class_2690<class_2248, class_2680> getBuilder() {
        return builder;
    }

    public void addProperty(class_2769<?>... properties) {
        builder.method_11667(properties);
    }

    public void addProperty(IProperty<?>... properties) {
        for (IProperty<?> property : properties) {
            builder.method_11667(property.getProperty());
        }
    }

    public void addAllDirectionBoolProperties() {
        DirectionBoolPropertyUtil.addProperties(this);
    }
}
