package net.pitan76.mcpitanlib.api.event.v1.event;

import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_3966;
import net.pitan76.mcpitanlib.api.entity.Player;
import net.pitan76.mcpitanlib.midohra.item.ItemWrapper;
import org.jetbrains.annotations.Nullable;

public class AttackEntityEvent {

    public Player player;
    public class_1937 world;
    public class_1297 target;
    public class_1268 hand;
    public class_3966 result;

    public AttackEntityEvent(class_1657 player, class_1937 level, class_1297 target, class_1268 hand, @Nullable class_3966 result) {
        this(new Player(player), level, target, hand, result);
    }

    public AttackEntityEvent(Player player, class_1937 level, class_1297 target, class_1268 hand, @Nullable class_3966 result) {
        this.player = player;
        this.world = level;
        this.target = target;
        this.hand = hand;
        this.result = result;
    }

    public Player getPlayer() {
        return player;
    }

    public class_1937 getWorld() {
        return world;
    }

    public class_1297 getTarget() {
        return target;
    }

    public class_3966 getResult() {
        return result;
    }

    public class_1268 getHand() {
        return hand;
    }

    public class_1799 getStackInPlayer() {
        return player.getStackInHand(hand);
    }

    public class_1792 getItemInPlayer() {
        return getStackInPlayer().method_7909();
    }

    public net.pitan76.mcpitanlib.midohra.world.World getWorldAsMidohra() {
        return net.pitan76.mcpitanlib.midohra.world.World.of(world);
    }

    public net.pitan76.mcpitanlib.midohra.item.ItemStack getStackInPlayerAsMidohra() {
        return net.pitan76.mcpitanlib.midohra.item.ItemStack.of(getStackInPlayer());
    }

    public ItemWrapper getItemWrapperInPlayer() {
        return ItemWrapper.of(getItemInPlayer());
    }
}
