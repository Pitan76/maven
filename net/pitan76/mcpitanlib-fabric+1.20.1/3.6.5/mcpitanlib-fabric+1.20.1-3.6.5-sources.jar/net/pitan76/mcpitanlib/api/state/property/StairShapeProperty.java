package net.pitan76.mcpitanlib.api.state.property;

import net.minecraft.class_2778;
import net.pitan76.mcpitanlib.api.util.block.properties.CompatStairShape;
import net.pitan76.mcpitanlib.midohra.block.BlockState;

import java.util.function.Predicate;

public class StairShapeProperty extends EnumProperty<class_2778> {

    public StairShapeProperty(String name, Class<class_2778> type) {
        super(name, type);
    }

    public StairShapeProperty(String name, Class<class_2778> type, Predicate<class_2778> filter) {
        super(name, type, filter);
    }

    public StairShapeProperty(net.minecraft.class_2754<class_2778> property) {
        super(property);
    }

    public static StairShapeProperty ofRaw(net.minecraft.class_2754<class_2778> property) {
        return new StairShapeProperty(property);
    }

    public BlockState with(BlockState state, CompatStairShape value) {
        return super.with(state, value.getStairShape());
    }

    public CompatStairShape getCompat(BlockState state) {
        return CompatStairShape.of(super.get(state));
    }
}
