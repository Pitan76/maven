package net.pitan76.mcpitanlib.api.util.entity;

import net.minecraft.class_1679;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1937;
import net.pitan76.mcpitanlib.api.util.ItemStackUtil;
import org.jetbrains.annotations.Nullable;

public class SpectralArrowEntityUtil {
    public static class_1679 create(class_1937 world, double x, double y, double z, class_1799 stack, @Nullable class_1799 shotFrom) {
        return new class_1679(world, x, y, z);
    }

    public static class_1679 create(class_1937 world, double x, double y, double z, class_1799 stack) {
        return create(world, x, y, z, stack, null);
    }

    public static class_1679 create(class_1937 world, double x, double y, double z) {
        return create(world, x, y, z, ItemStackUtil.getDefaultStack(class_1802.field_8107));
    }

    public static void setVelocity(class_1679 arrow, double x, double y, double z, float velocity, float divergence) {
        arrow.method_7485(x, y, z, velocity, divergence);
    }
}
