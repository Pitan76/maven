package net.pitan76.mcpitanlib.api.event.block;

import net.minecraft.class_2680;

public class FluidStateArgs {
    public class_2680 state;

    public FluidStateArgs(class_2680 state) {
        this.state = state;
    }

    public class_2680 getState() {
        return state;
    }

    public net.pitan76.mcpitanlib.midohra.block.BlockState getMidohraState() {
        return net.pitan76.mcpitanlib.midohra.block.BlockState.of(state);
    }
}
