package net.pitan76.mcpitanlib.api.event.block;

import net.minecraft.class_1268;
import net.minecraft.class_1750;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_2769;
import net.minecraft.class_3965;
import net.pitan76.mcpitanlib.api.entity.Player;
import net.pitan76.mcpitanlib.api.event.BaseEvent;
import net.pitan76.mcpitanlib.api.event.item.ItemUseOnBlockEvent;
import net.pitan76.mcpitanlib.api.state.property.IProperty;
import net.pitan76.mcpitanlib.api.util.BlockStateUtil;
import net.pitan76.mcpitanlib.api.util.WorldUtil;
import net.pitan76.mcpitanlib.mixin.ItemUsageContextMixin;
import org.jetbrains.annotations.Nullable;

public class PlacementStateArgs extends BaseEvent {
    public class_1750 ctx;

    @Nullable
    public class_2248 block;

    public PlacementStateArgs(class_1750 ctx) {
        this.ctx = ctx;
    }

    public PlacementStateArgs(class_1750 ctx, @Nullable class_2248 block) {
        this.ctx = ctx;
        this.block = block;
    }

    public boolean canPlace() {
        return ctx.method_7716();
    }

    public class_2338 getPos() {
        return ctx.method_8037();
    }

    public Player getPlayer() {
        return new Player(ctx.method_8036());
    }

    public class_2350[] getPlacementDirections() {
        return ctx.method_7718();
    }

    public class_1268 getHand() {
        return ctx.method_20287();
    }

    public class_2350 getSide() {
        return ctx.method_8038();
    }

    public class_2350 getHorizontalPlayerFacing() {
        return ctx.method_8042();
    }

    public float getPlayerYaw() {
        return ctx.method_8044();
    }

    public class_1937 getWorld() {
        return ctx.method_8045();
    }

    public boolean isClient() {
        return getWorld().method_8608();
    }

    public class_243 getHitPos() {
        return ctx.method_17698();
    }

    public boolean canReplaceExisting() {
        return ctx.method_7717();
    }

    @Deprecated
    public ItemUsageContextMixin getIUCAccessor() {
        return (ItemUsageContextMixin) ctx;
    }

    public class_3965 getHitResult() {
        return getIUCAccessor().getHit();
    }

    public ItemUseOnBlockEvent toItemUseOnBlockEvent() {
        return new ItemUseOnBlockEvent(getWorld(), getPlayer().getPlayerEntity(), getHand(), ctx.method_8041(), getHitResult());
    }

    public class_1750 getCtx() {
        return ctx;
    }

    public <T extends Comparable<T>, V extends T> class_2680 withBlockState(class_2769<T> property, V value) {
        if (block == null)
            return null;

        return BlockStateUtil.with(BlockStateUtil.getDefaultState(block), property, value);
    }

    public <T extends Comparable<T>, V extends T> net.pitan76.mcpitanlib.midohra.block.BlockState with(IProperty<T> property, V value) {
        return net.pitan76.mcpitanlib.midohra.block.BlockState.of(withBlockState(property.getProperty(), value));
    }

    public class_2680 getBlockState() {
        return BlockStateUtil.getDefaultState(block);
    }

    public net.pitan76.mcpitanlib.midohra.block.BlockState getMidohraBlockState() {
        return net.pitan76.mcpitanlib.midohra.block.BlockState.of(getBlockState());
    }

    public class_2586 getBlockEntity() {
        return WorldUtil.getBlockEntity(getWorld(), getPos());
    }
}
