package net.pitan76.mcpitanlib.api.transfer.fluid.v1;

import net.minecraft.class_3611;
import net.minecraft.class_3612;
import net.pitan76.mcpitanlib.midohra.fluid.FluidWrapper;

public interface IFluidVariant {
    class_3611 getFluid();

    default FluidWrapper getWrapper() {
        return FluidWrapper.of(getFluid());
    }

    default boolean isSame(IFluidVariant variant) {
        return getFluid() == variant.getFluid();
    }

    default boolean isSame(class_3611 fluid) {
        return getFluid() == fluid;
    }

    default boolean isBlank() {
        return getFluid() == null || getFluid() == class_3612.field_15906;
    }

    static IFluidVariant of(class_3611 fluid) {
        return FluidStorageUtil.getVariant(fluid);
    }
}
