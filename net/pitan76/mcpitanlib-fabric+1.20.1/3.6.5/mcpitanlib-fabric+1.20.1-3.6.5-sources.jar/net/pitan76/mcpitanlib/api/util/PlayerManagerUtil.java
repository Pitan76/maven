package net.pitan76.mcpitanlib.api.util;

import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_3324;
import net.minecraft.server.MinecraftServer;
import net.pitan76.mcpitanlib.api.entity.Player;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class PlayerManagerUtil {

    /**
     * Get player by UUID
     * @param server MinecraftServer
     * @param uuid UUID
     * @return Player
     */
    public static Player getPlayerByUUID(MinecraftServer server, UUID uuid) {
        return PlayerUtil.getPlayerByUUID(server, uuid);
    }

    /**
     * Get player by name
     * @param server MinecraftServer
     * @param name String
     * @return Player
     */
    public static Player getPlayerByName(MinecraftServer server, String name) {
        return PlayerUtil.getPlayerByName(server, name);
    }

    /**
     * Get players by IP
     * @param server MinecraftServer
     * @param ip String
     * @return List<Player>
     */
    public static List<Player> getPlayersByIP(MinecraftServer server, String ip) {
        return PlayerUtil.getPlayersByIP(server, ip);
    }

    /**
     * Get players
     * @param server MinecraftServer
     * @return List<Player>
     */
    public static List<Player> getPlayers(MinecraftServer server) {
        return PlayerUtil.getPlayers(server);
    }

    /**
     * Get players
     * @param world World
     * @return List<Player>
     */
    public static List<Player> getPlayers(class_1937 world) {
        List<Player> players = new ArrayList<>();
        for (class_1657 p : world.method_18456()) {
            players.add(new Player(p));
        }
        return players;
    }

    /**
     * Get player by UUID
     * @param world World
     * @param uuid UUID
     * @return Player
     */
    public static Player getPlayerByUUID(class_1937 world, UUID uuid) {
        return PlayerUtil.getPlayerByUUID(world, uuid);
    }

    /**
     * Get player by name
     * @param world World
     * @param name String
     * @return Player
     */
    public static Player getPlayerByName(class_1937 world, String name) {
        return PlayerUtil.getPlayerByName(world, name);
    }

    public static class_3324 getPlayerManager(MinecraftServer server) {
        return ServerUtil.getPlayerManager(server);
    }

    public static class_3324 getPlayerManager(class_1937 world) {
        return getPlayerManager(world.method_8503());
    }

    public static boolean hasPlayerByUUID(class_3324 playerManager, UUID uuid) {
        return playerManager.method_14602(uuid) != null;
    }

    public static boolean hasPlayerByName(class_3324 playerManager, String name) {
        return playerManager.method_14566(name) != null;
    }

    public static boolean hasPlayerByIP(class_3324 playerManager, String ip) {
        return !playerManager.method_14559(ip).isEmpty();
    }

    public static boolean hasPlayerByUUID(MinecraftServer server, UUID uuid) {
        return hasPlayerByUUID(getPlayerManager(server), uuid);
    }

    public static boolean hasPlayerByName(MinecraftServer server, String name) {
        return hasPlayerByName(getPlayerManager(server), name);
    }

    public static boolean hasPlayerByIP(MinecraftServer server, String ip) {
        return hasPlayerByIP(getPlayerManager(server), ip);
    }

    public static boolean hasPlayerByUUID(class_1937 world, UUID uuid) {
        return hasPlayerByUUID(getPlayerManager(world), uuid);
    }

    public static boolean hasPlayerByName(class_1937 world, String name) {
        return hasPlayerByName(getPlayerManager(world), name);
    }

    public static boolean hasPlayerByIP(class_1937 world, String ip) {
        return hasPlayerByIP(getPlayerManager(world), ip);
    }
}
