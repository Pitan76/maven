package net.pitan76.mcpitanlib.api.event.item;

import net.minecraft.class_1297;
import net.minecraft.class_1304;
import net.minecraft.class_1309;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_3218;
import net.pitan76.mcpitanlib.api.entity.Player;
import net.pitan76.mcpitanlib.api.event.BaseEvent;
import net.pitan76.mcpitanlib.api.item.ArmorEquipmentType;
import net.pitan76.mcpitanlib.api.util.WorldUtil;
import net.pitan76.mcpitanlib.api.util.entity.EquipmentSlotUtil;
import net.pitan76.mcpitanlib.api.util.entity.LivingEntityUtil;
import net.pitan76.mcpitanlib.midohra.entity.EntityWrapper;

public class InventoryTickEvent extends BaseEvent {
    public class_1799 stack;
    public class_1937 world;
    public class_1297 entity;
    public int slot;
    public boolean selected;
    public class_1304 equipmentSlot;

    public InventoryTickEvent(class_1799 stack, class_1937 world, class_1297 entity, int slot, boolean selected) {
        this.stack = stack;
        this.world = world;
        this.entity = entity;
        this.slot = slot;
        this.selected = selected;
        this.equipmentSlot = EquipmentSlotUtil.fromEntitySlotId(slot);
    }

    public InventoryTickEvent(class_1799 stack, class_3218 world, class_1297 entity, class_1304 slot) {
        this(stack, world, entity, EquipmentSlotUtil.getEntitySlotId(slot), isSelected(entity, slot, stack));
        this.equipmentSlot = slot;
    }

    private static boolean isSelected(class_1297 entity, class_1304 slot, class_1799 stack) {
        if (entity instanceof class_1309) {
            class_1309 livingEntity = (class_1309) entity;
            class_1799 equippedStack = LivingEntityUtil.getEquippedStack(livingEntity, slot);
            return equippedStack.method_31574(stack.method_7909()) && equippedStack.method_7947() == stack.method_7947();
        } else {
            return false;
        }
    }

    public class_1799 getStack() {
        return stack;
    }

    public class_1937 getWorld() {
        return world;
    }

    public boolean isServer() {
        return !isClient();
    }

    public class_3218 getServerWorld() {
        return (class_3218) world;
    }

    public class_1297 getEntity() {
        return entity;
    }

    public int getSlot() {
        return slot;
    }

    public boolean isSelected() {
        return selected;
    }
    
    public boolean isClient() {
        return WorldUtil.isClient(world);
    }

    public class_1304 getEquipmentSlot() {
        return equipmentSlot;
    }

    public ArmorEquipmentType getArmorEquipmentType() {
        return EquipmentSlotUtil.getArmorEquipmentType(equipmentSlot);
    }

    public boolean isPlayer() {
        return getEntity() instanceof net.minecraft.class_1657;
    }

    public Player getPlayer() {
        if (isPlayer()) {
            return new Player((net.minecraft.class_1657) getEntity());
        } else {
            return null;
        }
    }

    public EntityWrapper getEntityWrapper() {
        return EntityWrapper.of(getEntity());
    }

    public net.pitan76.mcpitanlib.midohra.world.World getMidohraWorld() {
        return net.pitan76.mcpitanlib.midohra.world.World.of(getWorld());
    }

    public net.pitan76.mcpitanlib.midohra.item.ItemStack getStackM() {
        return net.pitan76.mcpitanlib.midohra.item.ItemStack.of(getStack());
    }

    public net.pitan76.mcpitanlib.midohra.world.ServerWorld getServerWorldM() {
        return net.pitan76.mcpitanlib.midohra.world.ServerWorld.of(getServerWorld());
    }
}
