package net.pitan76.mcpitanlib.api.event.block;

import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.pitan76.mcpitanlib.api.entity.Player;
import net.pitan76.mcpitanlib.api.event.BaseEvent;
import net.pitan76.mcpitanlib.api.util.WorldUtil;
import net.pitan76.mcpitanlib.midohra.block.BlockWrapper;
import net.pitan76.mcpitanlib.midohra.block.entity.BlockEntityWrapper;
import net.pitan76.mcpitanlib.midohra.world.IWorldView;

public class BlockBreakEvent extends BaseEvent {
    public class_1937 world;
    public class_2338 pos;
    public class_2680 state;
    public Player player;

    public BlockBreakEvent(class_1937 world, class_2338 pos, class_2680 state, class_1657 player) {
        this.world = world;
        this.pos = pos;
        this.state = state;
        this.player = new Player(player);
    }

    public class_2338 getPos() {
        return pos;
    }

    public class_2680 getState() {
        return state;
    }

    public Player getPlayer() {
        return player;
    }

    public class_1657 getPlayerEntity() {
        return player.getPlayerEntity();
    }

    public class_1937 getWorld() {
        return world;
    }

    public boolean isClient() {
        return world.method_8608();
    }

    public class_2586 getBlockEntity() {
        return WorldUtil.getBlockEntity(getWorld(), getPos());
    }

    public net.pitan76.mcpitanlib.midohra.world.World getMidohraWorld() {
        return net.pitan76.mcpitanlib.midohra.world.World.of(world);
    }

    public IWorldView getWorldView() {
        return getMidohraWorld();
    }

    public net.pitan76.mcpitanlib.midohra.block.BlockState getMidohraState() {
        return net.pitan76.mcpitanlib.midohra.block.BlockState.of(state);
    }

    public net.pitan76.mcpitanlib.midohra.util.math.BlockPos getMidohraPos() {
        return net.pitan76.mcpitanlib.midohra.util.math.BlockPos.of(pos);
    }

    public BlockWrapper getBlockWrapper() {
        return BlockWrapper.of(state.method_26204());
    }

    public BlockEntityWrapper getBlockEntityWrapper() {
        return BlockEntityWrapper.of(getBlockEntity());
    }
}
