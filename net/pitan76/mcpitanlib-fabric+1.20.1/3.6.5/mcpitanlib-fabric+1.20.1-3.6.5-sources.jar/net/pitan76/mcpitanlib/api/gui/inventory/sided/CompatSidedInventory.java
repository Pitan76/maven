package net.pitan76.mcpitanlib.api.gui.inventory.sided;

import net.minecraft.class_1278;
import net.minecraft.class_1799;
import net.minecraft.class_2350;
import net.pitan76.mcpitanlib.api.gui.inventory.sided.args.AvailableSlotsArgs;
import net.pitan76.mcpitanlib.api.gui.inventory.sided.args.CanExtractArgs;
import net.pitan76.mcpitanlib.api.gui.inventory.sided.args.CanInsertArgs;
import org.jetbrains.annotations.Nullable;

public interface CompatSidedInventory extends class_1278 {
    @Override
    @Deprecated
    default int[] method_5494(class_2350 side) {
        return getAvailableSlots(new AvailableSlotsArgs(side, this));
    }

    int[] getAvailableSlots(AvailableSlotsArgs args);

    @Override
    @Deprecated
    default boolean method_5492(int slot, class_1799 stack, @Nullable class_2350 dir) {
        return canInsert(new CanInsertArgs(slot, stack, dir));
    }

    boolean canInsert(CanInsertArgs args);

    @Override
    @Deprecated
    default boolean method_5493(int slot, class_1799 stack, class_2350 dir) {
        return canExtract(new CanExtractArgs(slot, stack, dir));
    }

    boolean canExtract(CanExtractArgs args);
}
