package net.pitan76.mcpitanlib.api.event.block;

import net.minecraft.class_1936;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2586;
import net.minecraft.class_2680;

public class StateForNeighborUpdateArgs {
    public class_2680 state;
    public class_2350 direction;
    public class_2680 neighborState;
    public class_1936 world;
    public class_2338 pos;
    public class_2338 neighborPos;

    public StateForNeighborUpdateArgs(class_2680 state, class_2350 direction, class_2680 neighborState, class_1936 world, class_2338 pos, class_2338 neighborPos) {
        this.state = state;
        this.direction = direction;
        this.neighborState = neighborState;
        this.world = world;
        this.pos = pos;
        this.neighborPos = neighborPos;
    }

    public class_2680 getState() {
        return state;
    }

    public class_2586 getBlockEntity() {
        return world.method_8321(pos);
    }

    public class_2680 getBlockState(class_2338 pos) {
        return world.method_8320(pos);
    }

    public class_2586 getBlockEntity(class_2338 pos) {
        return world.method_8321(pos);
    }

    public class_2350 getDirection() {
        return direction;
    }

    public class_2680 getNeighborState() {
        return neighborState;
    }

    public class_1936 getWorld() {
        return world;
    }

    public class_2338 getPos() {
        return pos;
    }

    public class_2338 getNeighborPos() {
        return neighborPos;
    }
}
