package net.pitan76.mcpitanlib.api.command.argument;

import net.minecraft.class_1297;
import net.minecraft.class_2186;
import net.pitan76.mcpitanlib.api.event.PlayersCommandEvent;
import net.pitan76.mcpitanlib.api.event.ServerCommandEvent;

public abstract class PlayersCommand extends RequiredCommand<class_1297> {
    @Override
    public class_2186 getArgumentType() {
        return class_2186.method_9308();
    }

    public abstract void execute(PlayersCommandEvent event);

    @Override
    public void execute(ServerCommandEvent event) {
        execute((PlayersCommandEvent) event);
    }
}
