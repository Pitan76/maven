package net.pitan76.mcpitanlib.api.item;

import net.minecraft.class_1304;
import net.minecraft.class_1738;
import org.jetbrains.annotations.Nullable;

public class ArmorEquipmentType {

    public static ArmorEquipmentType HEAD = new ArmorEquipmentType(class_1304.field_6169, class_1738.class_8051.field_41934);
    public static ArmorEquipmentType CHEST = new ArmorEquipmentType(class_1304.field_6174, class_1738.class_8051.field_41935);
    public static ArmorEquipmentType LEGS = new ArmorEquipmentType(class_1304.field_6172, class_1738.class_8051.field_41936);
    public static ArmorEquipmentType FEET = new ArmorEquipmentType(class_1304.field_6166, class_1738.class_8051.field_41937);

    // New type for animals from 1.20.5
    public static ArmorEquipmentType BODY = new ArmorEquipmentType(null, null);

    protected final class_1304 slot;
    protected final class_1738.class_8051 type;

    protected ArmorEquipmentType(class_1304 slot, class_1738.class_8051 type) {
        this.slot = slot;
        this.type = type;
    }

    @Deprecated
    public class_1304 getSlot() {
        return slot;
    }

    @Deprecated
    public class_1738.class_8051 getType() {
        return type;
    }

    @Nullable
    public static ArmorEquipmentType of(class_1304 slot) {
        switch (slot) {
            case field_6169 -> {
                return HEAD;
            }
            case field_6174 -> {
                return CHEST;
            }
            case field_6172 -> {
                return LEGS;
            }
            case field_6166 -> {
                return FEET;
            }
            default -> {
                return null;
            }
        }
    }

    @Nullable
    public static ArmorEquipmentType of(class_1738.class_8051 type) {
        switch (type) {
            case field_41934 -> {
                return HEAD;
            }
            case field_41935 -> {
                return CHEST;
            }
            case field_41936 -> {
                return LEGS;
            }
            case field_41937 -> {
                return FEET;
            }
            default -> {
                return null;
            }
        }
    }
}
