package net.pitan76.mcpitanlib.api.util.block.properties;

import net.minecraft.class_2778;
import net.pitan76.mcpitanlib.api.util.CompatStringIdentifiable;

public class CompatStairShape implements CompatStringIdentifiable {
    private final class_2778 stairShape;

    public static final CompatStairShape STRAIGHT = of(class_2778.field_12710);
    public static final CompatStairShape INNER_LEFT = of(class_2778.field_12712);
    public static final CompatStairShape INNER_RIGHT = of(class_2778.field_12713);
    public static final CompatStairShape OUTER_LEFT = of(class_2778.field_12708);
    public static final CompatStairShape OUTER_RIGHT = of(class_2778.field_12709);

    public CompatStairShape(class_2778 stairShape) {
        this.stairShape = stairShape;
    }

    public static CompatStairShape of(class_2778 stairShape) {
        return new CompatStairShape(stairShape);
    }

    public class_2778 getStairShape() {
        return stairShape;
    }

    public String getName() {
        return stairShape.name();
    }

    @Override
    public String asString_compat() {
        return getName();
    }

    @Override
    public int hashCode() {
        return stairShape.hashCode();
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        CompatStairShape other = (CompatStairShape) obj;
        return stairShape == other.stairShape;
    }
}
