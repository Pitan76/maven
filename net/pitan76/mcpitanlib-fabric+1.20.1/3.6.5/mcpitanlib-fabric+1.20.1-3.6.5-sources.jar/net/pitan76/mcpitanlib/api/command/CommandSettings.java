package net.pitan76.mcpitanlib.api.command;

import net.minecraft.class_2168;

public class CommandSettings {
    private int permissionLevel = -1;
    private ICustom iCustom = null;

    public boolean requires(class_2168 source) {

        return customRequires(source) && (permissionLevel == -1 || source.method_9259(permissionLevel));
    }

    private boolean customRequires(class_2168 source) {
        if (iCustom == null) return true;
        return iCustom.custom(source);
    }

    public CommandSettings permissionLevel(int level) {
        this.permissionLevel = level;
        return this;
    }

    public CommandSettings custom(ICustom iCustom) {
        this.iCustom = iCustom;
        return this;
    }

    @FunctionalInterface
    public interface ICustom {
        boolean custom(class_2168 source);
    }
}
