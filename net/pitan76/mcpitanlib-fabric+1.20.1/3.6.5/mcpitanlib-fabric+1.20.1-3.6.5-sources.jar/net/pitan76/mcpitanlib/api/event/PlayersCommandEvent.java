package net.pitan76.mcpitanlib.api.event;

import com.mojang.brigadier.exceptions.CommandSyntaxException;
import net.minecraft.class_1297;
import net.minecraft.class_2186;
import net.pitan76.mcpitanlib.api.command.argument.PlayersCommand;

public class PlayersCommandEvent extends RequiredCommandEvent {
    public class_1297 getValue() {
        try {
            return class_2186.method_9315(context, ((PlayersCommand) getCommand()).getArgumentName());
        } catch (CommandSyntaxException e) {
            throw new RuntimeException(e);
        }
    }
}
