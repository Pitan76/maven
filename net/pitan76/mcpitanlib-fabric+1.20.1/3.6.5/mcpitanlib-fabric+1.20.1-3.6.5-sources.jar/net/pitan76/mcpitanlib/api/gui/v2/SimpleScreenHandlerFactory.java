package net.pitan76.mcpitanlib.api.gui.v2;

import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_2561;
import net.minecraft.class_3908;
import net.pitan76.mcpitanlib.api.event.container.factory.DisplayNameArgs;
import net.pitan76.mcpitanlib.api.gui.args.CreateMenuEvent;

public interface SimpleScreenHandlerFactory extends class_3908 {
    @Override
    default class_2561 method_5476() {
        return getDisplayName(new DisplayNameArgs());
    }

    class_2561 getDisplayName(DisplayNameArgs args);

    @Override
    default class_1703 createMenu(int syncId, class_1661 playerInventory, class_1657 player) {
        return createMenu(new CreateMenuEvent(syncId, playerInventory, player));
    }

    class_1703 createMenu(CreateMenuEvent event);
}
