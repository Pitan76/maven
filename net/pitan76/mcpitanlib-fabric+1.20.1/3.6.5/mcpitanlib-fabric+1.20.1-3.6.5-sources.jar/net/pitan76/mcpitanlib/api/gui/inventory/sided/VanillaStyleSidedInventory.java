package net.pitan76.mcpitanlib.api.gui.inventory.sided;

import net.minecraft.class_2350;
import net.pitan76.mcpitanlib.api.gui.inventory.sided.args.CanExtractArgs;
import net.pitan76.mcpitanlib.api.gui.inventory.sided.args.CanInsertArgs;

public interface VanillaStyleSidedInventory extends CompatSidedInventory {
    @Override
    default boolean canInsert(CanInsertArgs args) {
        if (args.getDir() == null)
            return false;

        return args.getDir() != class_2350.field_11033;
    }

    @Override
    default boolean canExtract(CanExtractArgs args) {
        return args.getDir() == class_2350.field_11033;
    }
}
