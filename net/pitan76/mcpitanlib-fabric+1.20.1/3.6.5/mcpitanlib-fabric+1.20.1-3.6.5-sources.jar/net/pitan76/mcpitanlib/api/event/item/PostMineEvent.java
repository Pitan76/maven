package net.pitan76.mcpitanlib.api.event.item;

import net.minecraft.class_1304;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.pitan76.mcpitanlib.api.entity.Player;
import net.pitan76.mcpitanlib.api.event.BaseEvent;
import net.pitan76.mcpitanlib.api.item.ArmorEquipmentType;
import net.pitan76.mcpitanlib.api.tag.TagKey;
import net.pitan76.mcpitanlib.api.util.BlockUtil;
import net.pitan76.mcpitanlib.api.util.WorldUtil;

public class PostMineEvent extends BaseEvent {
    public class_1799 stack;
    public class_1937 world;
    public class_2680 state;
    public class_2338 pos;
    public class_1309 miner;

    public PostMineEvent(class_1799 stack, class_1937 world, class_2680 state, class_2338 pos, class_1309 miner) {
        this.stack = stack;
        this.world = world;
        this.state = state;
        this.pos = pos;
        this.miner = miner;
    }

    public class_2680 getState() {
        return state;
    }

    public class_2338 getPos() {
        return pos;
    }

    public class_1937 getWorld() {
        return world;
    }

    public class_1799 getStack() {
        return stack;
    }

    public class_1309 getMiner() {
        return miner;
    }

    public class_2586 getBlockEntity() {
        return WorldUtil.getBlockEntity(world, pos);
    }

    public boolean isClient() {
        return world.field_9236;
    }

    public boolean stateIsIn(TagKey<class_2248> tagKey) {
        return BlockUtil.isIn(state.method_26204(), tagKey);
    }

    public boolean stateIsOf(class_2248 block) {
        return BlockUtil.isEqual(state.method_26204(), block);
    }

    /**
     * Damages the stack in the given slot
     * @param amount the amount of damage to deal
     * @param slot the slot to damage
     */
    public void damageStack(int amount, class_1304 slot) {
        stack.method_7956(amount, miner, (entity) -> {
            entity.method_20235(slot);
        });
    }

    /**
     * Damages the stack in the given slot
     * @param amount the amount of damage to deal
     * @param type the type of armor equipment
     */
    public void damageStack(int amount, ArmorEquipmentType type) {
        stack.method_7956(amount, miner, (entity) -> {
            entity.method_20235(type.getSlot());
        });
    }

    /**
     * Damages the stack in the main hand
     * @param amount the amount of damage to deal
     */
    public void damageStack(int amount) {
        stack.method_7956(amount, miner, (entity) -> {
            entity.method_20235(class_1304.field_6173);
        });
    }

    public boolean isPlayer() {
        return miner instanceof class_1657;
    }

    public Player getPlayer() {
        if (isPlayer())
            return new Player((class_1657) miner);

        return null;
    }

    public boolean isCreative() {
        return isPlayer() && getPlayer().isCreative();
    }

    public boolean isSneaking() {
        return miner.method_5715();
    }

    public class_1799 getMainHandStack() {
        return miner.method_6047();
    }
}
