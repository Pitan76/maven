package net.pitan76.mcpitanlib.api.item;

import net.minecraft.class_1761;
import net.minecraft.class_7706;
import net.minecraft.class_7923;

public class DefaultItemGroups {
    public static final class_1761 BUILDING_BLOCKS = class_7923.field_44687.method_29107(class_7706.field_40195);
    public static final class_1761 COLORED_BLOCKS = class_7923.field_44687.method_29107(class_7706.field_41059); // if 1.19.2 and below, BUILDING_BLOCKS
    public static final class_1761 NATURAL = class_7923.field_44687.method_29107(class_7706.field_40743); // if 1.19.2 and below, DECORATIONS
    public static final class_1761 FUNCTIONAL = class_7923.field_44687.method_29107(class_7706.field_40197); // if 1.19.2 and below, TRANSPORTATION
    public static final class_1761 REDSTONE = class_7923.field_44687.method_29107(class_7706.field_40198);
    public static final class_1761 HOTBAR = class_7923.field_44687.method_29107(class_7706.field_40199);
    public static final class_1761 SEARCH = class_7923.field_44687.method_29107(class_7706.field_40200);
    public static final class_1761 TOOLS = class_7923.field_44687.method_29107(class_7706.field_41060);
    public static final class_1761 COMBAT = class_7923.field_44687.method_29107(class_7706.field_40202);
    public static final class_1761 FOOD_AND_DRINK = class_7923.field_44687.method_29107(class_7706.field_41061); // if 1.19.2 and below, FOOD
    public static final class_1761 INGREDIENTS = class_7923.field_44687.method_29107(class_7706.field_41062); // if 1.19.2 and below, MISC
    public static final class_1761 SPAWN_EGGS = class_7923.field_44687.method_29107(class_7706.field_40205); // if 1.19.2 and below, MISC
    public static final class_1761 OPERATOR = class_7923.field_44687.method_29107(class_7706.field_41063); // if 1.19.2 and below, MISC
    public static final class_1761 INVENTORY = class_7923.field_44687.method_29107(class_7706.field_40206);

    // ～1.19.2 Item Group
    public static final class_1761 BREWING = FOOD_AND_DRINK;
    public static final class_1761 TRANSPORTATION = FUNCTIONAL;
    public static final class_1761 DECORATIONS = NATURAL;
    public static final class_1761 MISC = INGREDIENTS;
}