package net.pitan76.mcpitanlib.api.tile.v2;

import com.mojang.datafixers.types.Type;
import net.minecraft.class_2248;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.pitan76.mcpitanlib.midohra.block.SupplierBlockWrapper;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Supplier;

public class BlockEntityTypeBuilder<T extends class_2586> extends net.pitan76.mcpitanlib.api.tile.BlockEntityTypeBuilder<T> {
    private final Factory<? extends T> factory;
    private final Consumer<List<class_2248>> consumer;

    public BlockEntityTypeBuilder(Factory<? extends T> factory, Consumer<List<class_2248>> blocks) {
        super(null, null);

        this.factory = factory;
        this.consumer = blocks;
    }

    @Deprecated
    public static <T extends class_2586> BlockEntityTypeBuilder<T> create(Factory<? extends T> factory, class_2248... blocks) {
        throw new IllegalStateException("Use create(Factory, Consumer<List<Block>>) instead");
    }

    public static <T extends class_2586> BlockEntityTypeBuilder<T> create(BlockEntityTypeBuilder.Factory<? extends T> factory, Consumer<List<class_2248>> blocks) {
        return new BlockEntityTypeBuilder<>(factory, blocks);
    }

    public static <T extends class_2586> BlockEntityTypeBuilder<T> createA(BlockEntityTypeBuilder.Factory<? extends T> factory, Supplier<class_2248> block) {
        return new BlockEntityTypeBuilder<>(factory, blocks -> {
            blocks.add(block.get());
        });
    }

    public static <T extends class_2586> BlockEntityTypeBuilder<T> create(BlockEntityTypeBuilder.Factory<? extends T> factory, SupplierBlockWrapper wrapper) {
        return new BlockEntityTypeBuilder<>(factory, blocks -> {
            blocks.add(wrapper.get());
        });
    }

    @Override
    @Deprecated
    public BlockEntityTypeBuilder<T> addBlock(class_2248 block) {
        return this;
    }

    @Override
    @Deprecated
    public BlockEntityTypeBuilder<T> addBlocks(class_2248... blocks) {
        return this;
    }

    public class_2591<T> build() {
        return build(null);
    }

    public class_2591<T> build(Type<?> type) {
        List<class_2248> blocks = new ArrayList<>();
        if (consumer != null)
            consumer.accept(blocks);

        return class_2591.class_2592.<T>method_20528(factory::create, blocks.toArray(new class_2248[0])).method_11034(type);
    }
}
