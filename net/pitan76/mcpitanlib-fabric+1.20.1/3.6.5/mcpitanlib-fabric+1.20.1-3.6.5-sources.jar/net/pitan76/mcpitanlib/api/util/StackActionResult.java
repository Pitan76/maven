package net.pitan76.mcpitanlib.api.util;

import net.minecraft.class_1269;
import net.minecraft.class_1271;
import net.minecraft.class_1799;
import net.pitan76.mcpitanlib.api.event.result.EventResult;

import java.util.Optional;

public class StackActionResult extends CompatActionResult {
    private final class_1799 stack;
    private final CompatActionResult compatActionResult;
    private boolean isNewStack = false;

    public StackActionResult(class_1269 actionResult, EventResult eventResult, class_1799 stack) {
        this(new CompatActionResult(actionResult, eventResult), stack);
    }

    public StackActionResult(CompatActionResult actionResult, class_1799 stack) {
        super(null, null);
        compatActionResult = actionResult;
        this.stack = stack;
    }

    public void setNewStack(boolean b) {
        isNewStack = b;
    }

    @Override
    public class_1269 toActionResult() {
        return compatActionResult.toActionResult();
    }

    @Override
    public EventResult toEventResult() {
        return compatActionResult.toEventResult();
    }

    @Deprecated
    @Override
    public Optional<class_1799> getNewHandStack() {
        if (hasNewStack())
            return Optional.ofNullable(getStack());

        return Optional.empty();
    }

    public boolean hasNewStack() {
        return isNewStack;
    }

    public boolean hasStack() {
        return getStack() != null;
    }

    public CompatActionResult asCompatActionResult() {
        return compatActionResult;
    }

    public static StackActionResult create(CompatActionResult compatActionResult, class_1799 stack) {
        return new StackActionResult(compatActionResult, stack);
    }

    public static StackActionResult create(CompatActionResult compatActionResult) {
        return new StackActionResult(compatActionResult, null);
    }

    public static StackActionResult create(class_1269 actionResult, EventResult eventResult, class_1799 stack) {
        return new StackActionResult(actionResult, eventResult, stack);
    }

    public static StackActionResult create(class_1269 actionResult, class_1799 stack) {
        return new StackActionResult(actionResult, null, stack);
    }

    public static StackActionResult create(class_1271<class_1799> result) {
        StackActionResult actionResult = create(CompatActionResult.create(result.method_5467()), result.method_5466());
        actionResult.setNewStack(true);
        return actionResult;
    }

    public static StackActionResult success(class_1799 stack) {
        CompatActionResult compatActionResult = CompatActionResult.create(class_1269.field_5812);
        StackActionResult actionResult = create(compatActionResult, stack);
        actionResult.setNewStack(true);
        return actionResult;
    }

    public static StackActionResult successServer(class_1799 stack) {
        CompatActionResult compatActionResult = CompatActionResult.create(class_1269.field_5812);
        StackActionResult actionResult = create(compatActionResult, stack);
        actionResult.setNewStack(true);
        return actionResult;
    }

    public static StackActionResult consume(class_1799 stack) {
        CompatActionResult compatActionResult = CompatActionResult.create(class_1269.field_21466);
        StackActionResult actionResult = create(compatActionResult, stack);
        actionResult.setNewStack(true);
        return actionResult;
    }

    public class_1271<class_1799> toTypedActionResult() {
        return new class_1271<>(toActionResult(), getStack());
    }

    public static StackActionResult pass(class_1799 stack) {
        return create(CompatActionResult.PASS, stack);
    }

    public static StackActionResult pass() {
        return create(CompatActionResult.PASS);
    }

    public static StackActionResult fail(class_1799 stack) {
        return create(CompatActionResult.FAIL, stack);
    }

    public static StackActionResult fail() {
        return create(CompatActionResult.FAIL);
    }

    public class_1799 getStack() {
        return stack;
    }
}
