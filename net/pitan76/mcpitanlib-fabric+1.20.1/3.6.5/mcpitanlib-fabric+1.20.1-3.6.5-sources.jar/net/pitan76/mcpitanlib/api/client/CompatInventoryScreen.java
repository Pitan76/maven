package net.pitan76.mcpitanlib.api.client;

import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.pitan76.mcpitanlib.api.util.CompatIdentifier;

@Deprecated
public abstract class CompatInventoryScreen extends SimpleInventoryScreen {

    public CompatInventoryScreen(class_1703 handler, class_1661 inventory, class_2561 title) {
        super(handler, inventory, title);
    }

    public abstract CompatIdentifier getCompatTexture();

    @Override
    public class_2960 getTexture() {
        return getCompatTexture().toMinecraft();
    }
}
