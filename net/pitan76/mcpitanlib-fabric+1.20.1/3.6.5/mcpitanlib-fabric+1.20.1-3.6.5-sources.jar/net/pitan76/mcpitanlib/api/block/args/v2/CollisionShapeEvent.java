package net.pitan76.mcpitanlib.api.block.args.v2;

import net.minecraft.class_3726;
import net.pitan76.mcpitanlib.midohra.block.BlockState;
import net.pitan76.mcpitanlib.midohra.util.math.BlockPos;
import net.pitan76.mcpitanlib.midohra.world.BlockView;

public class CollisionShapeEvent extends OutlineShapeEvent {

    public CollisionShapeEvent(BlockState state, BlockView world, BlockPos pos, class_3726 context) {
        super(state, world, pos, context);
    }

    public CollisionShapeEvent(net.minecraft.class_2680 state, net.minecraft.class_1922 world, net.minecraft.class_2338 pos, class_3726 context) {
        super(BlockState.of(state), BlockView.of(world), BlockPos.of(pos), context);
    }
}
