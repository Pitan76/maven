package net.pitan76.mcpitanlib.api.sound;

import net.minecraft.class_2498;
import net.minecraft.class_3414;

public class CompatBlockSoundGroup {
    public static final CompatBlockSoundGroup INTENTIONALLY_EMPTY = of(class_2498.field_11544);
    public static final CompatBlockSoundGroup WOOD = of(class_2498.field_11547);
    public static final CompatBlockSoundGroup GRAVEL = of(class_2498.field_11529);
    public static final CompatBlockSoundGroup GRASS = of(class_2498.field_11535);
    public static final CompatBlockSoundGroup LILY_PAD = of(class_2498.field_25183);
    public static final CompatBlockSoundGroup STONE = of(class_2498.field_11544);
    public static final CompatBlockSoundGroup METAL = of(class_2498.field_11533);
    public static final CompatBlockSoundGroup GLASS = of(class_2498.field_11537);
    public static final CompatBlockSoundGroup WOOL = of(class_2498.field_11543);
    public static final CompatBlockSoundGroup SAND = of(class_2498.field_11526);
    public static final CompatBlockSoundGroup SNOW = of(class_2498.field_11548);
    public static final CompatBlockSoundGroup POWDER_SNOW = of(class_2498.field_27884);
    public static final CompatBlockSoundGroup LADDER = of(class_2498.field_11532);
    public static final CompatBlockSoundGroup ANVIL = of(class_2498.field_11531);
    public static final CompatBlockSoundGroup SLIME = of(class_2498.field_11545);
    public static final CompatBlockSoundGroup HONEY = of(class_2498.field_21214);
    public static final CompatBlockSoundGroup WET_GRASS = of(class_2498.field_11534);
    public static final CompatBlockSoundGroup CORAL = of(class_2498.field_11528);
    public static final CompatBlockSoundGroup BAMBOO = of(class_2498.field_11542);
    public static final CompatBlockSoundGroup BAMBOO_SAPLING = of(class_2498.field_11538);
    public static final CompatBlockSoundGroup SCAFFOLDING = of(class_2498.field_16498);
    public static final CompatBlockSoundGroup SWEET_BERRY_BUSH = of(class_2498.field_17579);
    public static final CompatBlockSoundGroup CROP = of(class_2498.field_17580);
    public static final CompatBlockSoundGroup STEM = of(class_2498.field_18852);
    public static final CompatBlockSoundGroup VINE = of(class_2498.field_23083);
    public static final CompatBlockSoundGroup NETHER_WART = of(class_2498.field_17581);
    public static final CompatBlockSoundGroup LANTERN = of(class_2498.field_17734);
    public static final CompatBlockSoundGroup NETHER_STEM = of(class_2498.field_22152);
    public static final CompatBlockSoundGroup NYLIUM = of(class_2498.field_22153);
    public static final CompatBlockSoundGroup FUNGUS = of(class_2498.field_22154);
    public static final CompatBlockSoundGroup ROOTS = of(class_2498.field_22138);
    public static final CompatBlockSoundGroup SHROOMLIGHT = of(class_2498.field_22139);
    public static final CompatBlockSoundGroup WEEPING_VINES = of(class_2498.field_22140);
    public static final CompatBlockSoundGroup WEEPING_VINES_LOW_PITCH = of(class_2498.field_23082);
    public static final CompatBlockSoundGroup SOUL_SAND = of(class_2498.field_22141);
    public static final CompatBlockSoundGroup SOUL_SOIL = of(class_2498.field_22142);
    public static final CompatBlockSoundGroup BASALT = of(class_2498.field_22143);
    public static final CompatBlockSoundGroup WART_BLOCK = of(class_2498.field_22144);
    public static final CompatBlockSoundGroup NETHERRACK = of(class_2498.field_22145);
    public static final CompatBlockSoundGroup NETHER_BRICKS = of(class_2498.field_22146);
    public static final CompatBlockSoundGroup NETHER_SPROUTS = of(class_2498.field_22147);
    public static final CompatBlockSoundGroup NETHER_ORE = of(class_2498.field_22148);
    public static final CompatBlockSoundGroup BONE = of(class_2498.field_22149);
    public static final CompatBlockSoundGroup NETHERITE = of(class_2498.field_22150);
    public static final CompatBlockSoundGroup ANCIENT_DEBRIS = of(class_2498.field_22151);
    public static final CompatBlockSoundGroup LODESTONE = of(class_2498.field_23265);
    public static final CompatBlockSoundGroup CHAIN = of(class_2498.field_24119);
    public static final CompatBlockSoundGroup NETHER_GOLD_ORE = of(class_2498.field_24120);
    public static final CompatBlockSoundGroup GILDED_BLACKSTONE = of(class_2498.field_24121);
    public static final CompatBlockSoundGroup CANDLE = of(class_2498.field_27196);
    public static final CompatBlockSoundGroup AMETHYST_BLOCK = of(class_2498.field_27197);
    public static final CompatBlockSoundGroup AMETHYST_CLUSTER = of(class_2498.field_27198);
    public static final CompatBlockSoundGroup SMALL_AMETHYST_BUD = of(class_2498.field_27199);
    public static final CompatBlockSoundGroup MEDIUM_AMETHYST_BUD = of(class_2498.field_27200);
    public static final CompatBlockSoundGroup LARGE_AMETHYST_BUD = of(class_2498.field_27201);
    public static final CompatBlockSoundGroup TUFF = of(class_2498.field_27202);
    public static final CompatBlockSoundGroup TUFF_BRICKS = of(class_2498.field_11544);
    public static final CompatBlockSoundGroup POLISHED_TUFF = of(class_2498.field_11544);
    public static final CompatBlockSoundGroup CALCITE = of(class_2498.field_27203);
    public static final CompatBlockSoundGroup DRIPSTONE_BLOCK = of(class_2498.field_28060);
    public static final CompatBlockSoundGroup POINTED_DRIPSTONE = of(class_2498.field_28061);
    public static final CompatBlockSoundGroup COPPER = of(class_2498.field_27204);
    public static final CompatBlockSoundGroup COPPER_BULB = of(class_2498.field_11544);
    public static final CompatBlockSoundGroup COPPER_GRATE = of(class_2498.field_11544);
    public static final CompatBlockSoundGroup CAVE_VINES = of(class_2498.field_28692);
    public static final CompatBlockSoundGroup SPORE_BLOSSOM = of(class_2498.field_28693);
    public static final CompatBlockSoundGroup AZALEA = of(class_2498.field_28694);
    public static final CompatBlockSoundGroup FLOWERING_AZALEA = of(class_2498.field_28695);
    public static final CompatBlockSoundGroup MOSS_CARPET = of(class_2498.field_28696);
    public static final CompatBlockSoundGroup PINK_PETALS = of(class_2498.field_42772);
    public static final CompatBlockSoundGroup MOSS_BLOCK = of(class_2498.field_28697);
    public static final CompatBlockSoundGroup BIG_DRIPLEAF = of(class_2498.field_28698);
    public static final CompatBlockSoundGroup SMALL_DRIPLEAF = of(class_2498.field_28699);
    public static final CompatBlockSoundGroup ROOTED_DIRT = of(class_2498.field_28700);
    public static final CompatBlockSoundGroup HANGING_ROOTS = of(class_2498.field_28701);
    public static final CompatBlockSoundGroup AZALEA_LEAVES = of(class_2498.field_28702);
    public static final CompatBlockSoundGroup SCULK_SENSOR = of(class_2498.field_28116);
    public static final CompatBlockSoundGroup SCULK_CATALYST = of(class_2498.field_37643);
    public static final CompatBlockSoundGroup SCULK = of(class_2498.field_37644);
    public static final CompatBlockSoundGroup SCULK_VEIN = of(class_2498.field_37645);
    public static final CompatBlockSoundGroup SCULK_SHRIEKER = of(class_2498.field_37646);
    public static final CompatBlockSoundGroup GLOW_LICHEN = of(class_2498.field_28427);
    public static final CompatBlockSoundGroup DEEPSLATE = of(class_2498.field_29033);
    public static final CompatBlockSoundGroup DEEPSLATE_BRICKS = of(class_2498.field_29034);
    public static final CompatBlockSoundGroup DEEPSLATE_TILES = of(class_2498.field_29035);
    public static final CompatBlockSoundGroup POLISHED_DEEPSLATE = of(class_2498.field_29036);
    public static final CompatBlockSoundGroup FROGLIGHT = of(class_2498.field_37636);
    public static final CompatBlockSoundGroup FROGSPAWN = of(class_2498.field_37637);
    public static final CompatBlockSoundGroup MANGROVE_ROOTS = of(class_2498.field_37638);
    public static final CompatBlockSoundGroup MUDDY_MANGROVE_ROOTS = of(class_2498.field_37639);
    public static final CompatBlockSoundGroup MUD = of(class_2498.field_37640);
    public static final CompatBlockSoundGroup MUD_BRICKS = of(class_2498.field_37641);
    public static final CompatBlockSoundGroup PACKED_MUD = of(class_2498.field_37642);
    public static final CompatBlockSoundGroup HANGING_SIGN = of(class_2498.field_40313);
    public static final CompatBlockSoundGroup NETHER_WOOD_HANGING_SIGN = of(class_2498.field_41083);
    public static final CompatBlockSoundGroup BAMBOO_WOOD_HANGING_SIGN = of(class_2498.field_41084);
    public static final CompatBlockSoundGroup BAMBOO_WOOD = of(class_2498.field_40314);
    public static final CompatBlockSoundGroup NETHER_WOOD = of(class_2498.field_40315);
    public static final CompatBlockSoundGroup CHERRY_WOOD = of(class_2498.field_42766);
    public static final CompatBlockSoundGroup CHERRY_SAPLING = of(class_2498.field_42767);
    public static final CompatBlockSoundGroup CHERRY_LEAVES = of(class_2498.field_42768);
    public static final CompatBlockSoundGroup CHERRY_WOOD_HANGING_SIGN = of(class_2498.field_42769);
    public static final CompatBlockSoundGroup CHISELED_BOOKSHELF = of(class_2498.field_41085);
    public static final CompatBlockSoundGroup SUSPICIOUS_SAND = of(class_2498.field_42770);
    public static final CompatBlockSoundGroup SUSPICIOUS_GRAVEL = of(class_2498.field_43255);
    public static final CompatBlockSoundGroup DECORATED_POT = of(class_2498.field_42771);
    public static final CompatBlockSoundGroup DECORATED_POT_SHATTER = of(class_2498.field_43256);
    public static final CompatBlockSoundGroup TRIAL_SPAWNER = of(class_2498.field_11544);
    public static final CompatBlockSoundGroup SPONGE = of(class_2498.field_11535);
    public static final CompatBlockSoundGroup WET_SPONGE = of(class_2498.field_11534);
    public static final CompatBlockSoundGroup VAULT = of(class_2498.field_11544);
    public static final CompatBlockSoundGroup HEAVY_CORE = of(class_2498.field_11544);
    public static final CompatBlockSoundGroup COBWEB = of(class_2498.field_11544);

    public class_2498 blockSoundGroup;

    private final float volume;
    private final float pitch;
    private final class_3414 breakSound;
    private final class_3414 stepSound;
    private final class_3414 placeSound;
    private final class_3414 hitSound;
    private final class_3414 fallSound;

    public CompatBlockSoundGroup(class_2498 blockSoundGroup) {
        this.blockSoundGroup = blockSoundGroup;

        this.volume = blockSoundGroup.method_10597();
        this.pitch = blockSoundGroup.method_10599();
        this.breakSound = blockSoundGroup.method_10595();
        this.stepSound = blockSoundGroup.method_10594();
        this.placeSound = blockSoundGroup.method_10598();
        this.hitSound = blockSoundGroup.method_10596();
        this.fallSound = blockSoundGroup.method_10593();
    }

    public CompatBlockSoundGroup(float volume, float pitch, class_3414 breakSound, class_3414 stepSound, class_3414 placeSound, class_3414 hitSound, class_3414 fallSound) {
        this.blockSoundGroup = new class_2498(volume, pitch, breakSound, stepSound, placeSound, hitSound, fallSound);

        this.volume = volume;
        this.pitch = pitch;
        this.breakSound = breakSound;
        this.stepSound = stepSound;
        this.placeSound = placeSound;
        this.hitSound = hitSound;
        this.fallSound = fallSound;
    }

    public class_2498 get() {
        if (blockSoundGroup == null) {
            return new class_2498(volume, pitch, breakSound, stepSound, placeSound, hitSound, fallSound);
        }
        return blockSoundGroup;
    }

    public static CompatBlockSoundGroup of(class_2498 blockSoundGroup) {
        return new CompatBlockSoundGroup(blockSoundGroup);
    }

    public static CompatBlockSoundGroup of(float volume, float pitch, class_3414 breakSound, class_3414 stepSound, class_3414 placeSound, class_3414 hitSound, class_3414 fallSound) {
        return new CompatBlockSoundGroup(volume, pitch, breakSound, stepSound, placeSound, hitSound, fallSound);
    }

    public static CompatBlockSoundGroup of(float volume, float pitch, CompatSoundEvent breakSound, CompatSoundEvent stepSound, CompatSoundEvent placeSound, CompatSoundEvent hitSound, CompatSoundEvent fallSound) {
        return new CompatBlockSoundGroup(volume, pitch, breakSound.get(), stepSound.get(), placeSound.get(), hitSound.get(), fallSound.get());
    }

    public float getVolume() {
        return volume;
    }

    public float getPitch() {
        return pitch;
    }

    public class_3414 getRawBreakSound() {
        return breakSound;
    }

    public class_3414 getRawStepSound() {
        return stepSound;
    }

    public class_3414 getRawPlaceSound() {
        return placeSound;
    }

    public class_3414 getRawHitSound() {
        return hitSound;
    }

    public class_3414 getRawFallSound() {
        return fallSound;
    }

    public CompatSoundEvent getBreakSound() {
        return CompatSoundEvent.of(breakSound);
    }

    public CompatSoundEvent getStepSound() {
        return CompatSoundEvent.of(stepSound);
    }

    public CompatSoundEvent getPlaceSound() {
        return CompatSoundEvent.of(placeSound);
    }

    public CompatSoundEvent getHitSound() {
        return CompatSoundEvent.of(hitSound);
    }

    public CompatSoundEvent getFallSound() {
        return CompatSoundEvent.of(fallSound);
    }
}
