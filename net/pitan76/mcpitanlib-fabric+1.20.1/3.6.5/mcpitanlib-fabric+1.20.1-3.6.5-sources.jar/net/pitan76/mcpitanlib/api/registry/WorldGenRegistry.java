package net.pitan76.mcpitanlib.api.registry;

import dev.architectury.registry.level.biome.BiomeModifications;
import dev.architectury.registry.registries.DeferredRegister;
import dev.architectury.registry.registries.RegistrySupplier;
import net.minecraft.class_2893;
import net.minecraft.class_2960;
import net.minecraft.class_2975;
import net.minecraft.class_6796;
import net.minecraft.class_6880;
import net.minecraft.class_7924;
import net.pitan76.mcpitanlib.api.registry.result.RegistryResult;

import java.util.function.Supplier;

public class WorldGenRegistry {
    protected String MOD_ID;

    protected DeferredRegister<class_2975<?, ?>> CONFIGURED_FEATURE;
    protected DeferredRegister<class_6796> PLACED_FEATURE;

    @Deprecated
    public WorldGenRegistry(String MOD_ID) {
        this.MOD_ID = MOD_ID;
        CONFIGURED_FEATURE = DeferredRegister.create(MOD_ID, class_7924.field_41239);
        PLACED_FEATURE = DeferredRegister.create(MOD_ID, class_7924.field_41245);
    }

    /**
     * Create a new CompatRegistry
     * @param MOD_ID The mod id
     * @return The new CompatRegistry
     */
    public static WorldGenRegistry createRegistry(String MOD_ID) {
        return new WorldGenRegistry(MOD_ID);
    }

    public static WorldGenRegistry createRegistry(CompatRegistry registry) {
        return registry.worldGenRegistry;
    }

    /**
     * Register a configured feature
     * @param id The id of the configured feature
     * @param supplier The supplier of the configured feature
     * @return The result of the registration
     */
    public RegistryResult<class_2975<?, ?>> registerFeature(class_2960 id, Supplier<class_2975<?, ?>> supplier) {
        RegistrySupplier<class_2975<?, ?>> feature = CONFIGURED_FEATURE.register(id, supplier);
        return new RegistryResult<>(feature);
    }

    /**
     * Register a placed feature
     * @param id The id of the placed feature
     * @param supplier The supplier of the placed feature
     * @return The result of the registration
     */
    public RegistryResult<class_6796> registerPlacedFeature(class_2960 id, Supplier<class_6796> supplier) {
        RegistrySupplier<class_6796> feature = PLACED_FEATURE.register(id, supplier);
        return new RegistryResult<>(feature);
    }

    /**
     * Replace the properties of a biome
     * @param decoration The decoration step
     * @param feature The feature to replace
     */
    public static void replaceProperties(class_2893.class_2895 decoration, RegistrySupplier<class_6796> feature) {
        BiomeModifications.replaceProperties((ctx, mutable) -> mutable.getGenerationProperties().addFeature(decoration, class_6880.method_40223(feature.getOrNull())));
    }

    public static void replaceProperties(class_2893.class_2895 decoration, RegistryResult<class_6796> feature) {
        replaceProperties(decoration, feature.supplier);
    }

    /**
     * Replace the properties of a biome
     * @param decoration The decoration step
     * @param feature The feature to replace
     */
    public static void replaceProperties(class_2893.class_2895 decoration, class_6796 feature) {
        BiomeModifications.replaceProperties((ctx, mutable) -> mutable.getGenerationProperties().addFeature(decoration, class_6880.method_40223(feature)));
    }

    /**
     * Add a feature to the biome properties
     * @param decoration The decoration step
     * @param feature The feature to add
     */
    public static void addProperties(class_2893.class_2895 decoration, RegistrySupplier<class_6796> feature) {
        BiomeModifications.addProperties((ctx, mutable) -> mutable.getGenerationProperties().addFeature(decoration, class_6880.method_40223(feature.getOrNull())));
    }

    public static void addProperties(class_2893.class_2895 decoration, RegistryResult<class_6796> feature) {
        addProperties(decoration, feature.supplier);
    }

    /**
     * Add a feature to the biome properties
     * @param decoration The decoration step
     * @param feature The feature to add
     */
    public static void addProperties(class_2893.class_2895 decoration, class_6796 feature) {
        BiomeModifications.addProperties((ctx, mutable) -> mutable.getGenerationProperties().addFeature(decoration, class_6880.method_40223(feature)));
    }
}
