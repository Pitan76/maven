package net.pitan76.mcpitanlib.api.util.collection;

import net.pitan76.mcpitanlib.api.util.inventory.ClippedInventory;
import net.minecraft.class_1263;
import net.minecraft.class_1799;
import net.minecraft.class_2371;
import net.pitan76.mcpitanlib.api.util.ItemStackUtil;
import org.jetbrains.annotations.NotNull;

public class ClippedItemStackList extends ItemStackList {

    public final ItemStackList list;
    public final int start;
    public final int end;

    public ClippedItemStackList(ItemStackList list, int start, int end) {
        super(null, null);
        this.list = list;
        if (start < 0 || end > list.size() || start >= end) {
            throw new IllegalArgumentException("Invalid start or end indices for clipping item stack list.");
        }
        this.start = start;
        this.end = end;
    }

    public static ClippedItemStackList of(ItemStackList list, int start, int end) {
        return new ClippedItemStackList(list, start, end);
    }

    public static ClippedItemStackList of(ItemStackList list) {
        return of(list, 0, list.size());
    }

    public static ClippedItemStackList of(ItemStackList list, int start) {
        return of(list, start, list.size());
    }

    @Override
    public int size() {
        return end - start;
    }

    @Override
    public class_1263 toInventory() {
        return ClippedInventory.of(list.toInventory(), start, end);
    }

    @Override
    public class_2371<class_1799> defaultedList() {
        class_2371<class_1799> clippedList = class_2371.method_10213(size(), ItemStackUtil.empty());
        for (int i = 0; i < size(); i++)
            clippedList.set(i, get(i));

        return clippedList;
    }

    @Override
    public @NotNull class_1799 get(int index) {
        return list.get(start + index);
    }

    @Override
    public class_1799 set(int index, class_1799 element) {
        return list.set(start + index, element);
    }

    @Override
    public class_1799 remove(int index) {
        return list.remove(start + index);
    }

    @Override
    public boolean contains(Object o) {
        for (int i = start; i < end; i++) {
            if (list.get(i).equals(o)) {
                return true;
            }
        }
        return false;
    }

    @Override
    public boolean isEmpty() {
        for (int i = start; i < end; i++) {
            if (!list.get(i).method_7960()) {
                return false;
            }
        }
        return true;
    }

    @Override
    public void clear() {
        for (int i = start; i < end; i++) {
            list.set(i, ItemStackUtil.empty());
        }
    }


}
