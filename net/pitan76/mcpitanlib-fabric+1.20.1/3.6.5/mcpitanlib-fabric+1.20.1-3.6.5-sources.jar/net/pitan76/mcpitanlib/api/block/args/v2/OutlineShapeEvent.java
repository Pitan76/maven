package net.pitan76.mcpitanlib.api.block.args.v2;

import net.minecraft.class_1792;
import net.minecraft.class_2586;
import net.minecraft.class_3726;
import net.pitan76.mcpitanlib.api.event.BaseEvent;
import net.pitan76.mcpitanlib.midohra.block.entity.BlockEntityWrapper;
import net.pitan76.mcpitanlib.midohra.holder.BlockStatePropertyHolder;
import net.pitan76.mcpitanlib.midohra.block.BlockState;
import net.pitan76.mcpitanlib.midohra.item.ItemWrapper;
import net.pitan76.mcpitanlib.midohra.util.math.BlockPos;
import net.pitan76.mcpitanlib.midohra.world.BlockView;
import net.pitan76.mcpitanlib.midohra.world.IWorldView;

public class OutlineShapeEvent extends BaseEvent implements BlockStatePropertyHolder {
    public BlockState state;
    public BlockView world;
    public BlockPos pos;
    public class_3726 context;

    public OutlineShapeEvent(BlockState state, BlockView world, BlockPos pos, class_3726 context) {
        this.state = state;
        this.world = world;
        this.pos = pos;
        this.context = context;
    }

    public OutlineShapeEvent(net.minecraft.class_2680 state, net.minecraft.class_1922 world, net.minecraft.class_2338 pos, net.minecraft.class_3726 context) {
        this(BlockState.of(state), BlockView.of(world), BlockPos.of(pos), context);
    }

    @Override
    public BlockState getBlockState() {
        return state;
    }

    public BlockEntityWrapper getBlockEntity() {
        return world.getBlockEntity(pos);
    }

    public class_2586 getRawBlockEntity() {
        return getBlockEntity().get();
    }

    public IWorldView getWorldView() {
        return world;
    }

    public BlockPos getPos() {
        return pos;
    }

    public class_3726 getContext() {
        return context;
    }

    public boolean isHolding(class_1792 item) {
        return getContext().method_17785(item);
    }

    public boolean isHolding(ItemWrapper item) {
        return isHolding(item.get());
    }
}
