package net.pitan76.mcpitanlib.api.tile;

import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2591;
import net.minecraft.class_2680;
import net.pitan76.mcpitanlib.api.event.block.TileCreateEvent;
import net.pitan76.mcpitanlib.api.world.ExtendWorld;

public class ExtendBlockEntity extends CompatBlockEntity {
    public ExtendWorld world;

    public ExtendBlockEntity(class_2591<?> type, class_2338 pos, class_2680 state) {
        super(type, pos, state);
    }

    public ExtendBlockEntity(class_2591<?> type, TileCreateEvent event) {
        this(type, event.getBlockPos(), event.getBlockState());
    }

    @Override
    public void method_31662(class_1937 world) {
        super.method_31662(world);
        this.world = new ExtendWorld(world);
    }
}
