package net.pitan76.mcpitanlib.api.util.client;

import net.minecraft.class_1041;

public class WindowUtil {

    public static class_1041 getWindow() {
        return ClientUtil.getWindow();
    }

    public static int getWindowScaledWidth() {
        return getWindow().method_4486();
    }

    public static int getWindowScaledHeight() {
        return getWindow().method_4502();
    }

    public static int getWindowWidth() {
        return getWindow().method_4480();
    }

    public static int getWindowHeight() {
        return getWindow().method_4507();
    }

    public static int getWindowX() {
        return getWindow().method_4499();
    }

    public static int getWindowY() {
        return getWindow().method_4477();
    }

    public static void setTitle(String title) {
        getWindow().method_24286(title);
    }

    public static void close() {
        getWindow().close();
    }
}
