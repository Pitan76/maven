package net.pitan76.mcpitanlib.api.event.block;

import net.minecraft.class_1922;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_3726;

public class CollisionShapeEvent extends OutlineShapeEvent {

    public CollisionShapeEvent(class_2680 state, class_1922 world, class_2338 pos, class_3726 context) {
        super(state, world, pos, context);
    }
}
