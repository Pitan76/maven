package net.pitan76.mcpitanlib.api.event;

import net.minecraft.class_2248;
import net.minecraft.class_2257;
import net.pitan76.mcpitanlib.api.command.argument.BlockCommand;

public class BlockCommandEvent extends RequiredCommandEvent {
    public class_2248 getValue() {
        return class_2257.method_9655(context, ((BlockCommand) getCommand()).getArgumentName()).method_9494().method_26204();
    }
}
