package net.pitan76.mcpitanlib.api.state.property;

import java.util.function.Predicate;
import net.minecraft.class_3542;

public class EnumProperty<T extends Enum<T> & class_3542> implements IProperty<T> {

    private final net.minecraft.class_2754<T> property;

    public EnumProperty(String name, Class<T> type) {
        this(net.minecraft.class_2754.method_11850(name, type));
    }

    public EnumProperty(String name, Class<T> type, Predicate<T> filter) {
        this(net.minecraft.class_2754.method_11848(name, type, filter));
    }

    public EnumProperty(net.minecraft.class_2754<T> property) {
        this.property = property;
    }

    public static <T extends Enum<T> & class_3542> EnumProperty<T> of(String name, Class<T> type) {
        return new EnumProperty<>(name, type);
    }

    public static <T extends Enum<T> & class_3542> EnumProperty<T> of(String name, Class<T> type, Predicate<T> filter) {
        return new EnumProperty<>(name, type, filter);
    }


    public static <T extends Enum<T> & class_3542> EnumProperty<T> of(net.minecraft.class_2754<T> property) {
        return new EnumProperty<>(property);
    }

    @Override
    public net.minecraft.class_2754<T> getProperty() {
        return property;
    }
}
