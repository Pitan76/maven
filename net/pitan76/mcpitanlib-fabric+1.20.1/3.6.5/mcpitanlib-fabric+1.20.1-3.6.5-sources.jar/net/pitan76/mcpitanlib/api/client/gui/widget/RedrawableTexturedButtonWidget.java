package net.pitan76.mcpitanlib.api.client.gui.widget;

import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_332;

public class RedrawableTexturedButtonWidget extends CompatibleTexturedButtonWidget {
    public class_2960 texture;
    public int u;
    public int v;
    public int hoveredVOffset;
    public int textureWidth;
    public int textureHeight;

    public RedrawableTexturedButtonWidget(int x, int y, int width, int height, int u, int v, int hoveredVOffset, class_2960 texture, int textureWidth, int textureHeight, class_4241 pressAction, class_2561 message) {
        super(x, y, width, height, u, v, hoveredVOffset, texture, textureWidth, textureHeight, pressAction, message);
        this.field_2124 = textureWidth;
        this.field_19080 = textureHeight;
        this.field_2126 = u;
        this.field_2125 = v;
        this.field_19079 = hoveredVOffset;
        this.field_2127 = texture;
    }

    public void method_48579(class_332 context, int mouseX, int mouseY, float delta) {
        this.method_48588(context, this.field_2127, this.method_46426(), this.method_46427(), this.field_2126, this.field_2125, this.field_19079, this.field_22758, this.field_22759, this.field_2124, this.field_19080);
    }

    public void setTexture(class_2960 texture) {
        this.field_2127 = texture;
    }

    public void setU(int u) {
        this.field_2126 = u;
    }

    public void setV(int v) {
        this.field_2125 = v;
    }

    public void setHoveredVOffset(int hoveredVOffset) {
        this.field_19079 = hoveredVOffset;
    }

    public void setTextureWidth(int textureWidth) {
        this.field_2124 = textureWidth;
    }

    public void setTextureHeight(int textureHeight) {
        this.field_19080 = textureHeight;
    }
}
