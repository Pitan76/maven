package net.pitan76.mcpitanlib.api.item.v3;

import net.minecraft.class_1856;
import net.pitan76.mcpitanlib.api.tag.item.RepairIngredientTag;

public interface CompatArmorMaterial extends net.pitan76.mcpitanlib.api.item.v2.CompatArmorMaterial {

    @Override
    default class_1856 getRepairIngredient() {
        return getRepairIngredientTag().getIngredient();
    }

    RepairIngredientTag getRepairIngredientTag();
}
