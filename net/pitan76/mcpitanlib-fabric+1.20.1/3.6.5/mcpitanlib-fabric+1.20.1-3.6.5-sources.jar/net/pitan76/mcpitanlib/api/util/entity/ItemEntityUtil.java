package net.pitan76.mcpitanlib.api.util.entity;

import net.minecraft.class_1299;
import net.minecraft.class_1542;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.pitan76.mcpitanlib.api.entity.Player;
import net.pitan76.mcpitanlib.api.util.WorldUtil;
import net.pitan76.mcpitanlib.midohra.entity.ItemEntityWrapper;
import net.pitan76.mcpitanlib.midohra.util.math.Vector3d;
import net.pitan76.mcpitanlib.midohra.util.math.Vector3i;

import java.util.List;
import java.util.stream.Collectors;

public class ItemEntityUtil {
    public static class_1542 create(class_1937 world, double x, double y, double z, class_1799 stack) {
        return new class_1542(world, x, y, z, stack);
    }

    public static class_1542 create(class_1937 world, class_2338 pos, class_1799 stack) {
        return create(world, pos.method_10263(), pos.method_10264(), pos.method_10260(), stack);
    }

    public static class_1542 create(class_1937 world, class_243 pos, class_1799 stack) {
        return create(world, pos.field_1352, pos.field_1351, pos.field_1350, stack);
    }

    public static class_1542 create(class_1937 world, double x, double y, double z, class_1799 stack, double velocityX, double velocityY, double velocityZ) {
        class_1542 itemEntity = create(world, x, y, z, stack);
        setVelocity(itemEntity, velocityX, velocityY, velocityZ);
        return itemEntity;
    }

    public static void setVelocity(class_1542 itemEntity, double velocityX, double velocityY, double velocityZ) {
        itemEntity.method_18800(velocityX, velocityY, velocityZ);
    }

    public static void setVelocity(class_1542 itemEntity, class_243 vec3d) {
        itemEntity.method_18799(vec3d);
    }

    public static void setPickupDelay(class_1542 itemEntity, int pickupDelay) {
        itemEntity.method_6982(pickupDelay);
    }

    public static void setToDefaultPickupDelay(class_1542 itemEntity) {
        itemEntity.method_6988();
    }

    public static class_1799 getStack(class_1542 entity) {
        return entity.method_6983();
    }

    public static List<class_1542> getEntities(class_1937 world, class_238 box) {
        return WorldUtil.getEntitiesByType(world, class_1299.field_6052, box);
    }

    public static class_1542 createWithSpawn(class_1937 world, class_1799 stack, double x, double y, double z) {
        class_1542 itemEntity = create(world, x, y, z, stack);
        setToDefaultPickupDelay(itemEntity);
        setVelocity(itemEntity, 0.0D, 0.0D, 0.0D);
        WorldUtil.spawnEntity(world, itemEntity);
        return itemEntity;
    }

    public static class_1542 createWithSpawn(class_1937 world, class_1799 stack, class_2338 pos) {
        return createWithSpawn(world, stack, pos.method_10263(), pos.method_10264(), pos.method_10260());
    }

    public static class_1542 createWithSpawn(class_1937 world, class_1799 stack, Vector3d pos) {
        return createWithSpawn(world, stack, pos.x, pos.y, pos.z);
    }

    public static class_1542 createWithSpawn(class_1937 world, class_1799 stack, Vector3i pos) {
        return createWithSpawn(world, stack, pos.toCenter());
    }

    public static class_1542 createWithSpawn(net.pitan76.mcpitanlib.midohra.world.World world, class_1799 stack, double x, double y, double z) {
        return createWithSpawn(world.getRaw(), stack, x, y, z);
    }

    public static class_1542 createWithSpawn(net.pitan76.mcpitanlib.midohra.world.World world, class_1799 stack, class_2338 pos) {
        return createWithSpawn(world, stack, pos.method_10263(), pos.method_10264(), pos.method_10260());
    }

    public static class_1542 createWithSpawn(net.pitan76.mcpitanlib.midohra.world.World world, class_1799 stack, Vector3i pos) {
        return createWithSpawn(world, stack, pos.toCenter());
    }

    public static class_1542 createWithSpawn(net.pitan76.mcpitanlib.midohra.world.World world, class_1799 stack, net.pitan76.mcpitanlib.midohra.util.math.Vector3d pos) {
        return createWithSpawn(world.getRaw(), stack, pos.x, pos.y, pos.z);
    }

    public static class_1542 createWithSpawnAtCenter(net.pitan76.mcpitanlib.midohra.world.World world, class_1799 stack, net.pitan76.mcpitanlib.midohra.util.math.BlockPos pos) {
        return createWithSpawn(world, stack, pos.toCenterVector3d());
    }

    public static class_1542 createWithSpawn(net.pitan76.mcpitanlib.midohra.world.World world, net.pitan76.mcpitanlib.midohra.item.ItemStack stack, double x, double y, double z) {
        return createWithSpawn(world.getRaw(), stack.toMinecraft(), x, y, z);
    }

    public static class_1542 createWithSpawn(net.pitan76.mcpitanlib.midohra.world.World world, net.pitan76.mcpitanlib.midohra.item.ItemStack stack, net.pitan76.mcpitanlib.midohra.util.math.BlockPos pos) {
        return createWithSpawn(world.getRaw(), stack.toMinecraft(), pos.toRaw());
    }

    public static class_1542 createWithSpawn(net.pitan76.mcpitanlib.midohra.world.World world, net.pitan76.mcpitanlib.midohra.item.ItemStack stack, net.pitan76.mcpitanlib.midohra.util.math.Vector3d pos) {
        return createWithSpawn(world.getRaw(), stack.toMinecraft(), pos.x, pos.y, pos.z);
    }

    public static class_1542 createWithSpawnAtCenter(net.pitan76.mcpitanlib.midohra.world.World world, net.pitan76.mcpitanlib.midohra.item.ItemStack stack, net.pitan76.mcpitanlib.midohra.util.math.BlockPos pos) {
        return createWithSpawn(world, stack, pos.toCenterVector3d());
    }

    public static class_1542 createWithSpawn(net.pitan76.mcpitanlib.midohra.world.World world, net.pitan76.mcpitanlib.midohra.item.ItemStack stack, net.pitan76.mcpitanlib.midohra.util.math.Vector3i pos) {
        return createWithSpawn(world, stack, pos.toCenter());
    }

    public static List<class_1542> getEntities(net.pitan76.mcpitanlib.midohra.world.World world, net.pitan76.mcpitanlib.midohra.util.math.Box box) {
        return getEntities(world.getRaw(), box.toMinecraft());
    }

    public static List<ItemEntityWrapper> getEntityWrappers(net.pitan76.mcpitanlib.midohra.world.World world, net.pitan76.mcpitanlib.midohra.util.math.Box box) {
        return getEntities(world, box).stream().map(ItemEntityWrapper::of).collect(Collectors.toList());
    }

    public static void onPlayerCollision(class_1542 itemEntity, Player player) {
        itemEntity.method_5694(player.getEntity());
    }

    public static void onPlayerCollision(ItemEntityWrapper itemEntity, Player player) {
        onPlayerCollision(itemEntity.get(), player);
    }
}
