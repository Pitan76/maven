package net.pitan76.mcpitanlib.api.util.color;

import net.minecraft.class_1767;
import net.pitan76.mcpitanlib.api.util.CompatStringIdentifiable;

public class CompatDyeColor implements CompatStringIdentifiable {
    private final class_1767 color;

    public static final CompatDyeColor WHITE = of(class_1767.field_7952);
    public static final CompatDyeColor ORANGE = of(class_1767.field_7946);
    public static final CompatDyeColor MAGENTA = of(class_1767.field_7958);
    public static final CompatDyeColor LIGHT_BLUE = of(class_1767.field_7951);
    public static final CompatDyeColor YELLOW = of(class_1767.field_7947);
    public static final CompatDyeColor LIME = of(class_1767.field_7961);
    public static final CompatDyeColor PINK = of(class_1767.field_7954);
    public static final CompatDyeColor GRAY = of(class_1767.field_7944);
    public static final CompatDyeColor LIGHT_GRAY = of(class_1767.field_7967);
    public static final CompatDyeColor CYAN = of(class_1767.field_7955);
    public static final CompatDyeColor PURPLE = of(class_1767.field_7945);
    public static final CompatDyeColor BLUE = of(class_1767.field_7966);
    public static final CompatDyeColor BROWN = of(class_1767.field_7957);
    public static final CompatDyeColor GREEN = of(class_1767.field_7942);
    public static final CompatDyeColor RED = of(class_1767.field_7964);
    public static final CompatDyeColor BLACK = of(class_1767.field_7963);

    public CompatDyeColor(class_1767 color) {
        this.color = color;
    }

    public static CompatDyeColor of(class_1767 color) {
        return new CompatDyeColor(color);
    }

    public class_1767 getColor() {
        return color;
    }

    public String getName() {
        return color.method_7792();
    }

    @Override
    public String asString_compat() {
        return getName();
    }

    @Override
    public int hashCode() {
        return color.hashCode();
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        CompatDyeColor other = (CompatDyeColor) obj;
        return color == other.color;
    }
}
