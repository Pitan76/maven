package net.pitan76.mcpitanlib.api.block.args.v2;

import net.minecraft.class_1936;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_4538;
import net.pitan76.mcpitanlib.api.util.math.random.CompatRandom;
import net.pitan76.mcpitanlib.midohra.block.entity.BlockEntityWrapper;
import net.pitan76.mcpitanlib.midohra.holder.BlockStatePropertyHolder;
import net.pitan76.mcpitanlib.midohra.world.IWorldView;

public class StateForNeighborUpdateArgs implements BlockStatePropertyHolder {
    public class_2680 state;
    public class_2350 direction;
    public class_2680 neighborState;
    public class_1936 world;
    public class_2338 pos;
    public class_2338 neighborPos;
    public CompatRandom random;

    public StateForNeighborUpdateArgs(class_2680 state, class_2350 direction, class_2680 neighborState, class_1936 world, class_2338 pos, class_2338 neighborPos) {
        this.state = state;
        this.direction = direction;
        this.neighborState = neighborState;
        this.world = world;
        this.pos = pos;
        this.neighborPos = neighborPos;
        this.random = new CompatRandom(world.method_8409());
    }

    public class_2350 getDirection() {
        return direction;
    }

    public class_2680 getRawNeighborState() {
        return neighborState;
    }

    public class_4538 getRawWorld() {
        return world;
    }

    public class_2338 getRawPos() {
        return pos;
    }

    public class_2338 getRawNeighborPos() {
        return neighborPos;
    }

    public net.pitan76.mcpitanlib.midohra.block.BlockState getNeighborState() {
        return net.pitan76.mcpitanlib.midohra.block.BlockState.of(getRawNeighborState());
    }

    public net.pitan76.mcpitanlib.midohra.world.WorldView getWorld() {
        return net.pitan76.mcpitanlib.midohra.world.WorldView.of(getRawWorld());
    }

    public IWorldView getWorldView() {
        return getWorld();
    }

    public net.pitan76.mcpitanlib.midohra.util.math.BlockPos getPos() {
        return net.pitan76.mcpitanlib.midohra.util.math.BlockPos.of(getRawPos());
    }

    public net.pitan76.mcpitanlib.midohra.util.math.BlockPos getNeighborPos() {
        return net.pitan76.mcpitanlib.midohra.util.math.BlockPos.of(getRawNeighborPos());
    }

    public CompatRandom getRandom() {
        return random;
    }

    public net.pitan76.mcpitanlib.midohra.world.tick.ScheduledTickView getTickView() {
        return net.pitan76.mcpitanlib.midohra.world.tick.ScheduledTickView.of(world);
    }

    @Override
    public net.pitan76.mcpitanlib.midohra.block.BlockState getBlockState() {
        return net.pitan76.mcpitanlib.midohra.block.BlockState.of(state);
    }

    public BlockEntityWrapper getBlockEntity() {
        return getWorld().getBlockEntity(getPos());
    }

    public class_2586 getRawBlockEntity() {
        return world.method_8321(pos);
    }

    public boolean isClient() {
        return world.method_8608();
    }
}
