package net.pitan76.mcpitanlib.api.nbt;

import net.minecraft.class_1799;
import net.minecraft.class_2487;
import net.minecraft.class_4614;

@Deprecated
public class NbtTag extends class_2487 {
    public NbtTag() {
        super();
    }

    /**
     * Create NbtTag instance
     * @return NbtTag instance
     */
    public static NbtTag create() {
        return new NbtTag();
    }

    /**
     * Cast to NbtTag
     * @param nbt Nbt Object
     * @return NbtTag
     */
    public static NbtTag from(Object nbt) {
        if (nbt instanceof class_2487) {
            return (NbtTag) nbt;
        }
        return (NbtTag) nbt;
    }

    /**
     * Check item stack nbt
     * @param stack Item stack
     * @return boolean
     */
    public static boolean hasNbt(class_1799 stack) {
        return stack.method_7985();
    }

    /**
     * Get nbt from item stack
     * @param stack Item stack
     * @return NbtTag
     */
    public static NbtTag getNbt(class_1799 stack) {
        return from(stack.method_7969());
    }

    /**
     * Set nbt to item stack
     * @param stack Item stack
     * @param nbt NbtTag
     */
    public static void setNbt(class_1799 stack, NbtTag nbt) {
        stack.method_7980(nbt);
    }

    public boolean method_10545(String key) {
        return super.method_10545(key);
    }

    public class_4614<class_2487> method_23258() {
        return super.method_23258();
    }
}