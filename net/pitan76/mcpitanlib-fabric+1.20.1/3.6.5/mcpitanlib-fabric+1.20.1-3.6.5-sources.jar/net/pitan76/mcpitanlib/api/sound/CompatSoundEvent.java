package net.pitan76.mcpitanlib.api.sound;

import net.minecraft.class_3414;
import net.minecraft.class_6880;
import org.jetbrains.annotations.Nullable;

public class CompatSoundEvent {
    private class_3414 soundEvent;
    private class_6880.class_6883<class_3414> reference;
    private class_6880<class_3414> entry;

    public CompatSoundEvent(class_3414 soundEvent) {
        this.soundEvent = soundEvent;
    }

    public CompatSoundEvent(class_6880.class_6883<class_3414> reference) {
        this.reference = reference;
    }

    public CompatSoundEvent(class_6880<class_3414> entry) {
        this.entry = entry;
    }

    public static CompatSoundEvent of(class_3414 soundEvent) {
        return new CompatSoundEvent(soundEvent);
    }

    public class_3414 get() {
        if (soundEvent == null) {
            if (reference != null) {
                soundEvent = reference.comp_349();
            } else if (entry != null) {
                soundEvent = entry.comp_349();
            }
        }

        return soundEvent;
    }

    @Nullable
    @Deprecated
    public class_6880.class_6883<class_3414> getReference() {
        return reference;
    }

    @Nullable
    @Deprecated
    public class_6880<class_3414> getEntry() {
        if (entry == null) {
            entry = class_6880.method_40223(soundEvent);
        }

        return entry;
    }
}
