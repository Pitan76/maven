package net.pitan76.mcpitanlib.api.event.block.result;

import net.minecraft.class_2680;

public class BlockBreakResult {
    public class_2680 state;

    public BlockBreakResult(class_2680 state) {
        this.state = state;
    }

    public class_2680 getState() {
        return state;
    }
}
