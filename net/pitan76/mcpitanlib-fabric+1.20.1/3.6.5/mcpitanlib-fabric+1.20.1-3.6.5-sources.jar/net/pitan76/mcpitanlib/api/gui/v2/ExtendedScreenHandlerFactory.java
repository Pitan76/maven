package net.pitan76.mcpitanlib.api.gui.v2;

import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.pitan76.mcpitanlib.api.gui.args.CreateMenuEvent;

@SuppressWarnings("deprecation")
public interface ExtendedScreenHandlerFactory extends net.pitan76.mcpitanlib.api.gui.ExtendedScreenHandlerFactory {

    @Override
    default class_1703 createMenu(int syncId, class_1661 playerInventory, class_1657 player) {
        return createMenu(new CreateMenuEvent(syncId, playerInventory, player));
    }

    class_1703 createMenu(CreateMenuEvent event);
}
