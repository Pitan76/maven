package net.pitan76.mcpitanlib.api.util.client.render;

import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_761;

public class WorldRendererUtil {
    public static int getLightmapCoordinates(class_1937 world, class_2338 pos) {
        return class_761.method_23794(world, pos);
    }

    public static int getLightmapCoordinates(net.pitan76.mcpitanlib.midohra.world.World world, net.pitan76.mcpitanlib.midohra.util.math.BlockPos pos) {
        return getLightmapCoordinates(world.getRaw(), pos.toMinecraft());
    }
}
