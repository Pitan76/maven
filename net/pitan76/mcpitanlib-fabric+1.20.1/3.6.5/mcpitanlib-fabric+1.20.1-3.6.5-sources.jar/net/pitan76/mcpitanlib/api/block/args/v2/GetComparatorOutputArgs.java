package net.pitan76.mcpitanlib.api.block.args.v2;

import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.pitan76.mcpitanlib.api.event.BaseEvent;
import net.pitan76.mcpitanlib.api.util.WorldUtil;
import net.pitan76.mcpitanlib.api.util.screen.ScreenHandlerUtil;

public class GetComparatorOutputArgs extends BaseEvent {
    public class_2680 state;
    public class_1937 world;
    public class_2338 pos;

    public GetComparatorOutputArgs(class_2680 state, class_1937 world, class_2338 pos) {
        this.state = state;
        this.world = world;
        this.pos = pos;
    }

    public class_2680 getState() {
        return state;
    }

    public class_1937 getWorld() {
        return world;
    }

    public class_2338 getPos() {
        return pos;
    }

    public class_2586 getBlockEntity() {
        return WorldUtil.getBlockEntity(world, pos);
    }

    public int calcComparatorOutputFromBlockEntity() {
        return ScreenHandlerUtil.calcComparatorOutput(getBlockEntity());
    }

    public net.pitan76.mcpitanlib.midohra.block.BlockState getMidohraState() {
        return net.pitan76.mcpitanlib.midohra.block.BlockState.of(state);
    }

    public net.pitan76.mcpitanlib.midohra.world.World getMidohraWorld() {
        return net.pitan76.mcpitanlib.midohra.world.World.of(world);
    }

    public net.pitan76.mcpitanlib.midohra.util.math.BlockPos getMidohraPos() {
        return net.pitan76.mcpitanlib.midohra.util.math.BlockPos.of(pos);
    }
}
