package net.pitan76.mcpitanlib.api.block;

import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2343;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_2680;
import net.minecraft.class_5558;
import net.pitan76.mcpitanlib.api.event.block.TileCreateEvent;
import net.pitan76.mcpitanlib.api.tile.ExtendBlockEntityTicker;
import org.jetbrains.annotations.Nullable;

public interface ExtendBlockEntityProvider extends class_2343 {

    /**
     * @deprecated Use {@link #createBlockEntity(TileCreateEvent)} instead.
     */
    @Deprecated
    @Nullable
    default class_2586 method_10123(class_2338 pos, class_2680 state) {
        return createBlockEntity(new TileCreateEvent(pos, state));
    }

    /**
     * create instance of BlockEntity
     * @param event TileCreateEvent
     * @return BlockEntity
     *
     * <pre>{@code
     * public BlockEntity createBlockEntity(TileCreateEvent e) {
     *    return new ExampleBlockEntity(e); // ExampleBlockEntity extends CompatBlockEntity
     * }</pre>
     */
    @Nullable
    default class_2586 createBlockEntity(TileCreateEvent event) {
        if (getBlockEntityType() == null) return null;

        // return new ...BlockEntity(pos, state)
        return getBlockEntityType().method_11032(event.getBlockPos(), event.getBlockState());
    }

    @Nullable
    default <T extends class_2586> class_2591<T> getBlockEntityType() {
        return null;
    }

    @Nullable
    @Override
    default <T extends class_2586> class_5558<T> method_31645(class_1937 world, class_2680 state, class_2591<T> type) {
        if (isTick()) {
            return ((world1, pos, state1, blockEntity) -> {
                if (getBlockEntityType() == null || blockEntity == getBlockEntityType().method_24182(world, pos)) {
                    if (blockEntity instanceof ExtendBlockEntityTicker<?>) {
                        ExtendBlockEntityTicker<T> ticker = (ExtendBlockEntityTicker<T>) blockEntity;
                        ticker.tick(world, pos, state, blockEntity);
                    } else if (blockEntity instanceof class_5558<?>) {
                        class_5558<T> ticker = (class_5558<T>) blockEntity;
                        ticker.tick(world, pos, state, blockEntity);
                    }
                }
            });
        }
        return class_2343.super.method_31645(world, state, type);
    }

    @Nullable
    default <T extends class_2586> ExtendBlockEntityTicker<T> getCompatibleTicker(class_1937 world, class_2680 state, class_2591<T> type) {
        class_5558<T> ticker = method_31645(world, state, type);
        if (ticker instanceof ExtendBlockEntityTicker<T>)
            return (ExtendBlockEntityTicker<T>) ticker;

        return null;
    }

    default boolean isTick() {
        return false;
    }
}
