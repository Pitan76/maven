package net.pitan76.mcpitanlib.api.sound;

import net.minecraft.class_3419;

public class CompatSoundCategory {
    
    public static final CompatSoundCategory MASTER = of(class_3419.field_15250);
    public static final CompatSoundCategory MUSIC = of(class_3419.field_15253);
    public static final CompatSoundCategory RECORDS = of(class_3419.field_15247);
    public static final CompatSoundCategory WEATHER = of(class_3419.field_15252);
    public static final CompatSoundCategory BLOCKS = of(class_3419.field_15245);
    public static final CompatSoundCategory HOSTILE = of(class_3419.field_15251);
    public static final CompatSoundCategory NEUTRAL = of(class_3419.field_15254);
    public static final CompatSoundCategory PLAYERS = of(class_3419.field_15248);
    public static final CompatSoundCategory AMBIENT = of(class_3419.field_15256);
    public static final CompatSoundCategory VOICE = of(class_3419.field_15246);
    
    public class_3419 soundCategory;
    
    public CompatSoundCategory(class_3419 soundCategory) {
        this.soundCategory = soundCategory;
    }
    
    public static CompatSoundCategory of(class_3419 soundCategory) {
        return new CompatSoundCategory(soundCategory);
    }

    public class_3419 get() {
        return soundCategory;
    }
    
    public String getName() {
        return soundCategory.method_14840();
    }
}
