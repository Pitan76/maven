package net.pitan76.mcpitanlib.api.util.math;

import net.minecraft.class_243;

public class Vec3dUtil {
    public static class_243 create(double x, double y, double z) {
        return new class_243(x, y, z);
    }

    public static class_243 add(class_243 a, class_243 b) {
        return a.method_1019(b);
    }

    public static class_243 subtract(class_243 a, class_243 b) {
        return a.method_1020(b);
    }

    public static class_243 multiply(class_243 a, double b) {
        return a.method_1021(b);
    }

    public static class_243 divide(class_243 a, double b) {
        return a.method_1021(1.0D / b);
    }

    public static double dot(class_243 a, class_243 b) {
        return a.method_1026(b);
    }

    public static class_243 cross(class_243 a, class_243 b) {
        return a.method_1036(b);
    }

    public static class_243 normalize(class_243 a) {
        return a.method_1029();
    }

    public static class_243 rotateX(class_243 a, float angle) {
        return a.method_1037(angle);
    }

    public static class_243 rotateY(class_243 a, float angle) {
        return a.method_1024(angle);
    }

    public static class_243 rotateZ(class_243 a, float angle) {
        return a.method_31033(angle);
    }

    public static class_243 add(class_243 a, double x, double y, double z) {
        return a.method_1031(x, y, z);
    }

    public static class_243 subtract(class_243 a, double x, double y, double z) {
        return a.method_1023(x, y, z);
    }

    public static class_243 multiply(class_243 a, double x, double y, double z) {
        return a.method_18805(x, y, z);
    }

    public static double distanceTo(class_243 a, class_243 b) {
        return a.method_1022(b);
    }

    public static class_243 ofCenter(double x, double y, double z) {
        return new class_243(x + 0.5, y + 0.5, z + 0.5);
    }
}
