package net.pitan76.mcpitanlib.api.util.entity;

import net.minecraft.class_1304;
import net.pitan76.mcpitanlib.api.item.ArmorEquipmentType;

public class EquipmentSlotUtil {
    public static boolean isArmor(class_1304 slot) {
        return slot == class_1304.field_6169 || slot == class_1304.field_6174 || slot == class_1304.field_6172 || slot == class_1304.field_6166;
    }

    public static boolean isMainHand(class_1304 slot) {
        return slot == class_1304.field_6173;
    }

    public static boolean isOffHand(class_1304 slot) {
        return slot == class_1304.field_6171;
    }

    public static boolean isWeapon(class_1304 slot) {
        return slot == class_1304.field_6173 || slot == class_1304.field_6171;
    }

    public static int getEntitySlotId(class_1304 slot) {
        if (slot == null)
            return 0;

        return slot.method_5927();
    }

    public static class_1304 fromEntitySlotId(int id) {
        for (class_1304 slot : class_1304.values()) {
            if (slot.method_5927() == id) {
                return slot;
            }
        }
        return class_1304.field_6173;
    }

    public static ArmorEquipmentType getArmorEquipmentType(class_1304 slot) {
        switch (slot) {
            case field_6169:
                return ArmorEquipmentType.HEAD;
            case field_6174:
                return ArmorEquipmentType.CHEST;
            case field_6172:
                return ArmorEquipmentType.LEGS;
            case field_6166:
                return ArmorEquipmentType.FEET;
            default:
                return null;
        }
    }
}
