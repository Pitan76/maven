package net.pitan76.mcpitanlib.api.recipe;

import net.minecraft.class_1860;
import net.minecraft.class_2960;
import net.minecraft.class_3859;
import net.minecraft.class_3861;
import net.minecraft.class_3862;
import net.minecraft.class_3920;
import net.minecraft.class_3955;
import net.minecraft.class_3956;
import net.minecraft.class_3975;
import net.minecraft.class_7923;
import net.minecraft.class_8059;
import net.minecraft.recipe.*;
import net.pitan76.mcpitanlib.api.util.CompatIdentifier;

@Deprecated
public class CompatRecipeType<T extends class_1860<?>> {
    public static final CompatRecipeType<class_3955> CRAFTING = new CompatRecipeType<>(class_3956.field_17545);
    public static final CompatRecipeType<class_3861> SMELTING = new CompatRecipeType<>(class_3956.field_17546);
    public static final CompatRecipeType<class_3859> BLASTING = new CompatRecipeType<>(class_3956.field_17547);
    public static final CompatRecipeType<class_3862> SMOKING = new CompatRecipeType<>(class_3956.field_17548);
    public static final CompatRecipeType<class_3920> CAMPFIRE_COOKING = new CompatRecipeType<>(class_3956.field_17549);
    public static final CompatRecipeType<class_3975> STONECUTTING = new CompatRecipeType<>(class_3956.field_17641);
    public static final CompatRecipeType<class_8059> SMITHING = new CompatRecipeType<>(class_3956.field_25388);

    private final class_3956<T> type;

    public CompatRecipeType(String id) {
        this(class_3956.method_17726(id));
    }

    public CompatRecipeType(class_3956<T> type) {
        this.type = type;
    }

    public class_3956<T> getType() {
        return type;
    }

    public CompatIdentifier getName() {
        class_2960 id = class_7923.field_41188.method_10221(type);
        if (id == null) return CompatIdentifier.empty();

        return CompatIdentifier.fromMinecraft(id);
    }

    public static CompatRecipeType<?> of(CompatIdentifier id) {
        class_3956<?> type = class_7923.field_41188.method_10223(id.toMinecraft());
        if (type == null) return null;

        return new CompatRecipeType<>(type);
    }

    public static <T extends class_1860<?>> CompatRecipeType<T> of(CompatIdentifier id, Class<T> clazz) {
        return (CompatRecipeType<T>) of(id);
    }

    public static <T extends class_1860<?>> CompatRecipeType<T> of(class_3956<T> type) {
        return new CompatRecipeType<>(type);
    }

    public net.pitan76.mcpitanlib.midohra.recipe.RecipeType toMidohra() {
        return net.pitan76.mcpitanlib.midohra.recipe.RecipeType.of(type);
    }
}
