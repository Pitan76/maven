package net.pitan76.mcpitanlib.api.client.color;

import net.minecraft.class_1920;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_322;
import org.jetbrains.annotations.Nullable;

public interface CompatBlockColorProvider extends class_322 {
    default int getColor(class_2680 state, @Nullable class_1920 world, @Nullable class_2338 pos, int tintIndex) {
        return getColor(new BlockColorEvent(state, world, pos, tintIndex));
    }

    int getColor(BlockColorEvent e);
}
