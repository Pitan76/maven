package net.pitan76.mcpitanlib.api.block.args.v2;

import net.pitan76.mcpitanlib.api.event.BaseEvent;
import net.pitan76.mcpitanlib.midohra.block.BlockState;
import net.pitan76.mcpitanlib.midohra.util.math.BlockPos;
import net.pitan76.mcpitanlib.midohra.world.WorldView;

public class CanPlaceAtArgs extends BaseEvent {
    public final net.minecraft.class_2680 state;
    public final net.minecraft.class_4538 world;
    public final net.minecraft.class_2338 pos;

    public CanPlaceAtArgs(net.minecraft.class_2680 state, net.minecraft.class_4538 world, net.minecraft.class_2338 pos) {
        this.state = state;
        this.world = world;
        this.pos = pos;
    }

    public CanPlaceAtArgs(BlockState state, WorldView world, BlockPos pos) {
        this(state.toMinecraft(), world.toMinecraft(), pos.toMinecraft());
    }

    public net.minecraft.class_2680 getState() {
        return state;
    }

    public net.minecraft.class_4538 getWorld() {
        return world;
    }

    public net.minecraft.class_2338 getPos() {
        return pos;
    }

    public BlockState getMidohraState() {
        return BlockState.of(state);
    }

    public WorldView getMidohraWorld() {
        return WorldView.of(world);
    }

    public BlockPos getMidohraPos() {
        return BlockPos.of(pos);
    }

    public boolean isClient() {
        return world.method_8608();
    }

    public boolean isServer() {
        return !world.method_8608();
    }
}
