package net.pitan76.mcpitanlib.api.util;

import net.minecraft.class_1297;
import net.minecraft.class_1937;
import net.minecraft.class_2586;
import net.pitan76.mcpitanlib.api.entity.CompatEntity;
import net.pitan76.mcpitanlib.api.event.item.ItemAppendTooltipEvent;
import net.pitan76.mcpitanlib.api.event.nbt.NbtRWArgs;
import net.pitan76.mcpitanlib.api.registry.CompatRegistryLookup;
import net.pitan76.mcpitanlib.api.tile.CompatBlockEntity;

public class RegistryLookupUtil {
    public static CompatRegistryLookup getRegistryLookup(ItemAppendTooltipEvent e) {
        return new CompatRegistryLookup();
    }

    public static CompatRegistryLookup getRegistryLookup(CompatEntity entity) {
        return new CompatRegistryLookup(entity.method_37908().method_30349());
    }

    public static CompatRegistryLookup getRegistryLookup(class_1297 entity) {
        return new CompatRegistryLookup(entity.method_37908().method_30349());
    }

    public static CompatRegistryLookup getRegistryLookup(CompatBlockEntity entity) {
        return new CompatRegistryLookup(entity.method_10997().method_30349());
    }

    public static CompatRegistryLookup getRegistryLookup(class_2586 entity) {
        return new CompatRegistryLookup(entity.method_10997().method_30349());
    }

    public static CompatRegistryLookup getRegistryLookup(NbtRWArgs args) {
        return args.getRegistryLookup();
    }

    public static CompatRegistryLookup getRegistryLookup(class_1937 world) {
        return new CompatRegistryLookup(world.method_30349());
    }
}