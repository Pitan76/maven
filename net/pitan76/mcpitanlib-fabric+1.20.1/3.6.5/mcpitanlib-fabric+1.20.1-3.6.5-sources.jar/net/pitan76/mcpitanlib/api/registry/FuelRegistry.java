package net.pitan76.mcpitanlib.api.registry;

import java.util.HashMap;
import java.util.Map;
import java.util.function.Supplier;
import net.minecraft.class_1935;

public class FuelRegistry {

    private static final Map<String, Map<Supplier<class_1935>, Integer>> FUEL_MAP = new HashMap<>();

    public static void register(Supplier<class_1935> itemSupplier, int time, String namespace) {
        Map<Supplier<class_1935>, Integer> map = new HashMap<>();
        map.put(itemSupplier, time);

        FUEL_MAP.put(namespace, map);
    }

    @Deprecated
    public static void allRegister(String namespace) {
        if (!FUEL_MAP.containsKey(namespace)) return;

        Map<Supplier<class_1935>, Integer> map = FUEL_MAP.get(namespace);
        for (Map.Entry<Supplier<class_1935>, Integer> entry : map.entrySet()) {
            net.pitan76.mcpitanlib.core.registry.FuelRegistry.register(entry.getValue(), entry.getKey().get());
        }

        FUEL_MAP.remove(namespace);
    }
}
