package net.pitan76.mcpitanlib.api.event;

import net.minecraft.class_1792;
import net.minecraft.class_2287;
import net.pitan76.mcpitanlib.api.command.argument.ItemCommand;

public class ItemCommandEvent extends RequiredCommandEvent {
    public class_1792 getValue() {
        return class_2287.method_9777(context, ((ItemCommand) getCommand()).getArgumentName()).method_9785();
    }
}
