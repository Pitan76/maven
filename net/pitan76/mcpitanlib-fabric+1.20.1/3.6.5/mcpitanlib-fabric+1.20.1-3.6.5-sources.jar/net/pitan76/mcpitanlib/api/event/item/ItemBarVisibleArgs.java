package net.pitan76.mcpitanlib.api.event.item;

import net.minecraft.class_1799;

public class ItemBarVisibleArgs {

    public class_1799 stack;

    public ItemBarVisibleArgs(class_1799 stack) {
        this.stack = stack;
    }

    public class_1799 getStack() {
        return stack;
    }
}
