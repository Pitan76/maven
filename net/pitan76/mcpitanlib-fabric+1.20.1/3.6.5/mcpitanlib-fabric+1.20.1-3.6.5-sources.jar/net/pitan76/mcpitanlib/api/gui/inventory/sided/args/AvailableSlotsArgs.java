package net.pitan76.mcpitanlib.api.gui.inventory.sided.args;

import net.pitan76.mcpitanlib.api.gui.inventory.sided.CompatSidedInventory;
import net.minecraft.class_2350;
import net.pitan76.mcpitanlib.api.gui.inventory.IInventory;

public class AvailableSlotsArgs {
    public class_2350 side;
    public CompatSidedInventory inventory;

    public AvailableSlotsArgs(class_2350 side, CompatSidedInventory inventory) {
        this.side = side;
        this.inventory = inventory;
    }

    public class_2350 getSide() {
        return side;
    }

    public CompatSidedInventory getInventory() {
        return inventory;
    }

    public int[] getAllSlots() {
        if (!(inventory instanceof IInventory))
            return new int[0];

        IInventory inv = (IInventory) inventory;
        int size = inv.method_5439();

        int[] slots = new int[size];
        for (int i = 0; i < size; i++) {
            slots[i] = i;
        }

        return slots;
    }
}
