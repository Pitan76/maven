package net.pitan76.mcpitanlib.api.util;

import net.minecraft.class_2561;
import net.minecraft.class_2583;
import net.minecraft.class_5250;
import net.pitan76.mcpitanlib.api.text.TextConverter;

public class TextUtil {
    public static class_5250 literal(String string) {
        return class_2561.method_43470(string);
    }

    public static class_5250 translatable(String key) {
        return class_2561.method_43471(key);
    }

    public static class_5250 translatable(String key, Object... args) {
        return class_2561.method_43469(key, args);
    }

    public static class_5250 empty() {
        return literal("");
    }

    public static class_5250 keybind(String string) {
        return class_2561.method_43472(string);
    }

    public static String txt2str(class_2561 text) {
        return text.getString();
    }

    public static class_5250 setStyle(class_5250 text, class_2583 style) {
        return text.method_10862(style);
    }

    public static class_2583 getStyle(class_5250 text) {
        return text.method_10866();
    }

    public static class_5250 withColor(class_5250 text, int color) {
        return setStyle(text, StyleUtil.withColor(text.method_10866(), color));
    }

    public static class_5250 withBold(class_5250 text, boolean bold) {
        return setStyle(text, StyleUtil.withBold(text.method_10866(), bold));
    }

    public static class_5250 append(class_5250 text, class_2561 sibling) {
        return text.method_10852(sibling);
    }

    public static class_5250 append(class_5250 text, String string) {
        return text.method_27693(string);
    }

    public static class_5250 of(String string) {
        return literal(string);
    }

    public static class_5250 convert(String text) {
        return TextConverter.convert(text, false);
    }

    public static class_5250 convertWithTranslatable(String text) {
        return TextConverter.convert(text, true);
    }

    public static boolean contains(class_2561 text, class_2561 text1) {
        return text.method_44745(text1);
    }
}