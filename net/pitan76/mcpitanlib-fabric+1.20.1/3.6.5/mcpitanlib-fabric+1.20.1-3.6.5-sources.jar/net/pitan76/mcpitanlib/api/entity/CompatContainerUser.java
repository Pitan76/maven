package net.pitan76.mcpitanlib.api.entity;

import net.minecraft.class_1309;
import net.minecraft.class_1657;

public class CompatContainerUser {
    protected class_1657 containerUser;

    public CompatContainerUser(class_1657 containerUser) {
        this.containerUser = containerUser;
    }

    public double getContainerInteractionRange() {
        return 4.5d;
    }

    public class_1309 asLivingEntity() {
        return containerUser;
    }

    public boolean isPlayer() {
        return true;
    }

    public Player asPlayer() {
        return new Player(containerUser);
    }

    @Deprecated
    public class_1657 getRaw() {
        return containerUser;
    }
}
