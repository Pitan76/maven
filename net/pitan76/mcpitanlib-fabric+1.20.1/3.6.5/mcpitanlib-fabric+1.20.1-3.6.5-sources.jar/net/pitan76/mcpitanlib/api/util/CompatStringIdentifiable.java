package net.pitan76.mcpitanlib.api.util;

import net.minecraft.class_3542;

public interface CompatStringIdentifiable extends class_3542 {
    @Deprecated
    @Override
    default String method_15434() {
        return asString_compat();
    }

    String asString_compat();

    default class_3542 get() {
        return this;
    }
}
