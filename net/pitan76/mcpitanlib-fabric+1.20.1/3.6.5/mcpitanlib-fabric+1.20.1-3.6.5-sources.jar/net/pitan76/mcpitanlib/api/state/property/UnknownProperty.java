package net.pitan76.mcpitanlib.api.state.property;

import net.minecraft.class_2769;

public class UnknownProperty implements IProperty {

    private final net.minecraft.class_2769<?> property;

    public UnknownProperty(net.minecraft.class_2769<?> property) {
        this.property = property;
    }

    public static UnknownProperty of(net.minecraft.class_2769<?> property) {
        return new UnknownProperty(property);
    }

    @Override
    public class_2769<?> getProperty() {
        return property;
    }
}
