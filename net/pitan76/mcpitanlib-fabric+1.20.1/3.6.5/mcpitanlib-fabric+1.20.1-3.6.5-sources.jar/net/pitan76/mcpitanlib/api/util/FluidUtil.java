package net.pitan76.mcpitanlib.api.util;

import net.minecraft.class_1792;
import net.minecraft.class_2960;
import net.minecraft.class_3609;
import net.minecraft.class_3610;
import net.minecraft.class_3611;
import net.minecraft.class_3612;
import net.minecraft.class_4538;
import net.minecraft.class_7923;

public class FluidUtil {
    public static class_2960 toID(class_3611 fluid) {
        return class_7923.field_41173.method_10221(fluid);
    }

    public static class_3611 fromId(class_2960 identifier) {
        return class_7923.field_41173.method_10223(identifier);
    }

    public static class_3611 fromId(CompatIdentifier identifier) {
        return fromId(identifier.toMinecraft());
    }

    public static int getRawId(class_3611 fluid) {
        return class_7923.field_41173.method_10206(fluid);
    }

    public static class_3611 fromIndex(int index) {
        return class_7923.field_41173.method_10200(index);
    }

    public static boolean isExist(CompatIdentifier id) {
        return class_7923.field_41173.method_10250(id.toMinecraft());
    }

    public static CompatIdentifier toCompatId(class_3611 fluid) {
        return CompatIdentifier.fromMinecraft(toID(fluid));
    }

    public static class_3611 fromCompatId(CompatIdentifier id) {
        return fromId(id.toMinecraft());
    }

    public static class_3609 water() {
        return class_3612.field_15910;
    }

    public static class_3609 lava() {
        return class_3612.field_15908;
    }

    public static class_3611 empty() {
        return class_3612.field_15906;
    }

    public static class_3609 flowingWater() {
        return class_3612.field_15909;
    }

    public static class_3609 flowingLava() {
        return class_3612.field_15907;
    }

    public static boolean isStill(class_3611 fluid) {
        return fluid == water() || fluid == lava();
    }

    public static boolean isStill(class_3610 state) {
        return state.method_15771();
    }

    public static class_3610 getStill(class_3609 fluid, boolean falling) {
        return fluid.method_15729(falling);
    }

    public static class_3610 getFlowing(class_3609 fluid, int level, boolean falling) {
        return fluid.method_15728(level, falling);
    }

    public static class_3610 getStill(class_3609 fluid) {
        return getStill(fluid, false);
    }

    public static class_3610 getStillWater() {
        return getStill(water());
    }

    public static class_3610 getStillLava() {
        return getStill(lava());
    }

    public static boolean isFlowing(class_3611 fluid) {
        return fluid == flowingWater() || fluid == flowingLava();
    }

    public static int getTickRate(class_3611 fluid, class_4538 world) {
        return fluid.method_15789(world);
    }

    public static class_3610 getDefaultState(class_3611 fluid) {
        return fluid.method_15785();
    }


    public static class_1792 getBucketItem(class_3611 fluid) {
        return fluid.method_15774();
    }
}
