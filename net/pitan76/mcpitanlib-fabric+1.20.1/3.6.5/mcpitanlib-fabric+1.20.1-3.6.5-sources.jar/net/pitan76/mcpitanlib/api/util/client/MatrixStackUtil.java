package net.pitan76.mcpitanlib.api.util.client;

import net.pitan76.mcpitanlib.api.util.MathUtil;

import static net.pitan76.mcpitanlib.api.util.MathUtil.getRotationDegrees;

import net.minecraft.class_4587;

public class MatrixStackUtil {
    public static void multiply(class_4587 matrixStack, MathUtil.RotationAxisType type, float deg) {
        matrixStack.method_22907(getRotationDegrees(type, deg));
    }

    public static void push(class_4587 matrices) {
        matrices.method_22903();
    }

    public static void pop(class_4587 matrices) {
        matrices.method_22909();
    }

    public static void translate(class_4587 matrices, double x, double y, double z) {
        matrices.method_22904(x, y, z);
    }

    public static void scale(class_4587 matrices, float x, float y, float z) {
        matrices.method_22905(x, y, z);
    }

    public static class_4587.class_4665 peek(class_4587 matrices) {
        return matrices.method_23760();
    }
}
