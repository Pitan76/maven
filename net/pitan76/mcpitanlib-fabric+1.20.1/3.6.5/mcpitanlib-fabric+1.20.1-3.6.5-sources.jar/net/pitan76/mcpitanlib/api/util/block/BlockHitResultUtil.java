package net.pitan76.mcpitanlib.api.util.block;

import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_3965;

public class BlockHitResultUtil {

    public static class_3965 create(class_243 pos, class_2350 direction, class_2338 blockPos, boolean insideBlock) {
        return new class_3965(pos, direction, blockPos, insideBlock);
    }

    public static class_3965 create(class_243 pos, class_2350 direction, class_2338 blockPos) {
        return new class_3965(pos, direction, blockPos, false);
    }

    public static class_243 getPos(class_3965 blockHitResult) {
        return blockHitResult.method_17784();
    }

    public static class_2350 getSide(class_3965 blockHitResult) {
        return blockHitResult.method_17780();
    }

    public static class_2338 getBlockPos(class_3965 blockHitResult) {
        return blockHitResult.method_17777();
    }

    public static boolean isInsideBlock(class_3965 blockHitResult) {
        return blockHitResult.method_17781();
    }
}
