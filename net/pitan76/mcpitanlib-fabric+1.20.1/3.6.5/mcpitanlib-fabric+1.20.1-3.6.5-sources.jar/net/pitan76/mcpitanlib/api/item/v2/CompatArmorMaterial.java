package net.pitan76.mcpitanlib.api.item.v2;

import net.minecraft.class_2960;
import net.minecraft.class_3414;
import net.pitan76.mcpitanlib.api.item.CompatibleArmorMaterial;
import net.pitan76.mcpitanlib.api.sound.CompatSoundEvent;
import net.pitan76.mcpitanlib.api.util.CompatIdentifier;

@Deprecated
public interface CompatArmorMaterial extends CompatibleArmorMaterial {

    @Override
    default class_3414 getEquipSound() {
        return getEquipCompatSound().get();
    }

    CompatSoundEvent getEquipCompatSound();

    @Override
    default class_2960 getId() {
        return getCompatId().toMinecraft();
    }

    CompatIdentifier getCompatId();
}
