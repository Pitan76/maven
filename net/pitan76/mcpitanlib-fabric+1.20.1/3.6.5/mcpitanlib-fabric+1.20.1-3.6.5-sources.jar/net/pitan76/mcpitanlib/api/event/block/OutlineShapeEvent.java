package net.pitan76.mcpitanlib.api.event.block;

import net.minecraft.class_1922;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_2769;
import net.minecraft.class_3726;
import net.pitan76.mcpitanlib.api.event.BaseEvent;
import net.pitan76.mcpitanlib.api.state.property.IProperty;

public class OutlineShapeEvent extends BaseEvent {
    public class_2680 state;
    public class_1922 world;
    public class_2338 pos;
    public class_3726 context;

    public OutlineShapeEvent(class_2680 state, class_1922 world, class_2338 pos, class_3726 context) {
        this.state = state;
        this.world = world;
        this.pos = pos;
        this.context = context;
    }

    public class_2338 getPos() {
        return pos;
    }

    public class_2680 getState() {
        return state;
    }

    public class_1922 getWorld() {
        return world;
    }

    public class_3726 getContext() {
        return context;
    }

    public <T extends Comparable<T>> T getProperty(class_2769<T> property) {
        return state.method_11654(property);
    }

    public <T extends Comparable<T>> boolean containsProperty(class_2769<T> property) {
        return state.method_28498(property);
    }

    public <T extends Comparable<T>, V extends T> class_2680 with(class_2769<T> property, V value) {
        return state.method_11657(property, value);
    }

    public <T extends Comparable<T>> T get(IProperty<T> property) {
        return getProperty(property.getProperty());
    }

    public <T extends Comparable<T>> boolean contains(IProperty<T> property) {
        return containsProperty(property.getProperty());
    }

    public <T extends Comparable<T>, V extends T> net.pitan76.mcpitanlib.midohra.block.BlockState with(IProperty<T> property, V value) {
        return net.pitan76.mcpitanlib.midohra.block.BlockState.of(with(property.getProperty(), value));
    }
}
