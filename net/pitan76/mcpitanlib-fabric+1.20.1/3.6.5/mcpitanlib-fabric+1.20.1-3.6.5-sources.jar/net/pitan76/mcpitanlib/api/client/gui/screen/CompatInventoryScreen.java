package net.pitan76.mcpitanlib.api.client.gui.screen;

import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1735;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.pitan76.mcpitanlib.api.client.render.DrawObjectDM;
import net.pitan76.mcpitanlib.api.util.CompatIdentifier;
import net.pitan76.mcpitanlib.guilib.api.render.SlotRenderer;

public abstract class CompatInventoryScreen<S extends class_1703> extends SimpleInventoryScreen<S> {

    public CompatInventoryScreen(S handler, class_1661 inventory, class_2561 title) {
        super(handler, inventory, title);
    }

    public abstract CompatIdentifier getCompatTexture();

    @Deprecated
    @Override
    public class_2960 getTexture() {
        return getCompatTexture().toMinecraft();
    }

    public void drawSlot(DrawObjectDM drawObjectDM, class_1735 slot) {
        SlotRenderer.drawSlot(drawObjectDM, slot, field_2776, field_2800);
    }

    public void drawSlots(DrawObjectDM drawObjectDM) {
        SlotRenderer.drawSlots(drawObjectDM, field_2797, field_2776, field_2800);
    }
}
