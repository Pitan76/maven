package net.pitan76.mcpitanlib.api.util.color;

import net.minecraft.class_3620;

public class CompatBrightness {
    private final class_3620.class_6594 brightness;

    public static final CompatBrightness LOW = of(class_3620.class_6594.field_34759);
    public static final CompatBrightness NORMAL = of(class_3620.class_6594.field_34760);
    public static final CompatBrightness HIGH = of(class_3620.class_6594.field_34761);
    public static final CompatBrightness LOWEST = of(class_3620.class_6594.field_34762);

    public CompatBrightness(class_3620.class_6594 brightness) {
        this.brightness = brightness;
    }

    public static CompatBrightness of(class_3620.class_6594 brightness) {
        return new CompatBrightness(brightness);
    }

    public class_3620.class_6594 get() {
        return brightness;
    }

    public String getName() {
        return get().name();
    }

    public int getId() {
        return get().field_34763;
    }

    public int getBrightness() {
        return get().field_34764;
    }

    @Override
    public int hashCode() {
        return brightness.hashCode();
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        CompatBrightness other = (CompatBrightness) obj;
        return brightness == other.brightness;
    }
}
