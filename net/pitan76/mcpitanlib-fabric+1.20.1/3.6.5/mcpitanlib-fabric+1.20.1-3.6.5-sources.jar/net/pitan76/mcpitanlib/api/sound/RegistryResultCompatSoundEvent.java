package net.pitan76.mcpitanlib.api.sound;

import net.minecraft.class_3414;
import net.pitan76.mcpitanlib.api.registry.result.RegistryResult;

public class RegistryResultCompatSoundEvent extends CompatSoundEvent {

    public RegistryResult<class_3414> result;

    public RegistryResultCompatSoundEvent(RegistryResult<class_3414> result) {
        super((class_3414) null);
        this.result = result;
    }

    public static RegistryResultCompatSoundEvent of(RegistryResult<class_3414> result) {
        return new RegistryResultCompatSoundEvent(result);
    }

    @Override
    public class_3414 get() {
        if ((result == null || result.getOrNull() == null) && super.get() != null)
            return super.get();

        return result.get();
    }
}
