package net.pitan76.mcpitanlib.api.entity.attribute;

import net.minecraft.class_1309;
import net.minecraft.class_1324;
import net.pitan76.mcpitanlib.api.entity.Player;
import net.pitan76.mcpitanlib.api.util.CompatIdentifier;

import java.util.function.Consumer;

public class CompatEntityAttributeInstance {
    private final net.minecraft.class_1324 raw;

    @Deprecated
    public CompatEntityAttributeInstance(net.minecraft.class_1324 instance) {
        this.raw = instance;
    }

    @Deprecated
    public net.minecraft.class_1324 raw() {
        return raw;
    }

    @Deprecated
    public static CompatEntityAttributeInstance of(net.minecraft.class_1324 instance) {
        return new CompatEntityAttributeInstance(instance);
    }

    public static CompatEntityAttributeInstance create(CompatEntityAttribute type, Consumer<CompatEntityAttributeInstance> updateCallback) {
        return of(new class_1324(type.raw(), modifier -> {
            if (updateCallback != null)
                updateCallback.accept(of(modifier));
        }));
    }

    public static CompatEntityAttributeInstance get(class_1309 entity, CompatEntityAttribute attribute) {
        return new CompatEntityAttributeInstance(entity.method_5996(attribute.raw()));
    }

    public static CompatEntityAttributeInstance get(Player player, CompatEntityAttribute attribute) {
        return get(player.getEntity(), attribute);
    }

    // TODO: Implement this method properly
    public boolean hasModifier(CompatIdentifier id) {
        return false; //raw().hasModifier();
    }

    public double getValue() {
        return raw().method_6194();
    }

    public void setBaseValue(double value) {
        raw().method_6192(value);
    }

    public void addPersistentModifier(CompatEntityAttributeModifier modifier) {
        raw().method_26837(modifier.raw());
    }

    // TODO: Implement this method properly
    public void removeModifier(CompatIdentifier id) {

    }

    public CompatEntityAttribute getAttribute() {
        return CompatEntityAttribute.of(raw().method_6198());
    }

    public boolean isNull() {
        return raw() == null;
    }
}
