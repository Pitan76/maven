package net.pitan76.mcpitanlib.api.util.recipe;

import net.minecraft.class_1860;
import net.minecraft.class_1937;
import net.minecraft.class_3956;
import net.pitan76.mcpitanlib.api.recipe.v3.CompatRecipe;
import net.pitan76.mcpitanlib.api.util.CompatIdentifier;
import net.pitan76.mcpitanlib.midohra.recipe.CraftingRecipe;
import net.pitan76.mcpitanlib.midohra.recipe.entry.CraftingRecipeEntry;
import net.pitan76.mcpitanlib.midohra.recipe.entry.RecipeEntry;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

public class RecipeUtil {
    public static Collection<class_1860<?>> getMCRecipes(class_1937 world) {
        return world.method_8433().method_8126();
    }

    public static Collection<CompatRecipe> getRecipes(class_1937 world) {
        List<CompatRecipe> recipes = new ArrayList<>();

        for (class_1860<?> recipe : getMCRecipes(world)) {
            recipes.add(new CompatRecipe(recipe, recipe.method_8114()));
        }

        return recipes;
    }

    public static Collection<CompatRecipe> getRecipesByType(class_1937 world, class_3956<?> type) {
        List<CompatRecipe> recipes = new ArrayList<>();

        for (class_1860<?> recipe : getMCRecipes(world)) {
            if (recipe.method_17716() == type) {
                recipes.add(new CompatRecipe(recipe, recipe.method_8114()));
            }
        }

        return recipes;
    }

    // MidohraAPI
    public static Collection<CompatRecipe> getRecipes(net.pitan76.mcpitanlib.midohra.world.World world) {
        return getRecipes(world.getRaw());
    }

    public static Collection<CompatRecipe> getRecipesByType(net.pitan76.mcpitanlib.midohra.world.World world, net.pitan76.mcpitanlib.midohra.recipe.RecipeType type) {
        return getRecipesByType(world.getRaw(), type.getRaw());
    }

    public static Collection<RecipeEntry> getRecipeEntries(net.pitan76.mcpitanlib.midohra.world.World world) {
        List<RecipeEntry> entries = new ArrayList<>();

        for (class_1860<?> recipe : getMCRecipes(world.getRaw())) {
            entries.add(RecipeEntry.of(recipe, CompatIdentifier.fromMinecraft(recipe.method_8114())));
        }

        return entries;
    }

    public static Collection<CraftingRecipe> getCraftingRecipes(net.pitan76.mcpitanlib.midohra.world.World world) {
        List<CraftingRecipe> recipes = new ArrayList<>();

        for (CompatRecipe recipe : getRecipesByType(world, net.pitan76.mcpitanlib.midohra.recipe.RecipeType.CRAFTING)) {
            if (recipe.getRecipe() instanceof net.minecraft.class_3955) {
                recipes.add(CraftingRecipe.of((net.minecraft.class_3955) recipe.getRecipe()));
            }
        }

        return recipes;
    }

    public static Collection<CraftingRecipeEntry> getCraftingRecipeEntries(net.pitan76.mcpitanlib.midohra.world.World world) {
        List<CraftingRecipeEntry> entries = new ArrayList<>();

        for (class_1860<?> recipe : getMCRecipes(world.getRaw())) {
            if (recipe instanceof net.minecraft.class_3955) {
                entries.add(CraftingRecipeEntry.of((net.minecraft.class_3955) recipe, CompatIdentifier.fromMinecraft(recipe.method_8114())));
            }
        }

        return entries;
    }
}
