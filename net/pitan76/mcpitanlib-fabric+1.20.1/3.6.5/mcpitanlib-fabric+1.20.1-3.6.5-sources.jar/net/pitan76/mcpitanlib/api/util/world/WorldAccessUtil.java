package net.pitan76.mcpitanlib.api.util.world;

import net.minecraft.class_1297;
import net.minecraft.class_1936;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_3611;
import net.minecraft.server.MinecraftServer;

public class WorldAccessUtil extends WorldViewUtil {

    public static void scheduleBlockTick(class_1936 world, class_2338 pos, class_2248 block, int delay) {
        world.method_39279(pos, block, delay);
    }

    public static void scheduleFluidTick(class_1936 world, class_2338 pos, class_3611 fluid, int delay) {
        world.method_39281(pos, fluid, delay);
    }

    public static boolean setBlockState(class_1936 world, class_2338 pos, class_2680 state, int flags) {
        return world.method_8652(pos, state, flags);
    }

    public static boolean setBlockState(class_1936 world, class_2338 pos, class_2680 state, int flags, int maxUpdateDepth) {
        return world.method_30092(pos, state, flags, maxUpdateDepth);
    }

    public static boolean setBlockState(class_1936 world, class_2338 pos, class_2680 state) {
        return setBlockState(world, pos, state, 3);
    }

    public static class_2680 getBlockState(class_1936 world, class_2338 pos) {
        return world.method_8320(pos);
    }

    public static boolean breakBlock(class_1936 world, class_2338 pos, boolean drop) {
        return world.method_22352(pos, drop);
    }

    public static boolean breakBlock(class_1936 world, class_2338 pos, boolean drop, class_1297 entity) {
        return world.method_8651(pos, drop, entity);
    }

    public static boolean removeBlock(class_1936 world, class_2338 pos, boolean move) {
        return world.method_8650(pos, move);
    }

    public static MinecraftServer getServer(class_1936 world) {
        return world.method_8503();
    }
}
