package net.pitan76.mcpitanlib.api.util.world;

import net.minecraft.class_1297;
import net.minecraft.class_1799;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2394;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_3215;
import net.minecraft.class_3218;
import net.pitan76.mcpitanlib.api.entity.Player;
import net.pitan76.mcpitanlib.midohra.block.entity.BlockEntityWrapper;
import org.jetbrains.annotations.Nullable;

import java.util.List;

public class ServerWorldUtil {
    public static void spawnParticles(class_3218 world, class_2394 particle, double x, double y, double z, int count, double velocityX, double velocityY, double velocityZ, double speed) {
        world.method_14199(particle, x, y, z, count, velocityX, velocityY, velocityZ, speed);
    }

    public static void spawnParticles(class_3218 world, Player player, class_2394 particle, boolean force, double x, double y, double z, int count, double velocityX, double velocityY, double velocityZ, double speed) {
        if (player.isServer()) {
            world.method_14166(player.getServerPlayer().get(), particle, force, x, y, z, count, velocityX, velocityY, velocityZ, speed);
        }
    }

    public static List<class_1799> getDroppedStacksOnBlock(class_2680 state, class_3218 world, class_2338 pos, @Nullable class_2586 blockEntity) {
        return class_2248.method_9562(state, world, pos, blockEntity);
    }

    public static List<class_1799> getDroppedStacksOnBlock(class_2680 state, class_3218 world, class_2338 pos, @Nullable BlockEntityWrapper blockEntity) {
        return getDroppedStacksOnBlock(state, world, pos, blockEntity.get());
    }

    public static List<class_1799> getDroppedStacksOnBlock(class_2680 state, class_3218 world, class_2338 pos, @Nullable class_2586 blockEntity, @Nullable class_1297 entity, class_1799 stack) {
        return class_2248.method_9609(state, world, pos, blockEntity, entity, stack);
    }

    public static class_3215 getChunkManager(class_3218 world) {
        return world.method_14178();
    }
}
