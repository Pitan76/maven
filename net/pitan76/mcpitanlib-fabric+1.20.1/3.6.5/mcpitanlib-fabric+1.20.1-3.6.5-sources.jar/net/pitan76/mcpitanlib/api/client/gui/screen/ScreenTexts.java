package net.pitan76.mcpitanlib.api.client.gui.screen;

import net.minecraft.class_2561;
import net.pitan76.mcpitanlib.api.util.TextUtil;

public class ScreenTexts {
    public static final class_2561 ON = TextUtil.translatable("options.on");
    public static final class_2561 OFF = TextUtil.translatable("options.off");
    public static final class_2561 DONE = TextUtil.translatable("gui.done");
    public static final class_2561 CANCEL = TextUtil.translatable("gui.cancel");
    public static final class_2561 YES = TextUtil.translatable("gui.yes");
    public static final class_2561 NO = TextUtil.translatable("gui.no");
    public static final class_2561 PROCEED = TextUtil.translatable("gui.proceed");
    public static final class_2561 BACK = TextUtil.translatable("gui.back");
    public static final class_2561 CONNECT_FAILED = TextUtil.translatable("connect.failed");
    public static final class_2561 LINE_BREAK = TextUtil.literal("\n");
    public static final class_2561 SENTENCE_SEPARATOR = TextUtil.literal(". ");

    public ScreenTexts() {
    }
}
