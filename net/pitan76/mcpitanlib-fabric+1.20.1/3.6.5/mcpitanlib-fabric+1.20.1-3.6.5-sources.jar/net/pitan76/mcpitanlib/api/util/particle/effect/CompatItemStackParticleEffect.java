package net.pitan76.mcpitanlib.api.util.particle.effect;

import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_2392;
import net.pitan76.mcpitanlib.api.util.ItemStackUtil;
import net.pitan76.mcpitanlib.api.util.ParticleEffectUtil;
import net.pitan76.mcpitanlib.midohra.item.ItemWrapper;

public class CompatItemStackParticleEffect extends CompatParticleEffect {
    @Deprecated
    public CompatItemStackParticleEffect(class_2392 effect) {
        super(effect);
    }

    public CompatItemStackParticleEffect(class_1799 stack) {
        this(ParticleEffectUtil.itemStack.createTypedItem(stack));
    }

    @Deprecated
    public static CompatItemStackParticleEffect of(class_2392 effect) {
        return new CompatItemStackParticleEffect(effect);
    }

    public static CompatItemStackParticleEffect of(class_1799 stack) {
        return new CompatItemStackParticleEffect(stack);
    }

    public static CompatItemStackParticleEffect of(net.pitan76.mcpitanlib.midohra.item.ItemStack stack) {
        return new CompatItemStackParticleEffect(stack.toMinecraft());
    }

    public static CompatItemStackParticleEffect of(CompatParticleEffect effect) {
        if (effect.getRaw() instanceof class_2392 itemEffect) {
            return new CompatItemStackParticleEffect(itemEffect);
        }
        throw new IllegalArgumentException("The provided particle effect is not an ItemStackParticleEffect.");
    }

    public static CompatItemStackParticleEffect of(class_1792 item) {
        return new CompatItemStackParticleEffect(ItemStackUtil.create(item));
    }

    public static CompatItemStackParticleEffect of(ItemWrapper item) {
        return of(item.get());
    }

    public class_1799 getStack() {
        class_2392 itemEffect = (class_2392) getRaw();
        return itemEffect.method_10289();
    }

    public net.pitan76.mcpitanlib.midohra.item.ItemStack getStackM() {
        return net.pitan76.mcpitanlib.midohra.item.ItemStack.of(getStack());
    }
}
