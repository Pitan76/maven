package net.pitan76.mcpitanlib.api.entity;

import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1937;
import net.minecraft.class_2487;
import net.minecraft.class_2596;
import net.minecraft.class_2602;
import net.pitan76.mcpitanlib.api.nbt.NbtTag;

public class ExtendEntity extends class_1297 {
    public ExtendEntity(class_1299<?> type, class_1937 world) {
        super(type, world);
    }

    public void method_5693() {
    }

    public void method_5749(class_2487 nbt) {

    }

    public void method_5652(class_2487 nbt) {

    }

    public class_2596<class_2602> method_18002() {
        return null;
    }

    // 互換性用 (NbtTag型をOverrideすること)
    public void writeNbt(NbtTag nbt) {
        super.method_5647(nbt);
    }

    public void readNbt(NbtTag nbt) {
        super.method_5651(nbt);
    }

    // 1.18
    @Override
    public class_2487 method_5647(class_2487 nbt) {
        this.writeNbt(NbtTag.from(nbt));
        return nbt;
    }

    @Override
    public void method_5651(class_2487 nbt) {
        this.readNbt(NbtTag.from(nbt));
    }

    // 1.14
    public class_2487 toTag(class_2487 nbt) {
        this.writeNbt(NbtTag.from(nbt));
        return nbt;
    }

    public class_2487 fromTag(class_2487 nbt) {
        this.readNbt(NbtTag.from(nbt));
        return nbt;
    }

    @Override
    public class_1937 method_37908() {
        return super.method_37908();
    }
}