package net.pitan76.mcpitanlib.api.client.color;

import dev.architectury.injectables.annotations.ExpectPlatform;
import net.minecraft.class_1920;
import net.minecraft.class_2338;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.pitan76.mcpitanlib.midohra.world.BlockView;
import org.jetbrains.annotations.Nullable;

public class BlockColorEvent {
    private final class_2680 state;
    private final class_1920 world;
    private final class_2338 pos;
    private final int tintIndex;

    public BlockColorEvent(class_2680 state, @Nullable class_1920 world, @Nullable class_2338 pos, int tintIndex) {
        this.state = state;
        this.world = world;
        this.pos = pos;
        this.tintIndex = tintIndex;
    }

    public class_2680 getState() {
        return state;
    }

    public class_1920 getWorld() {
        return world;
    }

    public class_2338 getPos() {
        return pos;
    }

    public int getTintIndex() {
        return tintIndex;
    }

    public net.pitan76.mcpitanlib.midohra.util.math.BlockPos getMidohraPos() {
        return net.pitan76.mcpitanlib.midohra.util.math.BlockPos.of(getPos());
    }

    public net.pitan76.mcpitanlib.midohra.block.BlockState getMidohraState() {
        return net.pitan76.mcpitanlib.midohra.block.BlockState.of(getState());
    }

    public boolean hasWorld() {
        return getWorld() != null;
    }

    public boolean hasPos() {
        return getPos() != null;
    }

    public BlockView getMidohraWorld() {
        if (!hasWorld()) return null;
        return net.pitan76.mcpitanlib.midohra.world.BlockView.of(getWorld());
    }

    public class_2586 getBlockEntity() {
        if (!hasWorld() || !hasPos()) return null;
        return getWorld().method_8321(getPos());
    }

    public int getDefaultColor() {
        return 0xFFFFFF;
    }

    public Object getRenderData() {
        if (!hasWorld() || !hasPos()) return null;
        return getRenderDataD(getBlockEntity());
    }

    @ExpectPlatform
    protected static Object getRenderDataD(class_2586 blockEntity) {
        if (blockEntity instanceof net.pitan76.mcpitanlib.api.tile.RenderDataBlockEntity) {
            return ((net.pitan76.mcpitanlib.api.tile.RenderDataBlockEntity) blockEntity).getCompatRenderData();
        }

        return null;
    }
}