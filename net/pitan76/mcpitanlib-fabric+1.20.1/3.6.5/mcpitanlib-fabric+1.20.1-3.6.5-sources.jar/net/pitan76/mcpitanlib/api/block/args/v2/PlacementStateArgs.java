package net.pitan76.mcpitanlib.api.block.args.v2;

import net.minecraft.class_1268;
import net.minecraft.class_1750;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_2586;
import net.minecraft.class_2769;
import net.minecraft.class_3965;
import net.pitan76.mcpitanlib.api.entity.Player;
import net.pitan76.mcpitanlib.api.event.BaseEvent;
import net.pitan76.mcpitanlib.api.event.item.ItemUseOnBlockEvent;
import net.pitan76.mcpitanlib.api.util.BlockStateUtil;
import net.pitan76.mcpitanlib.midohra.holder.BlockStatePropertyHolder;
import net.pitan76.mcpitanlib.midohra.block.BlockState;
import net.pitan76.mcpitanlib.midohra.block.BlockWrapper;
import net.pitan76.mcpitanlib.midohra.block.entity.BlockEntityWrapper;
import net.pitan76.mcpitanlib.midohra.util.hit.HitResultType;
import net.pitan76.mcpitanlib.midohra.util.math.Direction;
import net.pitan76.mcpitanlib.midohra.world.IWorldView;
import net.pitan76.mcpitanlib.midohra.world.World;
import net.pitan76.mcpitanlib.mixin.ItemUsageContextMixin;
import org.jetbrains.annotations.Nullable;

public class PlacementStateArgs extends BaseEvent implements BlockStatePropertyHolder {
    public class_1750 ctx;

    @Nullable
    public class_2248 block;

    public PlacementStateArgs(class_1750 ctx) {
        this.ctx = ctx;
    }

    public PlacementStateArgs(class_1750 ctx, @Nullable class_2248 block) {
        this.ctx = ctx;
        this.block = block;
    }

    public boolean canPlace() {
        return ctx.method_7716();
    }

    public class_2338 getRawPos() {
        return ctx.method_8037();
    }

    public net.pitan76.mcpitanlib.midohra.util.math.BlockPos getPos() {
        return net.pitan76.mcpitanlib.midohra.util.math.BlockPos.of(getRawPos());
    }

    public Player getPlayer() {
        return new Player(ctx.method_8036());
    }

    public Direction[] getPlacementDirections() {
        net.minecraft.class_2350[] rawDirs = getRawPlacementDirections();
        Direction[] directions = new Direction[rawDirs.length];
        for (int i = 0; i < directions.length; i++) {
            directions[i] = Direction.of(rawDirs[i]);
        }

        return directions;
    }

    public net.minecraft.class_2350[] getRawPlacementDirections() {
        return ctx.method_7718();
    }

    public class_1268 getHand() {
        return ctx.method_20287();
    }

    public Direction getSide() {
        return Direction.of(getRawSide());
    }

    public net.minecraft.class_2350 getRawSide() {
        return ctx.method_8038();
    }

    public Direction getHorizontalPlayerFacing() {
        return Direction.of(getRawHorizontalPlayerFacing());
    }

    public net.minecraft.class_2350 getRawHorizontalPlayerFacing() {
        return ctx.method_8042();
    }

    public float getPlayerYaw() {
        return ctx.method_8044();
    }

    public World getWorld() {
        return World.of(ctx.method_8045());
    }

    public IWorldView getWorldView() {
        return getWorld();
    }

    public boolean isClient() {
        return getWorld().isClient();
    }

    public class_243 getHitPos() {
        return ctx.method_17698();
    }

    public boolean canReplaceExisting() {
        return ctx.method_7717();
    }

    @Deprecated
    public ItemUsageContextMixin getIUCAccessor() {
        return (ItemUsageContextMixin) ctx;
    }

    public class_3965 getHitResult() {
        return getIUCAccessor().getHit();
    }

    public ItemUseOnBlockEvent toItemUseOnBlockEvent() {
        return new ItemUseOnBlockEvent(getWorld().getRaw(), getPlayer().getPlayerEntity(), getHand(), ctx.method_8041(), getHitResult());
    }

    public class_1750 getCtx() {
        return ctx;
    }

    public @Nullable class_2248 getRawBlock() {
        return block;
    }

    public boolean isBlockExist() {
        return block != null;
    }

    public net.minecraft.class_2680 getRawBlockState() {
        return BlockStateUtil.getDefaultState(block);
    }

    public class_2586 getRawBlockEntity() {
        return getWorld().getBlockEntity(getRawPos());
    }

    public BlockWrapper getBlock() {
        return BlockWrapper.of(block);
    }

    public <T extends Comparable<T>, V extends T> net.minecraft.class_2680 with(class_2769<T> property, V value) {
        if (block == null)
            return null;

        return BlockStateUtil.with(BlockStateUtil.getDefaultState(block), property, value);
    }

    @Override
    public BlockState getBlockState() {
        return BlockState.of(getRawBlockState());
    }

    public BlockEntityWrapper getBlockEntity() {
        return getWorld().getBlockEntity(getPos());
    }

    public net.pitan76.mcpitanlib.midohra.util.hit.BlockHitResult getHitResultM() {
        return net.pitan76.mcpitanlib.midohra.util.hit.BlockHitResult.of(getHitResult());
    }

    public HitResultType getHitResultTypeM() {
        return HitResultType.from(getHitResult().method_17783());
    }
}
