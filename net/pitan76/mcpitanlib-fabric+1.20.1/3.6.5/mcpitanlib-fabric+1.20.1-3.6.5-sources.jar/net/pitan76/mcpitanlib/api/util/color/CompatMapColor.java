package net.pitan76.mcpitanlib.api.util.color;

import net.minecraft.class_3620;

public class CompatMapColor {
    private final class_3620 color;

    public static final CompatMapColor CLEAR = of(class_3620.field_16008);
    public static final CompatMapColor PALE_GREEN = of(class_3620.field_15999);
    public static final CompatMapColor PALE_YELLOW = of(class_3620.field_15986);
    public static final CompatMapColor WHITE_GRAY = of(class_3620.field_15979);
    public static final CompatMapColor BRIGHT_RED = of(class_3620.field_16002);
    public static final CompatMapColor PALE_PURPLE = of(class_3620.field_16016);
    public static final CompatMapColor IRON_GRAY = of(class_3620.field_16005);
    public static final CompatMapColor DARK_GREEN = of(class_3620.field_16004);
    public static final CompatMapColor WHITE = of(class_3620.field_16022);
    public static final CompatMapColor LIGHT_BLUE_GRAY = of(class_3620.field_15976);
    public static final CompatMapColor DIRT_BROWN = of(class_3620.field_16000);
    public static final CompatMapColor STONE_GRAY = of(class_3620.field_16023);
    public static final CompatMapColor WATER_BLUE = of(class_3620.field_16019);
    public static final CompatMapColor OAK_TAN = of(class_3620.field_15996);
    public static final CompatMapColor OFF_WHITE = of(class_3620.field_16025);
    public static final CompatMapColor ORANGE = of(class_3620.field_15987);
    public static final CompatMapColor MAGENTA = of(class_3620.field_15998);
    public static final CompatMapColor LIGHT_BLUE = of(class_3620.field_16024);
    public static final CompatMapColor YELLOW = of(class_3620.field_16010);
    public static final CompatMapColor LIME = of(class_3620.field_15997);
    public static final CompatMapColor PINK = of(class_3620.field_16030);
    public static final CompatMapColor GRAY = of(class_3620.field_15978);
    public static final CompatMapColor LIGHT_GRAY = of(class_3620.field_15993);
    public static final CompatMapColor CYAN = of(class_3620.field_16026);
    public static final CompatMapColor PURPLE = of(class_3620.field_16014);
    public static final CompatMapColor BLUE = of(class_3620.field_15984);
    public static final CompatMapColor BROWN = of(class_3620.field_15977);
    public static final CompatMapColor GREEN = of(class_3620.field_15995);
    public static final CompatMapColor RED = of(class_3620.field_16020);
    public static final CompatMapColor BLACK = of(class_3620.field_16009);
    public static final CompatMapColor GOLD = of(class_3620.field_15994);
    public static final CompatMapColor DIAMOND_BLUE = of(class_3620.field_15983);
    public static final CompatMapColor LAPIS_BLUE = of(class_3620.field_15980);
    public static final CompatMapColor EMERALD_GREEN = of(class_3620.field_16001);
    public static final CompatMapColor SPRUCE_BROWN = of(class_3620.field_16017);
    public static final CompatMapColor DARK_RED = of(class_3620.field_16012);
    public static final CompatMapColor TERRACOTTA_WHITE = of(class_3620.field_16003);
    public static final CompatMapColor TERRACOTTA_ORANGE = of(class_3620.field_15981);
    public static final CompatMapColor TERRACOTTA_MAGENTA = of(class_3620.field_15985);
    public static final CompatMapColor TERRACOTTA_LIGHT_BLUE = of(class_3620.field_15991);
    public static final CompatMapColor TERRACOTTA_YELLOW = of(class_3620.field_16013);
    public static final CompatMapColor TERRACOTTA_LIME = of(class_3620.field_16018);
    public static final CompatMapColor TERRACOTTA_PINK = of(class_3620.field_15989);
    public static final CompatMapColor TERRACOTTA_GRAY = of(class_3620.field_16027);
    public static final CompatMapColor TERRACOTTA_LIGHT_GRAY = of(class_3620.field_15988);
    public static final CompatMapColor TERRACOTTA_CYAN = of(class_3620.field_15990);
    public static final CompatMapColor TERRACOTTA_PURPLE = of(class_3620.field_16029);
    public static final CompatMapColor TERRACOTTA_BLUE = of(class_3620.field_16015);
    public static final CompatMapColor TERRACOTTA_BROWN = of(class_3620.field_15992);
    public static final CompatMapColor TERRACOTTA_GREEN = of(class_3620.field_16028);
    public static final CompatMapColor TERRACOTTA_RED = of(class_3620.field_15982);
    public static final CompatMapColor TERRACOTTA_BLACK = of(class_3620.field_16007);
    public static final CompatMapColor DULL_RED = of(class_3620.field_25702);
    public static final CompatMapColor DULL_PINK = of(class_3620.field_25703);
    public static final CompatMapColor DARK_CRIMSON = of(class_3620.field_25704);
    public static final CompatMapColor TEAL = of(class_3620.field_25705);
    public static final CompatMapColor DARK_AQUA = of(class_3620.field_25706);
    public static final CompatMapColor DARK_DULL_PINK = of(class_3620.field_25707);
    public static final CompatMapColor BRIGHT_TEAL = of(class_3620.field_25708);
    public static final CompatMapColor DEEPSLATE_GRAY = of(class_3620.field_33532);
    public static final CompatMapColor RAW_IRON_PINK = of(class_3620.field_33533);
    public static final CompatMapColor LICHEN_GREEN = of(class_3620.field_33617);

    public CompatMapColor(class_3620 color) {
        this.color = color;
    }

    public static CompatMapColor of(class_3620 color) {
        return new CompatMapColor(color);
    }

    public class_3620 getColor() {
        return color;
    }

    public int getId() {
        return color.field_16021;
    }

    public int getRgb() {
        return color.field_16011;
    }

    public int getRenderColor(CompatBrightness brightness) {
        return color.method_15820(brightness.get());
    }

    @Override
    public int hashCode() {
        return color.hashCode();
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        CompatMapColor other = (CompatMapColor) obj;
        return color.equals(other.color);
    }
}
