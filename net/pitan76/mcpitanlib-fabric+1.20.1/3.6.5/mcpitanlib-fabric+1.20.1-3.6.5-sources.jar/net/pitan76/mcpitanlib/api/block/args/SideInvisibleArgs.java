package net.pitan76.mcpitanlib.api.block.args;

import net.minecraft.class_2350;
import net.minecraft.class_2680;

public class SideInvisibleArgs {
    public class_2680 state;
    public class_2680 stateFrom;
    public class_2350 direction;

    public SideInvisibleArgs(class_2680 state, class_2680 stateFrom, class_2350 direction) {
        this.state = state;
        this.stateFrom = stateFrom;
        this.direction = direction;
    }

    public SideInvisibleArgs(net.pitan76.mcpitanlib.midohra.block.BlockState state, net.pitan76.mcpitanlib.midohra.block.BlockState stateFrom, net.pitan76.mcpitanlib.midohra.util.math.Direction direction) {
        this.state = state.toMinecraft();
        this.stateFrom = stateFrom.toMinecraft();
        this.direction = direction.toMinecraft();
    }

    public class_2680 getState() {
        return state;
    }

    public class_2680 getStateFrom() {
        return stateFrom;
    }

    public class_2350 getDirection() {
        return direction;
    }

    public net.pitan76.mcpitanlib.midohra.block.BlockState getMidohraState() {
        return net.pitan76.mcpitanlib.midohra.block.BlockState.of(getState());
    }

    public net.pitan76.mcpitanlib.midohra.block.BlockState getMidohraStateFrom() {
        return net.pitan76.mcpitanlib.midohra.block.BlockState.of(getStateFrom());
    }

    public net.pitan76.mcpitanlib.midohra.util.math.Direction getMidohraDirection() {
        return net.pitan76.mcpitanlib.midohra.util.math.Direction.of(getDirection());
    }
}
