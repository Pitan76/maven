package net.pitan76.mcpitanlib.api.recipe.v2;

import net.minecraft.class_1263;
import net.minecraft.class_1860;
import net.minecraft.class_1865;
import net.minecraft.class_2960;
import net.minecraft.class_3956;
import net.minecraft.recipe.*;
import net.pitan76.mcpitanlib.api.util.CompatIdentifier;
import net.pitan76.mcpitanlib.api.util.RecipeUtil;
import org.jetbrains.annotations.Nullable;

@Deprecated
public class CompatRecipeEntry<T extends class_1263> {
    private final class_1860<T> recipe;

    private class_2960 id;

    public String group = "";
    public RecipeUtil.CompatibilityCraftingRecipeCategory category = null;

    @Deprecated
    public CompatRecipeEntry(class_1860<T> recipe) {
        this.recipe = recipe;
    }

    public CompatRecipeEntry(class_2960 id, String group, RecipeUtil.CompatibilityCraftingRecipeCategory category, class_1860<T> recipe) {
        this.recipe = recipe;
        this.id = id;
        this.group = group;
        this.category = category;
    }

    public CompatRecipeEntry(CompatIdentifier id, String group, RecipeUtil.CompatibilityCraftingRecipeCategory category, class_1860<T> recipe) {
        this(id.toMinecraft(), group, category, recipe);
    }

    public boolean isNull() {
        return recipe == null;
    }

    public class_1860<T> getRecipe() {
        return recipe;
    }

    public class_2960 getId() {
        return id;
    }

    public CompatIdentifier getCompatId() {
        return CompatIdentifier.fromMinecraft(getId());
    }

    public class_3956<?> getType() {
        class_1860<T> recipe = getRecipe();
        if (recipe == null) return null;

        return recipe.method_17716();
    }

    public class_1865<?> getSerializer() {
        class_1860<?> recipe = getRecipe();
        if (recipe == null) return null;

        return recipe.method_8119();
    }

    @Nullable
    public RecipeUtil.CompatibilityCraftingRecipeCategory getCategory() {
        return category;
    }

    public String getGroup() {
        return group;
    }
}
