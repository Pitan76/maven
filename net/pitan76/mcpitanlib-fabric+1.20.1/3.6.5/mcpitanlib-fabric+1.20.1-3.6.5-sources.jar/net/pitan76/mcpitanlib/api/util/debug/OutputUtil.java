package net.pitan76.mcpitanlib.api.util.debug;

import net.minecraft.class_1263;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.pitan76.mcpitanlib.api.util.ItemUtil;
import net.pitan76.mcpitanlib.api.util.PlatformUtil;

public class OutputUtil {

    public static boolean dev = PlatformUtil.isDevelopmentEnvironment();

    public static void print(class_1792 item) {
        if (!dev) return;
        System.out.println(getString(item));
    }

    public static void print(class_1799 stack) {
        if (!dev) return;
        System.out.println(getString(stack));
    }

    public static void print(class_1263 inventory) {
        if (!dev) return;
        System.out.println(getString(inventory));
    }

    public static String getString(class_1792 item) {
        StringBuilder sb = new StringBuilder();
        sb.append("Item: {").append("\n");

        sb.append("  Name: ").append(item.method_7876()).append("\n");
        sb.append("  Id: ").append(ItemUtil.toCompatID(item)).append("\n");
        sb.append("}\n");

        return sb.toString();
    }

    public static String getString(class_1799 stack) {
        class_1792 item = stack.method_7909();

        StringBuilder sb = new StringBuilder();
        sb.append("ItemStack: {").append("\n");

        sb.append(getString(item));
        sb.append("  Count: ").append(stack.method_7947()).append("\n");
        sb.append("}\n");

        return sb.toString();
    }

    public static String getString(class_1263 inventory) {
        StringBuilder sb = new StringBuilder();
        sb.append("Inventory: {").append("\n");

        for (int i = 0; i < inventory.method_5439(); i++) {
            class_1799 stack = inventory.method_5438(i);
            if (stack.method_7960()) continue;

            sb.append("  Slot ").append(i).append(": {").append("\n");
            sb.append(getString(stack));
            sb.append("  }\n");
        }

        sb.append("}\n");

        return sb.toString();
    }
}
