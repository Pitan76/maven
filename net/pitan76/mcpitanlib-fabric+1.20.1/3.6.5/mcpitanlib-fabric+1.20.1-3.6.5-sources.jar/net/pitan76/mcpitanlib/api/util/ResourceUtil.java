package net.pitan76.mcpitanlib.api.util;

import java.io.IOException;
import java.io.InputStream;
import java.util.Map;
import net.minecraft.class_2960;
import net.minecraft.class_3298;
import net.minecraft.class_3300;

public class ResourceUtil {
    public static class_3298 getResource(class_3300 resourceManager, class_2960 identifier) {
        return resourceManager.method_14486(identifier).get();
    }

    public static InputStream getInputStream(class_3298 resource) throws IOException {
        return resource.method_14482();
    }

    public static Map<class_2960, class_3298> findResources(class_3300 resourceManager, String startingPath, String endingPath) throws IOException {
        return resourceManager.method_14488(startingPath, s -> s.toString().endsWith(endingPath));
    }

    public static void close(class_3298 resource) throws IOException {
        getInputStream(resource).close();
    }
}
