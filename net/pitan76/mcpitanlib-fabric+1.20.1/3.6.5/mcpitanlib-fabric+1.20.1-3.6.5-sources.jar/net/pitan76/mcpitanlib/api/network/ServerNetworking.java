package net.pitan76.mcpitanlib.api.network;

import dev.architectury.networking.NetworkManager;
import net.minecraft.class_2540;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.server.MinecraftServer;

import static dev.architectury.networking.NetworkManager.Side.C2S;

public class ServerNetworking {
    public static void send(class_3222 player, class_2960 identifier, class_2540 buf) {
        NetworkManager.sendToPlayer(player, identifier, buf);
    }

    public static void send(Iterable<class_3222> players, class_2960 identifier, class_2540 buf) {
        NetworkManager.sendToPlayers(players, identifier, buf);
    }


    public static void sendAll(MinecraftServer server, class_2960 identifier, class_2540 buf) {
        send(server.method_3760().method_14571(), identifier, buf);
    }

    public static void registerReceiver(class_2960 identifier, ServerNetworkHandler handler) {
        NetworkManager.registerReceiver(C2S, identifier, ((buf, context) -> handler.receive(context.getPlayer().method_5682(), (class_3222) context.getPlayer(), buf)));
    }

    @FunctionalInterface
    public interface ServerNetworkHandler {
        void receive(MinecraftServer server, class_3222 player, class_2540 buf);
    }

    public static void registerS2CPayloadType(class_2960 identifier) {
        // ignore
    }
}
