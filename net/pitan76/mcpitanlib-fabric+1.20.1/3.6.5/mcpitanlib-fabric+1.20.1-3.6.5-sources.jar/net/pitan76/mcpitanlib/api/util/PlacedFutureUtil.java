package net.pitan76.mcpitanlib.api.util;

import java.util.List;
import net.minecraft.class_2975;
import net.minecraft.class_5450;
import net.minecraft.class_5843;
import net.minecraft.class_6793;
import net.minecraft.class_6795;
import net.minecraft.class_6796;
import net.minecraft.class_6797;
import net.minecraft.class_6880;

public class PlacedFutureUtil {
    public static class_6796 create(class_2975<?, ?> configuredFeature, List<class_6797> placementModifiers) {
        return new class_6796(class_6880.method_40223(configuredFeature), placementModifiers);
    }

    public static List<class_6797> createPlacementModifiers(class_6793 countPlacementModifier, class_5450 squarePlacementModifier, class_6795 heightRangePlacementModifier) {
        return List.of(countPlacementModifier, squarePlacementModifier, heightRangePlacementModifier);
    }

    public static List<class_6797> createPlacementModifiers(int chunkCount, int top, int bottom) {
        return createPlacementModifiers(
class_6793.method_39623(chunkCount),
                class_5450.method_39639(),
                class_6795.method_39634(class_5843.method_33841(bottom), class_5843.method_33841(top))
        );
    }

    public static List<class_6797> createPlacementModifiers(int chunkCount, int top) {
        return createPlacementModifiers(
                class_6793.method_39623(chunkCount),
                class_5450.method_39639(),
                class_6795.method_39634(class_5843.method_33840(), class_5843.method_33841(top))
        );
    }
}
