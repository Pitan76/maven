package net.pitan76.mcpitanlib.api.util.inventory;

import net.minecraft.class_1263;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.pitan76.mcpitanlib.api.util.ItemStackUtil;

public class ClippedInventory implements class_1263, ICompatInventory {

    private final class_1263 inventory;
    private final int start;
    private final int end;

    public static ClippedInventory of(class_1263 inventory, int start, int end) {
        if (start < 0 || end > inventory.method_5439() || start >= end) {
            throw new IllegalArgumentException("Invalid start or end indices for clipping inventory.");
        }
        return new ClippedInventory(inventory, start, end);
    }

    public static ClippedInventory of(class_1263 inventory) {
        return of(inventory, 0, inventory.method_5439());
    }

    public static ClippedInventory of(class_1263 inventory, int start) {
        return of(inventory, start, inventory.method_5439());
    }

    public ClippedInventory(class_1263 inventory, int start, int end) {
        this.inventory = inventory;
        this.start = start;
        this.end = end;
    }

    @Override
    public int method_5439() {
        return end - start;
    }

    @Override
    public boolean method_5442() {
        for (int i = start; i < end; i++) {
            if (!inventory.method_5438(i).method_7960()) {
                return false;
            }
        }
        return true;
    }

    @Override
    public class_1799 method_5438(int slot) {
        return inventory.method_5438(start + slot);
    }

    @Override
    public class_1799 method_5434(int slot, int amount) {
        return inventory.method_5434(start + slot, amount);
    }

    @Override
    public class_1799 method_5441(int slot) {
        return inventory.method_5441(start + slot);
    }

    @Override
    public void method_5447(int slot, class_1799 stack) {
        inventory.method_5447(start + slot, stack);
    }

    @Override
    public void method_5431() {
        inventory.method_5431();
    }

    @Override
    public boolean method_5443(class_1657 player) {
        return inventory.method_5443(player);
    }

    @Override
    public void method_5448() {
        for (int i = start; i < end; i++) {
            inventory.method_5447(i, ItemStackUtil.empty());
        }
    }

    @Override
    public int method_5444() {
        return inventory.method_5444();
    }
}
