package net.pitan76.mcpitanlib.api.recipe.v3;

import net.minecraft.class_1860;
import net.minecraft.class_2960;
import net.minecraft.class_3956;
import net.pitan76.mcpitanlib.api.recipe.CompatibleRecipeEntry;
import net.pitan76.mcpitanlib.api.recipe.v2.CompatRecipeEntry;
import net.pitan76.mcpitanlib.api.util.CompatIdentifier;
import net.pitan76.mcpitanlib.midohra.recipe.entry.RecipeEntry;

public class CompatRecipe {
    public class_1860<?> recipe;
    public class_2960 id;

    public CompatRecipe(class_1860<?> recipe, class_2960 id) {
        this.recipe = recipe;
        this.id = id;
    }

    @Deprecated
    public CompatRecipe(class_1860<?> recipe) {
        this.recipe = recipe;
        this.id = recipe.method_8114();
    }

    public boolean isNull() {
        return recipe == null;
    }

    public class_1860<?> getRecipe() {
        return recipe;
    }

    public class_2960 getId() {
        return id;
    }

    public CompatIdentifier getCompatId() {
        return CompatIdentifier.fromMinecraft(getId());
    }

    public class_3956<?> getType() {
        class_1860<?> recipe = getRecipe();
        if (recipe == null) return null;

        return recipe.method_17716();
    }

    @Deprecated
    public CompatRecipeEntry<?> getRecipeEntry() {
        return new CompatRecipeEntry<>(getId(), "", null, getRecipe());
    }

    @Deprecated
    public CompatibleRecipeEntry getCompatibleRecipeEntry() {
        return new CompatibleRecipeEntry(getRecipe());
    }

    // MidohraAPI
    public net.pitan76.mcpitanlib.midohra.recipe.Recipe getMidohraRecipe() {
        if (getMidohraType() == net.pitan76.mcpitanlib.midohra.recipe.RecipeType.CRAFTING) {
            return net.pitan76.mcpitanlib.midohra.recipe.CraftingRecipe.of((net.minecraft.class_3955) getRecipe());
        }

        return net.pitan76.mcpitanlib.midohra.recipe.Recipe.of(getRecipe());
    }

    public net.pitan76.mcpitanlib.midohra.recipe.entry.RecipeEntry getMidohraRecipeEntry() {
        if (getMidohraType() == net.pitan76.mcpitanlib.midohra.recipe.RecipeType.CRAFTING) {
            return net.pitan76.mcpitanlib.midohra.recipe.entry.CraftingRecipeEntry.of((net.minecraft.class_3955) getRecipe(), getCompatId());
        }

        return RecipeEntry.of(getRecipe(), getCompatId());
    }

    public net.pitan76.mcpitanlib.midohra.recipe.RecipeType getMidohraType() {
        return net.pitan76.mcpitanlib.midohra.recipe.RecipeType.of(getType());
    }
}
