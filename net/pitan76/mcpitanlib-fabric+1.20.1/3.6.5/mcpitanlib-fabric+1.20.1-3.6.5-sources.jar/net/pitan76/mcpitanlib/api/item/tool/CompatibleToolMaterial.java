package net.pitan76.mcpitanlib.api.item.tool;

import net.minecraft.class_1792;
import net.minecraft.class_1832;
import net.minecraft.class_1856;
import net.minecraft.class_3489;
import net.minecraft.class_6862;
import net.pitan76.mcpitanlib.api.util.IngredientUtil;

public interface CompatibleToolMaterial {

    int getCompatMiningLevel();

    float getCompatAttackDamage();

    float getCompatMiningSpeedMultiplier();

    default class_1856 getCompatRepairIngredient() {
        return IngredientUtil.fromTagByIdentifier(getRepairTag().comp_327());
    }

    int getCompatDurability();

    int getCompatEnchantability();

    @Deprecated
    default float getAttackDamage() {
        return getCompatAttackDamage();
    }

    @Deprecated
    default float getMiningSpeedMultiplier() {
        return getCompatMiningSpeedMultiplier();
    }

    @Deprecated
    default class_1856 getRepairIngredient() {
        return getCompatRepairIngredient();
    }

    @Deprecated
    default int getDurability() {
        return getCompatDurability();
    }

    @Deprecated
    default int getEnchantability() {
        return getCompatEnchantability();
    }

    default class_6862<class_1792> getRepairTag() {
        return class_3489.field_28994;
    }

    default class_1832 build() {
        return new class_1832() {
            @Override
            public int method_8025() {
                return getCompatDurability();
            }

            @Override
            public float method_8027() {
                return getCompatMiningSpeedMultiplier();
            }

            @Override
            public float method_8028() {
                return getCompatAttackDamage();
            }

            @Override
            public int method_8024() {
                return getCompatMiningLevel();
            }

            @Override
            public int method_8026() {
                return getCompatEnchantability();
            }

            @Override
            public class_1856 method_8023() {
                return getCompatRepairIngredient();
            }
        };
    }
}