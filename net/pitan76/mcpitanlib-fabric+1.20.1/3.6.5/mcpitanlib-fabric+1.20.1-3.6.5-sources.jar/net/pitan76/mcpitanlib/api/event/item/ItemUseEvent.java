package net.pitan76.mcpitanlib.api.event.item;

import net.minecraft.class_1268;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.pitan76.mcpitanlib.api.entity.Player;
import net.pitan76.mcpitanlib.api.event.BaseEvent;
import net.pitan76.mcpitanlib.api.util.CompatActionResult;
import net.pitan76.mcpitanlib.api.util.StackActionResult;
import net.pitan76.mcpitanlib.midohra.block.BlockWrapper;
import net.pitan76.mcpitanlib.midohra.block.entity.BlockEntityWrapper;
import net.pitan76.mcpitanlib.midohra.item.ItemWrapper;
import net.pitan76.mcpitanlib.midohra.world.IWorldView;

public class ItemUseEvent extends BaseEvent {

    public class_1937 world;
    public Player user;
    public class_1268 hand;
    public class_1799 stack;

    public ItemUseEvent(class_1937 world, class_1657 user, class_1268 hand) {
        this.world = world;
        this.user = new Player(user);
        this.hand = hand;
        this.stack = user.method_5998(hand);
    }

    public class_1799 getStack() {
        return stack;
    }

    public net.pitan76.mcpitanlib.midohra.item.ItemStack getMidohraStack() {
        return net.pitan76.mcpitanlib.midohra.item.ItemStack.of(stack);
    }

    public class_1268 getHand() {
        return hand;
    }

    public class_1937 getWorld() {
        return world;
    }

    public Player getUser() {
        return user;
    }

    public boolean isClient() {
        return world.method_8608();
    }

    public StackActionResult success(class_1799 stack) {
        if (getStack() != stack)
            StackActionResult.success(stack);

        return success();
    }

    public StackActionResult success(net.pitan76.mcpitanlib.midohra.item.ItemStack stack) {
        return success(stack.toMinecraft());
    }

    public StackActionResult success() {
        return StackActionResult.create(CompatActionResult.SUCCESS, stack);
    }

    public StackActionResult fail() {
        return new StackActionResult(CompatActionResult.FAIL, stack);
    }

    public StackActionResult fail(net.pitan76.mcpitanlib.midohra.item.ItemStack stack) {
        return StackActionResult.fail(stack.toMinecraft());
    }

    public StackActionResult pass() {
        return new StackActionResult(CompatActionResult.PASS, stack);
    }

    public StackActionResult pass(net.pitan76.mcpitanlib.midohra.item.ItemStack stack) {
        return StackActionResult.pass(stack.toMinecraft());
    }

    public StackActionResult consume(class_1799 stack) {
        if (getStack() != stack)
            StackActionResult.consume(stack);

        return consume();
    }

    public CompatActionResult consume(net.pitan76.mcpitanlib.midohra.item.ItemStack stack) {
        return consume(stack.toMinecraft());
    }

    public StackActionResult consume() {
        return StackActionResult.create(CompatActionResult.CONSUME, stack);
    }

    public boolean isSneaking() {
        return user.isSneaking();
    }

    public net.pitan76.mcpitanlib.midohra.world.World getMidohraWorld() {
        return net.pitan76.mcpitanlib.midohra.world.World.of(world);
    }

    public IWorldView getWorldView() {
        return getMidohraWorld();
    }

    public net.pitan76.mcpitanlib.midohra.item.ItemStack getStackM() {
        return net.pitan76.mcpitanlib.midohra.item.ItemStack.of(getStack());
    }

    public class_1792 getItem() {
        return stack.method_7909();
    }

    public ItemWrapper getItemWrapper() {
        return ItemWrapper.of(getItem());
    }
}
