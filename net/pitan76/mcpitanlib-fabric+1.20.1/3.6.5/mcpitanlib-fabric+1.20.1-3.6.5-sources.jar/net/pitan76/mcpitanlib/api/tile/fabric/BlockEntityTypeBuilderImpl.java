package net.pitan76.mcpitanlib.api.tile.fabric;

import com.mojang.datafixers.types.Type;
import net.fabricmc.fabric.api.object.builder.v1.block.entity.FabricBlockEntityTypeBuilder;
import net.minecraft.class_2248;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.pitan76.mcpitanlib.api.tile.BlockEntityTypeBuilder;

public class BlockEntityTypeBuilderImpl {
    @Deprecated
    public static <T extends class_2586> class_2591<T> build(Type<?> type, BlockEntityTypeBuilder.Factory<? extends T> factory, class_2248... blocks) {
        FabricBlockEntityTypeBuilder<T> builder = FabricBlockEntityTypeBuilder.create(factory::create, blocks);
        return builder.build(type);
    }
}
