package net.pitan76.mcpitanlib.api.event.nbt;

import net.minecraft.class_2487;
import net.minecraft.class_7225;
import net.pitan76.mcpitanlib.api.registry.CompatRegistryLookup;

public class NbtRWArgs {
    public class_2487 nbt;
    public CompatRegistryLookup registryLookup;

    public NbtRWArgs(class_2487 nbt, CompatRegistryLookup registryLookup) {
        this.nbt = nbt;
        this.registryLookup = registryLookup;
    }

    @Deprecated
    public NbtRWArgs(class_2487 nbt, class_7225.class_7874 wrapperLookup) {
        this(nbt, new CompatRegistryLookup(wrapperLookup));
    }

    public NbtRWArgs(class_2487 nbt) {
        this(nbt, (CompatRegistryLookup) null);
    }

    public class_2487 getNbt() {
        return nbt;
    }

    public CompatRegistryLookup getRegistryLookup() {
        return registryLookup;
    }

    public boolean hasRegistryLookup() {
        return registryLookup != null;
    }

    @Deprecated
    public class_7225.class_7874 getWrapperLookup() {
        if (registryLookup == null)
            registryLookup = new CompatRegistryLookup();

        return registryLookup.getRegistryLookup();
    }

    public boolean isNbtEmpty() {
        return nbt != null && !nbt.method_33133();
    }

    public boolean isViewEmpty() {
        return false;
    }

    public boolean isEmpty() {
        return isNbtEmpty() || isViewEmpty();
    }

    public NbtRWArgs copy() {
        return new NbtRWArgs(nbt.method_10553(), registryLookup);
    }

    public net.pitan76.mcpitanlib.midohra.nbt.NbtCompound getNbtM() {
        return net.pitan76.mcpitanlib.midohra.nbt.NbtCompound.of(nbt);
    }
}
