package net.pitan76.mcpitanlib.api.event.item;

import net.minecraft.class_1309;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.pitan76.mcpitanlib.api.event.BaseEvent;
import net.pitan76.mcpitanlib.midohra.item.ItemWrapper;

public class ItemFinishUsingEvent extends BaseEvent {
    public class_1799 stack;
    public class_1937 world;
    public class_1309 user;

    public ItemFinishUsingEvent(class_1799 stack, class_1937 world, class_1309 user) {
        this.stack = stack;
        this.world = world;
        this.user = user;
    }

    public class_1799 getStack() {
        return stack;
    }

    public class_1937 getWorld() {
        return world;
    }

    public class_1309 getUser() {
        return user;
    }

    public boolean isClient() {
        return world.method_8608();
    }

    public net.pitan76.mcpitanlib.midohra.item.ItemStack getStackM() {
        return net.pitan76.mcpitanlib.midohra.item.ItemStack.of(stack);
    }

    public net.pitan76.mcpitanlib.midohra.world.World getWorldM() {
        return net.pitan76.mcpitanlib.midohra.world.World.of(world);
    }

    public class_1792 getItem() {
        return stack.method_7909();
    }

    public ItemWrapper getItemWrapper() {
        return ItemWrapper.of(getItem());
    }
}
