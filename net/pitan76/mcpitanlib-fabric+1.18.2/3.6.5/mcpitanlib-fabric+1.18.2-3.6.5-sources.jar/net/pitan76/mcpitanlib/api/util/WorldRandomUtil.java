package net.pitan76.mcpitanlib.api.util;

import net.minecraft.class_1937;

public class WorldRandomUtil {
    public static int nextInt(class_1937 world) {
        return world.method_8409().nextInt();
    }

    public static int nextInt(class_1937 world, int bound) {
        return world.method_8409().nextInt(bound);
    }

    public static long nextLong(class_1937 world) {
        return world.method_8409().nextLong();
    }

    public static double nextDouble(class_1937 world) {
        return world.method_8409().nextDouble();
    }

    public static double nextGaussian(class_1937 world) {
        return world.method_8409().nextGaussian();
    }

    public static float nextFloat(class_1937 world) {
        return world.method_8409().nextFloat();
    }

    public static int nextBetween(class_1937 world, int min, int max) {
        return nextInt(world, max - min + 1) + min;
    }

    public static int nextBetweenExclusive(class_1937 world, int min, int max) {
        if (min >= max) {
            throw new IllegalArgumentException("bound - origin is non positive");
        } else {
            return min + nextInt(world, max - min);
        }
    }
}
