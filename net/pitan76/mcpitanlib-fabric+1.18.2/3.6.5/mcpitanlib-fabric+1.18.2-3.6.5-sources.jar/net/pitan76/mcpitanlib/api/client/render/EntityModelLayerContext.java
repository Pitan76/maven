package net.pitan76.mcpitanlib.api.client.render;

import net.minecraft.class_5609;

public class EntityModelLayerContext {
    private final class_5609 data;
    private final int width;
    private final int height;

    public EntityModelLayerContext(class_5609 data, int width, int height) {
        this.data = data;
        this.width = width;
        this.height = height;
    }

    public int getHeight() {
        return height;
    }

    public int getWidth() {
        return width;
    }

    public class_5609 getData() {
        return data;
    }
}
