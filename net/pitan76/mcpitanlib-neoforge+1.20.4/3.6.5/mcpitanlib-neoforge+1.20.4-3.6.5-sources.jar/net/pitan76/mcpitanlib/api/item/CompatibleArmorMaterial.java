package net.pitan76.mcpitanlib.api.item;

import java.util.EnumMap;
import java.util.List;
import java.util.function.Supplier;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.ArmorMaterial;
import net.minecraft.world.item.crafting.Ingredient;

public interface CompatibleArmorMaterial {
    int getDurability(ArmorEquipmentType type);

    int getProtection(ArmorEquipmentType type);

    int getEnchantability();

    SoundEvent getEquipSound();

    Ingredient getRepairIngredient();

    /**
     * @return the name of the material
     */
    default String getName() {
        return getId().getPath();
    }

    /**
     * @return the id of the material
     */
    ResourceLocation getId();

    float getToughness();

    float getKnockbackResistance();

    @Deprecated
    default ArmorMaterial build() {
        return new ArmorMaterial() {
            @Override
            public int getDurabilityForType(ArmorItem.Type type) {
                return CompatibleArmorMaterial.this.getDurability(ArmorEquipmentType.of(type));
            }

            @Override
            public int getDefenseForType(ArmorItem.Type type) {
                return CompatibleArmorMaterial.this.getProtection(ArmorEquipmentType.of(type));
            }

            @Override
            public int getEnchantmentValue() {
                return CompatibleArmorMaterial.this.getEnchantability();
            }

            @Override
            public SoundEvent getEquipSound() {
                return CompatibleArmorMaterial.this.getEquipSound();
            }

            @Override
            public Ingredient getRepairIngredient() {
                return CompatibleArmorMaterial.this.getRepairIngredient();
            }

            @Override
            public String getName() {
                return CompatibleArmorMaterial.this.getName();
            }

            @Override
            public float getToughness() {
                return CompatibleArmorMaterial.this.getToughness();
            }

            @Override
            public float getKnockbackResistance() {
                return CompatibleArmorMaterial.this.getKnockbackResistance();
            }
        };
    }
}
