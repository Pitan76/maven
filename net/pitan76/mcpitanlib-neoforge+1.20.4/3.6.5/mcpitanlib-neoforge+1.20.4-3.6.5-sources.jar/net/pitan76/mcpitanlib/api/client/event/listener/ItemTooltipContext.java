package net.pitan76.mcpitanlib.api.client.event.listener;

import net.minecraft.network.chat.Component;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.pitan76.mcpitanlib.api.text.TextComponent;
import net.pitan76.mcpitanlib.api.util.TextUtil;

import java.util.List;

public class ItemTooltipContext {

    public ItemStack stack;
    public List<Component> texts;
    public TooltipFlag tooltipContext;

    public ItemTooltipContext(ItemStack stack, List<Component> texts, TooltipFlag tooltipContext) {
        this.stack = stack;
        this.texts = texts;
        this.tooltipContext = tooltipContext;
    }

    public ItemStack getStack() {
        return stack;
    }

    public List<Component> getTexts() {
        return texts;
    }

    public TooltipFlag getTooltipContext() {
        return tooltipContext;
    }

    public void addTooltip(Component text) {
        texts.add(text);
    }

    public void addTooltip(List<Component> texts) {
        this.texts.addAll(texts);
    }

    public boolean isAdvanced() {
        return tooltipContext.isAdvanced();
    }

    public boolean isCreative() {
        return tooltipContext.isCreative();
    }

    public void addTooltip(TextComponent textComponent) {
        addTooltip(textComponent.getText());
    }

    public void addTooltip(String text) {
        addTooltip(TextUtil.literal(text));
    }
}
