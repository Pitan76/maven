package net.pitan76.mcpitanlib.api.util.recipe.input;

import net.minecraft.world.entity.player.StackedContents;
import net.minecraft.world.inventory.TransientCraftingContainer;
import net.minecraft.world.item.ItemStack;
import net.pitan76.mcpitanlib.api.recipe.input.CompatRecipeInput;
import net.pitan76.mcpitanlib.api.util.ItemStackUtil;
import net.pitan76.mcpitanlib.api.util.collection.ItemStackList;

import java.util.List;
import java.util.Optional;

public class CraftingRecipeInputUtil {
    public static Optional<TransientCraftingContainer> get(CompatRecipeInput<?> input) {
        if (input.getInput() instanceof TransientCraftingContainer) {
            return Optional.of((TransientCraftingContainer) input.getInput());
        }
        return Optional.empty();
    }

    public static CompatRecipeInput<?> create(TransientCraftingContainer input) {
        return new CompatRecipeInput<>(input);
    }

    public static CompatRecipeInput<?> create(int width, int height, List<ItemStack> stacks) {
        ItemStackList stackList = ItemStackList.ofSize(stacks.size(), ItemStackUtil.empty());
        for (int i = 0; i < stacks.size(); i++) {
            stackList.set(i, stacks.get(i));
        }

        return new CompatRecipeInput<>(new TransientCraftingContainer(null, width, height, stackList));
    }

    public static ItemStack getStack(TransientCraftingContainer input, int x, int y) {
        return input.getItem(x + y * input.getWidth());
    }

    public static ItemStack getStack(CompatRecipeInput<?> input, int x, int y) {
        Optional<TransientCraftingContainer> recipeInput = get(input);
        if (!recipeInput.isPresent()) return ItemStackUtil.empty();

        return getStack(recipeInput.get(), x, y);
    }

    public static net.pitan76.mcpitanlib.midohra.item.ItemStack getMidohraStack(CompatRecipeInput<?> input, int x, int y) {
        return net.pitan76.mcpitanlib.midohra.item.ItemStack.of(getStack(input, x, y));
    }

    public static StackedContents getRecipeMatcher(TransientCraftingContainer input) {
        return null;
    }

    public static StackedContents getRecipeMatcher(CompatRecipeInput<?> input) {
        Optional<TransientCraftingContainer> recipeInput = get(input);
        if (!recipeInput.isPresent()) return null;

        return getRecipeMatcher(recipeInput.get());
    }

    public static List<ItemStack> getStacks(TransientCraftingContainer input) {
        return input.getItems();
    }

    public static List<ItemStack> getStacks(CompatRecipeInput<?> input) {
        Optional<TransientCraftingContainer> recipeInput = get(input);
        if (!recipeInput.isPresent()) return null;

        return getStacks(recipeInput.get());
    }

    public static int getWidth(TransientCraftingContainer input) {
        return input.getWidth();
    }

    public static int getWidth(CompatRecipeInput<?> input) {
        Optional<TransientCraftingContainer> recipeInput = get(input);
        if (!recipeInput.isPresent()) return -1;

        return getWidth(recipeInput.get());
    }

    public static int getHeight(TransientCraftingContainer input) {
        return input.getHeight();
    }

    public static int getHeight(CompatRecipeInput<?> input) {
        Optional<TransientCraftingContainer> recipeInput = get(input);
        if (!recipeInput.isPresent()) return -1;

        return getHeight(recipeInput.get());
    }

    public static int getStackCount(TransientCraftingContainer input) {
        return input.getItems().size();
    }

    public static int getStackCount(CompatRecipeInput<?> input) {
        Optional<TransientCraftingContainer> recipeInput = get(input);
        if (!recipeInput.isPresent()) return -1;

        return getStackCount(recipeInput.get());
    }
}
