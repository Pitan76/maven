package net.pitan76.mcpitanlib.api.item.consume;

import net.minecraft.world.item.UseAnim;
import net.pitan76.mcpitanlib.api.util.CompatStringIdentifiable;

public class CompatUseAction implements CompatStringIdentifiable {
    private final UseAnim useAction;

    public static final CompatUseAction NONE = of(UseAnim.NONE);
    public static final CompatUseAction EAT = of(UseAnim.EAT);
    public static final CompatUseAction DRINK = of(UseAnim.DRINK);
    public static final CompatUseAction BLOCK = of(UseAnim.BLOCK);
    public static final CompatUseAction BOW = of(UseAnim.BOW);
    public static final CompatUseAction SPEAR = of(UseAnim.SPEAR);
    public static final CompatUseAction CROSSBOW = of(UseAnim.CROSSBOW);
    public static final CompatUseAction SPYGLASS = of(UseAnim.SPYGLASS);
    public static final CompatUseAction TOOT_HORN = of(UseAnim.TOOT_HORN);
    public static final CompatUseAction BRUSH = of(UseAnim.BRUSH);

    public CompatUseAction(UseAnim useAction) {
        this.useAction = useAction;
    }

    public static CompatUseAction of(UseAnim useAction) {
        return new CompatUseAction(useAction);
    }

    @Deprecated
    public UseAnim getUseAction() {
        return useAction;
    }

    public int getId() {
        return -1;
    }

    public String getName() {
        return useAction.name();
    }

    @Override
    public String asString_compat() {
        return getName();
    }
}
