package net.pitan76.mcpitanlib.api.event.block;

import net.minecraft.core.BlockPos;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.material.FluidState;
import net.minecraft.world.level.pathfinder.PathComputationType;
import net.pitan76.mcpitanlib.api.event.BaseEvent;
import net.pitan76.mcpitanlib.api.util.FluidStateUtil;

public class CanPathfindThroughArgs extends BaseEvent {
    public BlockState state;
    private BlockGetter blockView;
    private BlockPos pos;
    public PathComputationType type;

    public CanPathfindThroughArgs(BlockState state, BlockGetter blockView, BlockPos pos, PathComputationType type) {
        this.state = state;
        this.blockView = blockView;
        this.pos = pos;
        this.type = type;
    }

    public BlockState getState() {
        return state;
    }

    public PathComputationType getType() {
        return type;
    }

    public FluidState getFluidState() {
        return state.getFluidState();
    }

    public boolean isWaterNavigationType() {
        return type == PathComputationType.WATER;
    }

    public boolean isAirNavigationType() {
        return type == PathComputationType.AIR;
    }

    public boolean isLandNavigationType() {
        return type == PathComputationType.LAND;
    }

    public boolean isWaterState() {
        return FluidStateUtil.isWater(getFluidState());
    }

    public boolean isLavaState() {
        return FluidStateUtil.isLava(getFluidState());
    }

    @Deprecated(forRemoval = true)
    public BlockPos getPos() {
        return pos;
    }

    @Deprecated(forRemoval = true)
    public BlockGetter getBlockView() {
        return blockView;
    }
}
