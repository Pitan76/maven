package net.pitan76.mcpitanlib.api.entity;

import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;
import net.pitan76.mcpitanlib.api.event.entity.InitDataTrackerArgs;
import net.pitan76.mcpitanlib.api.event.nbt.ReadNbtArgs;
import net.pitan76.mcpitanlib.api.event.nbt.WriteNbtArgs;
import net.pitan76.mcpitanlib.midohra.util.math.Vector3d;

public class CompatEntity extends Entity {
    public CompatEntity(EntityType<?> type, Level world) {
        super(type, world);
    }

    @Deprecated
    @Override
    public void defineSynchedData() {
        initDataTracker(new InitDataTrackerArgs(entityData));
    }

    public void initDataTracker(InitDataTrackerArgs args) {

    }

    public void readCustomDataFromNbt(ReadNbtArgs nbt) {

    }

    public void writeCustomDataToNbt(WriteNbtArgs nbt) {

    }

    @Deprecated
    @Override
    public void readAdditionalSaveData(CompoundTag nbt) {
        readCustomDataFromNbt(new ReadNbtArgs(nbt));
    }

    @Deprecated
    @Override
    public void addAdditionalSaveData(CompoundTag nbt) {
        writeCustomDataToNbt(new WriteNbtArgs(nbt));
    }

    public Packet<ClientGamePacketListener> getAddEntityPacket() {
        return null;
    }

    public void writeNbt(WriteNbtArgs args) {
        super.saveWithoutId(args.getNbt());
    }

    public void readNbt(ReadNbtArgs args) {
        super.load(args.getNbt());
    }

    @Deprecated
    @Override
    public CompoundTag saveWithoutId(CompoundTag nbt) {
        writeNbt(new WriteNbtArgs(nbt));
        return nbt;
    }

    @Deprecated
    @Override
    public void load(CompoundTag nbt) {
        readNbt(new ReadNbtArgs(nbt));
    }

    @Deprecated
    @Override
    public Level level() {
        return callGetWorld();
    }

    public Level callGetWorld() {
        return super.level();
    }

    public BlockPos callGetBlockPos() {
        return blockPosition();
    }

    public Vec3 callGetPos() {
        return position();
    }

    public boolean hasServerWorld() {
        return callGetWorld() instanceof ServerLevel;
    }

    public ServerLevel getServerWorld() {
        return (ServerLevel) level();
    }

    public net.pitan76.mcpitanlib.midohra.world.World getMidohraWorld() {
        return net.pitan76.mcpitanlib.midohra.world.World.of(callGetWorld());
    }

    public net.pitan76.mcpitanlib.midohra.util.math.BlockPos getMidohraBlockPos() {
        return net.pitan76.mcpitanlib.midohra.util.math.BlockPos.of(callGetBlockPos());
    }

     public Vector3d getMidohraPos() {
        return Vector3d.of(callGetPos());
     }

     public net.pitan76.mcpitanlib.midohra.world.ServerWorld getMidohraServerWorld() {
         return net.pitan76.mcpitanlib.midohra.world.ServerWorld.of(getServerWorld());
     }
}