package net.pitan76.mcpitanlib.api.event.block;

import net.minecraft.core.BlockPos;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.pitan76.mcpitanlib.api.event.BaseEvent;
import net.pitan76.mcpitanlib.api.util.WorldUtil;
import net.pitan76.mcpitanlib.midohra.block.entity.BlockEntityWrapper;

public class NeighborUpdateEvent extends BaseEvent {
    public BlockState state;
    public Level world;
    public BlockPos pos;
    public Block sourceBlock;
    public BlockPos sourcePos;
    public boolean notify;

    public NeighborUpdateEvent(BlockState state, Level world, BlockPos pos, Block sourceBlock, BlockPos sourcePos, boolean notify) {
        this.state = state;
        this.world = world;
        this.pos = pos;
        this.sourceBlock = sourceBlock;
        this.sourcePos = sourcePos;
        this.notify = notify;
    }

    public BlockState getState() {
        return state;
    }

    public Level getWorld() {
        return world;
    }

    public BlockPos getPos() {
        return pos;
    }

    public Block getSourceBlock() {
        return sourceBlock;
    }

    public BlockPos getSourcePos() {
        return sourcePos;
    }

    public boolean isNotify() {
        return notify;
    }

    public boolean isReceivingRedstonePower() {
        return WorldUtil.isReceivingRedstonePower(world, pos);
    }

    public BlockEntity getBlockEntity() {
        return WorldUtil.getBlockEntity(world, pos);
    }

    public boolean hasBlockEntity() {
        return WorldUtil.hasBlockEntity(world, pos);
    }

    public net.pitan76.mcpitanlib.midohra.world.World getMidohraWorld() {
        return net.pitan76.mcpitanlib.midohra.world.World.of(world);
    }

    public net.pitan76.mcpitanlib.midohra.util.math.BlockPos getMidohraPos() {
        return net.pitan76.mcpitanlib.midohra.util.math.BlockPos.of(pos);
    }

    public net.pitan76.mcpitanlib.midohra.block.BlockState getMidohraState() {
        return net.pitan76.mcpitanlib.midohra.block.BlockState.of(state);
    }

    public BlockEntityWrapper getBlockEntityWrapper() {
        return BlockEntityWrapper.of(getBlockEntity());
    }
}
