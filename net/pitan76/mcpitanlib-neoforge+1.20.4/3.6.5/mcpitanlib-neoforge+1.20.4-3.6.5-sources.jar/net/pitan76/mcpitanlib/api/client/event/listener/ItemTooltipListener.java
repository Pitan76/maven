package net.pitan76.mcpitanlib.api.client.event.listener;

import java.util.List;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;

@FunctionalInterface
public interface ItemTooltipListener {
    void onTooltip(ItemTooltipContext context);

    default void onTooltip(ItemStack stack, List<Component> texts, TooltipFlag tooltipContext) {
        onTooltip(new ItemTooltipContext(stack, texts, tooltipContext));
    }
}