package net.pitan76.mcpitanlib.api.network;

import dev.architectury.networking.NetworkManager;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.resources.ResourceLocation;

import static dev.architectury.networking.NetworkManager.Side.S2C;

public class ClientNetworking {
    public static void send(ResourceLocation identifier, FriendlyByteBuf buf) {
        NetworkManager.sendToServer(identifier, buf);
    }

    public static void registerReceiver(ResourceLocation identifier, ClientNetworkHandler handler) {
        NetworkManager.registerReceiver(S2C, identifier, ((buf, context) -> handler.receive(Minecraft.getInstance(), Minecraft.getInstance().player, buf)));
    }

    @FunctionalInterface
    public interface ClientNetworkHandler {
        void receive(Minecraft client, LocalPlayer player, FriendlyByteBuf buf);
    }
}
