package net.pitan76.mcpitanlib.api.item.v3;

import net.minecraft.world.item.Tier;
import net.minecraft.world.item.Tiers;
import net.pitan76.mcpitanlib.api.tag.item.RepairIngredientTag;

public class VanillaCompatToolMaterial implements CompatToolMaterial {
    private final Tier material;

    public static final VanillaCompatToolMaterial WOOD = of(Tiers.WOOD);
    public static final VanillaCompatToolMaterial STONE = of(Tiers.STONE);
    public static final VanillaCompatToolMaterial IRON = of(Tiers.IRON);
    public static final VanillaCompatToolMaterial GOLD = of(Tiers.GOLD);
    public static final VanillaCompatToolMaterial DIAMOND = of(Tiers.DIAMOND);
    public static final VanillaCompatToolMaterial NETHERITE = of(Tiers.NETHERITE);

    protected VanillaCompatToolMaterial(Tier material) {
        this.material = material;
    }

    private static VanillaCompatToolMaterial of(Tier material) {
        return new VanillaCompatToolMaterial(material);
    }

    @Override
    public RepairIngredientTag getRepairIngredientTag() {
        if (material == Tiers.STONE) return RepairIngredientTag.STONE_TOOL_MATERIALS;
        if (material == Tiers.IRON) return RepairIngredientTag.IRON_TOOL_MATERIALS;
        if (material == Tiers.GOLD) return RepairIngredientTag.GOLDEN_TOOL_MATERIALS;
        if (material == Tiers.DIAMOND) return RepairIngredientTag.DIAMOND_TOOL_MATERIALS;
        if (material == Tiers.NETHERITE) return RepairIngredientTag.NETHERITE_TOOL_MATERIALS;
        return RepairIngredientTag.WOODEN_TOOL_MATERIALS;
    }

    @Override
    public int getCompatDurability() {
        return material.getUses();
    }

    @Override
    public float getCompatMiningSpeedMultiplier() {
        return material.getSpeed();
    }

    @Override
    public float getCompatAttackDamage() {
        return material.getAttackDamageBonus();
    }

    @Override
    public int getCompatMiningLevel() {
        return material.getLevel();
    }

    @Override
    public int getCompatEnchantability() {
        return material.getEnchantmentValue();
    }

    @Deprecated
    public Tier toMinecraft() {
        return material;
    }

    @Override
    public Tier build() {
        return material;
    }
}
