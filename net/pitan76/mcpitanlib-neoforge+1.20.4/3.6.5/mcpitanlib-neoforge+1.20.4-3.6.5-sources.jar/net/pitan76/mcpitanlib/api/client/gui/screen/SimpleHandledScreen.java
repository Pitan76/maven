package net.pitan76.mcpitanlib.api.client.gui.screen;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Renderable;
import net.minecraft.client.gui.components.events.GuiEventListener;
import net.minecraft.client.gui.narration.NarratableEntry;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.client.renderer.entity.ItemRenderer;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.pitan76.mcpitanlib.api.client.gui.widget.CompatibleTexturedButtonWidget;
import net.pitan76.mcpitanlib.api.client.render.DrawObjectDM;
import net.pitan76.mcpitanlib.api.client.render.handledscreen.*;
import net.pitan76.mcpitanlib.api.client.render.screen.RenderBackgroundTextureArgs;
import net.pitan76.mcpitanlib.api.text.TextComponent;
import net.pitan76.mcpitanlib.api.util.CompatIdentifier;
import net.pitan76.mcpitanlib.api.util.IdentifierUtil;
import net.pitan76.mcpitanlib.api.util.client.ClientUtil;
import net.pitan76.mcpitanlib.api.util.client.RenderUtil;
import net.pitan76.mcpitanlib.api.util.client.ScreenUtil;
import net.pitan76.mcpitanlib.core.datafixer.Pair;

public abstract class SimpleHandledScreen<S extends AbstractContainerMenu> extends AbstractContainerScreen<S> {

    public int width, height, imageWidth, imageHeight, leftPos, topPos;
    public S menu;
    public Font font;
    public ItemRenderer itemRenderer;

    public Component title;
    public Minecraft minecraft;
    public SimpleHandledScreen(S handler, Inventory inventory, Component title) {
        super(handler, inventory, title);
        fixScreen();
        this.menu = handler;
        this.title = title;

    }

    @Deprecated
    @Override
    public S getMenu() {
        return getScreenHandlerOverride();
    }

    public S getScreenHandlerOverride() {
        return super.getMenu();
    }

    public <T extends GuiEventListener & Renderable & NarratableEntry> T addDrawableChild_compatibility(T drawableElement) {
        return super.addRenderableWidget(drawableElement);
        // addButton
    }

    public <T extends GuiEventListener & NarratableEntry> T addSelectableChild_compatibility(T selectableElement) {
        return super.addWidget(selectableElement);
    }

    public CompatibleTexturedButtonWidget addDrawableCTBW(CompatibleTexturedButtonWidget widget) {
        return addDrawableChild_compatibility(widget);
    }

    @Deprecated
    @Override
    protected void renderBg(GuiGraphics context, float delta, int mouseX, int mouseY) {
        DrawObjectDM drawObjectDM = new DrawObjectDM(context, this);
        drawBackgroundOverride(new DrawBackgroundArgs(drawObjectDM, delta, mouseX, mouseY));
    }

    public abstract void drawBackgroundOverride(DrawBackgroundArgs args);

    @Deprecated
    @Override
    protected void renderLabels(GuiGraphics context, int mouseX, int mouseY) {
        DrawObjectDM drawObjectDM = new DrawObjectDM(context, this);
        drawForegroundOverride(new DrawForegroundArgs(drawObjectDM, mouseX, mouseY));
    }

    protected void drawForegroundOverride(DrawForegroundArgs args) {
        super.renderLabels(args.drawObjectDM.getContext(), args.mouseX, args.mouseY);
    }

    public void callDrawTexture(DrawObjectDM drawObjectDM, ResourceLocation texture, int x, int y, int u, int v, int width, int height) {
        //ScreenUtil.setBackground(GUI);
        //super.drawTexture(matrices, x, y, u, v, width, height);
        drawObjectDM.getContext().blit(texture, x, y, u, v, width, height);
    }

    public void callDrawTexture(DrawObjectDM drawObjectDM, CompatIdentifier texture, int x, int y, int u, int v, int width, int height) {
        callDrawTexture(drawObjectDM, texture.toMinecraft(), x, y, u, v, width, height);
    }

    @Deprecated
    public void callRenderBackground(DrawObjectDM drawObjectDM) {
        callRenderBackground(new RenderArgs(drawObjectDM, 0, 0, 0));
    }


    public void callRenderBackground(RenderArgs args) {
        super.renderBackground(args.drawObjectDM.getContext(), args.mouseX, args.mouseY, args.delta);
    }

    public void callDrawMouseoverTooltip(DrawMouseoverTooltipArgs args) {
        super.renderTooltip(args.drawObjectDM.getContext(), args.mouseX, args.mouseY);
    }

    public void renderOverride(RenderArgs args) {
        super.render(args.drawObjectDM.getContext(), args.mouseX, args.mouseY, args.delta);
    }

    public void resizeOverride(Minecraft client, int width, int height) {
    }

    public void initOverride() {
    }

    @Deprecated
    @Override
    protected void init() {
        super.init();
        fixScreen();
        initOverride();
    }

    @Deprecated
    @Override
    public void resize(Minecraft client, int width, int height) {
        super.resize(client, width, height);
        fixScreen();
        resizeOverride(client, width, height);
    }

    public void fixScreen() {
        this.imageWidth = getBackgroundWidth();
        this.imageHeight = getBackgroundHeight();
        this.leftPos = super.leftPos; //(this.width - this.backgroundWidth) / 2;
        this.topPos = super.topPos; //(this.height - this.backgroundHeight) / 2;
        this.font = super.font;
        this.itemRenderer = Minecraft.getInstance().getItemRenderer();
        this.width = super.width;
        this.height = super.height;
        if (super.minecraft == null)
            this.minecraft = Minecraft.getInstance();
        else
            this.minecraft = super.minecraft;
    }

    public void setX(int x) {
        this.leftPos = x;
        super.leftPos = x;
    }

    public void setY(int y) {
        this.topPos = y;
        super.topPos = y;
    }

    public void setTextRenderer(Font textRenderer) {
        this.font = textRenderer;
        super.font = textRenderer;
    }

    public void setItemRenderer(ItemRenderer itemRenderer) {
        this.itemRenderer = itemRenderer;
    }

    public void setWidth(int width) {
        this.width = width;
        super.width = width;
    }

    public void setBackgroundWidth(int backgroundWidth) {
        this.imageWidth = backgroundWidth;
        super.imageWidth = backgroundWidth;
    }

    public void setBackgroundHeight(int backgroundHeight) {
        this.imageHeight = backgroundHeight;
        super.imageHeight = backgroundHeight;
    }

    public void setHeight(int height) {
        this.height = height;
        super.height = height;
    }

    public int getBackgroundWidth() {
        return super.imageWidth;
    }

    public int getBackgroundHeight() {
        return super.imageHeight;
    }

    @Deprecated
    @Override
    public void render(GuiGraphics context, int mouseX, int mouseY, float delta) {
        DrawObjectDM drawObjectDM = new DrawObjectDM(context, this);
        renderOverride(new RenderArgs(drawObjectDM, mouseX, mouseY, delta));
    }

    public boolean keyReleased(KeyEventArgs args) {
        return super.keyReleased(args.keyCode, args.scanCode, args.modifiers);
    }

    public boolean keyPressed(KeyEventArgs args) {
        return super.keyPressed(args.keyCode, args.scanCode, args.modifiers);
    }

    public void renderBackgroundTexture(RenderBackgroundTextureArgs args) {
        if (getBackgroundTexture() == null) {
            super.renderDirtBackground(args.drawObjectDM.getContext());
            return;
        }

        RenderUtil.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
        callDrawTexture(args.drawObjectDM, getBackgroundTexture(), 0, 0, 0, 0, width, height);
    }

    @Deprecated
    @Override
    public boolean keyReleased(int keyCode, int scanCode, int modifiers) {
        return this.keyReleased(new KeyEventArgs(keyCode, scanCode, modifiers));
    }

    @Deprecated
    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        return this.keyPressed(new KeyEventArgs(keyCode, scanCode, modifiers));
    }

    @Deprecated
    @Override
    public void renderDirtBackground(GuiGraphics context) {
        this.renderBackgroundTexture(new RenderBackgroundTextureArgs(new DrawObjectDM(context, this), 0));
    }

    public void closeOverride() {
        super.onClose();
    }

    public void removedOverride() {
        super.removed();
    }

    @Override
    public void onClose() {
        closeOverride();
    }

    @Override
    public void removed() {
        removedOverride();
    }

    public ResourceLocation getBackgroundTexture() {
        return IdentifierUtil.from(getCompatBackgroundTexture());
    }

    public CompatIdentifier getCompatBackgroundTexture() {
        return null;
    }

    public void setTitleX(int x) {
        this.titleLabelX = x;
    }

    public void setTitleY(int y) {
        this.titleLabelY = y;
    }

    public void setTitlePos(int x, int y) {
        setTitleX(x);
        setTitleY(y);
    }

    public void setTitleXCenter() {
        if (font == null)
            font = ClientUtil.getTextRenderer();

        setTitleX(imageWidth / 2 - font.width(title) / 2);
    }

    public int getTitleX() {
        return titleLabelX;
    }

    public int getTitleY() {
        return titleLabelY;
    }

    public void drawText(DrawObjectDM drawObjectDM, Component text, int x, int y, int color) {
        ScreenUtil.RendererUtil.drawText(font, drawObjectDM, text, x, y, color);
    }

    public void drawText(DrawObjectDM drawObjectDM, TextComponent text, int x, int y, int color) {
        ScreenUtil.RendererUtil.drawText(font, drawObjectDM, text, x, y, color);
    }

    public void drawText(DrawObjectDM drawObjectDM, Component text, int x, int y) {
        ScreenUtil.RendererUtil.drawText(font, drawObjectDM, text, x, y);
    }

    public void drawText(DrawObjectDM drawObjectDM, TextComponent text, int x, int y) {
        ScreenUtil.RendererUtil.drawText(font, drawObjectDM, text, x, y);
    }

    @Deprecated
    @Override
    public Component getTitle() {
        return callGetTitle();
    }

    public Component callGetTitle() {
        return super.getTitle();
    }

    public Pair<Integer, Integer> getTitlePosP() {
        return new Pair<>(getTitleX(), getTitleY());
    }

    public int getPlayerInvTitleX() {
        return inventoryLabelX;
    }

    public int getPlayerInvTitleY() {
        return inventoryLabelY;
    }

    public void setPlayerInvTitleX(int x) {
        inventoryLabelX = x;
    }

    public void setPlayerInvTitleY(int y) {
        inventoryLabelY = y;
    }

    public void setPlayerInvTitle(int x, int y) {
        setPlayerInvTitleX(x);
        setPlayerInvTitleY(y);
    }

    public Font callGetTextRenderer() {
        if (font != null)
            return font;

        if (super.font != null)
            return super.font;

        return ClientUtil.getTextRenderer();
    }

    public ItemRenderer callGetItemRenderer() {
        if (itemRenderer != null)
            return itemRenderer;

        return ClientUtil.getItemRenderer();
    }

    public Component getPlayerInvTitle() {
        return playerInventoryTitle;
    }
}
