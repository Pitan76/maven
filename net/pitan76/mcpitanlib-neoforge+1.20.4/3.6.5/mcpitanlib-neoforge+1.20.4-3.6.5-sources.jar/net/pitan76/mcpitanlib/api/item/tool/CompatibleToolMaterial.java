package net.pitan76.mcpitanlib.api.item.tool;

import net.minecraft.tags.ItemTags;
import net.minecraft.tags.TagKey;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Tier;
import net.minecraft.world.item.crafting.Ingredient;
import net.pitan76.mcpitanlib.api.util.IngredientUtil;

public interface CompatibleToolMaterial {

    int getCompatMiningLevel();

    float getCompatAttackDamage();

    float getCompatMiningSpeedMultiplier();

    default Ingredient getCompatRepairIngredient() {
        return IngredientUtil.fromTagByIdentifier(getRepairTag().location());
    }

    int getCompatDurability();

    int getCompatEnchantability();

    @Deprecated
    default float getAttackDamage() {
        return getCompatAttackDamage();
    }

    @Deprecated
    default float getMiningSpeedMultiplier() {
        return getCompatMiningSpeedMultiplier();
    }

    @Deprecated
    default Ingredient getRepairIngredient() {
        return getCompatRepairIngredient();
    }

    @Deprecated
    default int getDurability() {
        return getCompatDurability();
    }

    @Deprecated
    default int getEnchantability() {
        return getCompatEnchantability();
    }

    default TagKey<Item> getRepairTag() {
        return ItemTags.IRON_ORES;
    }

    default Tier build() {
        return new Tier() {
            @Override
            public int getUses() {
                return getCompatDurability();
            }

            @Override
            public float getSpeed() {
                return getCompatMiningSpeedMultiplier();
            }

            @Override
            public float getAttackDamageBonus() {
                return getCompatAttackDamage();
            }

            @Override
            public int getLevel() {
                return getCompatMiningLevel();
            }

            @Override
            public int getEnchantmentValue() {
                return getCompatEnchantability();
            }

            @Override
            public Ingredient getRepairIngredient() {
                return getCompatRepairIngredient();
            }
        };
    }
}