package net.pitan76.mcpitanlib.api.event.nbt;

import net.minecraft.class_11372;
import net.minecraft.class_2487;
import net.minecraft.class_7225;
import net.pitan76.mcpitanlib.api.registry.CompatRegistryLookup;
import net.pitan76.mcpitanlib.core.mc1216.NbtDataConverter;

public class WriteNbtArgs extends NbtRWArgs {
    @Deprecated
    public class_11372 view;

    @Deprecated
    public WriteNbtArgs(class_2487 nbt, class_7225.class_7874 wrapperLookup) {
        super(nbt, wrapperLookup);
    }

    public WriteNbtArgs(class_2487 nbt, CompatRegistryLookup registryLookup) {
        super(nbt, registryLookup);
        view = NbtDataConverter.nbt2writeData(nbt, registryLookup);
    }

    public WriteNbtArgs(class_2487 nbt) {
        super(nbt);
        view = NbtDataConverter.nbt2writeData(nbt, (CompatRegistryLookup) null);
    }

    @Deprecated
    public WriteNbtArgs(class_2487 nbt, class_11372 view) {
        this(nbt);
        this.view = view;
    }

    @Deprecated
    public WriteNbtArgs(class_2487 nbt, class_11372 view, CompatRegistryLookup registryLookup) {
        this(nbt, registryLookup);
        this.view = view;
    }

    @Override
    public boolean isViewEmpty() {
        return view == null;
    }

    @Override
    public NbtRWArgs copy() {
        return new WriteNbtArgs(nbt.method_10553(), view, registryLookup);
    }

    public WriteNbtArgs(net.pitan76.mcpitanlib.midohra.nbt.NbtCompound nbt, CompatRegistryLookup registryLookup) {
        this(nbt.toMinecraft(), registryLookup);
    }

    public WriteNbtArgs(net.pitan76.mcpitanlib.midohra.nbt.NbtCompound nbt) {
        this(nbt.toMinecraft());
    }
}
