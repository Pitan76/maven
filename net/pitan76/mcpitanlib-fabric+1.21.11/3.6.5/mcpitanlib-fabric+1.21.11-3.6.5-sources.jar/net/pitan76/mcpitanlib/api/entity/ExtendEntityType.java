package net.pitan76.mcpitanlib.api.entity;

import com.google.common.collect.ImmutableSet;
import java.util.Optional;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1311;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_4048;
import net.minecraft.class_52;
import net.minecraft.class_5321;
import net.minecraft.class_7701;

public class ExtendEntityType<T extends class_1297> extends class_1299<T> {
    private final Boolean alwaysUpdateVelocity;

    @Deprecated
    public ExtendEntityType(EntityFactory<T> factory, class_1311 spawnGroup, boolean saveable, boolean summonable, boolean fireImmune, boolean spawnableFarFromPlayer, ImmutableSet<class_2248> canSpawnBlocks, class_4048 entityDimensions, float spawnBoxScale, int maxTrackDistance, int trackTickInterval, String translationKey, Optional<class_5321<class_52>> lootTable, Boolean alwaysUpdateVelocity) {
        super((factory::create), spawnGroup, saveable, summonable, fireImmune, spawnableFarFromPlayer, canSpawnBlocks, entityDimensions, spawnBoxScale, maxTrackDistance, trackTickInterval, translationKey, lootTable, class_7701.field_40183, spawnGroup.method_6136());
        this.alwaysUpdateVelocity = alwaysUpdateVelocity;
    }

    public ExtendEntityType(EntityFactory<T> factory, class_1311 spawnGroup, boolean saveable, boolean summonable, boolean fireImmune, boolean spawnableFarFromPlayer, ImmutableSet<class_2248> canSpawnBlocks, class_4048 entityDimensions, int maxTrackDistance, int trackTickInterval, String translationKey, Optional<class_5321<class_52>> lootTable, Boolean alwaysUpdateVelocity) {
        super((factory::create), spawnGroup, saveable, summonable, fireImmune, spawnableFarFromPlayer, canSpawnBlocks, entityDimensions, 5, maxTrackDistance, trackTickInterval, translationKey, lootTable, class_7701.field_40183, spawnGroup.method_6136());
        this.alwaysUpdateVelocity = alwaysUpdateVelocity;
    }

    @Override
    public boolean method_18389() {
        if (alwaysUpdateVelocity != null)
            return alwaysUpdateVelocity;

        return super.method_18389();
    }

    public interface EntityFactory<T extends class_1297> {
        T create(class_1299<T> type, class_1937 world);
    }
}
