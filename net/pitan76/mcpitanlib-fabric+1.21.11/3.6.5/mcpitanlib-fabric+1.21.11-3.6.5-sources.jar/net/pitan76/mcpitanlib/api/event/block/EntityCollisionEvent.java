package net.pitan76.mcpitanlib.api.event.block;

import net.minecraft.class_10774;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_3414;
import net.minecraft.class_3419;
import net.pitan76.mcpitanlib.api.event.BaseEvent;
import net.pitan76.mcpitanlib.api.util.CompatIdentifier;
import net.pitan76.mcpitanlib.api.util.SoundEventUtil;
import net.pitan76.mcpitanlib.api.util.WorldUtil;

import java.util.Optional;

public class EntityCollisionEvent extends BaseEvent {

    public class_2680 state;
    public class_1937 world;
    public class_2338 pos;
    public class_1297 entity;
    public class_10774 handler;
    public boolean bl = false;

    public EntityCollisionEvent(class_2680 state, class_1937 world, class_2338 pos, class_1297 entity) {
        this.state = state;
        this.world = world;
        this.pos = pos;
        this.entity = entity;
    }

    public EntityCollisionEvent(class_2680 state, class_1937 world, class_2338 pos, class_1297 entity, class_10774 handler) {
        this.state = state;
        this.world = world;
        this.pos = pos;
        this.entity = entity;
        this.handler = handler;
    }

    public EntityCollisionEvent(class_2680 state, class_1937 world, class_2338 pos, class_1297 entity, class_10774 handler, boolean bl) {
        this.state = state;
        this.world = world;
        this.pos = pos;
        this.entity = entity;
        this.handler = handler;
        this.bl = bl;
    }

    public boolean isClient() {
        return WorldUtil.isClient(world);
    }

    public class_2338 getEntityPos() {
        return entity.method_24515();
    }

    public class_2338 getBlockPos() {
        return pos;
    }

    public class_2680 getState() {
        return state;
    }

    public class_1297 getEntity() {
        return entity;
    }

    public class_1937 getWorld() {
        return world;
    }

    public void playSound(class_3414 event, class_3419 category, float volume, float pitch) {
        WorldUtil.playSound(world, null, entity.method_24515(), event, category, volume, pitch);
    }

    public void playSound(class_3414 event, float volume, float pitch) {
        playSound(event, class_3419.field_15245, volume, pitch);
    }

    public void playSound(class_3414 event) {
        playSound(event, 1f, 1f);
    }

    public void playSound(class_3414 event, class_3419 category) {
        playSound(event, category, 1f, 1f);
    }

    public void playSound(CompatIdentifier id, class_3419 category, float volume, float pitch) {
        playSound(SoundEventUtil.getSoundEvent(id), category, volume, pitch);
    }

    public boolean hasPlayerEntity() {
        return entity instanceof class_1657;
    }

    public Optional<class_1657> getPlayerEntity() {
        if (!hasPlayerEntity()) return Optional.empty();
        return Optional.of((class_1657) entity);
    }

    public class_2586 getBlockEntity() {
        return WorldUtil.getBlockEntity(getWorld(), getBlockPos());
    }

    public class_10774 getHandler() {
        return handler;
    }
}
