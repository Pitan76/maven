package net.pitan76.mcpitanlib.api.client.render.block.entity.event;

import net.minecraft.class_11659;
import net.minecraft.class_11954;
import net.minecraft.class_12075;
import net.minecraft.class_1799;
import net.minecraft.class_1921;
import net.minecraft.class_2338;
import net.minecraft.class_2586;
import net.minecraft.class_310;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_918;
import net.pitan76.mcpitanlib.api.client.registry.CompatRegistryClient;
import net.pitan76.mcpitanlib.api.client.render.CompatRenderLayer;
import net.pitan76.mcpitanlib.api.client.render.DrawObjectMV;
import net.pitan76.mcpitanlib.api.client.render.block.entity.CompatBlockEntityRenderer;
import net.pitan76.mcpitanlib.api.tile.CompatBlockEntity;
import net.pitan76.mcpitanlib.api.util.MathUtil;
import net.pitan76.mcpitanlib.api.util.client.ClientUtil;
import net.pitan76.mcpitanlib.api.util.client.MatrixStackUtil;
import net.pitan76.mcpitanlib.api.util.client.render.CompatItemRenderUtil;
import org.joml.Matrix3f;
import org.joml.Matrix4f;

public class BlockEntityRenderEvent<T extends CompatBlockEntity> {
    public T blockEntity;
    public float tickDelta;
    public class_4587 matrices;
    public class_4597 vertexConsumers;
    int light;
    int overlay;

    public BlockEntityRenderEvent(T blockEntity, float tickDelta, class_4587 matrices, class_4597 vertexConsumers, int light, int overlay) {
        this.blockEntity = blockEntity;
        this.tickDelta = tickDelta;
        this.matrices = matrices;
        this.vertexConsumers = vertexConsumers;
        this.light = light;
        this.overlay = overlay;
    }

    private class_11954 state;
    private class_11659 queue;
    private class_12075 cameraState;


    public <S extends class_11954> BlockEntityRenderEvent(S state, class_4587 matrices, class_11659 queue, class_12075 cameraState) {
        this.state = state;
        this.queue = queue;
        this.cameraState = cameraState;

        this.matrices = matrices;
        this.queue = queue;
        this.cameraState = cameraState;
        this.tickDelta = class_310.method_1551().method_61966().method_60636();
        class_2586 blockEntity = state.field_62675.method_24182(class_310.method_1551().field_1687, state.field_62673);
        if (blockEntity instanceof CompatBlockEntity) {
            this.blockEntity = (T) blockEntity;
        } else {
            //throw new IllegalArgumentException("BlockEntityRenderEvent: BlockEntity is not an instance of CompatBlockEntity");
        }

        this.vertexConsumers = class_310.method_1551().method_22940().method_23000();
        this.light = state.field_62676;
        if (state.field_62677 != null)
            this.overlay = state.field_62677.comp_4656();
        else
            this.overlay = 0;
    }

    public T getBlockEntity() {
        return blockEntity;
    }

    public class_4587 getMatrices() {
        return matrices;
    }

    public float getTickDelta() {
        return tickDelta;
    }

    public int getLight() {
        return light;
    }

    public int getOverlay() {
        return overlay;
    }

    public class_4588 getVertexConsumer(class_1921 layer) {
        return vertexConsumers.method_73477(layer);
    }

    public class_4588 getVertexConsumer(CompatRenderLayer layer) {
        return getVertexConsumer(layer.raw());
    }

    public class_4597 getVertexConsumers() {
        return vertexConsumers;
    }

    public void push() {
        MatrixStackUtil.push(matrices);
    }

    public void translate(double x, double y, double z) {
        MatrixStackUtil.translate(matrices, x, y, z);
    }

    public void pop() {
        MatrixStackUtil.pop(matrices);
    }

    public void multiply(MathUtil.RotationAxisType type, float deg) {
        MatrixStackUtil.multiply(matrices, type, deg);
    }

    public void scale(float x, float y, float z) {
        MatrixStackUtil.scale(matrices, x, y, z);
    }

    public class_918 getItemRenderer() {
        return ClientUtil.getItemRenderer();
    }

    public boolean isRemoved() {
        return blockEntity.method_11015();
    }

    public DrawObjectMV getDrawObject(CompatRenderLayer layer) {
        return new DrawObjectMV(getMatrices(), getVertexConsumer(layer));
    }

    public Matrix4f matrix4f;
    public Matrix3f matrix3f;

    public Matrix4f getMatrix4f() {
        if (matrix4f == null)
            matrix4f = matrices.method_23760().method_23761();

        return matrix4f;
    }

    public Matrix3f getMatrix3f() {
        if (matrix3f == null)
            matrix3f = matrices.method_23760().method_23762();

        return matrix3f;
    }

    public class_2338 getPos() {
        return state.field_62673;
    }

    public net.pitan76.mcpitanlib.midohra.util.math.BlockPos getMidohraPos() {
        return net.pitan76.mcpitanlib.midohra.util.math.BlockPos.of(getPos());
    }

    //----

    @Deprecated
    public CompatRegistryClient.BlockEntityRendererFactory.Context ctx;

    public BlockEntityRenderEvent(CompatBlockEntityRenderer renderer, T blockEntity, float tickDelta, class_4587 matrices, class_4597 vertexConsumers, int light, int overlay) {
        this(blockEntity, tickDelta, matrices, vertexConsumers, light, overlay);
        if (renderer instanceof net.pitan76.mcpitanlib.api.client.render.block.entity.v2.CompatBlockEntityRenderer<?>) {
            this.ctx = ((net.pitan76.mcpitanlib.api.client.render.block.entity.v2.CompatBlockEntityRenderer<?>) renderer).ctx;
        }
    }

    public BlockEntityRenderEvent(CompatBlockEntityRenderer renderer, class_11954 state, class_4587 matrices, class_11659 queue, class_12075 cameraState) {
        this(state, matrices, queue, cameraState);
        if (renderer instanceof net.pitan76.mcpitanlib.api.client.render.block.entity.v2.CompatBlockEntityRenderer<?>) {
            this.ctx = ((net.pitan76.mcpitanlib.api.client.render.block.entity.v2.CompatBlockEntityRenderer<?>) renderer).ctx;
        }
    }

    public void renderItemFixed(class_1799 stack) {
        CompatItemRenderUtil.renderItemFixed(stack, this, blockEntity.callGetWorld());
    }

    @Deprecated
    public class_11659 getQueue() {
        return queue;
    }

    @Deprecated
    public class_11954 getState() {
        return state;
    }

    @Deprecated
    public class_12075 getCameraState() {
        return cameraState;
    }
}
