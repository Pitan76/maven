package net.pitan76.mcpitanlib.api.client.render;

import net.minecraft.class_12249;
import net.minecraft.class_1921;
import net.pitan76.mcpitanlib.api.util.CompatIdentifier;

public class CompatRenderLayer {
    public static final CompatRenderLayer CUTOUT = new CompatRenderLayer(class_12249.method_75972());
    public static final CompatRenderLayer CUTOUT_MIPPED = new CompatRenderLayer(class_12249.method_75972());
    public static final CompatRenderLayer TRANSLUCENT = new CompatRenderLayer(class_12249.method_75993());
    public static final CompatRenderLayer TRANSLUCENT_MOVING_BLOCK = new CompatRenderLayer(class_12249.method_75977());
    public static final CompatRenderLayer SOLID = new CompatRenderLayer(class_12249.method_75965());
    public static final CompatRenderLayer LINES = new CompatRenderLayer(class_12249.method_76015());
    public static final CompatRenderLayer LINE_STRIP = new CompatRenderLayer(class_12249.method_76668());
    public static final CompatRenderLayer GLINT = new CompatRenderLayer(class_12249.method_75995());

    public final class_1921 layer;

    public CompatRenderLayer(class_1921 layer) {
        this.layer = layer;
    }

    public class_1921 raw() {
        return layer;
    }

    public static CompatRenderLayer getEntityCutout(CompatIdentifier id) {
        return new CompatRenderLayer(class_12249.method_75990(id.toMinecraft()));
    }

    public static CompatRenderLayer getEntityCutoutNoCull(CompatIdentifier id) {
        return new CompatRenderLayer(class_12249.method_75994(id.toMinecraft()));
    }

    public static CompatRenderLayer getEntityTranslucent(CompatIdentifier id) {
        return new CompatRenderLayer(class_12249.method_76000(id.toMinecraft()));
    }

    public static CompatRenderLayer getArmorCutoutNoCull(CompatIdentifier id) {
        return new CompatRenderLayer(class_12249.method_75966(id.toMinecraft()));
    }

    public static CompatRenderLayer getEntitySolid(CompatIdentifier id) {
        return new CompatRenderLayer(class_12249.method_75982(id.toMinecraft()));
    }
}
