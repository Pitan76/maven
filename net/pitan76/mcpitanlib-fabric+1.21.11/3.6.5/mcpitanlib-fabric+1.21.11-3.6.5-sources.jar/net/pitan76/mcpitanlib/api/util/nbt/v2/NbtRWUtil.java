package net.pitan76.mcpitanlib.api.util.nbt.v2;

import net.minecraft.class_11362;
import net.minecraft.class_11368;
import net.minecraft.class_1799;
import net.minecraft.class_2382;
import net.minecraft.class_243;
import net.minecraft.class_2487;
import net.minecraft.class_8942;
import net.pitan76.mcpitanlib.api.event.nbt.ReadNbtArgs;
import net.pitan76.mcpitanlib.api.event.nbt.WriteNbtArgs;
import net.pitan76.mcpitanlib.api.registry.CompatRegistryLookup;
import net.pitan76.mcpitanlib.api.util.collection.ItemStackList;
import net.pitan76.mcpitanlib.api.util.math.PosUtil;
import net.pitan76.mcpitanlib.api.util.math.Vec3dUtil;
import net.pitan76.mcpitanlib.api.util.math.Vec3iUtil;
import net.pitan76.mcpitanlib.api.util.nbt.InvRWUtil;
import net.pitan76.mcpitanlib.midohra.util.math.BlockPos;

import java.util.Optional;

public class NbtRWUtil extends net.pitan76.mcpitanlib.api.util.nbt.NbtRWUtil {
    public static void putInv(WriteNbtArgs args, ItemStackList stacks) {
        InvRWUtil.putInv(args, stacks);
    }

    public static void getInv(ReadNbtArgs args, ItemStackList stacks) {
        InvRWUtil.getInv(args, stacks);
    }

    public static WriteNbtArgs create(CompatRegistryLookup registryLookup) {
        class_11362 view = _view(registryLookup);
        return new WriteNbtArgs(view.method_71475(), view, registryLookup);
    }

    public static WriteNbtArgs create() {
        return create(null);
    }

    public static void put(WriteNbtArgs parent, WriteNbtArgs child, String key) {
        if (child.view instanceof class_11362 childView)
            parent.view.method_71468(key, class_2487.field_25128, childView.method_71475());
    }

    public static WriteNbtArgs putWithCreate(WriteNbtArgs parent, String key) {
        class_11362 subView = _view(parent.registryLookup);
        parent.view.method_71468(key, class_2487.field_25128, subView.method_71475());
        return new WriteNbtArgs(subView.method_71475(), subView, parent.registryLookup);
    }

    public static ReadNbtArgs get(ReadNbtArgs parent, String key) {
        class_11368 view = parent.view.method_71434(key);
        return new ReadNbtArgs(null, view, parent.registryLookup);
    }

    public static ReadNbtArgs getOrDefault(ReadNbtArgs parent, String key, ReadNbtArgs defaultValue) {
        Optional<class_11368> view = parent.view.method_71420(key);
        return view.map(readView -> new ReadNbtArgs(null, readView, parent.registryLookup)).orElse(defaultValue);
    }

    public static void putPos3i(WriteNbtArgs args, String key, int x, int y, int z) {
        WriteNbtArgs args2 = putWithCreate(args, key);
        putInt(args2, "x", x);
        putInt(args2, "y", y);
        putInt(args2, "z", z);
    }

    public static void putPos3d(WriteNbtArgs args, String key, double x, double y, double z) {
        WriteNbtArgs args2 = putWithCreate(args, key);
        putDouble(args2, "x", x);
        putDouble(args2, "y", y);
        putDouble(args2, "z", z);
    }

    public static class_2382 getPos3i(ReadNbtArgs args, String key) {
        ReadNbtArgs args2 = get(args, key);
        int x = getInt(args2, "x");
        int y = getInt(args2, "y");
        int z = getInt(args2, "z");
        return Vec3iUtil.create(x, y, z);
    }

    public static class_243 getPos3d(ReadNbtArgs args, String key) {
        ReadNbtArgs args2 = get(args, key);
        double x = getDouble(args2, "x");
        double y = getDouble(args2, "y");
        double z = getDouble(args2, "z");
        return Vec3dUtil.create(x, y, z);
    }

    public static void putBlockPos(WriteNbtArgs args, String key, BlockPos pos) {
        putPos3i(args, key, pos.getX(), pos.getY(), pos.getZ());
    }

    public static BlockPos getBlockPos(ReadNbtArgs args, String key) {
        ReadNbtArgs args2 = get(args, key);
        int x = getInt(args2, "x");
        int y = getInt(args2, "y");
        int z = getInt(args2, "z");
        return BlockPos.of(x, y, z);
    }

    public static void putBlockPos(WriteNbtArgs args, String key, net.minecraft.class_2338 pos) {
        putPos3i(args, key, PosUtil.x(pos), PosUtil.y(pos), PosUtil.z(pos));
    }

    public static net.minecraft.class_2338 getBlockPosV(ReadNbtArgs args, String key) {
        ReadNbtArgs args2 = get(args, key);
        int x = getInt(args2, "x");
        int y = getInt(args2, "y");
        int z = getInt(args2, "z");
        return PosUtil.flooredBlockPos(x, y, z);
    }

    private static class_11362 _view(CompatRegistryLookup registryLookup) {
        return class_11362.method_71459(class_8942.field_60348, registryLookup.getRegistryLookup());
    }

    public static void putItemStack(WriteNbtArgs args, String key, class_1799 stack) {
        args.view.method_71468(key, class_1799.field_24671, stack);
    }

    public static Optional<class_1799> getItemStack(ReadNbtArgs args, String key) {
        return args.view.method_71426(key, class_1799.field_24671);
    }
}
