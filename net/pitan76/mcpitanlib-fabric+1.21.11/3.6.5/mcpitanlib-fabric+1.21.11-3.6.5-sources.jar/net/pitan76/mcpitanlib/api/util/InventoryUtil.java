package net.pitan76.mcpitanlib.api.util;

import net.minecraft.class_11362;
import net.minecraft.class_11368;
import net.minecraft.class_11372;
import net.minecraft.class_1262;
import net.minecraft.class_1263;
import net.minecraft.class_1277;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2371;
import net.minecraft.class_2487;
import net.minecraft.class_8942;
import net.pitan76.mcpitanlib.api.event.nbt.NbtRWArgs;
import net.pitan76.mcpitanlib.api.event.nbt.ReadNbtArgs;
import net.pitan76.mcpitanlib.api.event.nbt.WriteNbtArgs;
import net.pitan76.mcpitanlib.api.registry.CompatRegistryLookup;
import net.pitan76.mcpitanlib.api.util.nbt.NbtListUtil;
import net.pitan76.mcpitanlib.core.mc1216.NbtDataConverter;

public class InventoryUtil {
    public static boolean insertItem(class_1799 insertStack, class_2371<class_1799> inventory) {
        return insertItem(insertStack, inventory, false);
    }

    public static boolean insertItem(class_1799 insertStack, class_2371<class_1799> inventory, boolean test) {
        boolean isInserted = false;
        for (int i = 0; i < inventory.size(); i++) {
            class_1799 stack = inventory.get(i);
            if (stack.method_7960()) {
                if (!test) inventory.set(i, insertStack);
                isInserted = true;
                break;
            } else if (canMergeItems(stack, insertStack)) {
                int j = insertStack.method_7947();
                if (!test) stack.method_7933(j);
                isInserted = j > 0;
                break;
            }
        }
        return isInserted;

    }

    public static boolean canMergeItems(class_1799 first, class_1799 second) {
        if (!first.method_31574(second.method_7909())) {
            return false;
        }
        if (first.method_7919() != second.method_7919()) {
            return false;
        }
        if (first.method_7947() + second.method_7947() > first.method_7914()) {
            return false;
        }
        return ItemStackUtil.areNbtOrComponentEqual(first, second);
    }

    public static class_2487 writeNbt(NbtRWArgs args, class_2487 nbt, class_2371<class_1799> stacks, boolean setIfEmpty) {
        boolean nbtNull = nbt == null;

        if (args instanceof WriteNbtArgs) {
            WriteNbtArgs writeNbtArgs = (WriteNbtArgs) args;
            if (writeNbtArgs.view == null) writeNbtArgs.view = class_11362.method_71458(class_8942.field_60348);

            class_1262.method_5427(writeNbtArgs.view, stacks, setIfEmpty);
            if (!nbtNull)
                NbtUtil.put(nbt, "Items", NbtListUtil.create()); // dummy list to compat with old mod

            NbtDataConverter.data2nbt(writeNbtArgs.view, nbt);
            return nbt;
        }

        class_11372 view = NbtDataConverter.nbt2writeData(nbt, args.registryLookup);
        class_1262.method_5427(view, stacks, setIfEmpty);
        if (!nbtNull)
            NbtUtil.put(nbt, "Items", NbtListUtil.create()); // dummy list to compat with old mod

        NbtDataConverter.data2nbt(view, nbt);
        return nbt;
    }

    public static void readNbt(NbtRWArgs args, class_2487 nbt, class_2371<class_1799> stacks) {
        if (args instanceof ReadNbtArgs) {
            ReadNbtArgs readNbtArgs = (ReadNbtArgs) args;
            if (readNbtArgs.view == null) return;

            class_1262.method_5429(readNbtArgs.view, stacks);
            return;
        }

        class_11368 view = NbtDataConverter.nbt2readData(nbt, args.registryLookup);
        class_1262.method_5429(view, stacks);
    }

    public static class_2487 writeNbt(NbtRWArgs args, class_2371<class_1799> stacks, boolean setIfEmpty) {
        return writeNbt(args, args.getNbt(), stacks, setIfEmpty);
    }

    public static class_2487 writeNbt(NbtRWArgs args, class_2371<class_1799> stacks) {
        return writeNbt(args, stacks, true);
    }

    public static void readNbt(NbtRWArgs args, class_2371<class_1799> stacks) {
        readNbt(args, args.getNbt(), stacks);
    }

    public static void readNbt(CompatRegistryLookup registryLookup, class_2487 nbt, class_2371<class_1799> stacks) {
        class_11368 view = NbtDataConverter.nbt2readData(nbt, registryLookup);
        class_1262.method_5429(view, stacks);
    }

    public static class_2487 writeNbt(CompatRegistryLookup registryLookup, class_2487 nbt, class_2371<class_1799> stacks, boolean setIfEmpty) {
        NbtUtil.put(nbt, "Items", NbtListUtil.create());
        class_11372 view = NbtDataConverter.nbt2writeData(nbt, registryLookup);
        class_1262.method_5427(view, stacks, setIfEmpty);

        NbtDataConverter.data2nbt(view, nbt);

        System.out.println("writeNbt(): " + nbt);

        return nbt;
    }

    public static class_2487 writeNbt(CompatRegistryLookup registryLookup, class_2487 nbt, class_2371<class_1799> stacks) {
        return writeNbt(registryLookup, nbt, stacks, true);
    }

    // deprecated
    /**
     * @deprecated Use {@link #writeNbt(NbtRWArgs, class_2371)} instead
     */
    @Deprecated
    public static class_2487 writeNbt(class_1937 world, class_2487 nbt, class_2371<class_1799> stacks) {
        return writeNbt(world, nbt, true, stacks);
    }

    /**
     * @deprecated Use {@link #writeNbt(NbtRWArgs, class_2371, boolean)} instead
     */
    @Deprecated
    public static class_2487 writeNbt(class_1937 world, class_2487 nbt, boolean setIfEmpty, class_2371<class_1799> stacks) {
        return writeNbt(new NbtRWArgs(nbt), stacks, setIfEmpty);
    }

    /**
     * @deprecated Use {@link #readNbt(NbtRWArgs, class_2371)} instead
     */
    @Deprecated
    public static void readNbt(class_1937 world, class_2487 nbt, class_2371<class_1799> stacks) {
        readNbt(new ReadNbtArgs(nbt), stacks);
    }
    // ----

    public static class_1277 createSimpleInventory(int size) {
        return new class_1277(size);
    }

    public static void copyToInv(class_2371<class_1799> from, class_1263 to) {
        for (int i = 0; i < from.size(); i++) {
            to.method_5447(i, from.get(i));
        }
    }

    public static void copyToList(class_1263 from, class_2371<class_1799> to) {
        for (int i = 0; i < from.method_5439(); i++) {
            to.set(i, from.method_5438(i));
        }
    }

    public static int getSize(class_1263 inventory) {
        return inventory.method_5439();
    }

    public static class_1799 getStack(class_1263 inventory, int slot) {
        return inventory.method_5438(slot);
    }

    public static void setStack(class_1263 inventory, int slot, class_1799 stack) {
        inventory.method_5447(slot, stack);
    }

    public static boolean isEmpty(class_1263 inventory) {
        return inventory.method_5442();
    }

    public static class_1799 removeStack(class_1263 inventory, int slot) {
        return inventory.method_5441(slot);
    }

    public static class_1799 removeStack(class_1263 inventory, int slot, int amount) {
        return inventory.method_5434(slot, amount);
    }

    public static void clear(class_1263 inventory) {
        inventory.method_5448();
    }

    public static void markDirty(class_1263 inventory) {
        inventory.method_5431();
    }
}
