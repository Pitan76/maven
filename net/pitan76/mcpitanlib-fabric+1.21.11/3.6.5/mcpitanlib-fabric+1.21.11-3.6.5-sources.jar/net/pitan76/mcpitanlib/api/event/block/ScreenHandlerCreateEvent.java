package net.pitan76.mcpitanlib.api.event.block;

import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.pitan76.mcpitanlib.api.entity.Player;
import net.pitan76.mcpitanlib.api.event.BaseEvent;

public class ScreenHandlerCreateEvent extends BaseEvent {

    public class_2680 state;
    public class_1937 world;
    public class_2338 pos;
    public int syncId;
    public class_1661 inventory;
    public Player player;

    public ScreenHandlerCreateEvent(class_2680 state, class_1937 world, class_2338 pos, int syncId, class_1661 inventory, class_1657 player) {
        this.state = state;
        this.world = world;
        this.pos = pos;
        this.syncId = syncId;
        this.inventory = inventory;
        this.player = new Player(player);
    }

    public class_2680 getState() {
        return state;
    }

    public class_2338 getPos() {
        return pos;
    }

    public class_1937 getWorld() {
        return world;
    }

    public int getSyncId() {
        return syncId;
    }

    public class_1661 getInventory() {
        return inventory;
    }

    public Player getPlayer() {
        return player;
    }

    public boolean isClient() {
        return world.method_8608();
    }
}
