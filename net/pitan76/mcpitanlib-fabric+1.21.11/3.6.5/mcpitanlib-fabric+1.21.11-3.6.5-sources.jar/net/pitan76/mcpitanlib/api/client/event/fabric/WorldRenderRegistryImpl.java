package net.pitan76.mcpitanlib.api.client.event.fabric;

import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderEvents;
import net.minecraft.class_310;
import net.minecraft.class_4184;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_4604;
import net.minecraft.class_638;
import net.minecraft.class_757;
import net.minecraft.class_761;
import net.minecraft.class_765;
import net.minecraft.client.render.*;
import net.pitan76.mcpitanlib.api.client.event.listener.BeforeBlockOutlineEvent;
import net.pitan76.mcpitanlib.api.client.event.listener.BeforeBlockOutlineListener;
import net.pitan76.mcpitanlib.api.client.event.listener.WorldRenderContext;
import net.pitan76.mcpitanlib.api.client.event.listener.WorldRenderContextListener;
import net.pitan76.mcpitanlib.api.util.client.ClientUtil;
import org.jetbrains.annotations.Nullable;
import org.joml.Matrix4f;

public class WorldRenderRegistryImpl {
    public static void _registerWorldRenderBeforeBlockOutline(BeforeBlockOutlineListener listener) {
        WorldRenderEvents.BEFORE_BLOCK_OUTLINE.register(((worldRenderContext, renderState) -> listener.beforeBlockOutline(new BeforeBlockOutlineEvent(
        new WorldRenderContext() {
            @Override
            public class_761 getWorldRenderer() {
                return worldRenderContext.worldRenderer();
            }

            @Override
            public class_4587 getMatrixStack() {
                return worldRenderContext.matrices();
            }

            @Override
            public float getTickDelta() {
                return class_310.method_1551().method_61966().method_60636();
            }

            @Override
            public class_4184 getCamera() {
                return worldRenderContext.gameRenderer().method_19418();
            }

            @Override
            public class_757 getGameRenderer() {
                return worldRenderContext.gameRenderer();
            }

            @Override
            public class_765 getLightmapTextureManager() {
                return getGameRenderer().method_22974();
            }

            @Override
            public Matrix4f getProjectionMatrix() {
                return worldRenderContext.gameRenderer().method_22973(0);
            }

            @Override
            public class_638 getWorld() {
                return ClientUtil.getWorld();
            }

            @Override
            public boolean isAdvancedTranslucency() {
                return renderState.comp_4933();
            }

            @Override
            public class_4597 getConsumers() {
                return worldRenderContext.consumers();
            }

            @Override
            public class_4604 getFrustum() {
                return worldRenderContext.worldRenderer().method_62222();
            }
        }, renderState))));
    }

    public static void _registerWorldRenderAfterLevel(WorldRenderContextListener listener) {
        WorldRenderEvents.END_MAIN.register((context -> {
            listener.render(new WorldRenderContext() {
                @Override
                public class_761 getWorldRenderer() {
                    return context.worldRenderer();
                }

                @Override
                public class_4587 getMatrixStack() {
                    return context.matrices();
                }

                @Override
                public float getTickDelta() {
                    return class_310.method_1551().method_61966().method_60636();
                }

                @Override
                public class_4184 getCamera() {
                    return context.gameRenderer().method_19418();
                }

                @Override
                public class_757 getGameRenderer() {
                    return context.gameRenderer();
                }

                @Override
                public class_765 getLightmapTextureManager() {
                    return getGameRenderer().method_22974();
                }

                @Override
                public Matrix4f getProjectionMatrix() {
                    return context.gameRenderer().method_22973(0);
                }

                @Override
                public class_638 getWorld() {
                    return ClientUtil.getWorld();
                }

                @Override
                public boolean isAdvancedTranslucency() {
                    return true;
                }

                @Override
                public @Nullable class_4597 getConsumers() {
                    return context.consumers();
                }

                @Override
                public @Nullable class_4604 getFrustum() {
                    return context.worldRenderer().method_62222();
                }
            });
        }));
    }
}
