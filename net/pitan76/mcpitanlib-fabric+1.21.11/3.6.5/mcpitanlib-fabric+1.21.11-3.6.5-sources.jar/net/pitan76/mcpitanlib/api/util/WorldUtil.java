package net.pitan76.mcpitanlib.api.util;

import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1301;
import net.minecraft.class_1303;
import net.minecraft.class_1309;
import net.minecraft.class_1542;
import net.minecraft.class_1569;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1923;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_2394;
import net.minecraft.class_243;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_3414;
import net.minecraft.class_3419;
import net.minecraft.class_3610;
import net.minecraft.class_3611;
import net.minecraft.class_3726;
import net.minecraft.class_5321;
import net.minecraft.class_7924;
import net.minecraft.entity.*;
import net.minecraft.server.MinecraftServer;
import net.pitan76.mcpitanlib.api.entity.Player;
import net.pitan76.mcpitanlib.api.sound.CompatSoundCategory;
import net.pitan76.mcpitanlib.api.sound.CompatSoundEvent;
import net.pitan76.mcpitanlib.api.util.math.BoxUtil;
import net.pitan76.mcpitanlib.api.util.math.random.CompatRandom;
import net.pitan76.mcpitanlib.api.util.particle.CompatParticleType;
import net.pitan76.mcpitanlib.midohra.block.BlockWrapper;
import net.pitan76.mcpitanlib.midohra.entity.EntityTypeWrapper;
import net.pitan76.mcpitanlib.midohra.util.math.Vector3d;
import net.pitan76.mcpitanlib.midohra.world.chunk.ChunkTicketType;
import org.jetbrains.annotations.Nullable;

import java.util.*;
import java.util.function.Predicate;

public class WorldUtil {
    public static boolean hasSkyLight(class_1937 world) {
        return world.method_8597().comp_642();
    }

    public static boolean isThundering(class_1937 world) {
        return world.method_8546();
    }

    public static boolean isRaining(class_1937 world) {
        return world.method_8419();
    }

    public static boolean isNight(class_1937 world) {
        return world.method_23886();
    }

    public static boolean isDay(class_1937 world) {
        return world.method_8530();
    }

    public static boolean isSkyVisible(class_1937 world, class_2338 pos) {
        return world.method_8311(pos);
    }

    public static boolean isClient(class_1937 world) {
        return world.method_8608();
    }

    public static void scheduleBlockTick(class_1937 world, class_2338 pos, class_2248 block, int delay) {
        world.method_64310(pos, block, delay);
    }

    public static void scheduleFluidTick(class_1937 world, class_2338 pos, class_3611 fluid, int delay) {
        world.method_64312(pos, fluid, delay);
    }

    public static boolean isServer(class_1937 world) {
        return !isClient(world);
    }

    public static void spawnStack(class_1937 world, class_2338 pos, class_1799 stack) {
        spawnEntity(world, new class_1542(world, pos.method_10263(), pos.method_10264(), pos.method_10260(), stack));
    }

    public static void spawnExperienceOrb(class_1937 world, class_243 pos, int amount) {
        if (world instanceof class_3218)
            class_1303.method_31493((class_3218) world, pos, amount);
    }

    public static void spawnExperienceOrb(class_1937 world, class_2338 pos, int amount) {
        spawnExperienceOrb(world, pos.method_46558(), amount);
    }

    public static void spawnEntity(class_1937 world, class_1297 entity) {
        world.method_8649(entity);
    }

    public static void playSound(class_1937 world, @Nullable Player player, class_2338 pos, class_3414 sound, class_3419 category, float volume, float pitch) {
        class_1657 entity = player == null ? null : player.getEntity();
        world.method_8396(entity, pos, sound, category, volume, pitch);
    }

    public static void playSound(class_1937 world, @Nullable Player player, class_2338 pos, CompatSoundEvent sound, CompatSoundCategory category, float volume, float pitch) {
        playSound(world, player, pos, sound.get(), category.get(), volume, pitch);
    }

    public static void playSound(class_1937 world, class_2338 pos, CompatSoundEvent sound, CompatSoundCategory category, float volume, float pitch) {
        playSound(world, null, pos, sound.get(), category.get(), volume, pitch);
    }

    public static void playSound(class_1937 world, double x, double y, double z, CompatSoundEvent sound, CompatSoundCategory category, float volume, float pitch, boolean useDistance) {
        world.method_8486(x, y, z, sound.get(), category.get(), volume, pitch, useDistance);
    }

    public static void sendEntityStatus(class_1937 world, class_1297 entity, byte status) {
        world.method_8421(entity, status);
    }

    public static class_2338 getSpawnPos(class_1937 world) {
        return world.method_74854().method_74897();
    }

    public static Optional<MinecraftServer> getServer(class_1937 world) {
        if (isClient(world)) return Optional.empty();
        return Optional.ofNullable(world.method_8503());
    }

    public static class_3218 getWorld(class_1937 world, class_2960 worldId) {
        Optional<MinecraftServer> server = getServer(world);
        return server.map(minecraftServer -> getWorld(minecraftServer, worldId)).orElse(null);

    }

    public static Optional<class_3218> getWorld(class_1937 world, CompatIdentifier worldId) {
        return Optional.ofNullable(getWorld(world, worldId.toMinecraft()));
    }

    public static class_3218 getOverworld(MinecraftServer server) {
        return server.method_3847(class_1937.field_25179);
    }

    public static class_3218 getNether(MinecraftServer server) {
        return server.method_3847(class_1937.field_25180);
    }

    public static class_3218 getEnd(MinecraftServer server) {
        return server.method_3847(class_1937.field_25181);
    }

    public static class_3218 getWorld(MinecraftServer server, class_2960 worldId) {
        return server.method_3847(class_5321.method_29179(class_7924.field_41223, worldId));
    }

    public static class_3218 getWorld(MinecraftServer server, CompatIdentifier worldId) {
        return getWorld(server, worldId.toMinecraft());
    }

    public static class_2960 getWorldId(class_1937 world) {
        return world.method_27983().method_29177();
    }

    public static CompatIdentifier getCompatWorldId(class_1937 world) {
        return CompatIdentifier.fromMinecraft(getWorldId(world));
    }

    public static boolean equals(class_1937 world, class_1937 world2) {
        return Objects.equals(getWorldId(world), getWorldId(world2));
    }

    @Deprecated
    public static <T> void addTicket(class_3218 world, net.minecraft.class_3230 type, class_1923 pos, int radius, T argument) {
        world.method_14178().method_66009(type, pos, radius);
    }

    @Deprecated
    public static <T> void removeTicket(class_3218 world, net.minecraft.class_3230 type, class_1923 pos, int radius, T argument) {
        world.method_14178().method_66010(type, pos, radius);
    }

    public static <T> void addTicket(class_3218 world, ChunkTicketType<T> type, class_1923 pos, int radius, T argument) {
        addTicket(world, type.getRaw(), pos, radius, argument);
    }

    public static <T> void removeTicket(class_3218 world, ChunkTicketType<T> type, class_1923 pos, int radius, T argument) {
        removeTicket(world, type.getRaw(), pos, radius, argument);
    }

    public static void addTicket(class_3218 world, ChunkTicketType<?> type, class_1923 pos, int radius) {
        world.method_14178().method_66009(type.getRaw(), pos, radius);
    }

    public static void removeTicket(class_3218 world, ChunkTicketType<?> type, class_1923 pos, int radius) {
        world.method_14178().method_66010(type.getRaw(), pos, radius);
    }

    public static boolean isReceivingRedstonePower(class_1937 world, class_2338 pos) {
        return world.method_49803(pos);
    }

    public static int getBottomY(class_1937 world) {
        return world.method_31607();
    }

    public static int getTopY(class_1937 world) {
        return world.method_31600();
    }

    public static int getDimensionHeight(class_1937 world) {
        return world.method_8597().comp_652();
    }

    public static class_2586 getBlockEntity(class_1937 world, class_2338 pos) {
        return world.method_8321(pos);
    }

    public static boolean hasBlockEntity(class_1937 world, class_2338 pos) {
        return getBlockEntity(world, pos) != null;
    }

    public static class_2680 getBlockState(class_1937 world, class_2338 pos) {
        return world.method_8320(pos);
    }

    public static class_3610 getFluidState(class_1937 world, class_2338 pos) {
        return world.method_8316(pos);
    }

    public static boolean hasFluidState(class_1937 world, class_2338 pos) {
        return ! getFluidState(world, pos).method_15769();
    }

    public static boolean isAir(class_1937 world, class_2338 pos) {
        return getBlockState(world, pos).method_26215();
    }

    public static boolean setBlockState(class_1937 world, class_2338 pos, class_2680 state, int flags) {
        return world.method_8652(pos, state, flags);
    }

    public static boolean setBlockState(class_1937 world, class_2338 pos, class_2680 state) {
        return setBlockState(world, pos, state, 3);
    }

    public static boolean setBlockState(class_1937 world, class_2338 pos, class_2248 block, int flags) {
        return setBlockState(world, pos, block.method_9564(), flags);
    }

    public static boolean setBlockState(class_1937 world, class_2338 pos, class_2248 block) {
        return setBlockState(world, pos, block, 3);
    }

    public static boolean breakBlock(class_1937 world, class_2338 pos, boolean drop) {
        return world.method_22352(pos, drop);
    }

    public static boolean breakBlock(class_1937 world, class_2338 pos) {
        return breakBlock(world, pos, true);
    }

    public static boolean breakBlock(class_1937 world, class_2338 pos, boolean drop, @Nullable Player player) {
        if (player == null)
            return world.method_8651(pos, drop, null);

        return world.method_8651(pos, drop, player.getPlayerEntity());
    }

    public static boolean breakBlock(class_1937 world, class_2338 pos, @Nullable Player player) {
        return breakBlock(world, pos, true, player);
    }

    public static void removeBlockEntity(class_1937 world, class_2338 pos) {
        world.method_8544(pos);
    }

    public static boolean removeBlock(class_1937 world, class_2338 pos, boolean move) {
        return world.method_8650(pos, move);
    }

    public static void addParticle(class_1937 world, class_2394 parameters, double x, double y, double z, double velocityX, double velocityY, double velocityZ) {
        world.method_8406(parameters, x, y, z, velocityX, velocityY, velocityZ);
    }

    public static boolean canSetBlock(class_1937 world, class_2338 pos) {
        return world.method_8628(class_2246.field_10340.method_9564(), pos, class_3726.method_16194());
    }

    public static void updateComparators(class_1937 world, class_2338 pos, class_2248 block) {
        world.method_8455(pos, block);
    }

    public static List<Player> getPlayers(class_1937 world) {
        List<Player> players = new ArrayList<>();
        for (class_1657 player : world.method_18456()) {
            players.add(new Player(player));
        }

        return players;
    }

    public static Player getPlayer(class_1937 world, UUID uuid) {
        return new Player(world.method_18470(uuid));
    }

    public static CompatRandom getRandom(class_1937 world) {
        return new CompatRandom(world.method_8409());
    }

    public static long getTime(class_1937 world) {
        return world.method_75260();
    }

    public static <T extends class_1297> List<T> getEntitiesByType(class_1937 world, class_1299<T> filter, class_238 box, Predicate<? super T> predicate) {
        return world.method_18023(filter, box, predicate);
    }

    public static <T extends class_1297> List<T> getEntitiesByClass(class_1937 world, Class<T> entityClass, class_238 box, Predicate<? super T> predicate) {
        return world.method_8390(entityClass, box, predicate);
    }

    public static void spawnParticles(class_1937 world, class_2394 parameters, double x, double y, double z, int count, double velocityX, double velocityY, double velocityZ, double speed) {
        if (!isServer(world)) return;

        ((class_3218) world).method_65096(parameters, x, y, z, count, velocityX, velocityY, velocityZ, speed);
    }

    public static void updateListeners(class_1937 world, class_2338 pos, class_2680 oldState, class_2680 newState, int flags) {
        world.method_8413(pos, oldState, newState, flags);
    }

    public static net.pitan76.mcpitanlib.midohra.block.BlockState getMidohraBlockState(class_1937 world, class_2338 pos) {
        return net.pitan76.mcpitanlib.midohra.block.BlockState.of(getBlockState(world, pos));
    }

    public static boolean setBlockState(class_1937 world, class_2338 pos, net.pitan76.mcpitanlib.midohra.block.BlockState state, int flags) {
        return setBlockState(world, pos, state.toMinecraft(), flags);
    }

    public static boolean setBlockState(class_1937 world, class_2338 pos, net.pitan76.mcpitanlib.midohra.block.BlockState state) {
        return setBlockState(world, pos, state, 3);
    }

    public static boolean setBlockState(class_1937 world, net.pitan76.mcpitanlib.midohra.util.math.BlockPos pos, net.pitan76.mcpitanlib.midohra.block.BlockState state, int flags) {
        return setBlockState(world, pos.toMinecraft(), state.toMinecraft(), flags);
    }

    public static boolean setBlockState(class_1937 world, net.pitan76.mcpitanlib.midohra.util.math.BlockPos pos, net.pitan76.mcpitanlib.midohra.block.BlockState state) {
        return setBlockState(world, pos, state, 3);
    }

    public static boolean breakBlock(class_1937 world, net.pitan76.mcpitanlib.midohra.util.math.BlockPos pos, boolean drop) {
        return breakBlock(world, pos.toMinecraft(), drop);
    }

    public static boolean breakBlock(class_1937 world, net.pitan76.mcpitanlib.midohra.util.math.BlockPos pos) {
        return breakBlock(world, pos, true);
    }

    public static boolean breakBlock(class_1937 world, net.pitan76.mcpitanlib.midohra.util.math.BlockPos pos, boolean drop, @Nullable Player player) {
        return breakBlock(world, pos.toMinecraft(), drop, player);
    }

    public static boolean breakBlock(class_1937 world, net.pitan76.mcpitanlib.midohra.util.math.BlockPos pos, @Nullable Player player) {
        return breakBlock(world, pos, true, player);
    }

    public static void removeBlockEntity(class_1937 world, net.pitan76.mcpitanlib.midohra.util.math.BlockPos pos) {
        removeBlockEntity(world, pos.toMinecraft());
    }

    public static boolean removeBlock(class_1937 world, net.pitan76.mcpitanlib.midohra.util.math.BlockPos pos, boolean move) {
        return removeBlock(world, pos.toMinecraft(), move);
    }

    public static void playSound(net.pitan76.mcpitanlib.midohra.world.World world, @Nullable Player player, net.pitan76.mcpitanlib.midohra.util.math.BlockPos pos, CompatSoundEvent sound, CompatSoundCategory category, float volume, float pitch) {
        playSound(world.getRaw(), player, pos.toMinecraft(), sound, category, volume, pitch);
    }

    public static void dropStackOnBlock(class_1937 world, class_2338 pos, class_1799 stack) {
        class_2248.method_9577(world, pos, stack);
    }

    public static float getSkyAngle(class_1937 world, float tickDelta) {
        long timeOfDay = world.method_8532();
        float f = ((float)(timeOfDay % 24000L) + tickDelta) / 24000.0F - 0.25F;
        if (f < 0.0F) {
            f += 1.0F;
        }
        if (f > 1.0F) {
            f -= 1.0F;
        }
        return f;
    }

    public static class_2248 getBlock(class_1937 world, class_2338 pos) {
        return getBlockState(world, pos).method_26204();
    }

    public static BlockWrapper getBlockWrapper(class_1937 world, class_2338 pos) {
        return BlockWrapper.of(getBlock(world, pos));
    }

    public static <T extends class_1297> List<T> getEntitiesByType(class_1937 world, class_1299<T> filter, class_238 box) {
        return getEntitiesByType(world, filter, box, class_1301.field_6154);
    }

    public static <T extends class_1297> List<T> getEntitiesByType(class_1937 world, EntityTypeWrapper filter, class_238 box, Predicate<? super T> predicate) {
        return getEntitiesByType(world, (class_1299<T>) filter.get(), box, predicate);
    }

    public static List<?> getEntitiesByType(class_1937 world, EntityTypeWrapper filter, class_238 box) {
        return getEntitiesByType(world, filter.get(), box);
    }

    public static CompatIdentifier getOverworldId() {
        return CompatIdentifier.fromMinecraft(class_1937.field_25179.method_29177());
    }

    public static CompatIdentifier getNetherId() {
        return CompatIdentifier.fromMinecraft(class_1937.field_25180.method_29177());
    }

    public static CompatIdentifier getEndId() {
        return CompatIdentifier.fromMinecraft(class_1937.field_25181.method_29177());
    }

    public static long getTimeOfDay(class_1937 world) {
        return world.method_8532();
    }

    public static <T extends class_1297> List<T> getEntitiesByClass(class_1937 world, Class<T> entityClass, net.pitan76.mcpitanlib.midohra.util.math.Box box) {
        return getEntitiesByClass(world, entityClass, box, class_1301.field_6154);
    }

    public static <T extends class_1297> List<T> getEntitiesByClass(class_1937 world, Class<T> entityClass, class_238 box) {
        return getEntitiesByClass(world, entityClass, box, class_1301.field_6154);
    }

    public static <T extends class_1297> List<T> getEntitiesByClass(class_1937 world, Class<T> entityClass, net.pitan76.mcpitanlib.midohra.util.math.Box box, Predicate<? super T> predicate) {
        return getEntitiesByClass(world, entityClass, box.toMinecraft(), predicate);
    }

    public static <T extends class_1297> List<T> getEntitiesByClass(class_1937 world, Class<T> entityClass, Vector3d center, double radius, Predicate<? super T> predicate) {
        class_238 box = BoxUtil.createBox(center.x - radius, center.y - radius, center.z - radius, center.x + radius, center.y + radius, center.z + radius);
        return getEntitiesByClass(world, entityClass, box, predicate);
    }

    public static <T extends class_1297> List<T> getEntitiesByClass(class_1937 world, Class<T> entityClass, Vector3d center, double radius) {
        return getEntitiesByClass(world, entityClass, center, radius, class_1301.field_6154);
    }

    public static List<class_1309> getMonsters(class_1937 world, class_238 box) {
        return world.method_8390(class_1309.class, box, entity -> entity instanceof class_1569);
    }

    public static List<class_1309> getMonsters(class_1937 world, net.pitan76.mcpitanlib.midohra.util.math.Box box) {
        return getMonsters(world, box.toMinecraft());
    }

    public static List<class_1309> getMonsters(class_1937 world, Vector3d center, double radius) {
        class_238 box = BoxUtil.createBox(center.x - radius, center.y - radius, center.z - radius, center.x + radius, center.y + radius, center.z + radius);
        return getMonsters(world, box);
    }

    public static List<?> getEntitiesByType(class_1937 world, EntityTypeWrapper filter, net.pitan76.mcpitanlib.midohra.util.math.Box box) {
        return getEntitiesByType(world, filter, box.toMinecraft());
    }

    public static List<?> getEntitiesByType(class_1937 world, EntityTypeWrapper filter, net.pitan76.mcpitanlib.midohra.util.math.Box box, Predicate<? super class_1297> predicate) {
        return getEntitiesByType(world, filter, box.toMinecraft(), predicate);
    }

    /**
     * ParticleType is a ParticleEffect only.
     */
    public static void addParticle(class_1937 world, CompatParticleType parameters, double x, double y, double z, double velocityX, double velocityY, double velocityZ) {
        if (parameters.getRaw() instanceof class_2394)
            addParticle(world, (class_2394) parameters.getRaw(), x, y, z, velocityX, velocityY, velocityZ);
    }
}
