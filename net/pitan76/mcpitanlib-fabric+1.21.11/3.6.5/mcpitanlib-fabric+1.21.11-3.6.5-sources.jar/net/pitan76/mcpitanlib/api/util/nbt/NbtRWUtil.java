package net.pitan76.mcpitanlib.api.util.nbt;

import net.minecraft.class_2487;
import net.pitan76.mcpitanlib.api.event.nbt.NbtRWArgs;
import net.pitan76.mcpitanlib.api.event.nbt.ReadNbtArgs;
import net.pitan76.mcpitanlib.api.event.nbt.WriteNbtArgs;
import net.pitan76.mcpitanlib.api.util.NbtUtil;

public class NbtRWUtil {

    public static void putBoolean(WriteNbtArgs args, String key, boolean value) {
        args.view.method_71472(key, value);
    }

    public static boolean getBoolean(ReadNbtArgs args, String key) {
        return args.view.method_71433(key, false);
    }

    public static void putByte(WriteNbtArgs args, String key, byte value) {
        args.view.method_71462(key, value);
    }

    public static byte getByte(ReadNbtArgs args, String key) {
        return args.view.method_71421(key, (byte) 0);
    }

    public static void putInt(WriteNbtArgs args, String key, int value) {
        args.view.method_71465(key, value);
    }

    public static int getInt(ReadNbtArgs args, String key) {
        return args.view.method_71424(key, 0);
    }

    public static void putLong(WriteNbtArgs args, String key, long value) {
        args.view.method_71466(key, value);
    }

    public static long getLong(ReadNbtArgs args, String key) {
        return args.view.method_71425(key, 0L);
    }

    public static void putShort(WriteNbtArgs args, String key, short value) {
        args.view.method_71471(key, value);
    }

    public static short getShort(ReadNbtArgs args, String key) {
        return (short) args.view.method_71432(key, (short) 0);
    }

    public static void putFloat(WriteNbtArgs args, String key, float value) {
        args.view.method_71464(key, value);
    }

    public static float getFloat(ReadNbtArgs args, String key) {
        return args.view.method_71423(key, 0.0f);
    }

    public static void putDouble(WriteNbtArgs args, String key, double value) {
        args.view.method_71463(key, value);
    }

    public static double getDouble(ReadNbtArgs args, String key) {
        return args.view.method_71422(key, 0.0);
    }

    public static void putString(WriteNbtArgs args, String key, String value) {
        args.view.method_71469(key, value);
    }

    public static String getString(ReadNbtArgs args, String key) {
        return args.view.method_71428(key, "");
    }

    public static void putIntArray(WriteNbtArgs args, String key, int[] value) {
        args.view.method_71473(key, value);
    }

    public static int[] getIntArray(ReadNbtArgs args, String key) {
        return args.view.method_71442(key).orElse(new int[0]);
    }

    public static boolean getBooleanOrDefault(ReadNbtArgs args, String key, boolean defaultValue) {
        return args.view.method_71433(key, defaultValue);
    }

    public static byte getByteOrDefault(ReadNbtArgs args, String key, byte defaultValue) {
        return args.view.method_71421(key, defaultValue);
    }

    public static int getIntOrDefault(ReadNbtArgs args, String key, int defaultValue) {
        return args.view.method_71424(key, defaultValue);
    }

    public static long getLongOrDefault(ReadNbtArgs args, String key, long defaultValue) {
        return args.view.method_71425(key, defaultValue);
    }

    public static short getShortOrDefault(ReadNbtArgs args, String key, short defaultValue) {
        return (short) args.view.method_71432(key, defaultValue);
    }

    public static float getFloatOrDefault(ReadNbtArgs args, String key, float defaultValue) {
        return args.view.method_71423(key, defaultValue);
    }

    public static double getDoubleOrDefault(ReadNbtArgs args, String key, double defaultValue) {
        return args.view.method_71422(key, defaultValue);
    }

    public static String getStringOrDefault(ReadNbtArgs args, String key, String defaultValue) {
        return args.view.method_71428(key, defaultValue);
    }

    public static int[] getIntArrayOrDefault(ReadNbtArgs args, String key, int[] defaultValue) {
        return args.view.method_71442(key).orElse(defaultValue);
    }

    public static boolean isEmpty(NbtRWArgs args) {
        if (args instanceof WriteNbtArgs)
            return ((WriteNbtArgs) args).view.method_71457();
        else
            return true;
    }

    public static void put(WriteNbtArgs args, String key, NbtRWArgs other) {
        putCompound(args, key, other.nbt);
    }

    public static NbtRWArgs get(ReadNbtArgs args, String key) {
        return new NbtRWArgs(getCompound(args, key));
    }

    public static void putCompound(WriteNbtArgs args, String key, class_2487 other) {
        args.view.method_71468(key, class_2487.field_25128, other);
    }

    public static class_2487 getCompound(ReadNbtArgs args, String key) {
        return args.view.method_71426(key, class_2487.field_25128).orElse(NbtUtil.create());
    }
}
