package net.pitan76.mcpitanlib.api.client.render.block.entity.v2;

import net.minecraft.class_11954;
import net.pitan76.mcpitanlib.api.client.registry.CompatRegistryClient;
import net.pitan76.mcpitanlib.api.client.render.block.entity.event.CompatBlockEntityRendererConstructArgs;
import net.pitan76.mcpitanlib.api.tile.CompatBlockEntity;

public abstract class CompatBlockEntityRenderer<T extends CompatBlockEntity> implements net.pitan76.mcpitanlib.api.client.render.block.entity.CompatBlockEntityRenderer<T, class_11954> {

    @Deprecated
    public CompatRegistryClient.BlockEntityRendererFactory.Context ctx;

    public CompatBlockEntityRenderer(CompatBlockEntityRendererConstructArgs args) {

    }

    public CompatBlockEntityRenderer(CompatRegistryClient.BlockEntityRendererFactory.Context ctx) {
        this.ctx = ctx;
    }

    @Override
    public class_11954 method_74335() {
        return new class_11954();
    }
}
