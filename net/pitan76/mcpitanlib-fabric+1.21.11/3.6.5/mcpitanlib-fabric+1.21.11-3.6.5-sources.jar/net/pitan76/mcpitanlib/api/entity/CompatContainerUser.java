package net.pitan76.mcpitanlib.api.entity;

import net.minecraft.class_11565;
import net.minecraft.class_1309;
import net.minecraft.class_1657;

public class CompatContainerUser {
    protected class_11565 containerUser;

    public CompatContainerUser(class_11565 containerUser) {
        this.containerUser = containerUser;
    }

    public double getContainerInteractionRange() {
        return containerUser.method_72381();
    }

    public class_1309 asLivingEntity() {
        return containerUser.method_72382();
    }

    public boolean isPlayer() {
        return containerUser instanceof class_1657;
    }

    public Player asPlayer() {
        return new Player((class_1657) containerUser);
    }

    @Deprecated
    public class_11565 getRaw() {
        return containerUser;
    }
}
