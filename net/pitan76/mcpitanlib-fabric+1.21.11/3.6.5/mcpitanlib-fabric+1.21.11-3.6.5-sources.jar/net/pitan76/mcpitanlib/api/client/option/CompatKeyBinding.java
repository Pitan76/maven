package net.pitan76.mcpitanlib.api.client.option;

import net.minecraft.class_2561;
import net.minecraft.class_304;
import net.pitan76.mcpitanlib.api.util.CompatIdentifier;

import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

public class CompatKeyBinding {
    private final class_304 keyBinding;
    public static final Map<CompatIdentifier, class_304.class_11900> categories = new HashMap<>();

    public CompatKeyBinding(class_304 keyBinding) {
        this.keyBinding = keyBinding;
    }

    public CompatKeyBinding(String translationKey, int defaultKeyCode, CompatIdentifier category) {
        class_304.class_11900 cat;

        if (categories.containsKey(category)) {
            cat = categories.get(category);
        } else {
            cat = class_304.class_11900.method_74698(category.toMinecraft());
            categories.put(category, cat);
        }

        this.keyBinding = new class_304(translationKey, defaultKeyCode, cat);
    }

    public CompatKeyBinding(String translationKey, int defaultKeyCode) {
        String[] parts = translationKey.split("\\.");
        if (Objects.equals(parts[0], "key") && parts.length == 3) {
            CompatIdentifier category = CompatIdentifier.of(parts[1], "main");
            class_304.class_11900 cat;

            if (categories.containsKey(category)) {
                cat = categories.get(category);
            } else {
                cat = class_304.class_11900.method_74698(category.toMinecraft());
                categories.put(category, cat);
            }

            this.keyBinding = new class_304(translationKey, defaultKeyCode, cat);
        } else {
            throw new IllegalArgumentException("Cannot infer category from translation key: " + translationKey);
        }
    }

    public String getTranslationKey() {
        return keyBinding.method_1428();
    }

    public class_2561 getBoundKeyLocalizedText() {
        return keyBinding.method_16007();
    }

    public int getDefaultKeyCode() {
        return keyBinding.method_1429().method_1444();
    }

    public static CompatKeyBinding of(String translationKey, int defaultKeyCode, CompatIdentifier category) {
        return new CompatKeyBinding(translationKey, defaultKeyCode, category);
    }

    public static CompatKeyBinding of(String translationKey, int defaultKeyCode) {
        return new CompatKeyBinding(translationKey, defaultKeyCode);
    }

    public class_304 toMinecraft() {
        return keyBinding;
    }

    public class_304 getRaw() {
        return keyBinding;
    }
}
