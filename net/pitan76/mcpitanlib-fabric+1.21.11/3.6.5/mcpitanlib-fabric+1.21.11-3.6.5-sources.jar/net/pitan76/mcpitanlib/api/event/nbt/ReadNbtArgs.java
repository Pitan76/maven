package net.pitan76.mcpitanlib.api.event.nbt;

import net.minecraft.class_11368;
import net.minecraft.class_2487;
import net.minecraft.class_7225;
import net.pitan76.mcpitanlib.api.registry.CompatRegistryLookup;
import net.pitan76.mcpitanlib.core.mc1216.NbtDataConverter;

public class ReadNbtArgs extends NbtRWArgs {
    @Deprecated
    public class_11368 view;

    @Deprecated
    public ReadNbtArgs(class_2487 nbt, class_7225.class_7874 wrapperLookup) {
        super(nbt, wrapperLookup);
    }

    public ReadNbtArgs(class_2487 nbt) {
        super(nbt);
        if (registryLookup == null)
            registryLookup = new CompatRegistryLookup();
        view = NbtDataConverter.nbt2readData(nbt, registryLookup);
    }

    public ReadNbtArgs(class_2487 nbt, CompatRegistryLookup registryLookup) {
        super(nbt, registryLookup);
        view = NbtDataConverter.nbt2readData(nbt, registryLookup);
    }

    @Deprecated
    public ReadNbtArgs(class_2487 nbt, class_11368 view) {
        this(nbt);
        this.view = view;
    }

    @Deprecated
    public ReadNbtArgs(class_2487 nbt, class_11368 view, CompatRegistryLookup registryLookup) {
        this(nbt, registryLookup);
        this.view = view;
    }

    @Override
    public boolean isViewEmpty() {
        return view == null;
    }

    @Override
    public NbtRWArgs copy() {
        return new ReadNbtArgs(nbt.method_10553(), view, registryLookup);
    }

    public ReadNbtArgs(net.pitan76.mcpitanlib.midohra.nbt.NbtCompound nbt, CompatRegistryLookup registryLookup) {
        this(nbt.toMinecraft(), registryLookup);
    }

    public ReadNbtArgs(net.pitan76.mcpitanlib.midohra.nbt.NbtCompound nbt) {
        this(nbt.toMinecraft());
    }
}
