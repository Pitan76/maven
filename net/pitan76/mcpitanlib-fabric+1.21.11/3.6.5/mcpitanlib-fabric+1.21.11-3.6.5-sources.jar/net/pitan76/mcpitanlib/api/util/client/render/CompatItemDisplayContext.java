package net.pitan76.mcpitanlib.api.util.client.render;

import net.minecraft.class_811;
import net.pitan76.mcpitanlib.api.util.CompatStringIdentifiable;

public class CompatItemDisplayContext implements CompatStringIdentifiable {
    private final class_811 context;

    public static final CompatItemDisplayContext NONE = of(class_811.field_4315);
    public static final CompatItemDisplayContext THIRD_PERSON_LEFT_HAND = of(class_811.field_4323);
    public static final CompatItemDisplayContext THIRD_PERSON_RIGHT_HAND = of(class_811.field_4320);
    public static final CompatItemDisplayContext FIRST_PERSON_LEFT_HAND = of(class_811.field_4321);
    public static final CompatItemDisplayContext FIRST_PERSON_RIGHT_HAND = of(class_811.field_4322);
    public static final CompatItemDisplayContext HEAD = of(class_811.field_4316);
    public static final CompatItemDisplayContext GUI = of(class_811.field_4317);
    public static final CompatItemDisplayContext GROUND = of(class_811.field_4318);
    public static final CompatItemDisplayContext FIXED = of(class_811.field_4319);
    public static final CompatItemDisplayContext ON_SHELF = of(class_811.field_61988);

    public CompatItemDisplayContext(class_811 context) {
        this.context = context;
    }

    public static CompatItemDisplayContext of(class_811 context) {
        return new CompatItemDisplayContext(context);
    }

    public class_811 getContext() {
        return context;
    }

    public String getName() {
        return context.name();
    }

    @Override
    public String asString_compat() {
        return getName();
    }
}
