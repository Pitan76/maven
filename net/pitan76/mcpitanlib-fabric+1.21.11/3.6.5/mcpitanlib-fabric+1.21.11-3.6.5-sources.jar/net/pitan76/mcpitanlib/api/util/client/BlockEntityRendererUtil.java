package net.pitan76.mcpitanlib.api.util.client;

import net.minecraft.class_5614;
import net.pitan76.mcpitanlib.api.client.registry.CompatRegistryClient;

public class BlockEntityRendererUtil {
    public static class_5614.class_5615 convert(CompatRegistryClient.BlockEntityRendererFactory.Context ctx) {
        return new class_5614.class_5615(ctx.getRenderDispatcher(), ctx.getRenderManager(), ctx.getItemModelManager(), ctx.getItemRenderer(), ctx.getEntityRenderDispatcher(), ctx.getLayerRenderDispatcher(), ctx.getTextRenderer(), ctx.getSpriteHolder(), ctx.getPlayerSkinRenderCache());
    }

    public static CompatRegistryClient.BlockEntityRendererFactory.Context convert(class_5614.class_5615 ctx) {
        return new CompatRegistryClient.BlockEntityRendererFactory.Context(ctx.comp_4534(), ctx.comp_4535(), ctx.comp_4536(), ctx.comp_4537(), ctx.comp_4538(), ctx.comp_4539(), ctx.comp_4540(), ctx.comp_4541(), ctx.comp_4655());
    }
}
