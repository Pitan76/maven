package net.pitan76.mcpitanlib.api.util.client.render;

import net.minecraft.class_10442;
import net.minecraft.class_10444;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_310;
import net.pitan76.mcpitanlib.api.client.render.block.entity.event.BlockEntityRenderEvent;

/**
 * Cross-version utility for rendering items in block entity renderers.
 */
public class CompatItemRenderUtil {
    /**
     * Renders an ItemStack in FIXED transform mode.
     */
    public static void renderItemFixed(class_1799 stack, BlockEntityRenderEvent<?> e, class_1937 world) {
        renderItem(stack, CompatItemDisplayContext.FIXED, e, world);
    }

    /**
     * Renders an ItemStack
     */
    public static void renderItem(class_1799 stack, CompatItemDisplayContext displayContext, BlockEntityRenderEvent<?> e, class_1937 world) {
        class_10442 manager = e.ctx != null ? e.ctx.getItemModelManager() : class_310.method_1551().method_65386();

        class_10444 state = new class_10444();
        manager.method_65598(state, stack, displayContext.getContext(), world, null, 0);

        int light = e.getLight();
        if (light == 0) light = 0xF000F0; // full-bright fallback if not populated by MCPitanLib
        int overlay = e.getOverlay();

        state.method_65604(e.matrices, e.getQueue(), light, overlay, 0);
    }

    public static void renderItemFixed(net.pitan76.mcpitanlib.midohra.item.ItemStack stack, BlockEntityRenderEvent<?> e, net.pitan76.mcpitanlib.midohra.world.World world) {
        renderItemFixed(stack.toMinecraft(), e, world.toMinecraft());
    }

    public static void renderItem(net.pitan76.mcpitanlib.midohra.item.ItemStack stack, CompatItemDisplayContext displayContext, BlockEntityRenderEvent<?> e, net.pitan76.mcpitanlib.midohra.world.World world) {
        renderItem(stack.toMinecraft(), displayContext, e, world.toMinecraft());
    }
}
