package net.pitan76.mcpitanlib.api.client.event.listener;

import net.minecraft.class_11658;
import net.minecraft.class_243;
import net.minecraft.class_4184;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_4604;
import net.minecraft.class_638;
import net.minecraft.class_757;
import net.minecraft.class_761;
import net.minecraft.class_765;
import net.minecraft.class_7833;
import net.minecraft.class_9779;
import net.minecraft.client.render.*;
import net.pitan76.mcpitanlib.api.util.client.ClientUtil;
import org.jetbrains.annotations.Nullable;
import org.joml.Matrix4f;

public class WorldRenderContextImpl implements WorldRenderContext {

    public class_761 worldRenderer;
    public class_4587 matrixStack;
    public float tickDelta;
    public class_4184 camera;
    public class_757 gameRenderer;
    public class_765 lightmapTextureManager;
    public Matrix4f projectionMatrix;
    public class_638 world;
    public boolean advancedTranslucency;
    public @Nullable class_4597 consumers;
    public @Nullable class_4604 frustum;

    @Override
    public class_761 getWorldRenderer() {
        return worldRenderer;
    }

    @Override
    public class_4587 getMatrixStack() {
        return matrixStack;
    }

    @Override
    public float getTickDelta() {
        return tickDelta;
    }

    @Override
    public class_4184 getCamera() {
        if (camera == null) {
            return getGameRenderer().method_19418();
        }
        return camera;
    }

    @Override
    public class_757 getGameRenderer() {
        if (gameRenderer == null) {
            return ClientUtil.getGameRenderer();
        }
        return gameRenderer;
    }

    @Override
    public class_765 getLightmapTextureManager() {
        return lightmapTextureManager;
    }

    @Override
    public Matrix4f getProjectionMatrix() {
        return projectionMatrix;
    }

    @Override
    public class_638 getWorld() {
        if (world == null) {
            return ClientUtil.getWorld();
        }
        return world;
    }

    @Override
    public boolean isAdvancedTranslucency() {
        return advancedTranslucency;
    }

    @Override
    public @Nullable class_4597 getConsumers() {
        return consumers;
    }

    @Override
    public @Nullable class_4604 getFrustum() {
        return frustum;
    }

    public void prepare(class_757 gameRenderer, class_761 worldRenderer, class_11658 worldRenderState, @Nullable class_638 world, class_9779 tickCounter, boolean renderBlockOutline, class_4184 camera, Matrix4f positionMatrix, Matrix4f matrix4f, Matrix4f projectionMatrix) {
        this.gameRenderer = gameRenderer;
        this.worldRenderer = worldRenderer;
        this.world = world;
        this.camera = camera;
        this.matrixStack = new class_4587();
        this.matrixStack.method_34425(projectionMatrix);
        this.matrixStack.method_22903();

        matrixStack.method_22907(class_7833.field_40716.rotationDegrees(-camera.method_19330()));
        matrixStack.method_22907(class_7833.field_40714.rotationDegrees(camera.method_19329()));

        class_243 camPos = camera.method_71156();
        matrixStack.method_22904(-camPos.field_1352, -camPos.field_1351, -camPos.field_1350);

        this.matrixStack.method_22909();

        this.projectionMatrix = projectionMatrix;;
        this.tickDelta = tickCounter.method_60636();
        this.lightmapTextureManager = gameRenderer.method_22974();
        this.frustum = worldRenderer.method_62222();
    }
}
