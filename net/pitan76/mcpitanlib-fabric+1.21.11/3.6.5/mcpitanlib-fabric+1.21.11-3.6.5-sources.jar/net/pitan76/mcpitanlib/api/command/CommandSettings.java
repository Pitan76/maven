package net.pitan76.mcpitanlib.api.command;

import net.minecraft.class_12087;
import net.minecraft.class_12094;
import net.minecraft.class_2168;

public class CommandSettings {
    private int permissionLevel = -1;
    private ICustom iCustom = null;

    private class_12087.class_12089 _level = null;

    public boolean requires(class_2168 source) {
        if (customRequires(source)) {
            if (permissionLevel == -1) return true;
            if (_level == null)
                _level = new class_12087.class_12089(class_12094.method_75027(permissionLevel));

            return source.method_75037().hasPermission(_level);
        }
        return false;
    }

    private boolean customRequires(class_2168 source) {
        if (iCustom == null) return true;
        return iCustom.custom(source);
    }

    public CommandSettings permissionLevel(int level) {
        this.permissionLevel = level;
        return this;
    }

    public CommandSettings custom(ICustom iCustom) {
        this.iCustom = iCustom;
        return this;
    }

    @FunctionalInterface
    public interface ICustom {
        boolean custom(class_2168 source);
    }
}
