package net.pitan76.mcpitanlib.api.client.event.listener;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_12249;
import net.minecraft.class_1297;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_239;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import net.minecraft.class_3965;
import net.minecraft.class_4184;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_4604;
import net.minecraft.class_638;
import net.minecraft.class_757;
import net.minecraft.class_761;
import net.minecraft.class_765;
import net.minecraft.client.render.*;
import net.pitan76.mcpitanlib.api.util.VoxelShapeUtil;
import net.pitan76.mcpitanlib.api.util.client.render.VertexRenderingUtil;
import net.pitan76.mcpitanlib.midohra.client.render.CameraWrapper;
import org.jetbrains.annotations.Nullable;
import org.joml.Matrix4f;

import java.util.Objects;
import java.util.Optional;

public interface WorldRenderContext {

    class_761 getWorldRenderer();

    class_4587 getMatrixStack();

    float getTickDelta();

    class_4184 getCamera();

    class_757 getGameRenderer();

    class_765 getLightmapTextureManager();

    @Deprecated
    Matrix4f getProjectionMatrix();

    class_638 getWorld();

    @Deprecated
    boolean isAdvancedTranslucency();

    @Nullable class_4597 getConsumers();
    @Nullable class_4604 getFrustum();

    @Environment(EnvType.CLIENT)
    interface BlockOutlineContext {
        @Deprecated
        class_4588 vertexConsumer();

        class_1297 entity();

        double cameraX();

        double cameraY();

        double cameraZ();

        class_2338 blockPos();

        class_2680 blockState();
    }

    default class_239 getHitResult() {
        return class_310.method_1551().field_1765;
    }

    default Optional<class_2680> getBlockState() {
        return Optional.ofNullable(getWorld().method_8320(getBlockPos().orElse(null)));
    }

    default Optional<class_2338> getBlockPos() {
        return Optional.ofNullable(((class_3965) getHitResult()).method_17777());
    }

    default boolean isBlockType() {
        return getHitResultType() == class_239.class_240.field_1332;
    }

    default class_239.class_240 getHitResultType() {
        return getHitResult().method_17783();
    }

    default Optional<class_265> getOutlineShape() {
        return getBlockState().map(blockState -> blockState.method_26218(getWorld(),
                getBlockPos().orElse(null)));
    }

    default void push() {
        getMatrixStack().method_22903();
    }

    default void translate(double x, double y, double z) {
        getMatrixStack().method_22904(x, y, z);
    }

    default void pop() {
        getMatrixStack().method_22909();
    }

    default Optional<class_4588> getVertexConsumer() {
        if (getConsumers() == null)
            return Optional.empty();

        return Optional.of(Objects.requireNonNull(getConsumers()).method_73477(class_12249.method_76015()));
    }

    default void drawBox(float red, float green, float blue, float alpha) {
        Optional<class_265> outlineShape = getOutlineShape();
        if (!outlineShape.isPresent()) return;

        drawBox(VoxelShapeUtil.getBoundingBox(outlineShape.get()), red, green, blue, alpha);
    }

    default void drawBox(class_238 box, float red, float green, float blue, float alpha) {
        Optional<class_4588> vertexConsumer = getVertexConsumer();

        if (!vertexConsumer.isPresent())
            return;

        class_4588 consumer = vertexConsumer.get();

        double x1 = box.field_1323;
        double y1 = box.field_1322;
        double z1 = box.field_1321;
        double x2 = box.field_1320;
        double y2 = box.field_1325;
        double z2 = box.field_1324;

        VertexRenderingUtil.drawBox(getMatrixStack(), consumer, x1, y1, z1, x2, y2, z2, red, green, blue, alpha);
    }

    default CameraWrapper getCameraWrapper() {
        return CameraWrapper.of(getCamera());
    }
}
