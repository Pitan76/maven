package net.pitan76.mcpitanlib.api.event.v0.event;

import net.minecraft.class_1282;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.pitan76.mcpitanlib.api.entity.Player;

public class LivingHurtEvent {
    public class_1309 entity;
    public class_1282 damageSource;
    public float damageAmount;

    public LivingHurtEvent(class_1309 entity, class_1282 damageSource, float damageAmount) {
        this.entity = entity;
        this.damageSource = damageSource;
        this.damageAmount = damageAmount;
    }

    public class_1309 getEntity() {
        return entity;
    }

    public class_1282 getDamageSource() {
        return damageSource;
    }

    public float getDamageAmount() {
        return damageAmount;
    }

    public class_1297 getAttacker() {
        return damageSource.method_5529();
    }

    public class_1297 getSource() {
        return damageSource.method_5526();
    }

    public boolean isDirect() {
        return damageSource.method_60489();
    }

    public boolean isPlayerAttacker() {
        return getAttacker() instanceof class_1657;
    }

    public class_1657 getPlayerEntityAttacker() {
        return (class_1657) getAttacker();
    }

    public Player getPlayerAttacker() {
        return new Player(getPlayerEntityAttacker());
    }

    public class_1937 getWorld() {
        return entity.method_73183();
    }

    public boolean isClient() {
        return getWorld().method_8608();
    }

    public class_1799 getWeaponStack() {
        return getAttacker().method_59958();
    }

    public class_1792 getWeaponItem() {
        return getWeaponStack().method_7909();
    }

    public boolean isWeaponEmpty() {
        return getWeaponStack().method_7960();
    }

    public boolean isWeaponItemEqual(class_1792 item) {
        if (isWeaponEmpty()) return false;
        return getWeaponItem() == item;
    }
}
