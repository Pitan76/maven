package net.pitan76.mcpitanlib.api.client.render.block.entity;

import net.minecraft.class_11659;
import net.minecraft.class_11954;
import net.minecraft.class_12075;
import net.minecraft.class_243;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_827;
import net.pitan76.mcpitanlib.api.client.render.block.entity.event.BlockEntityRenderEvent;
import net.pitan76.mcpitanlib.api.tile.CompatBlockEntity;

@Deprecated
public interface CompatBlockEntityRenderer<T extends CompatBlockEntity, S extends class_11954> extends class_827<T, S> {
    void render(BlockEntityRenderEvent<T> event);

    default void render(T entity, float tickProgress, class_4587 matrices, class_4597 vertexConsumers, int light, int overlay, class_243 cameraPos) {
        render(new BlockEntityRenderEvent<>(this, entity, tickProgress, matrices, vertexConsumers, light, overlay));
    }

    @Override
    default void method_3569(S state, class_4587 matrices, class_11659 queue, class_12075 cameraState) {
        render(new BlockEntityRenderEvent<>(this, state, matrices, queue, cameraState));
    }

    default boolean rendersOutsideBoundingBoxOverride(T blockEntity) {
        return class_827.super.method_3563();
    }

    default int getRenderDistanceOverride() {
        return class_827.super.method_33893();
    }

    @Deprecated
    @Override
    default boolean method_3563() {
        return rendersOutsideBoundingBoxOverride(null);
    }

    @Deprecated
    @Override
    default int method_33893() {
        return getRenderDistanceOverride();
    }
}
