package net.pitan76.mcpitanlib.api.world;

import net.minecraft.class_18;
import net.minecraft.class_2487;
import net.pitan76.mcpitanlib.api.event.nbt.ReadNbtArgs;
import net.pitan76.mcpitanlib.api.event.nbt.WriteNbtArgs;

public abstract class CompatiblePersistentState extends class_18 {
    // 1.16
    public CompatiblePersistentState(String key) {
        super();
    }

    public CompatiblePersistentState() {
        super();
    }

    // 1.16
    @Deprecated
    public void readNbt(class_2487 tag) {
        readNbt(new ReadNbtArgs(tag));
    }

    public abstract void readNbt(ReadNbtArgs args);

    public abstract class_2487 writeNbt(WriteNbtArgs args);

    @Deprecated
    @Override
    public void method_80() {
        callMarkDirty();
    }

    public void callMarkDirty() {
        super.method_80();
    }

    @Deprecated
    @Override
    public void method_78(boolean dirty) {
        callSetDirty(dirty);
    }

    public void callSetDirty(boolean dirty) {
        super.method_78(dirty);
    }
}
