package net.pitan76.mcpitanlib.api.entity;

import net.minecraft.class_11368;
import net.minecraft.class_11372;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_239;
import net.minecraft.class_2487;
import net.minecraft.class_2945;
import net.minecraft.class_3857;
import net.minecraft.class_3966;
import net.pitan76.mcpitanlib.api.event.entity.CollisionEvent;
import net.pitan76.mcpitanlib.api.event.entity.EntityHitEvent;
import net.pitan76.mcpitanlib.api.event.entity.InitDataTrackerArgs;
import net.pitan76.mcpitanlib.api.event.nbt.ReadNbtArgs;
import net.pitan76.mcpitanlib.api.event.nbt.WriteNbtArgs;
import net.pitan76.mcpitanlib.api.util.ItemStackUtil;
import net.pitan76.mcpitanlib.core.mc1216.NbtDataConverter;
import net.pitan76.mcpitanlib.midohra.entity.IEntityM;

public abstract class CompatThrownItemEntity extends class_3857 implements IEntityM {

    public CompatThrownItemEntity(class_1299<? extends class_3857> entityType, class_1937 world) {
        super(entityType, world);
    }

    public CompatThrownItemEntity(class_1299<? extends class_3857> entityType, double d, double e, double f, class_1937 world) {
        super(entityType, d, e, f, world, ItemStackUtil.empty());
    }

    public CompatThrownItemEntity(class_1299<? extends class_3857> entityType, class_1309 livingEntity, class_1937 world) {
        super(entityType, livingEntity, world, ItemStackUtil.empty());
    }

    public abstract class_1792 getDefaultItemOverride();

    @Deprecated
    @Override
    protected class_1792 method_16942() {
        return getDefaultItemOverride();
    }

    public class_1799 callGetItem() {
        return super.method_7495();
    }

    @Deprecated
    @Override
    public class_1799 method_7495() {
        return callGetItem();
    }

    public void callSetItem(class_1799 stack) {
        super.method_16940(stack);
    }

    @Deprecated
    @Override
    public void method_16940(class_1799 stack) {
        callSetItem(stack);
    }

    public void callHandleStatus(byte status) {
        super.method_5711(status);
    }

    @Deprecated
    @Override
    public void method_5711(byte status) {
        callHandleStatus(status);
    }

    public void onEntityHit(EntityHitEvent event) {
        super.method_7454(event.entityHitResult);
    }

    @Deprecated
    @Override
    protected void method_7454(class_3966 entityHitResult) {
        onEntityHit(new EntityHitEvent(entityHitResult));
    }

    public void onCollision(CollisionEvent event) {
        super.method_7488(event.hitResult);
    }

    @Deprecated
    @Override
    protected void method_7488(class_239 hitResult) {
        onCollision(new CollisionEvent(hitResult));
    }

    // ------------------ ExtendEntity ------------------

    @Deprecated
    @Override
    public void method_5693(class_2945.class_9222 builder) {
        initDataTracker(new InitDataTrackerArgs(builder, field_6011));
    }

    public void initDataTracker(InitDataTrackerArgs args) {
        super.method_5693(args.getBuilder());
    }

    public void readCustomDataFromNbt(ReadNbtArgs nbt) {
        super.method_5749(nbt.view);
    }

    public void writeCustomDataToNbt(WriteNbtArgs nbt) {
        super.method_5652(nbt.view);
    }

    @Deprecated
    @Override
    protected void method_5749(class_11368 view) {
        class_2487 nbt = NbtDataConverter.data2nbt(view);
        readCustomDataFromNbt(new ReadNbtArgs(nbt, view));
    }

    @Deprecated
    @Override
    protected void method_5652(class_11372 view) {
        class_2487 nbt = new class_2487();
        writeCustomDataToNbt(new WriteNbtArgs(nbt, view));
        NbtDataConverter.nbt2writeData(nbt, view);
    }

    public void writeNbt(WriteNbtArgs args) {
        super.method_5647(args.view);
    }

    public void readNbt(ReadNbtArgs args) {
        super.method_5651(args.view);
    }

    @Deprecated
    @Override
    public void method_5647(class_11372 view) {
        super.method_5647(view);
        class_2487 nbt = new class_2487();
        writeNbt(new WriteNbtArgs(nbt, view));
        NbtDataConverter.nbt2writeData(nbt, view);
    }

    @Deprecated
    @Override
    public void method_5651(class_11368 view) {
        super.method_5651(view);
        class_2487 nbt = NbtDataConverter.data2nbt(view);
        readNbt(new ReadNbtArgs(nbt, view));
    }

    @Override
    public class_1937 method_73183() {
        return super.method_73183();
    }

    public void setStack(net.pitan76.mcpitanlib.midohra.item.ItemStack stack) {
        callSetItem(stack.toMinecraft());
    }

    public net.pitan76.mcpitanlib.midohra.item.ItemStack getStackM() {
        return net.pitan76.mcpitanlib.midohra.item.ItemStack.of(callGetItem());
    }
}
