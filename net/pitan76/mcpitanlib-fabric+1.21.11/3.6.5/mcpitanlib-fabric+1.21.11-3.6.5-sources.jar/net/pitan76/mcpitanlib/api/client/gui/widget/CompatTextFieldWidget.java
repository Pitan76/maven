package net.pitan76.mcpitanlib.api.client.gui.widget;

import net.minecraft.class_11905;
import net.minecraft.class_11908;
import net.minecraft.class_2561;
import net.minecraft.class_327;
import net.minecraft.class_342;
import net.pitan76.mcpitanlib.api.util.TextUtil;
import org.jetbrains.annotations.Nullable;

public class CompatTextFieldWidget extends class_342 {
    public CompatTextFieldWidget(class_327 textRenderer, int width, int height) {
        this(textRenderer, width, height, TextUtil.empty());
    }

    public CompatTextFieldWidget(class_327 textRenderer, int x, int y, int width, int height) {
        this(textRenderer, x, y, width, height, TextUtil.empty());
    }

    // ----

    public CompatTextFieldWidget(class_327 textRenderer, int width, int height, class_2561 text) {
        super(textRenderer, width, height, text);
    }

    public CompatTextFieldWidget(class_327 textRenderer, int x, int y, int width, int height, class_2561 text) {
        super(textRenderer, x, y, width, height, text);
    }

    public CompatTextFieldWidget(class_327 textRenderer, int x, int y, int width, int height, @Nullable class_342 copyFrom, class_2561 text) {
        super(textRenderer, x, y, width, height, copyFrom, text);
    }

    // ----

    @Deprecated
    @Override
    public void method_1858(boolean drawsBackground) {
        callSetDrawsBackground(drawsBackground);
    }

    public void callSetDrawsBackground(boolean drawsBackground) {
        super.method_1858(drawsBackground);
    }

    @Deprecated
    @Override
    public void method_25365(boolean focused) {
        callSetFocused(focused);
    }

    public void callSetFocused(boolean focused) {
        super.method_25365(focused);
    }

    @Deprecated
    @Override
    public void method_1856(boolean focusUnlocked) {
        callSetFocusUnlocked(focusUnlocked);
    }

    public void callSetFocusUnlocked(boolean focusUnlocked) {
        super.method_1856(focusUnlocked);
    }

    @Deprecated
    @Override
    public void method_1880(int maxLength) {
        callSetMaxLength(maxLength);
    }

    public void callSetMaxLength(int maxLength) {
        super.method_1880(maxLength);
    }

    @Deprecated
    @Override
    public void method_1852(String text) {
        callSetText(text);
    }

    public void callSetText(String text) {
        super.method_1852(text);
    }

    @Deprecated
    @Override
    public String method_1882() {
        return callGetText();
    }

    public String callGetText() {
        return super.method_1882();
    }

    @Deprecated
    @Override
    public void method_1888(boolean editable) {
        callSetEditable(editable);
    }

    public void callSetEditable(boolean editable) {
        super.method_1888(editable);
    }

    @Deprecated
    @Override
    public boolean method_25370() {
        return callIsFocused();
    }

    public boolean callIsFocused() {
        return super.method_25370();
    }

    @Deprecated
    @Override
    public boolean method_25404(class_11908 input) {
        return callKeyPressed(input.comp_4795(), input.comp_4796(), input.comp_4797());
    }

    public boolean callKeyPressed(int keyCode, int scanCode, int modifiers) {
        return super.method_25404(new class_11908(keyCode, scanCode, modifiers));
    }

    @Deprecated
    @Override
    public boolean method_16803(class_11908 input) {
        return callKeyReleased(input.comp_4795(), input.comp_4796(), input.comp_4797());
    }

    public boolean callKeyReleased(int keyCode, int scanCode, int modifiers) {
        return super.method_16803(new class_11908(keyCode, scanCode, modifiers));
    }

    @Deprecated
    @Override
    public boolean method_25400(class_11905 input) {
        return callCharTyped((char) input.comp_4793(), input.comp_4794());
    }

    public boolean callCharTyped(char chr, int modifiers) {
        return super.method_25400(new class_11905(chr, modifiers));
    }
}
