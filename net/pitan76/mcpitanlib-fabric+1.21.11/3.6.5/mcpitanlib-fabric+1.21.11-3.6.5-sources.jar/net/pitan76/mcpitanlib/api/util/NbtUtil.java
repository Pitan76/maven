package net.pitan76.mcpitanlib.api.util;

import com.mojang.datafixers.util.Pair;
import com.mojang.serialization.DataResult;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_2338;
import net.minecraft.class_2382;
import net.minecraft.class_243;
import net.minecraft.class_2481;
import net.minecraft.class_2487;
import net.minecraft.class_2489;
import net.minecraft.class_2494;
import net.minecraft.class_2497;
import net.minecraft.class_2499;
import net.minecraft.class_2503;
import net.minecraft.class_2509;
import net.minecraft.class_2516;
import net.minecraft.class_2519;
import net.minecraft.class_2520;
import net.minecraft.nbt.*;
import net.pitan76.mcpitanlib.api.registry.CompatRegistryLookup;
import net.pitan76.mcpitanlib.api.util.math.PosUtil;
import net.pitan76.mcpitanlib.api.util.math.Vec3dUtil;
import net.pitan76.mcpitanlib.api.util.math.Vec3iUtil;

import java.util.Optional;
import java.util.Set;
import java.util.UUID;

public class NbtUtil {

    /**
     * 新しいNbtCompoundを作成する。
     * @return NbtCompound
     */
    public static class_2487 create() {
        return new class_2487();
    }

    /**
     * 値を設定する。
     * @param nbt NbtCompound
     * @param key キー
     * @param value 値
     */
    public static void put(class_2487 nbt, String key, class_2487 value) {
        nbt.method_10566(key, value);
    }

    /**
     * 値を設定する。
     * @param nbt NbtCompound
     * @param key キー
     * @param value 値
     */
    public static void put(class_2487 nbt, String key, class_2520 value) {
        nbt.method_10566(key, value);
    }

    /**
     * 値を取得する。
     * @param nbt NbtCompound
     * @param key キー
     * @return 値
     */
    public static class_2487 get(class_2487 nbt, String key) {
        return nbt.method_68568(key);
    }

    /**
     * 値を削除する。
     * @param nbt NbtCompound
     * @param key キー
     */
    public static void remove(class_2487 nbt, String key) {
        nbt.method_10551(key);
    }

    /**
     * 値が存在するかどうかを取得する。
     * @param nbt NbtCompound
     * @param key キー
     * @return 値が存在するかどうか
     */
    public static boolean has(class_2487 nbt, String key) {
        return nbt.method_10545(key);
    }

    /**
     * 指定した型の値を取得する
     * @param nbt NbtCompound
     * @param key キー
     * @param clazz クラス
     * @param <T> 値
     */
    public static <T> T get(class_2487 nbt, String key, Class<T> clazz) {
        if (clazz == Integer.class) {
            return (T) Integer.valueOf(nbt.method_68083(key, 0));
        }
        if (clazz == String.class) {
            return (T) nbt.method_10558(key).orElse("");
        }
        if (clazz == Boolean.class) {
            return (T) Boolean.valueOf(nbt.method_68566(key, false));
        }
        if (clazz == Float.class) {
            return (T) Float.valueOf(nbt.method_66563(key, 0f));
        }
        if (clazz == Double.class) {
            return (T) Double.valueOf(nbt.method_68563(key, 0d));
        }
        if (clazz == Long.class) {
            return (T) Long.valueOf(nbt.method_68080(key, 0l));
        }
        if (clazz == class_2487.class) {
            return (T) nbt.method_68568(key);
        }
        if (clazz == class_2499.class) {
            return (T) nbt.method_10580(key);
        }
        if (clazz == Byte.class) {
            return (T) Byte.valueOf(nbt.method_68562(key, (byte) 0));
        }
        if (clazz == Short.class) {
            return (T) Short.valueOf(nbt.method_68565(key, (short) 0));
        }
        if (clazz == UUID.class) {
            return (T) UUID.fromString(nbt.method_10558(key).orElse(""));
        }
        return null;
    }

    /**
     * 値を設定する。
     * @param nbt NbtCompound
     * @param key キー
     * @param value 値
     */
    public static <T> void set(class_2487 nbt, String key, T value) {
        if (value instanceof Integer) {
            nbt.method_10569(key, (Integer) value);
            return;
        }
        if (value instanceof String) {
            nbt.method_10582(key, (String) value);
            return;
        }
        if (value instanceof Boolean) {
            nbt.method_10556(key, (Boolean) value);
            return;
        }
        if (value instanceof Float) {
            nbt.method_10548(key, (Float) value);
            return;
        }
        if (value instanceof Double) {
            nbt.method_10549(key, (Double) value);
            return;
        }
        if (value instanceof Long) {
            nbt.method_10544(key, (Long) value);
            return;
        }
        if (value instanceof class_2487) {
            nbt.method_10566(key, (class_2487) value);
            return;
        }
        if (value instanceof class_2499) {
            nbt.method_10566(key, (class_2499) value);
            return;
        }
        if (value instanceof Byte) {
            nbt.method_10567(key, (Byte) value);
            return;
        }
        if (value instanceof Short) {
            nbt.method_10575(key, (Short) value);
            return;
        }
        if (value instanceof UUID) {
            nbt.method_10582(key, value.toString());
            return;
        }
    }

    /**
     * キーの一覧を取得する。
     * @param nbt NbtCompound
     * @return キーの一覧
     */
    public static Set<String> getKeys(class_2487 nbt) {
        return nbt.method_10541();
    }

    /**
     * NbtListを取得する。
     * @return NbtList
     */
    public static class_2499 getList(class_2487 nbt, String key) {
        return (class_2499) nbt.method_10580(key);
    }

    /**
     * NbtListを取得する。
     * @return NbtList
     */
    public static class_2499 getList(class_2487 nbt, String key, int type) {
        return nbt.method_68569(key);
    }

    /**
     * NbtCompoundのリストを取得する。
     * @return NbtList
     */
    public static class_2499 getNbtCompoundList(class_2487 nbt, String key) {
        return nbt.method_68569(key);
    }

    /**
     * NbtCompoundをコピーする。
     * @return NbtCompound
     */
    public static class_2487 copy(class_2487 nbt) {
        return nbt.method_10553();
    }

    // Helper methods

    public static void putInt(class_2487 nbt, String key, int value) {
        set(nbt, key, value);
    }

    public static int getInt(class_2487 nbt, String key) {
        if (has(nbt, key))
            return get(nbt, key, Integer.class);
        return 0;
    }

    public static void putString(class_2487 nbt, String key, String value) {
        set(nbt, key, value);
    }

    public static String getString(class_2487 nbt, String key) {
        if (has(nbt, key))
            return get(nbt, key, String.class);
        return "";
    }

    public static void putBoolean(class_2487 nbt, String key, boolean value) {
        set(nbt, key, value);
    }

    public static boolean getBoolean(class_2487 nbt, String key) {
        if (has(nbt, key))
            return get(nbt, key, Boolean.class);
        return false;
    }

    public static void putFloat(class_2487 nbt, String key, float value) {
        set(nbt, key, value);
    }

    public static float getFloat(class_2487 nbt, String key) {
        if (has(nbt, key))
            return get(nbt, key, Float.class);
        return 0;
    }

    public static void putDouble(class_2487 nbt, String key, double value) {
        set(nbt, key, value);
    }

    public static double getDouble(class_2487 nbt, String key) {
        if (has(nbt, key))
            return get(nbt, key, Double.class);
        return 0;
    }

    public static void putLong(class_2487 nbt, String key, long value) {
        set(nbt, key, value);
    }

    public static long getLong(class_2487 nbt, String key) {
        if (has(nbt, key))
            return get(nbt, key, Long.class);
        return 0;
    }

    public static void putByte(class_2487 nbt, String key, byte value) {
        set(nbt, key, value);
    }

    public static byte getByte(class_2487 nbt, String key) {
        if (has(nbt, key))
            return get(nbt, key, Byte.class);
        return 0;
    }

    public static void putShort(class_2487 nbt, String key, short value) {
        set(nbt, key, value);
    }

    public static short getShort(class_2487 nbt, String key) {
        if (has(nbt, key))
            return get(nbt, key, Short.class);
        return 0;
    }

    public static void putUuid(class_2487 nbt, String key, UUID value) {
        set(nbt, key, value);
    }

    public static UUID getUuid(class_2487 nbt, String key) {
        if (has(nbt, key))
            return get(nbt, key, UUID.class);
        return null;
    }

    /**
     * BlockPosを設定する。
     * key: {
     *   "x": pos.getX(),
     *   "y": pos.getY(),
     *   "z": pos.getZ()
     * }
     *
     * @param nbt NbtCompound
     * @param key キー
     * @param pos BlockPos
     */
    public static void setBlockPos(class_2487 nbt, String key, class_2338 pos) {
        class_2487 posNbt = create();
        putInt(posNbt, "x", pos.method_10263());
        putInt(posNbt, "y", pos.method_10264());
        putInt(posNbt, "z", pos.method_10260());
        put(nbt, key, posNbt);
    }

    /**
     * BlockPosを取得する。
     *
     * @param nbt NbtCompound
     * @param key キー
     * @return BlockPos
     */
    public static class_2338 getBlockPos(class_2487 nbt, String key) {
        class_2487 posNbt = get(nbt, key);
        return PosUtil.flooredBlockPos(getInt(posNbt, "x"), getInt(posNbt, "y"), getInt(posNbt, "z"));
    }

    public static void putVec3i(class_2487 nbt, String key, class_2382 vec3i) {
        class_2487 vec3iNbt = create();
        putInt(vec3iNbt, "x", vec3i.method_10263());
        putInt(vec3iNbt, "y", vec3i.method_10264());
        putInt(vec3iNbt, "z", vec3i.method_10260());
        put(nbt, key, vec3iNbt);
    }

    public static class_2382 getVec3i(class_2487 nbt, String key) {
        class_2487 vec3iNbt = get(nbt, key);
        return Vec3iUtil.create(getInt(vec3iNbt, "x"), getInt(vec3iNbt, "y"), getInt(vec3iNbt, "z"));
    }

    public static void putVec3d(class_2487 nbt, String key, class_243 vec3d) {
        class_2487 vec3dNbt = create();
        putDouble(vec3dNbt, "x", vec3d.method_10216());
        putDouble(vec3dNbt, "y", vec3d.method_10214());
        putDouble(vec3dNbt, "z", vec3d.method_10215());
        put(nbt, key, vec3dNbt);
    }

    public static class_243 getVec3d(class_2487 nbt, String key) {
        class_2487 vec3dNbt = get(nbt, key);
        return Vec3dUtil.create(getDouble(vec3dNbt, "x"), getDouble(vec3dNbt, "y"), getDouble(vec3dNbt, "z"));
    }

    public static void putItemStack(class_2487 nbt, String key, class_1799 stack, CompatRegistryLookup registryLookup) {
        DataResult<class_2520> dataResult = class_1799.field_24671.encodeStart(class_2509.field_11560, stack);
        put(nbt, key, dataResult.getOrThrow());
    }

    public static Optional<class_1799> getItemStack(class_2487 nbt, String key, CompatRegistryLookup registryLookup) {
        class_2520 stackNbt = get(nbt, key);
        DataResult<Pair<class_1799, class_2520>> dataResult = class_1799.field_24671.decode(class_2509.field_11560, stackNbt);
        if (dataResult.error().isPresent()) return Optional.empty();

        Pair<class_1799, class_2520> pair = dataResult.getOrThrow();
        return Optional.ofNullable(pair.getFirst());
    }

    public static void putSimpleItemStack(class_2487 nbt, String key, class_1799 stack) {
        class_2487 stackNbt = create();
        putString(stackNbt, "id", ItemUtil.toID(stack.method_7909()).toString());
        putByte(stackNbt, "Count", (byte) ItemStackUtil.getCount(stack));

        class_2487 tagNbt = create();
        class_2487 componentsNbt = create();
        put(componentsNbt, "minecraft:custom_data", CustomDataUtil.getOrCreateNbt(stack));
        put(tagNbt, "components", componentsNbt);
        put(stackNbt, "tag", tagNbt);
        put(nbt, key, stackNbt);
    }

    public static Optional<class_1799> getSimpleItemStack(class_2487 nbt, String key) {
        if (!has(nbt, key)) return Optional.empty();
        class_2487 stackNbt = get(nbt, key);

        if (!has(stackNbt, "id") || !has(stackNbt, "Count")) return Optional.empty();
        class_1792 item = ItemUtil.fromId(CompatIdentifier.of(getString(stackNbt, "id")));
        int count = getByte(stackNbt, "Count");

        class_1799 stack = ItemStackUtil.create(item, count);

        if (has(stackNbt, "tag")) {
            class_2487 tagNbt = get(stackNbt, "tag");
            if (has(tagNbt, "components")) {
                class_2487 componentsNbt = get(tagNbt, "components");
                if (has(componentsNbt, "minecraft:custom_data")) {
                    CustomDataUtil.setNbt(stack, get(componentsNbt, "minecraft:custom_data"));
                }
            }
        }

        return Optional.of(stack);
    }

    public static class_2499 createNbtList() {
        return new class_2499();
    }

    public static int getIntOrDefault(class_2487 nbt, String key, int defaultValue) {
        if (has(nbt, key))
            return getInt(nbt, key);
        return defaultValue;
    }

    public static String getStringOrDefault(class_2487 nbt, String key, String defaultValue) {
        if (has(nbt, key))
            return getString(nbt, key);
        return defaultValue;
    }

    public static boolean getBooleanOrDefault(class_2487 nbt, String key, boolean defaultValue) {
        if (has(nbt, key))
            return getBoolean(nbt, key);
        return defaultValue;
    }

    public static float getFloatOrDefault(class_2487 nbt, String key, float defaultValue) {
        if (has(nbt, key))
            return getFloat(nbt, key);
        return defaultValue;
    }

    public static double getDoubleOrDefault(class_2487 nbt, String key, double defaultValue) {
        if (has(nbt, key))
            return getDouble(nbt, key);
        return defaultValue;
    }

    public static long getLongOrDefault(class_2487 nbt, String key, long defaultValue) {
        if (has(nbt, key))
            return getLong(nbt, key);
        return defaultValue;
    }

    public static byte getByteOrDefault(class_2487 nbt, String key, byte defaultValue) {
        if (has(nbt, key))
            return getByte(nbt, key);
        return defaultValue;
    }

    public static short getShortOrDefault(class_2487 nbt, String key, short defaultValue) {
        if (has(nbt, key))
            return getShort(nbt, key);
        return defaultValue;
    }

    public static UUID getUuidOrDefault(class_2487 nbt, String key, UUID defaultValue) {
        if (has(nbt, key))
            return getUuid(nbt, key);
        return defaultValue;
    }

    public static class_2520 getElement(class_2487 nbt, String key) {
        return nbt.method_10580(key);
    }

    public static void putElement(class_2487 nbt, String key, class_2520 element) {
        nbt.method_10566(key, element);
    }

    public static void setBlockPosDirect(class_2487 nbt, class_2338 pos) {
        putInt(nbt, "x", pos.method_10263());
        putInt(nbt, "y", pos.method_10264());
        putInt(nbt, "z", pos.method_10260());
    }

    public static class_2338 getBlockPosDirect(class_2487 nbt) {
        return PosUtil.flooredBlockPos(getInt(nbt, "x"), getInt(nbt, "y"), getInt(nbt, "z"));
    }

    public static void setVec3iDirect(class_2487 nbt, class_2382 vec3i) {
        putInt(nbt, "x", vec3i.method_10263());
        putInt(nbt, "y", vec3i.method_10264());
        putInt(nbt, "z", vec3i.method_10260());
    }

    public static class_2382 getVec3iDirect(class_2487 nbt) {
        return Vec3iUtil.create(getInt(nbt, "x"), getInt(nbt, "y"), getInt(nbt, "z"));
    }

    public static void setVec3dDirect(class_2487 nbt, class_243 vec3d) {
        putDouble(nbt, "x", vec3d.method_10216());
        putDouble(nbt, "y", vec3d.method_10214());
        putDouble(nbt, "z", vec3d.method_10215());
    }

    public static class_243 getVec3dDirect(class_2487 nbt) {
        return Vec3dUtil.create(getDouble(nbt, "x"), getDouble(nbt, "y"), getDouble(nbt, "z"));
    }

    public static void setVec3iDirect(class_2487 nbt, int x, int y, int z) {
        putInt(nbt, "x", x);
        putInt(nbt, "y", y);
        putInt(nbt, "z", z);
    }

    public static void setVec3dDirect(class_2487 nbt, double x, double y, double z) {
        putDouble(nbt, "x", x);
        putDouble(nbt, "y", y);
        putDouble(nbt, "z", z);
    }

    public static String asString(class_2520 nbt) {
        return nbt.method_68658().orElse("");
    }

    public static class_2519 createString(String string) {
        return class_2519.method_23256(string);
    }

    public static class_2497 createInt(int value) {
        return class_2497.method_23247(value);
    }

    public static class_2494 createFloat(float value) {
        return class_2494.method_23244(value);
    }

    public static class_2489 createDouble(double value) {
        return class_2489.method_23241(value);
    }

    public static class_2503 createLong(long value) {
        return class_2503.method_23251(value);
    }

    public static class_2481 createByte(byte value) {
        return class_2481.method_23233(value);
    }

    public static class_2516 createShort(short value) {
        return class_2516.method_23254(value);
    }

    public static void copyFrom(class_2487 source, class_2487 target) {
        target.method_10543(source);
    }
}
