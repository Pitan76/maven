package net.pitan76.mcpitanlib.api.client.registry.v2;

import net.minecraft.class_304;
import net.pitan76.mcpitanlib.api.util.CompatIdentifier;

public class KeybindingRegistry extends net.pitan76.mcpitanlib.api.client.registry.KeybindingRegistry {

    public static void registerWithNetwork(class_304 keyBinding, CompatIdentifier identifier) {
        registerWithNetwork(keyBinding, identifier.toMinecraft());
    }

    public static void registerOnLevelWithNetwork(class_304 keyBinding, CompatIdentifier identifier) {
        registerOnLevelWithNetwork(keyBinding, identifier.toMinecraft());
    }

    public static void registerWithNetwork(String translationKey, int code, String category, CompatIdentifier identifier) {
        registerWithNetwork(new class_304(translationKey, code, class_304.class_11900.method_74698(CompatIdentifier.of(category).toMinecraft())), identifier);
    }

    public static void registerOnLevelWithNetwork(String translationKey, int code, String category, CompatIdentifier identifier) {
        // TODO: categoryの互換性
        registerOnLevelWithNetwork(new class_304(translationKey, code, class_304.class_11900.method_74698(CompatIdentifier.of(category).toMinecraft())), identifier);
    }
}
