package net.pitan76.mcpitanlib.api.tile;

import net.minecraft.class_11368;
import net.minecraft.class_11372;
import net.minecraft.class_2338;
import net.minecraft.class_2487;
import net.minecraft.class_2591;
import net.minecraft.class_2595;
import net.minecraft.class_2596;
import net.minecraft.class_2602;
import net.minecraft.class_2622;
import net.minecraft.class_2680;
import net.minecraft.class_7225;
import net.pitan76.mcpitanlib.api.event.block.TileCreateEvent;
import net.pitan76.mcpitanlib.api.event.nbt.ReadNbtArgs;
import net.pitan76.mcpitanlib.api.event.nbt.WriteNbtArgs;
import net.pitan76.mcpitanlib.api.packet.UpdatePacketType;
import net.pitan76.mcpitanlib.api.registry.CompatRegistryLookup;
import net.pitan76.mcpitanlib.api.util.NbtUtil;
import net.pitan76.mcpitanlib.core.mc1216.NbtDataConverter;
import org.jetbrains.annotations.Nullable;

public class CompatChestBlockEntity extends class_2595 {
    protected CompatChestBlockEntity(class_2591<?> blockEntityType, class_2338 blockPos, class_2680 blockState) {
        super(blockEntityType, blockPos, blockState);
    }

    public CompatChestBlockEntity(class_2591<?> type, TileCreateEvent event) {
        this(type, event.getBlockPos(), event.getBlockState());
    }

    @Nullable
    @Override
    @Deprecated
    public class_2596<class_2602> method_38235() {
        switch (getUpdatePacketType().name) {
            case "BLOCK_ENTITY_UPDATE_S2C":
                return class_2622.method_38585(this);
        }
        return super.method_38235();
    }

    public UpdatePacketType getUpdatePacketType() {
        return UpdatePacketType.NONE;
    }

    public void writeNbt(WriteNbtArgs args) {

    }

    public void readNbt(ReadNbtArgs args) {

    }


    // deprecated

    /**
     * @deprecated Use {@link #writeNbt(WriteNbtArgs)} instead
     */
    @Deprecated
    public void writeNbtOverride(class_2487 nbt) {

    }

    /**
     * @deprecated Use {@link #readNbt(ReadNbtArgs)} instead
     */
    @Deprecated
    public void readNbtOverride(class_2487 nbt) {

    }

    @Deprecated
    private class_7225.class_7874 wrapperLookupCache;

    // ----

    @Override
    protected void method_11007(class_11372 view) {
        super.method_11007(view);
        class_2487 nbt = NbtUtil.create();
        writeNbt(nbt, this.method_10997().method_30349());
        writeNbt(new WriteNbtArgs(nbt, view, new CompatRegistryLookup(this.method_10997().method_30349())));
        NbtDataConverter.nbt2writeData(nbt, view);
    }

    @Override
    protected void method_11014(class_11368 view) {
        super.method_11014(view);
        class_2487 nbt = NbtDataConverter.data2nbt(view);
        readNbt(nbt, view.method_71414());
        readNbt(new ReadNbtArgs(nbt, view, new CompatRegistryLookup(view.method_71414())));
    }

    @Deprecated
    public void writeNbt(class_2487 nbt, class_7225.class_7874 registryLookup) {
        // deprecated
        wrapperLookupCache = registryLookup;
        writeNbtOverride(nbt);
        // ----
    }

    @Deprecated
    public void readNbt(class_2487 nbt, class_7225.class_7874 registryLookup) {
        // deprecated
        wrapperLookupCache = registryLookup;
        readNbtOverride(nbt);
        // ----
    }
}