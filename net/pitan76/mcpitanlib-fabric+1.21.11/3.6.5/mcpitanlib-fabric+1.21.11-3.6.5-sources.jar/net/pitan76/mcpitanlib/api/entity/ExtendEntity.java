package net.pitan76.mcpitanlib.api.entity;

import net.minecraft.class_11368;
import net.minecraft.class_11372;
import net.minecraft.class_1282;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1937;
import net.minecraft.class_2487;
import net.minecraft.class_2596;
import net.minecraft.class_2602;
import net.minecraft.class_2945;
import net.minecraft.class_3218;
import net.pitan76.mcpitanlib.api.nbt.NbtTag;
import net.pitan76.mcpitanlib.core.mc1216.NbtDataConverter;

public class ExtendEntity extends class_1297 {
    public ExtendEntity(class_1299<?> type, class_1937 world) {
        super(type, world);
    }

    @Deprecated
    @Override
    public void method_5693(class_2945.class_9222 builder) {
        initDataTracker();
    }

    @Override
    public boolean method_64397(class_3218 world, class_1282 source, float amount) {
        return false;
    }

    public void initDataTracker() {
    }

    public void readCustomDataFromNbt(class_2487 nbt) {

    }

    public void writeCustomDataToNbt(class_2487 nbt) {

    }

    public class_2596<class_2602> createSpawnPacket() {
        return null;
    }

    // 互換性用 (NbtTag型をOverrideすること)
    public void writeNbt(NbtTag nbt) {

    }

    public void readNbt(NbtTag nbt) {

    }

    @Deprecated
    @Override
    public void method_5647(class_11372 view) {
        super.method_5647(view);
        class_2487 nbt = new class_2487();
        writeNbt(NbtTag.from(nbt));
        NbtDataConverter.nbt2writeData(nbt, view);
    }

    @Deprecated
    @Override
    public void method_5651(class_11368 view) {
        super.method_5651(view);
        class_2487 nbt = NbtDataConverter.data2nbt(view);
        readNbt(NbtTag.from(nbt));
    }

    @Override
    protected void method_5749(class_11368 view) {
        class_2487 nbt = NbtDataConverter.data2nbt(view);
        readCustomDataFromNbt(nbt);
    }

    @Override
    protected void method_5652(class_11372 view) {
        class_2487 nbt = new class_2487();
        writeCustomDataToNbt(nbt);
        NbtDataConverter.nbt2writeData(nbt, view);
    }

    // 1.14
    public class_2487 toTag(class_2487 nbt) {
        this.writeNbt(NbtTag.from(nbt));
        return nbt;
    }

    public class_2487 fromTag(class_2487 nbt) {
        this.readNbt(NbtTag.from(nbt));
        return nbt;
    }

    @Override
    public class_1937 method_73183() {
        return super.method_73183();
    }
}