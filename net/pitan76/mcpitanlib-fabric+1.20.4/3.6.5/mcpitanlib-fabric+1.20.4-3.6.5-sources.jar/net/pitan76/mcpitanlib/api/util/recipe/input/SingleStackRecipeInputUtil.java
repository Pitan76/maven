package net.pitan76.mcpitanlib.api.util.recipe.input;

import net.minecraft.class_1799;
import net.minecraft.class_2586;
import net.minecraft.class_8181;
import net.pitan76.mcpitanlib.api.recipe.input.CompatRecipeInput;
import net.pitan76.mcpitanlib.api.util.ItemStackUtil;

import java.util.Optional;

public class SingleStackRecipeInputUtil {
    public static Optional<class_8181> get(CompatRecipeInput<?> input) {
        if (input.getInput() instanceof class_8181) {
            return Optional.of((class_8181) input.getInput());
        }
        return Optional.empty();
    }

    public static CompatRecipeInput<?> create(class_8181 input) {
        return new CompatRecipeInput<>(input);
    }

    public static CompatRecipeInput<?> create(class_1799 stack) {
        return new CompatRecipeInput<>(new class_8181() {
            private class_1799 itemStack = stack;

            @Override
            public void method_5431() {

            }

            @Override
            public class_1799 method_54079() {
                return itemStack;
            }

            @Override
            public class_1799 method_54078(int count) {
                ItemStackUtil.decrementCount(itemStack, count);
                return itemStack;
            }

            @Override
            public void method_54077(class_1799 stack) {
                this.itemStack = stack;
            }

            @Override
            public class_2586 method_54080() {
                return null;
            }
        });
    }

    public static class_1799 getStack(CompatRecipeInput<?> input) {
        Optional<class_8181> recipeInput = get(input);
        if (!recipeInput.isPresent()) return ItemStackUtil.empty();

        return recipeInput.get().method_5438(0);
    }
}
