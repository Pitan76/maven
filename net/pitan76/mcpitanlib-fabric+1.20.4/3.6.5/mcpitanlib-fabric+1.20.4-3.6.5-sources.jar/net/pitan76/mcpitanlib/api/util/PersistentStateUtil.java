package net.pitan76.mcpitanlib.api.util;

import net.minecraft.class_18;
import net.minecraft.class_1937;
import net.minecraft.class_2487;
import net.minecraft.class_26;
import net.minecraft.class_3218;
import net.minecraft.class_4284;
import net.minecraft.server.MinecraftServer;
import java.util.function.Function;
import java.util.function.Supplier;

public class PersistentStateUtil {
    public static <T extends class_18> T getOrCreate(class_26 manager, String id, Supplier<T> supplier, Function<class_2487, T> function) {
        class_18.class_8645<T> type = new class_18.class_8645<>(supplier, function, class_4284.field_19212);
        return manager.method_17924(type, id);
    }

    public static class_26 getManagerFromServer(MinecraftServer server) {
        return server.method_3847(class_1937.field_25179).method_17983();
    }

    public static class_26 getManagerFromWorld(class_3218 world) {
        return world.method_17983();
    }

    public static void markDirty(class_18 state) {
        state.method_80();
    }
}