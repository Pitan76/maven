package net.pitan76.mcpitanlib.api.recipe.v2;

import net.minecraft.class_1860;
import net.minecraft.class_1865;
import net.minecraft.class_2960;
import net.minecraft.class_3956;
import net.minecraft.class_8786;
import net.minecraft.recipe.*;
import net.pitan76.mcpitanlib.api.util.CompatIdentifier;
import net.pitan76.mcpitanlib.api.util.RecipeUtil;
import org.jetbrains.annotations.Nullable;

@Deprecated
public class CompatRecipeEntry<T extends class_1860<?>> {
    private final class_8786<T> entry;

    public String group = "";
    public RecipeUtil.CompatibilityCraftingRecipeCategory category = null;

    @Deprecated
    public CompatRecipeEntry(class_8786<T> entry) {
        this.entry = entry;
    }

    public CompatRecipeEntry(class_2960 id, String group, RecipeUtil.CompatibilityCraftingRecipeCategory category, T recipe) {
        this.entry = new class_8786<>(id, recipe);
        this.group = group;
        this.category = category;
    }

    public CompatRecipeEntry(CompatIdentifier id, String group, RecipeUtil.CompatibilityCraftingRecipeCategory category, T recipe) {
        this(id.toMinecraft(), group, category, recipe);
    }

    public boolean isNull() {
        return entry == null;
    }

    @Deprecated
    public class_8786<?> getRecipeEntry() {
        return entry;
    }

    public T getRecipe() {
        return entry.comp_1933();
    }

    public class_2960 getId() {
        return entry.comp_1932();
    }

    public CompatIdentifier getCompatId() {
        return CompatIdentifier.fromMinecraft(getId());
    }

    public class_3956<?> getType() {
        T recipe = getRecipe();
        if (recipe == null) return null;

        return recipe.method_17716();
    }

    public class_1865<?> getSerializer() {
        class_1860<?> recipe = getRecipe();
        if (recipe == null) return null;

        return recipe.method_8119();
    }

    @Nullable
    public RecipeUtil.CompatibilityCraftingRecipeCategory getCategory() {
        return category;
    }

    public String getGroup() {
        return group;
    }
}
