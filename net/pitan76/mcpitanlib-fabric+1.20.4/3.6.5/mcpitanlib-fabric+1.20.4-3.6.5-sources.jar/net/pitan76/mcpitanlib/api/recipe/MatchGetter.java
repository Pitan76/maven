package net.pitan76.mcpitanlib.api.recipe;

import net.minecraft.class_1263;
import net.minecraft.class_1860;
import net.minecraft.class_1937;
import net.pitan76.mcpitanlib.api.recipe.input.CompatRecipeInput;
import net.pitan76.mcpitanlib.api.recipe.v2.CompatRecipeEntry;

import java.util.Optional;

@Deprecated
public interface MatchGetter<I extends class_1263, T extends class_1860<I>> {
    Optional<CompatRecipeEntry<T>> getFirstMatch(CompatRecipeInput<I> input, class_1937 world);
}
