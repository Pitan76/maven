package net.pitan76.mcpitanlib.api.recipe;

import net.minecraft.class_1860;
import net.minecraft.class_1865;
import net.minecraft.class_1867;
import net.minecraft.class_2960;
import net.minecraft.class_3956;
import net.minecraft.class_8786;
import net.minecraft.recipe.*;
import net.pitan76.mcpitanlib.api.util.CompatIdentifier;
import net.pitan76.mcpitanlib.api.util.RecipeUtil;
import org.jetbrains.annotations.Nullable;

@Deprecated
public class CompatibleRecipeEntry {
    private final class_8786<?> entry;

    public String group = "";
    public RecipeUtil.CompatibilityCraftingRecipeCategory category = null;

    @Deprecated
    public CompatibleRecipeEntry(class_8786<?> entry) {
        this.entry = entry;
    }

    public CompatibleRecipeEntry(class_2960 id, String group, RecipeUtil.CompatibilityCraftingRecipeCategory category, class_1867 shapelessRecipe) {
        this.entry = new class_8786<>(id, shapelessRecipe);
        this.group = group;
        this.category = category;
    }

    public CompatibleRecipeEntry(CompatIdentifier id, String group, RecipeUtil.CompatibilityCraftingRecipeCategory category, class_1867 shapelessRecipe) {
        this(id.toMinecraft(), group, category, shapelessRecipe);
    }

    @Deprecated
    public class_8786<?> getRecipeEntry() {
        return entry;
    }

    public class_1860<?> getRecipe() {
        Object object = entry.comp_1933();
        if (object instanceof class_1860<?>) {
            return (class_1860<?>) object;
        }
        return null;
    }

    public class_2960 getId() {
        return entry.comp_1932();
    }

    public CompatIdentifier getCompatId() {
        return CompatIdentifier.fromMinecraft(getId());
    }

    public class_3956<?> getType() {
        class_1860<?> recipe = getRecipe();
        if (recipe == null) return null;

        return recipe.method_17716();
    }

    public class_1865<?> getSerializer() {
        class_1860<?> recipe = getRecipe();
        if (recipe == null) return null;

        return recipe.method_8119();
    }

    @Nullable
    public RecipeUtil.CompatibilityCraftingRecipeCategory getCategory() {
        return category;
    }

    public String getGroup() {
        return group;
    }
}
