package net.pitan76.mcpitanlib.api.util.block.entity;

import net.minecraft.class_1263;
import net.minecraft.class_1799;
import net.minecraft.class_1874;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2609;
import net.pitan76.mcpitanlib.api.recipe.MatchGetter;
import net.pitan76.mcpitanlib.api.recipe.input.CompatRecipeInput;
import net.pitan76.mcpitanlib.api.util.WorldUtil;
import net.pitan76.mcpitanlib.api.util.recipe.input.SingleStackRecipeInputUtil;

public class FurnaceUtil {
    public static int getDefaultCookTime() {
        return class_2609.field_31294;
    }

    public static boolean canUseAsFuel(net.pitan76.mcpitanlib.midohra.item.ItemStack stack, class_1937 world) {
        return canUseAsFuel(stack.toMinecraft(), world);
    }

    public static boolean canUseAsFuel(class_1799 stack, class_1937 world) {
        return class_2609.method_11195(stack);
    }

    public static void tick(class_1937 world, class_2338 pos, class_2609 blockEntity) {
        class_2609.method_31651(world, pos, WorldUtil.getBlockState(world, pos), blockEntity);
    }

    public static int getCookTime(class_1937 world, class_2609 furnace, MatchGetter<class_1263, ? extends class_1874> matchGetter) {
        return getCookTime(world, furnace.method_5438(0), matchGetter);
    }

    public static int getCookTime(class_1937 world, class_1799 stack, MatchGetter<class_1263, ? extends class_1874> matchGetter) {
        CompatRecipeInput<class_1263> input = (CompatRecipeInput<class_1263>) SingleStackRecipeInputUtil.create(stack);

        matchGetter.getFirstMatch(input, world);

        return matchGetter.getFirstMatch(input, world).map(
                (recipe) -> (recipe.getRecipe()).method_8167()).orElse(200);
    }
}
