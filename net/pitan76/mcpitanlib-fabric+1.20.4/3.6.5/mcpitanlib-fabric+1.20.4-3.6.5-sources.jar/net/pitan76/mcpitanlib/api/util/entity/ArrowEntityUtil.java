package net.pitan76.mcpitanlib.api.util.entity;

import net.minecraft.class_1667;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1937;
import net.pitan76.mcpitanlib.api.util.ItemStackUtil;
import org.jetbrains.annotations.Nullable;

public class ArrowEntityUtil {
    public static class_1667 create(class_1937 world, double x, double y, double z, class_1799 stack, @Nullable class_1799 shotFrom) {
        return new class_1667(world, x, y, z, stack);
    }

    public static class_1667 create(class_1937 world, double x, double y, double z, class_1799 stack) {
        return create(world, x, y, z, stack, null);
    }

    public static class_1667 create(class_1937 world, double x, double y, double z) {
        return create(world, x, y, z, ItemStackUtil.getDefaultStack(class_1802.field_8107));
    }

    public static void setVelocity(class_1667 arrow, double x, double y, double z, float velocity, float divergence) {
        arrow.method_7485(x, y, z, velocity, divergence);
    }
}
