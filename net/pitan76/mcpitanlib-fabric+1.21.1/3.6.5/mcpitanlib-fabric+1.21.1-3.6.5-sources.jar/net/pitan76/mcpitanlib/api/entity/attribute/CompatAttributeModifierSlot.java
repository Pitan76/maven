package net.pitan76.mcpitanlib.api.entity.attribute;

import net.minecraft.class_9274;
import net.pitan76.mcpitanlib.api.util.CompatStringIdentifiable;

public class CompatAttributeModifierSlot implements CompatStringIdentifiable {

    private final class_9274 raw;

    public static final CompatAttributeModifierSlot ANY = new CompatAttributeModifierSlot(class_9274.field_49216);
    public static final CompatAttributeModifierSlot MAIN_HAND = new CompatAttributeModifierSlot(class_9274.field_49217);
    public static final CompatAttributeModifierSlot OFF_HAND = new CompatAttributeModifierSlot(class_9274.field_49218);
    public static final CompatAttributeModifierSlot HEAD = new CompatAttributeModifierSlot(class_9274.field_49223);
    public static final CompatAttributeModifierSlot FEET = new CompatAttributeModifierSlot(class_9274.field_49220);
    public static final CompatAttributeModifierSlot LEGS = new CompatAttributeModifierSlot(class_9274.field_49221);
    public static final CompatAttributeModifierSlot CHEST = new CompatAttributeModifierSlot(class_9274.field_49222);
    public static final CompatAttributeModifierSlot ARMOR = new CompatAttributeModifierSlot(class_9274.field_49224);
    public static final CompatAttributeModifierSlot BODY = new CompatAttributeModifierSlot(class_9274.field_50127);
    public static final CompatAttributeModifierSlot SADDLE = new CompatAttributeModifierSlot(class_9274.field_50127);

    @Deprecated
    public CompatAttributeModifierSlot(class_9274 raw) {
        this.raw = raw;
    }

    public static CompatAttributeModifierSlot of(class_9274 slot) {
        if (slot == class_9274.field_49216) return ANY;
        if (slot == class_9274.field_49217) return MAIN_HAND;
        if (slot == class_9274.field_49218) return OFF_HAND;
        if (slot == class_9274.field_49223) return HEAD;
        if (slot == class_9274.field_49220) return FEET;
        if (slot == class_9274.field_49221) return LEGS;
        if (slot == class_9274.field_49222) return CHEST;
        if (slot == class_9274.field_49224) return ARMOR;
        if (slot == class_9274.field_50127) return BODY;

        return new CompatAttributeModifierSlot(slot);
    }

    @Deprecated
    public class_9274 raw() {
        return raw;
    }

    @Override
    public String asString_compat() {
        return raw().method_15434();
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (!(obj instanceof CompatAttributeModifierSlot)) return false;
        CompatAttributeModifierSlot that = (CompatAttributeModifierSlot) obj;
        return raw().equals(that.raw());
    }

    @Override
    public int hashCode() {
        if (raw() == null) return super.hashCode();
        return raw().hashCode();
    }
}
