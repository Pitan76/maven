package net.pitan76.mcpitanlib.api.item;

import java.util.EnumMap;
import java.util.List;
import java.util.function.Supplier;
import net.minecraft.class_156;
import net.minecraft.class_1738;
import net.minecraft.class_1741;
import net.minecraft.class_1856;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_3414;
import net.minecraft.class_3417;
import net.minecraft.class_6880;
import net.minecraft.class_7923;

public interface CompatibleArmorMaterial {
    int getDurability(ArmorEquipmentType type);

    int getProtection(ArmorEquipmentType type);

    int getEnchantability();

    class_3414 getEquipSound();

    class_1856 getRepairIngredient();

    /**
     * @return the name of the material
     */
    default String getName() {
        return getId().method_12832();
    }

    /**
     * @return the id of the material
     */
    class_2960 getId();

    float getToughness();

    float getKnockbackResistance();

    @Deprecated
    default class_6880<class_1741> build() {
        if (CompatibleArmorItem.CACHE.containsKey(this)) {
            return CompatibleArmorItem.CACHE.get(this);
        }

        class_6880<class_1741> entry = register(getId(), class_156.method_654(new EnumMap<>(class_1738.class_8051.class), (map) -> {
                    map.put(class_1738.class_8051.field_41934, this.getProtection(ArmorEquipmentType.HEAD));
                    map.put(class_1738.class_8051.field_41935, this.getProtection(ArmorEquipmentType.CHEST));
                    map.put(class_1738.class_8051.field_41936, this.getProtection(ArmorEquipmentType.LEGS));
                    map.put(class_1738.class_8051.field_41937, this.getProtection(ArmorEquipmentType.FEET));

                    map.put(class_1738.class_8051.field_48838, this.getProtection(ArmorEquipmentType.BODY));
                }), getEnchantability(), class_3417.field_14581, getToughness(), getKnockbackResistance(),
                this::getRepairIngredient
        );
        CompatibleArmorItem.CACHE.put(this, entry);
        return entry;
    }

    private static class_6880<class_1741> register(class_2960 id, EnumMap<class_1738.class_8051, Integer> defense, int enchantability, class_6880<class_3414> equipSound, float toughness, float knockbackResistance, Supplier<class_1856> repairIngredient) {
        List<class_1741.class_9196> list = List.of(new class_1741.class_9196(id));
        return register(id, defense, enchantability, equipSound, toughness, knockbackResistance, repairIngredient, list);
    }

    private static class_6880<class_1741> register(class_2960 id, EnumMap<class_1738.class_8051, Integer> defense, int enchantability, class_6880<class_3414> equipSound, float toughness, float knockbackResistance, Supplier<class_1856> repairIngredient, List<class_1741.class_9196> layers) {
        EnumMap<class_1738.class_8051, Integer> enumMap = new EnumMap<>(class_1738.class_8051.class);
        class_1738.class_8051[] var9 = class_1738.class_8051.values();

        for (class_1738.class_8051 type : var9) {
            enumMap.put(type, defense.get(type));
        }

        return class_2378.method_47985(class_7923.field_48976, id, new class_1741(enumMap, enchantability, equipSound, repairIngredient, layers, toughness, knockbackResistance));
    }
}
