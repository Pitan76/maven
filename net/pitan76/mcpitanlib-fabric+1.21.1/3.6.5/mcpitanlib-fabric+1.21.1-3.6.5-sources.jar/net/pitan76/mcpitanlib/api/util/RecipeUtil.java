package net.pitan76.mcpitanlib.api.util;

import net.minecraft.class_1263;
import net.minecraft.class_1799;
import net.minecraft.class_1856;
import net.minecraft.class_1860;
import net.minecraft.class_1863;
import net.minecraft.class_1867;
import net.minecraft.class_1937;
import net.minecraft.class_2371;
import net.minecraft.class_2960;
import net.minecraft.class_3956;
import net.minecraft.class_7710;
import net.minecraft.class_8786;
import net.minecraft.class_9695;
import net.minecraft.recipe.*;
import net.pitan76.mcpitanlib.api.recipe.CompatRecipeType;
import net.pitan76.mcpitanlib.api.recipe.MatchGetter;
import net.pitan76.mcpitanlib.api.recipe.input.CompatRecipeInput;
import net.pitan76.mcpitanlib.api.recipe.v2.CompatRecipeEntry;
import net.pitan76.mcpitanlib.api.recipe.v2.CompatRecipeNonEntry;
import net.pitan76.mcpitanlib.api.registry.CompatRegistryLookup;
import net.pitan76.mcpitanlib.api.util.collection.ItemStackList;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Optional;

public class RecipeUtil {
    public static class_1867 createShapelessRecipe(class_2960 id, String group, CompatibilityCraftingRecipeCategory category, class_1799 output, class_2371<class_1856> input) {
        return new class_1867(group, class_7710.valueOf(category.name()), output, input);
    }

    public static class_1867 createShapelessRecipe(class_2960 id, String group, class_1799 output, class_2371<class_1856> input) {
        return createShapelessRecipe(id, group, CompatibilityCraftingRecipeCategory.MISC, output, input);
    }

    @Deprecated
    public static <C extends class_9695> class_1799 craft_2(class_1860<C> recipe, C inventory, class_1937 world) {
        return recipe.method_8116(inventory, world.method_30349());
    }

    @Deprecated
    public static <C extends class_9695> class_1799 getOutput_2(class_1860<C> recipe, class_1937 world) {
        return recipe.method_8110(world.method_30349());
    }

    public static class_1799 craft(class_1860<?> recipe, class_1263 inventory, class_1937 world) {
        if (inventory instanceof class_9695) {
            class_1860<class_9695> inputRecipe = (class_1860<class_9695>) recipe;
            return inputRecipe.method_8116((class_9695) inventory, world.method_30349());
        }
        return class_1799.field_8037;
    }

    public static class_1799 getOutput(class_1860<?> recipe, class_1937 world) {
        return getOutput(recipe, RegistryLookupUtil.getRegistryLookup(world));
    }

    public static List<class_1860<?>> getAllRecipes(class_1937 world) {
        Collection<class_8786<?>> recipes = getRecipeManager(world).method_8126();
        List<class_1860<?>> outRecipes = new ArrayList<>();
        for (Object recipeEntryObj : recipes) {
            if (recipeEntryObj instanceof class_8786) {
                class_8786<?> recipeEntry = (class_8786<?>) recipeEntryObj;
                if (recipeEntry.comp_1933() instanceof class_1860) {
                    outRecipes.add(recipeEntry.comp_1933());
                }
            }
        }
        return outRecipes;
    }

    public static List<CompatRecipeNonEntry<?>> getAllCompatRecipeEntry(class_1937 world) {
        List<class_1860<?>> recipes = getAllRecipes(world);
        List<CompatRecipeNonEntry<?>> outRecipes = new ArrayList<>();
        for (class_1860<?> recipe : recipes) {
            outRecipes.add(new CompatRecipeNonEntry<>(recipe));
        }
        return outRecipes;
    }

    public static class_3956<?> getType(class_1860<?> recipe) {
        return recipe.method_17716();
    }

    public static class_2960 getId(class_1860<?> recipe) {
        return IdentifierUtil.id(recipe.getClass().hashCode() + "");
    }

    public static <I extends class_9695, T extends class_1860<I>> CompatRecipeEntry<T> getFirstMatch(class_1863 recipeManager, CompatRecipeType<T> type, CompatRecipeInput<I> input, class_1937 world) {
        Optional<class_8786<T>> recipe = recipeManager.method_8132(type.getType(), input.getInput(), world);
        return recipe.map(CompatRecipeEntry::new).orElseGet(() -> new CompatRecipeEntry<>(null));
    }

    public static <I extends class_9695, T extends class_1860<I>> CompatRecipeEntry<T> getFirstMatch(class_1863 recipeManager, CompatRecipeType<T> type, CompatRecipeInput<I> input, class_1937 world, CompatIdentifier identifier) {
        Optional<class_8786<T>> recipe = recipeManager.method_42299(type.getType(), input.getInput(), world, identifier.toMinecraft());
        return recipe.map(CompatRecipeEntry::new).orElseGet(() -> new CompatRecipeEntry<>(null));
    }

    public static <I extends class_9695, T extends class_1860<I>> CompatRecipeEntry<T> getFirstMatch(class_1937 world, CompatRecipeType<T> type, CompatRecipeInput<I> input) {
        return getFirstMatch(getRecipeManager(world), type, input, world);
    }

    public static <I extends class_9695, T extends class_1860<I>> CompatRecipeEntry<T> getFirstMatch(class_1937 world, CompatRecipeType<T> type, CompatRecipeInput<I> input, CompatIdentifier identifier) {
        return getFirstMatch(getRecipeManager(world), type, input, world, identifier);
    }

    public static class_1863 getRecipeManager(class_1937 world) {
        return world.method_8433();
    }

    public Optional<class_8786<?>> get(class_1937 world, CompatIdentifier id) {
        return get(getRecipeManager(world), id);
    }

    public Optional<class_8786<?>> get(class_1863 recipeManager, CompatIdentifier id) {
        return recipeManager.method_8130(id.toMinecraft());
    }

    public static <I extends class_9695, T extends class_1860<I>> MatchGetter<I, T> createCachedMatchGetter(class_3956<T> type) {
        return (input, world) -> {
            Optional<class_8786<T>> optional = class_1863.method_42302(type).method_42303(input.getInput(), world);
            return optional.map(CompatRecipeEntry::new);
        };
    }

    public static <I extends class_9695, T extends class_1860<I>> MatchGetter<I, T> createCachedMatchGetter(CompatRecipeType<T> type) {
        return createCachedMatchGetter(type.getType());
    }

    public static class_2371<class_1856> getInputs(class_1860<?> recipe) {
        return recipe.method_8117();
    }

    public static class_2371<class_1856> getInputs(CompatRecipeEntry<?> recipeEntry) {
        return getInputs(recipeEntry.getRecipe());
    }

    public static ItemStackList getInputsAsStack(class_1860<?> recipe) {
        class_2371<class_1856> ingredients = getInputs(recipe);
        ItemStackList stacks = ItemStackList.ofSize(ingredients.size(), ItemStackUtil.empty());
        for (class_1856 ingredient : ingredients) {
            stacks.addAll(IngredientUtil.getMatchingStacksAsList(ingredient));
        }
        return stacks;
    }

    public static ItemStackList getInputsAsStack(CompatRecipeEntry<?> recipeEntry) {
        return getInputsAsStack(recipeEntry.getRecipe());
    }

    public static class_1799 getOutput(class_1860<?> recipe, CompatRegistryLookup registryLookup) {
        return recipe.method_8110(registryLookup.getRegistryLookup());
    }

    public static class_1799 getOutput(CompatRecipeEntry<?> recipeEntry, CompatRegistryLookup registryLookup) {
        return getOutput(recipeEntry.getRecipe(), registryLookup);
    }

    public static CompatRecipeType<?> getType(CompatRecipeEntry<?> recipeEntry) {
        return CompatRecipeType.of(recipeEntry.getRecipe().method_17716());
    }

    public static  <I extends class_9695, T extends class_1860<I>> ItemStackList getRemainder(CompatRecipeEntry<T> recipeEntry, CompatRecipeInput<I> input) {
        return ItemStackList.of(recipeEntry.getRecipe().method_8111(input.getInput()));
    }

    public enum CompatibilityCraftingRecipeCategory {
        BUILDING,
        REDSTONE,
        EQUIPMENT,
        MISC;
    }
}
