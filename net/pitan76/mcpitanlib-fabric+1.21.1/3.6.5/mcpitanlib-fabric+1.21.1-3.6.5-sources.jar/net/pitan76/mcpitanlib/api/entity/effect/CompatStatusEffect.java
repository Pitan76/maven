package net.pitan76.mcpitanlib.api.entity.effect;

import net.minecraft.class_1291;
import net.minecraft.class_1937;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.minecraft.class_6880;
import net.minecraft.class_7887;
import net.minecraft.class_7924;
import net.pitan76.mcpitanlib.api.util.StatusEffectUtil;
import org.jetbrains.annotations.Nullable;

import java.util.Optional;

public class CompatStatusEffect {
    private final class_5321<class_1291> registryKey;

    @Deprecated
    public CompatStatusEffect(class_5321<class_1291> registryKey) {
        this.registryKey = registryKey;
    }

    public CompatStatusEffect of(class_2960 identifier) {
        return StatusEffectUtil.getStatusEffect(identifier);
    }

    public class_2960 getId() {
        return registryKey.method_41185();
    }

    @Deprecated
    public class_5321<class_1291> getRegistryKey() {
        return registryKey;
    }

    public String toString() {
        return getId().toString();
    }

    public boolean equals(Object obj) {
        if (obj instanceof CompatStatusEffect) {
            return ((CompatStatusEffect) obj).getId().equals(getId());
        }
        return false;
    }

    @Deprecated
    public class_6880<class_1291> getEntry(@Nullable class_1937 world) {
        Optional<class_6880.class_6883<class_1291>> optionalEntry;
        if (world == null) {
            optionalEntry = class_7887.method_46817().method_46758()
                    .method_58561(class_7924.field_41208, registryKey);
        } else {
            optionalEntry = world.method_30349().method_30530(class_7924.field_41208).method_40264(registryKey);
        }

        return optionalEntry.orElseThrow();
    }

    public class_1291 getStatusEffect(@Nullable class_1937 world) {
        return getEntry(world).comp_349();
    }
}
