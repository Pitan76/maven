package net.pitan76.mcpitanlib.api.util;

import net.minecraft.class_1282;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1937;
import net.minecraft.class_243;
import net.minecraft.class_2470;
import net.minecraft.class_2561;
import net.minecraft.class_2709;
import net.minecraft.class_3218;
import net.pitan76.mcpitanlib.api.entity.Player;
import net.pitan76.mcpitanlib.midohra.util.math.BlockPos;
import net.pitan76.mcpitanlib.midohra.util.math.Vector3d;

import java.util.UUID;

public class EntityUtil {
    public static class_1937 getWorld(class_1297 entity) {
        return entity.method_37908();
    }

    public static boolean damage(class_1297 target, class_1282 damageSource, float amount) {
        return target.method_5643(damageSource, amount);
    }

    public static boolean damageWithThrownProjectile(class_1297 target, float damageAmount, class_1297 projectile, class_1297 attacker) {
        return target.method_5643(DamageSourceUtil.thrownProjectile(projectile, attacker), damageAmount);
    }

    public static boolean damageWithMobProjectile(class_1297 target, float damageAmount, class_1297 projectile, class_1309 attacker) {
        return target.method_5643(DamageSourceUtil.mobProjectile(projectile, attacker), damageAmount);
    }

    public static boolean damageWithMobAttack(class_1297 target, float damageAmount, class_1297 source, class_1309 attacker) {
        return target.method_5643(DamageSourceUtil.mobAttack(attacker, source), damageAmount);
    }

    public static boolean damageWithPlayerAttack(class_1297 target, float damageAmount, class_1297 source, Player attacker) {
        return target.method_5643(DamageSourceUtil.playerAttack(attacker, source), damageAmount);
    }

    public static void discard(class_1297 entity) {
        entity.method_31472();
    }

    public static void kill(class_1297 entity) {
        entity.method_5768();
    }

    public static void setVelocity(class_1297 entity, double x, double y, double z) {
        entity.method_18800(x, y, z);
    }

    public static class_243 getVelocity(class_1297 entity) {
        return entity.method_18798();
    }

    public static void setNoGravity(class_1297 entity, boolean noGravity) {
        entity.method_5875(noGravity);
    }

    public static boolean hasNoGravity(class_1297 entity) {
        return entity.method_5740();
    }

    public static void setInvulnerable(class_1297 entity, boolean invulnerable) {
        entity.method_5684(invulnerable);
    }

    public static boolean isInvulnerable(class_1297 entity) {
        return entity.method_5655();
    }

    public static void setSilent(class_1297 entity, boolean silent) {
        entity.method_5803(silent);
    }

    public static boolean isSilent(class_1297 entity) {
        return entity.method_5701();
    }

    public static void setGlowing(class_1297 entity, boolean glowing) {
        entity.method_5834(glowing);
    }

    public static boolean isGlowing(class_1297 entity) {
        return entity.method_5851();
    }

    public static void setFire(class_1297 entity, int seconds) {
        entity.method_5639(seconds);
    }

    public static void extinguish(class_1297 entity) {
        entity.method_5646();
    }

    public static boolean isOnFire(class_1297 entity) {
        return entity.method_5809();
    }

    public static void setInvisible(class_1297 entity, boolean invisible) {
        entity.method_5648(invisible);
    }

    public static boolean isInvisible(class_1297 entity) {
        return entity.method_5767();
    }

    public static void setSneaking(class_1297 entity, boolean sneaking) {
        entity.method_5660(sneaking);
    }

    public static boolean isSneaking(class_1297 entity) {
        return entity.method_5715();
    }

    public static void setSprinting(class_1297 entity, boolean sprinting) {
        entity.method_5728(sprinting);
    }

    public static boolean isSprinting(class_1297 entity) {
        return entity.method_5624();
    }

    public static void setSwimming(class_1297 entity, boolean swimming) {
        entity.method_5796(swimming);
    }

    public static boolean isSwimming(class_1297 entity) {
        return entity.method_5681();
    }

    public static void detach(class_1297 entity) {
        entity.method_18375();
    }

    public static void attach(class_1297 entity, class_1297 vehicle) {
        entity.method_5873(vehicle, true);
    }

    public static void detachFromVehicle(class_1297 entity) {
        entity.method_5848();
    }

    public static boolean isRiding(class_1297 entity) {
        return entity.method_5765();
    }

    public static class_1297 getVehicle(class_1297 entity) {
        return entity.method_5854();
    }

    public static void setVehicle(class_1297 entity, class_1297 vehicle) {
        entity.method_5873(vehicle, true);
    }

    public static void applyRotation(class_1297 entity, class_2470 rotation) {
        entity.method_5832(rotation);
    }

    public static void setVelocity(class_1297 entity, class_243 velocity) {
        entity.method_18799(velocity);
    }

    public static void setFallDistance(class_1297 entity, double fallDistance) {
        entity.field_6017 = (float) fallDistance;
    }

    public static double getFallDistance(class_1297 entity) {
        return entity.field_6017;
    }

    public static void setVelocityModified(class_1297 entity, boolean velocityModified) {
        entity.field_6037 = velocityModified;
    }

    public static boolean isVelocityModified(class_1297 entity) {
        return entity.field_6037;
    }

    public static float getYaw(class_1297 entity) {
        return entity.method_36454();
    }

    public static float getPitch(class_1297 entity) {
        return entity.method_36455();
    }

    public static void setYaw(class_1297 entity, float yaw) {
        entity.method_36456(yaw);
    }

    public static void setPitch(class_1297 entity, float pitch) {
        entity.method_36457(pitch);
    }

    public static float getSpeed(class_1297 entity) {
        return entity.field_28627;
    }

    public static void setSpeed(class_1297 entity, float speed) {
        entity.field_28627 = speed;
    }

    public static boolean isOnGround(class_1297 entity) {
        return entity.method_24828();
    }

    public static void setOnGround(class_1297 entity, boolean onGround) {
        entity.method_24830(onGround);
    }

    public static boolean isAlive(class_1297 entity) {
        return entity.method_5805();
    }

    public static UUID getUuid(class_1297 entity) {
        return entity.method_5667();
    }

    public static String getUuidString(class_1297 entity) {
        return entity.method_5845();
    }

    public static void setUuid(class_1297 entity, UUID uuid) {
        entity.method_5826(uuid);
    }

    public static class_2561 getName(class_1297 entity) {
        return entity.method_5477();
    }

    public static class_2561 getDisplayName(class_1297 entity) {
        return entity.method_5476();
    }

    public static void setCustomName(class_1297 entity, class_2561 customName) {
        entity.method_5665(customName);
    }

    public static class_2561 getCustomName(class_1297 entity) {
        return entity.method_5797();
    }

    public static void setCustomNameVisible(class_1297 entity, boolean visible) {
        entity.method_5880(visible);
    }

    public static boolean isCustomNameVisible(class_1297 entity) {
        return entity.method_5807();
    }

    public static boolean hasCustomName(class_1297 entity) {
        return entity.method_16914();
    }

    public static String getNameAsString(class_1297 entity) {
        return entity.method_5477().getString();
    }

    public static String getDisplayNameAsString(class_1297 entity) {
        if (entity.method_5476() == null)
            return null;
        return entity.method_5476().getString();
    }

    public static String getCustomNameAsString(class_1297 entity) {
        if (entity.method_5797() == null)
            return null;
        return entity.method_5797().getString();
    }

    public static void setCustomName(class_1297 entity, String customName) {
        entity.method_5665(TextUtil.literal(customName));
    }

    public static class_243 getRotationVector(class_1297 entity) {
        return entity.method_5720();
    }

    public static class_243 getPos(class_1297 entity) {
        return entity.method_19538();
    }

    public static Vector3d getPosM(class_1297 entity) {
        return Vector3d.of(getPos(entity));
    }

    public static void setPos(class_1297 entity, double x, double y, double z) {
        entity.method_23327(x, y, z);
    }

    public static void addVelocity(class_1297 entity, double x, double y, double z) {
        entity.method_5762(x, y, z);
    }

    public static void addVelocity(class_1297 entity, class_243 velocity) {
        entity.method_60491(velocity);
    }

    public static void addVelocity(class_1297 entity, Vector3d velocity) {
        addVelocity(entity, velocity.toMinecraft());
    }

    public static void setVelocity(class_1297 entity, Vector3d velocity) {
        entity.method_18799(velocity.toMinecraft());
    }

    public static void setPos(class_1297 entity, BlockPos pos) {
        setPos(entity, pos.getX(), pos.getY(), pos.getZ());
    }

     public static void setPos(class_1297 entity, Vector3d pos) {
        setPos(entity, pos.getX(), pos.getY(), pos.getZ());
    }

    public static void teleport(class_1297 entity, class_3218 world, double x, double y, double z, float yaw, float pitch, boolean resetCamera) {
        entity.method_48105(world, x, y, z, class_2709.field_40710, yaw, pitch);
    }

    public static void teleport(class_1297 entity, class_3218 world, double x, double y, double z, float yaw, float pitch) {
        teleport(entity, world, x, y, z, yaw, pitch, true);
    }

    public static void teleport(class_1297 entity, class_3218 world, double x, double y, double z) {
        teleport(entity, world, x, y, z, entity.method_36454(), entity.method_36455(), true);
    }

    public static void teleport(class_1297 entity, class_3218 world, Vector3d pos) {
        teleport(entity, world, pos.getX(), pos.getY(), pos.getZ());
    }

    public static void teleport(class_1297 entity, class_3218 world, BlockPos pos) {
        teleport(entity, world, pos.getX(), pos.getY(), pos.getZ());
    }

    public static void teleport(class_1297 entity, double x, double y, double z) {
        if (!(entity.method_37908() instanceof class_3218))
            return;

        teleport(entity, (class_3218) entity.method_37908(), x, y, z, entity.method_36454(), entity.method_36455());
    }

    public static void teleport(class_1297 entity, Vector3d pos) {
        teleport(entity, pos.getX(), pos.getY(), pos.getZ());
    }

    public static void teleport(class_1297 entity, BlockPos pos) {
        teleport(entity, pos.getX(), pos.getY(), pos.getZ());
    }

    public static void teleport(class_1297 entity, class_3218 world, Vector3d pos, float yaw, float pitch, boolean resetCamera) {
        teleport(entity, world, pos.getX(), pos.getY(), pos.getZ(), yaw, pitch, resetCamera);
    }

    public static void teleport(class_1297 entity, class_3218 raw, BlockPos pos, float yaw, float pitch, boolean resetCamera) {
        teleport(entity, raw, pos.getX(), pos.getY(), pos.getZ(), yaw, pitch, resetCamera);
    }
}
