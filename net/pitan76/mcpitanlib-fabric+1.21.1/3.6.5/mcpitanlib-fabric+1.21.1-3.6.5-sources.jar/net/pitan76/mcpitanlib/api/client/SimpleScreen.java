package net.pitan76.mcpitanlib.api.client;

import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_364;
import net.minecraft.class_4068;
import net.minecraft.class_437;
import net.minecraft.class_6379;
import net.minecraft.class_918;
import net.pitan76.mcpitanlib.api.client.gui.widget.CompatibleTexturedButtonWidget;
import net.pitan76.mcpitanlib.api.client.render.DrawObjectDM;
import net.pitan76.mcpitanlib.api.client.render.handledscreen.*;
import net.pitan76.mcpitanlib.api.client.render.screen.RenderBackgroundTextureArgs;
import net.pitan76.mcpitanlib.api.util.CompatIdentifier;
import net.pitan76.mcpitanlib.api.util.IdentifierUtil;
import net.pitan76.mcpitanlib.api.util.client.RenderUtil;

public abstract class SimpleScreen extends class_437 {

    public int field_22789, field_22790;
    public class_327 field_22793;
    public class_918 itemRenderer;

    public class_2561 field_22785;
    public class_310 field_22787;

    public SimpleScreen(class_2561 title) {
        super(title);
        fixScreen();
        this.field_22785 = title;
    }

    public <T extends class_364 & class_4068 & class_6379> T addDrawableChild_compatibility(T drawableElement) {
        return super.method_37063(drawableElement);
        // addButton
    }

    public <T extends class_364 & class_6379> T addSelectableChild_compatibility(T selectableElement) {
        return super.method_25429(selectableElement);
    }

    public CompatibleTexturedButtonWidget addDrawableCTBW(CompatibleTexturedButtonWidget widget) {
        return addDrawableChild_compatibility(widget);
    }

    public void callDrawTexture(DrawObjectDM drawObjectDM, class_2960 texture, int x, int y, int u, int v, int width, int height) {
        //ScreenUtil.setBackground(GUI);
        //super.drawTexture(matrices, x, y, u, v, width, height);
        drawObjectDM.getContext().method_25290(texture, x, y, u, v, width, height, 256, 256);
    }

    public void callDrawTexture(DrawObjectDM drawObjectDM, CompatIdentifier texture, int x, int y, int u, int v, int width, int height) {
        callDrawTexture(drawObjectDM, texture.toMinecraft(), x, y, u, v, width, height);
    }

    @Deprecated
    @Override
    public void method_25420(class_332 context, int mouseX, int mouseY, float delta) {
        renderBackground(new RenderArgs(new DrawObjectDM(context, this), mouseX, mouseY, delta));
    }


    public void renderBackground(RenderArgs args) {
        super.method_25420(args.drawObjectDM.getContext(), args.mouseX, args.mouseY, args.delta);
    }

    public void render(RenderArgs args) {
        super.method_25394(args.drawObjectDM.getContext(), args.mouseX, args.mouseY, args.delta);
    }

    public void resizeOverride(class_310 client, int width, int height) {
    }

    public void initOverride() {
    }

    @Deprecated
    @Override
    protected void method_25426() {
        super.method_25426();
        fixScreen();
        initOverride();
    }

    @Deprecated
    @Override
    public void method_25410(class_310 client, int width, int height) {
        super.method_25410(client, width, height);
        fixScreen();
        resizeOverride(client, width, height);
    }

    public void fixScreen() {
        this.field_22793 = super.field_22793;
        this.itemRenderer = class_310.method_1551().method_1480();
        this.field_22789 = super.field_22789;
        this.field_22790 = super.field_22790;
        if (super.field_22787 == null)
            this.field_22787 = class_310.method_1551();
        else
            this.field_22787 = super.field_22787;
    }

    public void setTextRenderer(class_327 textRenderer) {
        this.field_22793 = textRenderer;
        super.field_22793 = textRenderer;
    }

    public void setItemRenderer(class_918 itemRenderer) {
        this.itemRenderer = itemRenderer;
    }

    public void setWidth(int width) {
        this.field_22789 = width;
        super.field_22789 = width;
    }

    public void setHeight(int height) {
        this.field_22790 = height;
        super.field_22790 = height;
    }

    @Deprecated
    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        DrawObjectDM drawObjectDM = new DrawObjectDM(context, this);
        render(new RenderArgs(drawObjectDM, mouseX, mouseY, delta));
    }

    public boolean keyReleased(KeyEventArgs args) {
        return super.method_16803(args.keyCode, args.scanCode, args.modifiers);
    }

    public boolean keyPressed(KeyEventArgs args) {
        return super.method_25404(args.keyCode, args.scanCode, args.modifiers);
    }

    public void renderBackgroundTexture(RenderBackgroundTextureArgs args) {
        if (getBackgroundTexture() != null)
            class_437.method_57737(args.getDrawObjectDM().getContext(), getBackgroundTexture(), 0, 0, 0, 0, this.field_22789, this.field_22790);

        RenderUtil.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
        callDrawTexture(args.drawObjectDM, getBackgroundTexture(), 0, 0, 0, 0, field_22789, field_22790);
    }

    @Deprecated
    @Override
    public boolean method_16803(int keyCode, int scanCode, int modifiers) {
        return this.keyReleased(new KeyEventArgs(keyCode, scanCode, modifiers));
    }

    @Deprecated
    @Override
    public boolean method_25404(int keyCode, int scanCode, int modifiers) {
        return this.keyPressed(new KeyEventArgs(keyCode, scanCode, modifiers));
    }

    @Deprecated
    @Override
    public void method_57735(class_332 context) {
        this.renderBackgroundTexture(new RenderBackgroundTextureArgs(new DrawObjectDM(context, this), 0));
    }

    public void closeOverride() {
        super.method_25419();
    }

    public void removedOverride() {
        super.method_25432();
    }

    @Override
    public void method_25419() {
        closeOverride();
    }

    @Override
    public void method_25432() {
        removedOverride();
    }

    public class_2960 getBackgroundTexture() {
        return IdentifierUtil.from(getCompatBackgroundTexture());
    }

    public CompatIdentifier getCompatBackgroundTexture() {
        return null;
    }
}
