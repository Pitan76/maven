package net.pitan76.mcpitanlib.api.event.block;

import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.pitan76.mcpitanlib.api.event.BaseEvent;
import net.pitan76.mcpitanlib.api.util.WorldUtil;
import net.pitan76.mcpitanlib.midohra.block.entity.BlockEntityWrapper;
import org.jetbrains.annotations.Nullable;

public class NeighborUpdateEvent extends BaseEvent {
    public class_2680 state;
    public class_1937 world;
    public class_2338 pos;
    public class_2248 sourceBlock;

    @Nullable
    public class_2338 sourcePos;

    public boolean notify;

    public NeighborUpdateEvent(class_2680 state, class_1937 world, class_2338 pos, class_2248 sourceBlock, @Nullable class_2338 sourcePos, boolean notify) {
        this.state = state;
        this.world = world;
        this.pos = pos;
        this.sourceBlock = sourceBlock;
        this.sourcePos = sourcePos;
        this.notify = notify;
    }

    public NeighborUpdateEvent(class_2680 state, class_1937 world, class_2338 pos, class_2248 sourceBlock, boolean notify) {
        this(state, world, pos, sourceBlock, null, notify);
    }

    public class_2680 getState() {
        return state;
    }

    public class_1937 getWorld() {
        return world;
    }

    public class_2338 getPos() {
        return pos;
    }

    public class_2248 getSourceBlock() {
        return sourceBlock;
    }

    public @Nullable class_2338 getSourcePos() {
        return sourcePos;
    }

    public boolean isNotify() {
        return notify;
    }

    public boolean isReceivingRedstonePower() {
        return WorldUtil.isReceivingRedstonePower(world, pos);
    }

    public class_2586 getBlockEntity() {
        return WorldUtil.getBlockEntity(world, pos);
    }

    public boolean hasBlockEntity() {
        return WorldUtil.hasBlockEntity(world, pos);
    }

    public net.pitan76.mcpitanlib.midohra.world.World getMidohraWorld() {
        return net.pitan76.mcpitanlib.midohra.world.World.of(world);
    }

    public net.pitan76.mcpitanlib.midohra.util.math.BlockPos getMidohraPos() {
        return net.pitan76.mcpitanlib.midohra.util.math.BlockPos.of(pos);
    }

    public net.pitan76.mcpitanlib.midohra.block.BlockState getMidohraState() {
        return net.pitan76.mcpitanlib.midohra.block.BlockState.of(state);
    }

    public BlockEntityWrapper getBlockEntityWrapper() {
        return BlockEntityWrapper.of(getBlockEntity());
    }
}
