package net.pitan76.mcpitanlib.api.item.tool;

import net.minecraft.class_1309;
import net.minecraft.class_1743;
import net.minecraft.class_1799;
import net.minecraft.class_1832;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.pitan76.mcpitanlib.api.event.item.PostHitEvent;
import net.pitan76.mcpitanlib.api.event.item.PostMineEvent;
import net.pitan76.mcpitanlib.api.item.v2.CompatibleItemSettings;
import net.pitan76.mcpitanlib.api.item.v2.CompatItemProvider;
import net.pitan76.mcpitanlib.api.util.ItemStackUtil;

public class CompatibleAxeItem extends class_1743 implements CompatItemProvider {

    public CompatibleItemSettings settings;

    public CompatibleAxeItem(CompatibleToolMaterial material, float attackDamage, float attackSpeed, CompatibleItemSettings settings) {
        super(material.build(), settings.build());
        this.settings = settings;
    }

    public CompatibleAxeItem(float attackDamage, float attackSpeed, class_1832 material, CompatibleItemSettings settings) {
        super(material, settings.build());
        this.settings = settings;
    }

    @Override
    public CompatibleItemSettings getCompatSettings() {
        return settings;
    }

    public boolean overrideIsSuitableFor(class_2680 state) {
        return super.method_58405(method_7854(), state);
    }

    @Deprecated
    @Override
    public boolean method_58405(class_1799 stack, class_2680 state) {
        return overrideIsSuitableFor(state);
    }

    public float overrideGetMiningSpeedMultiplier(class_1799 stack, class_2680 state) {
        return 1.0F;
    }

    @Deprecated
    @Override
    public float method_58404(class_1799 stack, class_2680 state) {
        return overrideGetMiningSpeedMultiplier(stack, state) * super.method_58404(stack, state);
    }

    @Deprecated
    @Override
    public boolean method_7873(class_1799 stack, class_1309 target, class_1309 attacker) {
        return postHit(new PostHitEvent(stack, target, attacker));
    }

    @Deprecated
    @Override
    public boolean method_7879(class_1799 stack, class_1937 world, class_2680 state, class_2338 pos, class_1309 miner) {
        return postMine(new PostMineEvent(stack, world, state, pos, miner));
    }

    /**
     * post hit event
     * @param event PostHitEvent
     * @return boolean
     */
    public boolean postHit(PostHitEvent event) {
        return super.method_7873(event.stack, event.target, event.attacker);
    }

    /**
     * post mine event
     * @param event PostMineEvent
     * @return boolean
     */
    public boolean postMine(PostMineEvent event) {
        return super.method_7879(event.stack, event.world, event.state, event.pos, event.miner);
    }

    // -1.20.6
    public boolean isDamageableOnDefault() {
        return ItemStackUtil.getMaxDamage(this) > 0;
    }
}
