package net.pitan76.mcpitanlib.api.util;

import it.unimi.dsi.fastutil.ints.IntList;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1856;
import net.minecraft.class_1935;
import net.minecraft.class_2371;
import net.minecraft.class_2960;
import net.minecraft.class_6862;
import net.minecraft.class_7923;

public class IngredientUtil {
    public static class_1856 fromTagByIdentifier(class_2960 id) {
        return class_1856.method_8106(class_6862.method_40092(class_7923.field_41178.method_30517(), id));
    }

    public static class_1856 fromTagByString(String id) {
        return fromTagByIdentifier(IdentifierUtil.id(id));
    }

    public static class_1856 fromTagByIdentifier(CompatIdentifier id) {
        return fromTagByIdentifier(id.toMinecraft());
    }

    public static List<class_1792> getItems(class_1856 ingredient) {
        List<class_1792> items = new ArrayList<>();
        for (int rawId : ingredient.method_8100()) {
            try {
                items.add(ItemUtil.fromIndex(rawId));
            } catch (Exception ignored) {}
        }
        return items;
    }

    public static IntList getMatchingStacksIds(class_1856 ingredient) {
        return ingredient.method_8100();
    }

    public static List<class_1799> getMatchingStacksAsList(class_1856 ingredient) {
        return new ArrayList<>(Arrays.asList(getMatchingStacks(ingredient)));
    }

    public static class_1799[] getMatchingStacks(class_1856 ingredient) {
        return ingredient.method_8105();
    }

    public static class_1856 empty() {
        return class_1856.field_9017;
    }

    public static class_1856 ofItems(class_1935... items) {
        return class_1856.method_8091(items);
    }

    public static class_2371<class_1856> buildInput(Object[] input) {
        class_2371<class_1856> list = class_2371.method_10211();
        for (Object obj : input) {
            if (obj instanceof class_1856) {
                list.add((class_1856) obj);
                continue;
            }

            if (obj instanceof class_1935) {
                list.add(ofItems((class_1935) obj));
            }
        }
        return list;
    }
}
