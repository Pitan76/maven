package net.pitan76.mcpitanlib.api.tile;

import com.mojang.datafixers.types.Type;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_2680;
import net.pitan76.mcpitanlib.api.event.block.TileCreateEvent;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class BlockEntityTypeBuilder<T extends class_2586> {
    private final Factory<? extends T> factory;
    private final List<class_2248> blocks;

    public BlockEntityTypeBuilder(Factory<? extends T> factory, List<class_2248> blocks) {
        this.factory = factory;
        this.blocks = blocks;
    }

    public static <T extends class_2586> BlockEntityTypeBuilder<T> create(Factory<? extends T> factory, class_2248... blocks) {
        List<class_2248> blocksList = new ArrayList<>(blocks.length);
        Collections.addAll(blocksList, blocks);

        return new BlockEntityTypeBuilder<>(factory, blocksList);
    }

    public BlockEntityTypeBuilder<T> addBlock(class_2248 block) {
        this.blocks.add(block);
        return this;
    }

    public BlockEntityTypeBuilder<T> addBlocks(class_2248... blocks) {
        Collections.addAll(this.blocks, blocks);
        return this;
    }


    public class_2591<T> build() {
        return build(null);
    }

    public class_2591<T> build(Type<?> type) {
        return class_2591.class_2592.<T>method_20528(factory::create, blocks.toArray(new class_2248[0])).method_11034(type);
    }

    @FunctionalInterface
    public interface Factory<T extends class_2586> {
        T create(TileCreateEvent event);

        @Deprecated
        default T create(class_2338 pos, class_2680 state) {
            return create(new TileCreateEvent(pos, state));
        }
    }
}
