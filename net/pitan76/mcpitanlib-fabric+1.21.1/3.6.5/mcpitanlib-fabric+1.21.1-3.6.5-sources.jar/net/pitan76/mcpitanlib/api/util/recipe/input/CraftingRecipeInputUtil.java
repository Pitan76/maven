package net.pitan76.mcpitanlib.api.util.recipe.input;

import net.minecraft.class_1662;
import net.minecraft.class_1799;
import net.minecraft.class_9694;
import net.pitan76.mcpitanlib.api.recipe.input.CompatRecipeInput;
import net.pitan76.mcpitanlib.api.util.ItemStackUtil;

import java.util.List;
import java.util.Optional;

public class CraftingRecipeInputUtil {
    public static Optional<class_9694> get(CompatRecipeInput<?> input) {
        if (input.getInput() instanceof class_9694) {
            return Optional.of((class_9694) input.getInput());
        }
        return Optional.empty();
    }

    public static CompatRecipeInput<?> create(class_9694 input) {
        return new CompatRecipeInput<>(input);
    }

    public static CompatRecipeInput<?> create(int width, int height, List<class_1799> stacks) {
        return new CompatRecipeInput<>(class_9694.method_59986(width, height, stacks));
    }

    public static class_1799 getStack(class_9694 input, int x, int y) {
        return input.method_59985(x, y);
    }

    public static class_1799 getStack(CompatRecipeInput<?> input, int x, int y) {
        Optional<class_9694> recipeInput = get(input);
        if (!recipeInput.isPresent()) return ItemStackUtil.empty();

        return getStack(recipeInput.get(), x, y);
    }

    public static net.pitan76.mcpitanlib.midohra.item.ItemStack getMidohraStack(CompatRecipeInput<?> input, int x, int y) {
        return net.pitan76.mcpitanlib.midohra.item.ItemStack.of(getStack(input, x, y));
    }

    public static class_1662 getRecipeMatcher(class_9694 input) {
        return input.method_59988();
    }

    public static class_1662 getRecipeMatcher(CompatRecipeInput<?> input) {
        Optional<class_9694> recipeInput = get(input);
        if (!recipeInput.isPresent()) return null;

        return getRecipeMatcher(recipeInput.get());
    }

    public static List<class_1799> getStacks(class_9694 input) {
        return input.method_59989();
    }

    public static List<class_1799> getStacks(CompatRecipeInput<?> input) {
        Optional<class_9694> recipeInput = get(input);
        if (!recipeInput.isPresent()) return null;

        return getStacks(recipeInput.get());
    }

    public static int getWidth(class_9694 input) {
        return input.method_59991();
    }

    public static int getWidth(CompatRecipeInput<?> input) {
        Optional<class_9694> recipeInput = get(input);
        if (!recipeInput.isPresent()) return -1;

        return getWidth(recipeInput.get());
    }

    public static int getHeight(class_9694 input) {
        return input.method_59992();
    }

    public static int getHeight(CompatRecipeInput<?> input) {
        Optional<class_9694> recipeInput = get(input);
        if (!recipeInput.isPresent()) return -1;

        return getHeight(recipeInput.get());
    }

    public static int getStackCount(class_9694 input) {
        return input.method_59990();
    }

    public static int getStackCount(CompatRecipeInput<?> input) {
        Optional<class_9694> recipeInput = get(input);
        if (!recipeInput.isPresent()) return -1;

        return getStackCount(recipeInput.get());
    }
}
