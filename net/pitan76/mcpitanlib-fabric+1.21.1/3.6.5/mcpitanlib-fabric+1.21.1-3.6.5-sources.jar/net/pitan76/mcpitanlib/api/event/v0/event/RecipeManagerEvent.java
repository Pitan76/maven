package net.pitan76.mcpitanlib.api.event.v0.event;

import com.google.common.collect.ImmutableMap;
import com.google.common.collect.ImmutableMultimap;
import com.google.gson.JsonElement;
import net.minecraft.class_1860;
import net.minecraft.class_2960;
import net.minecraft.class_3300;
import net.minecraft.class_3695;
import net.minecraft.class_3956;
import net.minecraft.class_8786;
import net.pitan76.mcpitanlib.api.recipe.CompatibleRecipeEntry;
import net.pitan76.mcpitanlib.api.recipe.v2.CompatRecipeEntry;
import net.pitan76.mcpitanlib.api.recipe.v3.CompatRecipe;

import java.util.Map;

public class RecipeManagerEvent {
    public Map<class_2960, JsonElement> jsonMap;
    public class_3300 resourceManager;
    public class_3695 profiler;

    @Deprecated
    public ImmutableMap.Builder<class_2960, class_8786<?>> recipesById;

    @Deprecated
    public ImmutableMultimap.Builder<class_3956<?>, class_8786<?>> recipesByType;

    public RecipeManagerEvent(Map<class_2960, JsonElement> map, class_3300 resourceManager, class_3695 profiler, ImmutableMap.Builder<class_2960, class_8786<?>> recipesById, ImmutableMultimap.Builder<class_3956<?>, class_8786<?>> recipesByType) {
        this.jsonMap = map;
        this.resourceManager = resourceManager;
        this.profiler = profiler;
        this.recipesById = recipesById;
        this.recipesByType = recipesByType;
    }

    public Map<class_2960, JsonElement> getJsonMap() {
        return jsonMap;
    }

    @Deprecated
    public ImmutableMap.Builder<class_2960, class_8786<?>> getRecipesById() {
        return recipesById;
    }

    @Deprecated
    public ImmutableMultimap.Builder<class_3956<?>, class_8786<?>> getRecipesByType() {
        return recipesByType;
    }

    public class_3695 getProfiler() {
        return profiler;
    }

    public class_3300 getResourceManager() {
        return resourceManager;
    }

    public net.pitan76.mcpitanlib.midohra.resource.ResourceManager getResourceManagerM() {
        return net.pitan76.mcpitanlib.midohra.resource.ResourceManager.of(resourceManager);
    }

    public void putCompatibleRecipeEntry(class_2960 id, CompatibleRecipeEntry entry) {
        putCompatibleRecipeEntry(entry);
    }

    public void putCompatibleRecipeEntry(CompatibleRecipeEntry entry) {
        recipesById.put(entry.getId(), entry.getRecipeEntry());
        recipesByType.put(entry.getType(), entry.getRecipeEntry());
    }

    public <T extends class_1860<?>> void putCompatibleRecipeEntry(CompatRecipeEntry<T> entry) {
        recipesById.put(entry.getId(), entry.getRecipeEntry());
        recipesByType.put(entry.getType(), entry.getRecipeEntry());
    }

    public void putRecipeEntry(net.pitan76.mcpitanlib.midohra.recipe.entry.RecipeEntry entry) {
        recipesById.put(entry.getId().toMinecraft(), entry.toMinecraft());
        recipesByType.put(entry.getRawRecipeType(), entry.toMinecraft());
    }

    public void putRecipe(CompatRecipe recipe) {
        recipesById.put(recipe.getId(), recipe.getRecipeEntry().getRecipeEntry());
        recipesByType.put(recipe.getType(), recipe.getRecipeEntry().getRecipeEntry());
    }
}
