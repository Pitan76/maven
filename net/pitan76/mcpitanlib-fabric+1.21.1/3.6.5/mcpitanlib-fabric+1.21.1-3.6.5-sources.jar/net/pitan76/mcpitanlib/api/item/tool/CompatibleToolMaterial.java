package net.pitan76.mcpitanlib.api.item.tool;

import net.minecraft.class_1792;
import net.minecraft.class_1832;
import net.minecraft.class_1856;
import net.minecraft.class_2248;
import net.minecraft.class_3481;
import net.minecraft.class_3489;
import net.minecraft.class_6862;
import net.pitan76.mcpitanlib.api.util.IngredientUtil;

public interface CompatibleToolMaterial {

    int getCompatMiningLevel();

    float getCompatAttackDamage();

    float getCompatMiningSpeedMultiplier();

    default class_1856 getCompatRepairIngredient() {
        return IngredientUtil.fromTagByIdentifier(getRepairTag().comp_327());
    }

    int getCompatDurability();

    int getCompatEnchantability();

    default class_6862<class_2248> getInverseTag() {

        return level2inverseTag(getCompatMiningLevel());
    }

    @Deprecated
    default class_6862<class_2248> _getInverseTag() {
        return getInverseTag();
    }

    public static class_6862<class_2248> level2inverseTag(int level) {
        switch (level) {
            case 1:
                return class_3481.field_49930;
            case 2:
                return class_3481.field_49928;
            case 3:
                return class_3481.field_49927;
            case 4:
                return class_3481.field_49929;
            case 5:
                return class_3481.field_49926;
            case 6:
                return class_3481.field_49925;

            default:
                return class_3481.field_49930;
        }
    }

    @Deprecated
    default float getAttackDamage() {
        return getCompatAttackDamage();
    }

    @Deprecated
    default float getMiningSpeedMultiplier() {
        return getCompatMiningSpeedMultiplier();
    }

    @Deprecated
    default class_1856 getRepairIngredient() {
        return getCompatRepairIngredient();
    }

    @Deprecated
    default int getDurability() {
        return getCompatDurability();
    }

    @Deprecated
    default int getEnchantability() {
        return getCompatEnchantability();
    }

    default class_6862<class_1792> getRepairTag() {
        return class_3489.field_28994;
    }

    default class_1832 build() {
        return new class_1832() {
            @Override
            public int method_8025() {
                return getCompatDurability();
            }

            @Override
            public float method_8027() {
                return getCompatMiningSpeedMultiplier();
            }

            @Override
            public float method_8028() {
                return getCompatAttackDamage();
            }

            @Override
            public class_6862<class_2248> method_58419() {
                return _getInverseTag();
            }

            @Override
            public int method_8026() {
                return getCompatEnchantability();
            }

            @Override
            public class_1856 method_8023() {
                return getCompatRepairIngredient();
            }
        };
    }
}