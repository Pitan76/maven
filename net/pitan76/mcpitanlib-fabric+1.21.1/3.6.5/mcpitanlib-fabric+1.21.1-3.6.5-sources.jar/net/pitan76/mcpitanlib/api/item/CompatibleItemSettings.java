package net.pitan76.mcpitanlib.api.item;

import dev.architectury.registry.registries.RegistrySupplier;
import net.minecraft.class_1761;
import net.minecraft.class_1792;
import net.minecraft.class_1814;
import net.minecraft.class_2960;
import net.minecraft.class_4174;
import net.pitan76.mcpitanlib.api.util.CompatIdentifier;
import net.pitan76.mcpitanlib.core.registry.MCPLRegistry1_20;

import java.util.function.Supplier;

@Deprecated
public class CompatibleItemSettings {
    protected final ExtendSettings settings = new ExtendSettings();

    protected class_2960 itemGroupId = null;

    @Deprecated
    public static CompatibleItemSettings of() {
        return new CompatibleItemSettings();
    }

    // ～1.19.2
    public CompatibleItemSettings addGroup(class_1761 itemGroup) {
        settings.addGroup(itemGroup);
        return this;
    }

    // 1.19.3～
    // identifier: Item ID
    public CompatibleItemSettings addGroup(class_1761 itemGroup, class_2960 identifier) {
        settings.addGroup(itemGroup, identifier);
        return this;
    }

    public CompatibleItemSettings addGroup(Supplier<class_1761> itemGroup, class_2960 identifier) {
        settings.addGroup(itemGroup, identifier);
        return this;
    }

    public CompatibleItemSettings addGroup(CreativeTabBuilder itemGroup) {
        this.itemGroupId = itemGroup.getIdentifier();
        return this;
    }

    public CompatibleItemSettings maxCount(int maxCount) {
        settings.method_7889(maxCount);
        return this;
    }

    public CompatibleItemSettings maxDamage(int maxDamage) {
        settings.method_7895(maxDamage);
        return this;
    }

    public CompatibleItemSettings maxDamageIfAbsent(int maxDamage) {
        try {
            settings.method_7895(maxDamage);
        } catch (Exception ignored) {}

        return this;
    }

    @Deprecated
    public CompatibleItemSettings food(class_4174 foodComponent) {
        settings.method_19265(foodComponent);
        return this;
    }

    public CompatibleItemSettings rarity(class_1814 rarity) {
        settings.method_7894(rarity);
        return this;
    }

    public CompatibleItemSettings recipeRemainder(class_1792 recipeRemainder) {
        settings.method_7896(recipeRemainder);
        return this;
    }

    public ExtendSettings build() {
        if (itemGroupId != null) {
            RegistrySupplier<class_1761> itemGroup = MCPLRegistry1_20.REGISTRY_SUPPLIER_ITEM_GROUP_CACHE.get(itemGroupId);
            settings.arch$tab(itemGroup);
        }
        return settings;
    }

    public CompatibleItemSettings addGroup(class_1761 itemGroup, CompatIdentifier identifier) {
        return addGroup(itemGroup, identifier.toMinecraft());
    }

    public CompatibleItemSettings addGroup(Supplier<class_1761> itemGroup, CompatIdentifier identifier) {
        return addGroup(itemGroup, identifier.toMinecraft());
    }

    public CompatibleItemSettings food(CompatFoodComponent foodComponent) {
        return food(foodComponent.build());
    }
}
