package net.pitan76.mcpitanlib.api.item;

import java.util.Map;
import net.minecraft.class_1738;
import net.minecraft.class_1741;
import net.minecraft.class_6880;
import net.pitan76.mcpitanlib.api.item.v2.CompatItemProvider;
import net.pitan76.mcpitanlib.api.item.v2.CompatibleItemSettings;

public class CompatibleArmorItem extends class_1738 implements CompatItemProvider {
    public final ArmorEquipmentType type;
    public final CompatibleArmorMaterial material;

    @Deprecated
    public static final Map<CompatibleArmorMaterial, class_6880<class_1741>> CACHE = new java.util.HashMap<>();

    public CompatibleItemSettings settings;

    public CompatibleArmorItem(CompatibleArmorMaterial material, ArmorEquipmentType type, CompatibleItemSettings settings) {
        super(material.build(), type.getType(), settings.build());
        this.type = type;
        this.material = material;

        this.settings = settings;
    }

    @Override
    public CompatibleItemSettings getCompatSettings() {
        return settings;
    }

    /**
     * get ArmorEquipmentType
     * @return ArmorEquipmentType
     */
    public ArmorEquipmentType getArmorEquipmentType() {
        return type;
    }

    /**
     * get ArmorMaterial
     * @return CompatibleArmorMaterial
     */
    public CompatibleArmorMaterial getArmorMaterial() {
        return material;
    }
}
