package net.pitan76.mcpitanlib.api.util.recipe;

import it.unimi.dsi.fastutil.ints.IntList;
import net.minecraft.class_1662;
import net.minecraft.class_1799;
import net.minecraft.class_1860;
import net.pitan76.mcpitanlib.api.recipe.CompatibleRecipeEntry;

public class RecipeMatcherUtil {
    public static class_1799 getStackFromId(int itemId) {
        return class_1662.method_7405(itemId);
    }

    public static int getItemId(class_1799 stack) {
        return class_1662.method_7408(stack);
    }

    public static boolean match(class_1662 matcher, CompatibleRecipeEntry entry, IntList output) {
        return match(matcher, entry.getRecipe(), output);
    }

    public static boolean match(class_1662 matcher, CompatibleRecipeEntry entry, IntList output, int multiplier) {
        return match(matcher, entry.getRecipe(), output, multiplier);
    }

    public static boolean match(class_1662 matcher, class_1860<?> recipe, IntList output) {
        return matcher.method_7402(recipe, output);
    }

    public static boolean match(class_1662 matcher, class_1860<?> recipe, IntList output, int multiplier) {
        return matcher.method_7406(recipe, output, multiplier);
    }

    public static void clear(class_1662 matcher) {
        matcher.method_7409();
    }
}
