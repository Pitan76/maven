package net.pitan76.mcpitanlib.api.item.v3;

import net.minecraft.class_1832;
import net.minecraft.class_1834;
import net.minecraft.class_2248;
import net.minecraft.class_6862;
import net.pitan76.mcpitanlib.api.tag.item.RepairIngredientTag;

public class VanillaCompatToolMaterial implements CompatToolMaterial {
    private final class_1832 material;

    public static final VanillaCompatToolMaterial WOOD = of(class_1834.field_8922);
    public static final VanillaCompatToolMaterial STONE = of(class_1834.field_8927);
    public static final VanillaCompatToolMaterial IRON = of(class_1834.field_8923);
    public static final VanillaCompatToolMaterial GOLD = of(class_1834.field_8929);
    public static final VanillaCompatToolMaterial DIAMOND = of(class_1834.field_8930);
    public static final VanillaCompatToolMaterial NETHERITE = of(class_1834.field_22033);

    protected VanillaCompatToolMaterial(class_1832 material) {
        this.material = material;
    }

    private static VanillaCompatToolMaterial of(class_1832 material) {
        return new VanillaCompatToolMaterial(material);
    }

    @Override
    public RepairIngredientTag getRepairIngredientTag() {
        if (material == class_1834.field_8927) return RepairIngredientTag.STONE_TOOL_MATERIALS;
        if (material == class_1834.field_8923) return RepairIngredientTag.IRON_TOOL_MATERIALS;
        if (material == class_1834.field_8929) return RepairIngredientTag.GOLDEN_TOOL_MATERIALS;
        if (material == class_1834.field_8930) return RepairIngredientTag.DIAMOND_TOOL_MATERIALS;
        if (material == class_1834.field_22033) return RepairIngredientTag.NETHERITE_TOOL_MATERIALS;
        return RepairIngredientTag.WOODEN_TOOL_MATERIALS;
    }

    @Override
    public int getCompatDurability() {
        return material.method_8025();
    }

    @Override
    public float getCompatMiningSpeedMultiplier() {
        return material.method_8027();
    }

    @Override
    public float getCompatAttackDamage() {
        return material.method_8028();
    }

    @Override
    public int getCompatMiningLevel() {
        class_6862<class_2248> tag = material.method_58419();
        if (tag == class_1834.field_8922.method_58419()) return 0;
        if (tag == class_1834.field_8927.method_58419()) return 1;
        if (tag == class_1834.field_8923.method_58419()) return 2;
        if (tag == class_1834.field_8929.method_58419()) return 2;
        if (tag == class_1834.field_8930.method_58419()) return 3;
        if (tag == class_1834.field_22033.method_58419()) return 4;
        return -1;
    }

    @Override
    public int getCompatEnchantability() {
        return material.method_8026();
    }

    @Deprecated
    public class_1832 toMinecraft() {
        return material;
    }

    @Override
    public class_1832 build() {
        return material;
    }
}
