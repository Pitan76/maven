package net.pitan76.mcpitanlib.api.util.entity;

import net.minecraft.class_1293;
import net.minecraft.class_1297;
import net.minecraft.class_1304;
import net.minecraft.class_1309;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.pitan76.mcpitanlib.api.entity.effect.CompatStatusEffect;
import net.pitan76.mcpitanlib.api.entity.effect.CompatStatusEffectInstance;
import net.pitan76.mcpitanlib.api.item.ArmorEquipmentType;
import net.pitan76.mcpitanlib.api.util.EntityUtil;
import net.pitan76.mcpitanlib.midohra.entity.EntityWrapper;

import java.util.ArrayList;
import java.util.List;

public class LivingEntityUtil extends EntityUtil {
    public static void addStatusEffect(class_1309 entity, CompatStatusEffectInstance effect) {
        entity.method_6092(effect.getInstance());
    }

    public static void removeStatusEffect(class_1309 entity, CompatStatusEffectInstance effect) {
        entity.method_6016(effect.getInstance().method_5579());
    }

    public static void removeStatusEffect(class_1309 entity, CompatStatusEffect effect, class_1937 world) {
        entity.method_6016(effect.getEntry(world));
    }

    public static List<CompatStatusEffectInstance> getStatusEffects(class_1309 entity) {
        List<CompatStatusEffectInstance> compatEffects = new ArrayList<>();

        for (class_1293 effect : entity.method_6026()) {
            compatEffects.add(new CompatStatusEffectInstance(effect));
        }

        return compatEffects;
    }

    public static float getHealth(class_1309 entity) {
        return entity.method_6032();
    }

    public static void setHealth(class_1309 entity, float health) {
        entity.method_6033(health);
    }

    public static float getMaxHealth(class_1309 entity) {
        return entity.method_6063();
    }

    public static class_1799 getEquippedStack(class_1309 entity, class_1304 slot) {
        return entity.method_6118(slot);
    }

    public static void setEquippedStack(class_1309 entity, class_1304 slot, class_1799 stack) {
        entity.method_5673(slot, stack);
    }

    public static class_1799 getEquippedStack(class_1309 entity, ArmorEquipmentType type) {
        return getEquippedStack(entity, type.getSlot());
    }

    public static void setEquippedStack(class_1309 entity, ArmorEquipmentType type, class_1799 stack) {
        entity.method_5673(type.getSlot(), stack);
    }

    public static net.pitan76.mcpitanlib.midohra.item.ItemStack getEquippedStack(EntityWrapper entity, ArmorEquipmentType slot) {
        class_1297 e = entity.get();
        if (e instanceof class_1309) {
            return net.pitan76.mcpitanlib.midohra.item.ItemStack.of(getEquippedStack((class_1309) e, slot));
        }

        return net.pitan76.mcpitanlib.midohra.item.ItemStack.empty();
    }

    public static void setEquippedStack(EntityWrapper entity, ArmorEquipmentType slot, net.pitan76.mcpitanlib.midohra.item.ItemStack stack) {
        class_1297 e = entity.get();
        if (e instanceof class_1309) {
            setEquippedStack((class_1309) e, slot, stack.toMinecraft());
        }
    }
}
