package net.pitan76.mcpitanlib.api.util;

import net.minecraft.class_2960;

public class IdentifierUtil {
    public static class_2960 id(String id) {
        return class_2960.method_60654(id);
    }

    public static class_2960 id(String namespace, String path) {
        return class_2960.method_60655(namespace, path);
    }

    public static String toString(class_2960 identifier) {
        return identifier.toString();
    }

    public static String getNamespace(class_2960 identifier) {
        return identifier.method_12836();
    }

    public static String getPath(class_2960 identifier) {
        return identifier.method_12832();
    }

    public static class_2960 from(CompatIdentifier id) {
        if (id == null)
            return null;

        return id.toMinecraft();
    }
}
