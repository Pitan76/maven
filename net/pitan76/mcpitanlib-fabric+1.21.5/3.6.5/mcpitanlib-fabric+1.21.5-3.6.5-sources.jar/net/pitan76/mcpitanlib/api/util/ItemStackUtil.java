package net.pitan76.mcpitanlib.api.util;

import net.minecraft.class_1304;
import net.minecraft.class_1309;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1935;
import net.minecraft.class_1937;
import net.minecraft.class_2487;
import net.minecraft.class_3222;
import net.pitan76.mcpitanlib.api.entity.Player;
import net.pitan76.mcpitanlib.api.event.nbt.NbtRWArgs;
import net.pitan76.mcpitanlib.midohra.item.ItemWrapper;

import java.util.Objects;
import java.util.Optional;

public class ItemStackUtil {
    public static class_1799 copy(class_1799 stack) {
        return stack.method_7972();
    }

    public static class_1799 copyWithCount(class_1799 stack, int count) {
        return stack.method_46651(count);
    }

    public static boolean areItemsEqual(class_1799 left, class_1799 right) {
        return class_1799.method_7984(left, right);
    }

    @Deprecated
    public static boolean areNbtEqual(class_1799 left, class_1799 right) {
        return areNbtOrComponentEqual(left, right);
    }

    /**
     * NBT (1.20.4) か Component (1.20.5以降) が一致するかどうかを取得する。
     * @param left ItemStack
     * @param right ItemStack
     * @return NBTかComponentが一致するかどうか
     */
    public static boolean areNbtOrComponentEqual(class_1799 left, class_1799 right) {
        return Objects.equals(left.method_57353(), right.method_57353());
    }

    /**
     * NBTかComponentが存在するかどうか
     * @param stack ItemStack
     * @return Whether NBT or Component exists
     */
    public static boolean hasNbtOrComponent(class_1799 stack) {
        return !stack.method_57353().method_57837();
    }

    /**
     * NBTからItemStackを取得する
     * @param world World
     * @param nbt NbtCompound
     * @return ItemStack
     */
    public static class_1799 fromNbt(class_1937 world, class_2487 nbt) {
        return class_1799.method_57360(world.method_30349(), nbt).orElse(class_1799.field_8037);
    }

    /**
     * NBTからItemStackを取得する
     * @param args NbtRWArgs
     * @return ItemStack
     */
    public static class_1799 fromNbt(NbtRWArgs args) {
        return class_1799.method_57360(args.getWrapperLookup(), args.getNbt()).orElse(class_1799.field_8037);
    }

    public static class_1799 getDefaultStack(class_1792 item) {
        return item.method_7854();
    }

    public static int getMaxDamage(class_1799 stack) {
        return stack.method_7936();
    }

    public static int getMaxDamage(class_1792 item) {
        return getMaxDamage(getDefaultStack(item));
    }

    public static int getDamage(class_1799 stack) {
        return stack.method_7919();
    }

    public static void setDamage(class_1799 stack, int damage) {
        stack.method_7974(damage);
    }

    public static int getCount(class_1799 stack) {
        return stack.method_7947();
    }

    public static void setCount(class_1799 stack, int count) {
        stack.method_7939(count);
    }

    public static void decrementCount(class_1799 stack, int count) {
        stack.method_7934(count);
    }

    public static void incrementCount(class_1799 stack, int count) {
        stack.method_7933(count);
    }

    public static void damage(class_1799 stack, int amount, class_3222 entity, Runnable breakCallback) {
        stack.method_7956(amount, entity.method_51469(), entity, (item) -> breakCallback.run());
    }

    public static void damage(class_1799 stack, int amount, class_1309 entity, class_1304 slot) {
        stack.method_7970(amount, entity, slot);
    }

    public static void damage(class_1799 stack, int amount, class_3222 entity) {
        stack.method_7956(amount, entity.method_51469(), entity, (item) -> entity.method_20235(item, class_1304.field_6173));
    }

    public static void damage(class_1799 stack, int amount, Player entity) {
        Optional<class_3222> player = entity.getServerPlayer();
        if (player.isEmpty()) return;

        damage(stack, amount, player.get());
    }

    public static class_1799 empty() {
        return class_1799.field_8037;
    }

    public static class_1799 create(class_1792 item) {
        if (item == null) return empty();
        return new class_1799(item);
    }

    public static class_1799 create(class_1792 item, int count) {
        if (item == null) return empty();
        return new class_1799(item, count);
    }

    public static class_1799 create(class_1935 item) {
        if (item == null) return empty();
        return new class_1799(item);
    }

    public static class_1799 create(class_1935 item, int count) {
        if (item == null) return empty();
        return new class_1799(item, count);
    }

    public static boolean isEmpty(class_1799 stack) {
        if (stack == null) return true;
        return stack.method_7960();
    }

    public static boolean isEnchantable(class_1799 stack) {
        return stack.method_7923();
    }

    public static boolean isDamageable(class_1799 stack) {
        return stack.method_7963();
    }

    public static boolean isBreak(class_1799 stack) {
        if (isDamageable(stack))
            return getDamage(stack) >= getMaxDamage(stack);

        return false;
    }

    public static ItemWrapper getItemWrapper(class_1799 stack) {
        return ItemWrapper.of(stack.method_7909());
    }

    public static int getMaxCount(class_1799 stack) {
        return stack.method_7914();
    }

    public static class_1792 getItem(class_1799 stack) {
        return stack.method_7909();
    }
}
