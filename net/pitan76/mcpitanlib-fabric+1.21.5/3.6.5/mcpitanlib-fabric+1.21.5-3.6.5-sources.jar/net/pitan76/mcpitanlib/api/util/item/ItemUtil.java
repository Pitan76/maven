package net.pitan76.mcpitanlib.api.util.item;

import net.minecraft.class_1747;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_2248;
import net.pitan76.mcpitanlib.api.item.v2.CompatibleItemSettings;
import net.pitan76.mcpitanlib.api.tag.TagKey;
import net.pitan76.mcpitanlib.api.text.TextComponent;
import net.pitan76.mcpitanlib.api.util.CompatIdentifier;
import net.pitan76.mcpitanlib.api.util.ItemStackUtil;

import java.util.ArrayList;
import java.util.List;

@SuppressWarnings("deprecation")
public class ItemUtil {

    /**
     * Check if the item is equal.
     * @param item Item to compare.
     * @param item2 Item to compare.
     * @return If the item is equal.
     */
    public static boolean isEqual(class_1792 item, class_1792 item2) {
        return net.pitan76.mcpitanlib.api.util.ItemUtil.isEqual(item, item2);
    }

    /**
     * Get item from CompatIdentifier.
     * @param id CompatIdentifier of the item.
     * @return Item of the CompatIdentifier.
     */
    public static class_1792 fromId(CompatIdentifier id) {
        return net.pitan76.mcpitanlib.api.util.ItemUtil.fromId(id);
    }

    public static class_1792 fromId(String id) {
        return fromId(CompatIdentifier.of(id));
    }

    public static class_1792 fromId(String namespace, String path) {
        return fromId(CompatIdentifier.of(namespace, path));
    }

    /**
     * Get CompatIdentifier from Item.
     * @param item Item to get CompatIdentifier.
     * @return CompatIdentifier of the Item.
     */
    public static CompatIdentifier toId(class_1792 item) {
        return net.pitan76.mcpitanlib.api.util.ItemUtil.toCompatID(item);
    }

    public static String toIdAsString(class_1792 item) {
        return toId(item).toString();
    }

    /**
     * Check if the item exist.
     * @param id CompatIdentifier of the item.
     * @return If the item exist.
     */
    public static boolean isExist(CompatIdentifier id) {
        return net.pitan76.mcpitanlib.api.util.ItemUtil.isExist(id);
    }

    public static boolean isExist(String id) {
        return isExist(CompatIdentifier.of(id));
    }

    public static boolean isExist(String namespace, String path) {
        return isExist(CompatIdentifier.of(namespace, path));
    }

    public static boolean isMinecraftItem(class_1792 item) {
        return CompatIdentifier.isMinecraftNamespace(toId(item));
    }

    /**
     * Create a new BlockItem.
     * @param block Block to create BlockItem.
     * @param settings CompatItemSettings of the BlockItem.
     * @return The new BlockItem.
     */
    public static class_1747 create(class_2248 block, CompatibleItemSettings settings) {
        if (!settings.changedTranslationKey)
            settings.useBlockPrefixedTranslationKey();

        return net.pitan76.mcpitanlib.api.util.ItemUtil.ofBlock(block, settings);
    }

    /**
     * Create a new Item.
     * @param settings CompatItemSettings of the Item.
     * @return The new Item.
     */
    public static class_1792 create(CompatibleItemSettings settings) {
        return net.pitan76.mcpitanlib.api.util.ItemUtil.of(settings);
    }

    /**
     * Get all items.
     * @return List of all items.
     */
    public static List<class_1792> getItems() {
        return net.pitan76.mcpitanlib.api.util.ItemUtil.getAllItems();
    }

    /**
     * Get items in the tag.
     * @param tagKey TagKey of the items.
     * @return List of items in the tag.
     */
    public static List<class_1792> getInTag(TagKey<class_1792> tagKey) {
        return net.pitan76.mcpitanlib.api.util.ItemUtil.getItems(tagKey);
    }

    /**
     * Get items in the tag.
     * @param id CompatIdentifier of the tag.
     * @return List of items in the tag.
     */
    public static List<class_1792> getInTag(CompatIdentifier id) {
        return net.pitan76.mcpitanlib.api.util.ItemUtil.getItems(id);
    }

    public static List<class_1792> getInTag(String id) {
        return getInTag(CompatIdentifier.of(id));
    }

    public static List<class_1792> getInTag(String namespace, String path) {
        return getInTag(CompatIdentifier.of(namespace, path));
    }

    /**
     * Check if the item is in the tag.
     * @param item Item to check.
     * @param tagKey TagKey of the tag.
     * @return If the item is in the tag.
     */
    public static boolean isInTag(class_1792 item, TagKey<class_1792> tagKey) {
        return net.pitan76.mcpitanlib.api.util.ItemUtil.isIn(item, tagKey);
    }

    /**
     * Check if the item is in the tag.
     * @param item Item to check.
     * @param id CompatIdentifier of the tag.
     * @return If the item is in the tag.
     */
    public static boolean isInTag(class_1792 item, CompatIdentifier id) {
        return net.pitan76.mcpitanlib.api.util.ItemUtil.isItemInTag(item, id);
    }

    public static boolean isInTag(class_1792 item, String id) {
        return isInTag(item, CompatIdentifier.of(id));
    }

    public static boolean isInTag(class_1792 item, String namespace, String path) {
        return isInTag(item, CompatIdentifier.of(namespace, path));
    }

    /**
     * Get raw id of the item.
     * @param item Item to get raw id.
     * @return Raw id of the item.
     */
    public static int toRawId(class_1792 item) {
        return net.pitan76.mcpitanlib.api.util.ItemUtil.getRawId(item);
    }

    /**
     * Get item from raw id.
     * @param rawId Raw id of the item.
     * @return Item from raw id.
     */
    public static class_1792 fromRawId(int rawId) {
        return net.pitan76.mcpitanlib.api.util.ItemUtil.fromIndex(rawId);
    }

    /**
     * Get items by namespace.
     * @param namespace Namespace of the items.
     * @return List of items by namespace.
     */
    public static List<class_1792> getItemsByNamespace(String namespace) {
        List<class_1792> items = new ArrayList<>();

        for (class_1792 item : getItems()) {
            if (toId(item).getNamespace().equals(namespace))
                items.add(item);
        }

        return items;
    }

    /**
     * Get number of all items.
     * @return Number of all items.
     */
    public static int getNumberOfItems() {
        return getItems().size();
    }

    /**
     * Get item from stack.
     * @param stack ItemStack to get item.
     * @return Item of the stack.
     */
    public static class_1792 of(class_1799 stack) {
        return stack.method_7909();
    }

    /**
     * Check if the item is of the item.
     * @param stack ItemStack to check.
     * @param item Item to check.
     * @return If the item is of the item.
     */
    public static boolean isOf(class_1799 stack, class_1792 item) {
        return net.pitan76.mcpitanlib.api.util.ItemUtil.isOf(stack, item);
    }

    /**
     * Get name of the item.
     * @param item Item
     * @return Name of the item.
     */
    public static String getNameAsString(class_1792 item) {
        return item.method_63680().getString();
    }

    /**
     * Get name of the item.
     * @param item Item
     * @return Name of the item.
     */
    public static TextComponent getName(class_1792 item) {
        return new TextComponent(item.method_63680());
    }

    /**
     * Get translation key of the item.
     * @param item Item
     * @return Translation key of the item.
     */
    public static String getTranslationKey(class_1792 item) {
        return item.method_7876();
    }

    public static boolean hasRecipeRemainder(class_1792 item) {
        return !ItemStackUtil.isEmpty(getRecipeRemainderStack(item));
    }

    public static class_1792 getRecipeRemainder(class_1792 item) {
        return getRecipeRemainderStack(item).method_7909();
    }

    public static class_1799 getRecipeRemainderStack(class_1792 item) {
        return item.method_7858();
    }
}
