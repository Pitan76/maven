package net.pitan76.mcpitanlib.api.item.tool;

import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_9886;
import net.pitan76.mcpitanlib.api.event.item.ItemUseOnEntityEvent;
import net.pitan76.mcpitanlib.api.event.item.PostHitEvent;
import net.pitan76.mcpitanlib.api.event.item.PostMineEvent;
import net.pitan76.mcpitanlib.api.item.v2.CompatItemProvider;
import net.pitan76.mcpitanlib.api.item.v2.CompatibleItemSettings;
import net.pitan76.mcpitanlib.api.tag.TagKey;
import net.pitan76.mcpitanlib.api.tag.v2.CompatTagKey;
import net.pitan76.mcpitanlib.api.tag.v2.typed.BlockTagKey;
import net.pitan76.mcpitanlib.api.util.CompatActionResult;
import net.pitan76.mcpitanlib.api.util.ItemStackUtil;

public class CompatibleMiningToolItem extends class_1792 implements CompatItemProvider {

    public CompatibleItemSettings settings;

    @Deprecated
    protected CompatibleMiningToolItem(float attackDamage, float attackSpeed, class_9886 material, net.minecraft.class_6862<class_2248> effectiveBlocks, class_1793 settings) {
        super(settings.method_66331(material, effectiveBlocks, attackDamage, attackSpeed, 0));
    }

    public CompatibleMiningToolItem(CompatibleToolMaterial material, int attackDamage, float attackSpeed, TagKey<class_2248> tagKey, CompatibleItemSettings settings) {
        this(attackDamage, attackSpeed, material.build(), tagKey.getTagKey(), settings.build());
        this.settings = settings;
    }

    public CompatibleMiningToolItem(CompatibleToolMaterial material, int attackDamage, float attackSpeed, CompatTagKey<class_2248> tagKey, CompatibleItemSettings settings) {
        this(attackDamage, attackSpeed, material.build(), tagKey.getTagKey(), settings.build());
        this.settings = settings;
    }

    public CompatibleMiningToolItem(CompatibleToolMaterial material, int attackDamage, float attackSpeed, BlockTagKey tagKey, CompatibleItemSettings settings) {
        this(attackDamage, attackSpeed, material.build(), tagKey.getTagKey(), settings.build());
        this.settings = settings;
    }

    @Override
    public CompatibleItemSettings getCompatSettings() {
        return settings;
    }

    public boolean overrideIsSuitableFor(class_2680 state) {
        return super.method_58405(method_7854(), state);
    }

    @Deprecated
    @Override
    public boolean method_58405(class_1799 stack, class_2680 state) {
        return overrideIsSuitableFor(state);
    }

    public float overrideGetMiningSpeedMultiplier(class_1799 stack, class_2680 state) {
        return 1.0F;
    }

    @Deprecated
    @Override
    public float method_58404(class_1799 stack, class_2680 state) {
        return overrideGetMiningSpeedMultiplier(stack, state);
    }

    /**
     * post hit event
     * @param event PostHitEvent
     * @return boolean
     */
    public boolean postHit(PostHitEvent event) {
        super.method_7873(event.stack, event.target, event.attacker);
        return true;
    }

    /**
     * post mine event
     * @param event PostMineEvent
     * @return boolean
     */
    public boolean postMine(PostMineEvent event) {
        return super.method_7879(event.stack, event.world, event.state, event.pos, event.miner);
    }

    @Deprecated
    @Override
    public void method_7873(class_1799 stack, class_1309 target, class_1309 attacker) {
        postHit(new PostHitEvent(stack, target, attacker));
    }

    @Deprecated
    @Override
    public boolean method_7879(class_1799 stack, class_1937 world, class_2680 state, class_2338 pos, class_1309 miner) {
        return postMine(new PostMineEvent(stack, world, state, pos, miner));
    }

    // -1.20.6
    public boolean isDamageableOnDefault() {
        return ItemStackUtil.getMaxDamage(this) > 0;
    }

    @Deprecated
    @Override
    public class_1269 method_7847(class_1799 stack, class_1657 user, class_1309 entity, class_1268 hand) {
        return onRightClickOnEntity(new ItemUseOnEntityEvent(stack, user, entity, hand)).toActionResult();
    }

    @Deprecated
    @Override
    public CompatActionResult onRightClickOnEntity(ItemUseOnEntityEvent event, Options options) {
        return CompatItemProvider.super.onRightClickOnEntity(event, options);
    }

    public CompatActionResult onRightClickOnEntity(ItemUseOnEntityEvent e) {
        return CompatActionResult.of(super.method_7847(e.stack, e.user.getEntity(), e.entity, e.hand));
    }
}