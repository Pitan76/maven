package net.pitan76.mcpitanlib.api.util;

import net.minecraft.class_1799;
import net.minecraft.class_1887;
import net.minecraft.class_1890;
import net.minecraft.class_1937;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.minecraft.class_7924;
import net.minecraft.class_9304;
import net.minecraft.class_9334;
import net.pitan76.mcpitanlib.api.enchantment.CompatEnchantment;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class EnchantmentUtil {
    public static CompatEnchantment getEnchantment(class_2960 identifier) {
        class_5321<class_1887> registryKey = class_5321.method_29179(class_7924.field_41265, identifier);
        return new CompatEnchantment(registryKey);
    }

    public static class_2960 getId(CompatEnchantment enchantment) {
        return enchantment.getId();
    }

    public static int getLevel(CompatEnchantment enchantment, class_1799 stack, @Nullable class_1937 world) {
        return enchantment.getLevel(stack, world);
    }

    // CompatIdentifier
    public static CompatEnchantment getEnchantment(CompatIdentifier identifier) {
        return getEnchantment(identifier.toMinecraft());
    }

    public static CompatIdentifier getCompatId(CompatEnchantment enchantment) {
        return CompatIdentifier.fromMinecraft(enchantment.getId());
    }

    public static List<CompatEnchantment> getEnchantments(class_1799 stack) {
        List<CompatEnchantment> enchantments = new ArrayList<>();

        class_1890.method_57532(stack).method_57534().forEach((enchantment) -> {
            if (enchantment.method_40230().isPresent())
                enchantments.add(new CompatEnchantment(enchantment.method_40230().get()));
        });

        return enchantments;
    }

    public static boolean hasEnchantment(class_1799 stack) {
        return class_1890.method_58117(stack);
    }

    public static Map<CompatEnchantment, Integer> getEnchantment(class_1799 stack, @Nullable class_1937 world) {
        Map<CompatEnchantment, Integer> enchantments = new HashMap<>();

        List<CompatEnchantment> enchantmentList = getEnchantments(stack);
        enchantmentList.forEach((enchantment) -> {
            enchantments.put(enchantment, getLevel(enchantment, stack, world));
        });

        return enchantments;
    }

    public static void setEnchantment(class_1799 stack, Map<CompatEnchantment, Integer> enchantments, @Nullable class_1937 world) {
        class_9304.class_9305 builder = new class_9304.class_9305(class_9304.field_49385);

        enchantments.forEach((compatEnchantment, integer) -> {
            builder.method_57550(compatEnchantment.getEntry(world), integer);
        });

        class_1890.method_57530(stack, builder.method_57549());
    }

    public static void removeEnchantment(class_1799 stack) {
        stack.method_57381(class_9334.field_49633);
    }
}
