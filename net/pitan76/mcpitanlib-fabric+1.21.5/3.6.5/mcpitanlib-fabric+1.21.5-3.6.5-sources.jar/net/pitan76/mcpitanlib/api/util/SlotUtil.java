package net.pitan76.mcpitanlib.api.util;

import net.minecraft.class_1263;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.pitan76.mcpitanlib.api.entity.Player;

public class SlotUtil {
    public static void setStack(class_1735 slot, class_1799 stack) {
        slot.method_53512(stack);
    }

    public static class_1799 getStack(class_1735 slot) {
        return slot.method_7677();
    }

    public static void takeStack(class_1735 slot, int amount) {
        slot.method_7671(amount);
    }

    public static boolean hasStack(class_1735 slot) {
        return slot.method_7681();
    }

    public static void markDirty(class_1735 slot) {
        slot.method_7668();
    }

    public static boolean canInsert(class_1735 slot, class_1799 stack) {
        return slot.method_7680(stack);
    }

    public static boolean canTakeItems(class_1735 slot) {
        return slot.method_7674(null);
    }

    public static void onTakeItem(class_1735 slot, Player player, class_1799 stack) {
        slot.method_7667(player.getEntity(), stack);
    }

    public static class_1263 getInventory(class_1735 slot) {
        return slot.field_7871;
    }
}
