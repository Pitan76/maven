package net.pitan76.mcpitanlib.api.util.particle.effect;

import net.minecraft.class_2394;
import net.pitan76.mcpitanlib.api.util.particle.CompatParticleType;

public class CompatParticleEffect {
    private final class_2394 effect;

    @Deprecated
    public CompatParticleEffect(class_2394 effect) {
        this.effect = effect;
    }

    @Deprecated
    public static CompatParticleEffect of(class_2394 effect) {
        return new CompatParticleEffect(effect);
    }

    public static CompatParticleEffect of(CompatParticleType type) {
        class_2394 options = type::getRaw;
        return new CompatParticleEffect(options);
    }

    @Deprecated
    public class_2394 getRaw() {
        return effect;
    }

    public CompatParticleType getType() {
        return CompatParticleType.of(getRaw().method_10295());
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        CompatParticleEffect other = (CompatParticleEffect) obj;
        return getRaw().equals(other.getRaw());
    }

    @Override
    public int hashCode() {
        return getRaw().hashCode();
    }
}
