package net.pitan76.mcpitanlib.api.event.entity;

import net.minecraft.class_2940;
import net.minecraft.class_2945;
import org.jetbrains.annotations.Nullable;

public class InitDataTrackerArgs {
    public class_2945.class_9222 builder;
    public class_2945 tracker;

    public InitDataTrackerArgs(class_2945.class_9222 builder) {
        this.builder = builder;
    }

    public InitDataTrackerArgs(class_2945 tracker) {
        this.tracker = tracker;
    }

    public InitDataTrackerArgs(class_2945.class_9222 builder, @Nullable class_2945 tracker) {
        this.builder = builder;
        this.tracker = tracker;
    }

    public class_2945.class_9222 getBuilder() {
        return builder;
    }

    public <T> class_2945.class_9222 add(class_2940<T> data, T value) {
        return builder.method_56912(data, value);
    }

    public <T> void set(class_2940<T> data, T value) {
        tracker.method_12778(data, value);
    }

    public <T> void addTracking(class_2940<T> data, T value) {
        if (builder != null) {
            add(data, value);
            return;
        }

        if (tracker != null) {
            set(data, value);
            return;
        }
    }
}
