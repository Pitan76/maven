package net.pitan76.mcpitanlib.api.util;

import net.minecraft.class_1856;
import net.minecraft.class_2960;
import net.minecraft.class_3414;
import net.minecraft.class_3489;
import net.minecraft.class_9886;
import net.pitan76.mcpitanlib.api.item.ArmorEquipmentType;
import net.pitan76.mcpitanlib.api.item.CompatibleArmorMaterial;
import net.pitan76.mcpitanlib.api.item.tool.CompatibleToolMaterial;
import net.pitan76.mcpitanlib.api.tag.item.RepairIngredientTag;

public class EquipMaterialUtil {
    @Deprecated
    public static class_9886 createToolMaterial(int durability, float miningSpeedMultiplier, float attackDamage, int miningLevel, int enchantability, class_1856 repairIngredient) {
        return new class_9886(CompatibleToolMaterial.level2inverseTag(miningLevel), durability, miningSpeedMultiplier, attackDamage, enchantability, class_3489.field_52382);
    }

    public static class_9886 createToolMaterial(int durability, float miningSpeedMultiplier, float attackDamage, int miningLevel, int enchantability, RepairIngredientTag ingredientTag) {
        return new class_9886(CompatibleToolMaterial.level2inverseTag(miningLevel), durability, miningSpeedMultiplier, attackDamage, enchantability, ingredientTag.getTag());
    }

    public static int toInt(ArmorEquipmentType type) {
        switch (type.getSlot()) {
            case field_6169:
                return 0;
            case field_6174:
                return 1;
            case field_6172:
                return 2;
            case field_6166:
                return 3;
            default:
                return 0;
        }
    }

    public static CompatibleArmorMaterial createArmorMaterial(int[] durability, int[] protection, int enchantability, class_3414 equipSound, class_1856 repairIngredient, String name, float toughness, float knockbackResistance) {
        return ArmorMaterialUtil.create(name, durability, protection, enchantability, equipSound, toughness, knockbackResistance, repairIngredient);
    }

    @Deprecated
    public static CompatibleArmorMaterial createArmorMaterial(int[] durability, int[] protection, int enchantability, class_3414 equipSound, class_1856 repairIngredient, class_2960 id, float toughness, float knockbackResistance) {
        return ArmorMaterialUtil.create(id, durability, protection, enchantability, equipSound, toughness, knockbackResistance, repairIngredient);
    }
}
