package net.pitan76.mcpitanlib.api.util;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import net.minecraft.class_2960;
import net.minecraft.class_3414;
import net.minecraft.class_7923;

public class SoundEventUtil {
    public static class_2960 getId(class_3414 soundEvent) {
        return soundEvent.comp_3319();
    }

    public static class_3414 getSoundEvent(class_2960 id) {
        return class_3414.method_47908(id);
    }

    public static CompatIdentifier getCompatId(class_3414 soundEvent) {
        return CompatIdentifier.fromMinecraft(getId(soundEvent));
    }

    public static class_3414 getSoundEvent(CompatIdentifier id) {
        return getSoundEvent(id.toMinecraft());
    }

    public static List<class_3414> getAllSoundEvents() {
        return class_7923.field_41172.method_10220().collect(Collectors.toList());
    }

    public static List<class_2960> getAllSoundEventIds() {
        return new ArrayList<>(class_7923.field_41172.method_10235());
    }
}
