package net.pitan76.mcpitanlib.api.entity.attribute;

import net.minecraft.class_1320;
import net.minecraft.class_6880;

public class CompatEntityAttribute {
    public final class_6880<class_1320> raw;

    @Deprecated
    public CompatEntityAttribute(class_6880<class_1320> attribute) {
        this.raw = attribute;
    }

    @Deprecated
    public class_6880<class_1320> raw() {
        return raw;
    }

    public String getId() {
        return raw.method_55840();
    }

    public class_1320 getValue() {
        return raw.comp_349();
    }

    public boolean isNull() {
        return raw == null;
    }

    @Deprecated
    public static CompatEntityAttribute of(class_6880<class_1320> attribute) {
        return new CompatEntityAttribute(attribute);
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (!(obj instanceof CompatEntityAttribute)) return false;
        CompatEntityAttribute that = (CompatEntityAttribute) obj;
        return raw.equals(that.raw);
    }

    @Override
    public int hashCode() {
        if (raw == null) return super.hashCode();
        return raw.hashCode();
    }
}
