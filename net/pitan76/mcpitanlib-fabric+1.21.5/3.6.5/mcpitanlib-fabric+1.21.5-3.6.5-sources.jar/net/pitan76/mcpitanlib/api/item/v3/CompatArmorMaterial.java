package net.pitan76.mcpitanlib.api.item.v3;

import net.minecraft.class_1792;
import net.minecraft.class_6862;
import net.pitan76.mcpitanlib.api.tag.item.RepairIngredientTag;

public interface CompatArmorMaterial extends net.pitan76.mcpitanlib.api.item.v2.CompatArmorMaterial {

    @Deprecated
    @Override
    default class_6862<class_1792> getRepairTag() {
        return getRepairIngredientTag().getTag();
    }

    RepairIngredientTag getRepairIngredientTag();
}
