package net.pitan76.mcpitanlib.api.network;

import dev.architectury.networking.NetworkManager;
import dev.architectury.networking.transformers.PacketTransformer;
import io.netty.buffer.Unpooled;
import net.minecraft.class_2540;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_746;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9139;
import net.pitan76.mcpitanlib.core.network.BufPayload;

import java.util.List;

import static dev.architectury.impl.NetworkAggregator.*;

import dev.architectury.impl.NetworkAggregator.BufCustomPacketPayload;

public class ClientNetworking {
    public static void send(class_2960 identifier, class_2540 buf) {
        /*
        if (!C2S_TYPE.containsKey(identifier)) {
            CustomPayload.Id type = new CustomPayload.Id<>(identifier);
            C2S_TYPE.put(identifier, type);
            //registerC2SType(type, NetworkAggregator.BufCustomPacketPayload.streamCodec(type), List.of());
        }
         */

        BufPayload payload = new BufPayload(buf, identifier);
        NetworkManager.sendToServer(payload);
    }

    public static void registerReceiver(class_2960 identifier, ClientNetworkHandler handler) {
        BufPayload.Id<BufPayload> id = BufPayload.id(identifier);

        NetworkManager.registerReceiver(NetworkManager.Side.S2C, id, BufPayload.getCodec(id),
                (payload, context) -> {
                    class_2540 buf = new class_2540(Unpooled.wrappedBuffer(payload.getData()));

                    class_746 player = null;
                    if (context.getPlayer() instanceof class_746)
                        player = (class_746) context.getPlayer();

                    handler.receive(class_310.method_1551(), player, buf);
                    buf.release();
                });
    }

    @FunctionalInterface
    public interface ClientNetworkHandler {
        void receive(class_310 client, class_746 player, class_2540 buf);
    }


    public static void registerC2SType(class_8710.class_9154<BufCustomPacketPayload> type, class_9139<? super class_9129, BufCustomPacketPayload> codec, List<PacketTransformer> packetTransformers) {
//        Objects.requireNonNull(type, "Cannot register a null type!");
//        packetTransformers = Objects.requireNonNullElse(packetTransformers, List.of());
//        C2S_CODECS.put(type.id(), (PacketCodec<ByteBuf, ?>) codec);
//        C2S_TRANSFORMERS.put(type.id(), PacketTransformer.concat(packetTransformers));
    }
}
