package net.pitan76.mcpitanlib.api.util.recipe.input;

import net.minecraft.class_1799;
import net.minecraft.class_9696;
import net.pitan76.mcpitanlib.api.recipe.input.CompatRecipeInput;
import net.pitan76.mcpitanlib.api.util.ItemStackUtil;

import java.util.Optional;

public class SingleStackRecipeInputUtil {
    public static Optional<class_9696> get(CompatRecipeInput<?> input) {
        if (input.getInput() instanceof class_9696) {
            return Optional.of((class_9696) input.getInput());
        }
        return Optional.empty();
    }

    public static CompatRecipeInput<?> create(class_9696 input) {
        return new CompatRecipeInput<>(input);
    }

    public static CompatRecipeInput<?> create(class_1799 stack) {
        return new CompatRecipeInput<>(new class_9696(stack));
    }

    public static class_1799 getStack(CompatRecipeInput<?> input) {
        Optional<class_9696> recipeInput = get(input);
        if (!recipeInput.isPresent()) return ItemStackUtil.empty();

        return recipeInput.get().method_59984(0);
    }
}
