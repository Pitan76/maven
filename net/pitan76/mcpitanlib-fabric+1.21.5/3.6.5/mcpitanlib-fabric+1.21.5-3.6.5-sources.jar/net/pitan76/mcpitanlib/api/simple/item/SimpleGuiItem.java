package net.pitan76.mcpitanlib.api.simple.item;

import net.minecraft.class_1703;
import net.minecraft.class_2561;
import net.pitan76.mcpitanlib.api.event.container.factory.DisplayNameArgs;
import net.pitan76.mcpitanlib.api.event.item.ItemUseEvent;
import net.pitan76.mcpitanlib.api.gui.args.CreateMenuEvent;
import net.pitan76.mcpitanlib.api.gui.v2.SimpleScreenHandlerFactory;
import net.pitan76.mcpitanlib.api.item.v2.CompatibleItemSettings;
import net.pitan76.mcpitanlib.api.item.v2.CompatItem;
import net.pitan76.mcpitanlib.api.util.StackActionResult;

public class SimpleGuiItem extends CompatItem implements SimpleScreenHandlerFactory {

    public ScreenHandlerFactory factory;
    public class_2561 name;

    public SimpleGuiItem(CompatibleItemSettings settings, ScreenHandlerFactory factory, class_2561 name) {
        super(settings);
        this.factory = factory;
        this.name = name;
    }

    public SimpleGuiItem(CompatibleItemSettings settings, ScreenHandlerFactory factory) {
        super(settings);
        this.factory = factory;
    }

    public SimpleGuiItem(CompatibleItemSettings settings) {
        super(settings);
    }

    @Override
    public StackActionResult onRightClick(ItemUseEvent e) {
        if (!e.isClient())
            e.user.openGuiScreen(this);

        return e.success();
    }

    @Override
    public class_2561 getDisplayName(DisplayNameArgs args) {
        if (name == null)
            return method_63680();

        return name;
    }

    @Override
    public class_1703 createMenu(CreateMenuEvent e) {
        if (factory == null)
            return null;

        return factory.create(e);
    }

    @FunctionalInterface
    public interface ScreenHandlerFactory {
        class_1703 create(CreateMenuEvent e);
    }
}
