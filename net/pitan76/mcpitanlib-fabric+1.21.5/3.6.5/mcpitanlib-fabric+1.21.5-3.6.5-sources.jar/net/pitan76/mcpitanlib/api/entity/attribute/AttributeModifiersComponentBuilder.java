package net.pitan76.mcpitanlib.api.entity.attribute;

import net.minecraft.class_9285;

public class AttributeModifiersComponentBuilder {

    public final class_9285.class_9286 builder = class_9285.method_57480();

    public AttributeModifiersComponentBuilder() {

    }

    public AttributeModifiersComponentBuilder add(CompatEntityAttribute attribute, CompatEntityAttributeModifier modifier, CompatAttributeModifierSlot slot) {
        builder.method_57487(attribute.raw(), modifier.raw(), slot.raw());
        return this;
    }

    @Deprecated
    public class_9285 build_raw() {
        return builder.method_57486();
    }

    public CompatAttributeModifiersComponent build() {
        return CompatAttributeModifiersComponent.of(build_raw());
    }
}
