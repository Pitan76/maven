package net.pitan76.mcpitanlib.api.event.block;

import net.minecraft.class_10;
import net.minecraft.class_2680;
import net.minecraft.class_3610;
import net.pitan76.mcpitanlib.api.event.BaseEvent;
import net.pitan76.mcpitanlib.api.util.FluidStateUtil;

public class CanPathfindThroughArgs extends BaseEvent {
    public class_2680 state;
    public class_10 type;

    public CanPathfindThroughArgs(class_2680 state, class_10 type) {
        this.state = state;

        this.type = type;
    }

    public class_2680 getState() {
        return state;
    }

    public class_10 getType() {
        return type;
    }

    public class_3610 getFluidState() {
        return state.method_26227();
    }

    public boolean isWaterNavigationType() {
        return type == class_10.field_48;
    }

    public boolean isAirNavigationType() {
        return type == class_10.field_51;
    }

    public boolean isLandNavigationType() {
        return type == class_10.field_50;
    }

    public boolean isWaterState() {
        return FluidStateUtil.isWater(getFluidState());
    }

    public boolean isLavaState() {
        return FluidStateUtil.isLava(getFluidState());
    }
}
