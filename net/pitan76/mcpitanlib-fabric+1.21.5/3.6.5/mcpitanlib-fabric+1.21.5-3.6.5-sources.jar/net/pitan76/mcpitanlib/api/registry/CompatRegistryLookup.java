package net.pitan76.mcpitanlib.api.registry;

import net.minecraft.class_2487;
import net.minecraft.class_7225;
import net.minecraft.class_7887;
import net.pitan76.mcpitanlib.api.event.nbt.NbtRWArgs;
import net.pitan76.mcpitanlib.api.event.nbt.ReadNbtArgs;
import net.pitan76.mcpitanlib.api.event.nbt.WriteNbtArgs;

public class CompatRegistryLookup {

    private final class_7225.class_7874 registryLookup;

    @Deprecated
    public CompatRegistryLookup(class_7225.class_7874 registryLookup) {
        this.registryLookup = registryLookup;
    }

    public CompatRegistryLookup() {
        this.registryLookup = class_7887.method_46817();
    }

    @Deprecated
    public class_7225.class_7874 getRegistryLookup() {
        if (registryLookup == null)
            return class_7887.method_46817();

        return registryLookup;
    }

    public NbtRWArgs getNbtRWArgs(class_2487 nbt) {
        return new NbtRWArgs(nbt, registryLookup);
    }

    public WriteNbtArgs createWriteNbtArgs(class_2487 nbt) {
        return new WriteNbtArgs(nbt, registryLookup);
    }

    public ReadNbtArgs createReadNbtArgs(class_2487 nbt) {
        return new ReadNbtArgs(nbt, registryLookup);
    }
}
