package net.pitan76.mcpitanlib.api.network;

import dev.architectury.impl.NetworkAggregator;
import dev.architectury.networking.NetworkManager;
import io.netty.buffer.Unpooled;
import net.minecraft.class_2540;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.server.MinecraftServer;
import net.pitan76.mcpitanlib.core.network.BufPayload;

import java.util.ArrayList;
import java.util.List;

public class ServerNetworking {
    public static void send(class_3222 player, class_2960 identifier, class_2540 buf) {
        registerS2CPayloadType(identifier);

        BufPayload payload = new BufPayload(buf, identifier);
        NetworkManager.sendToPlayer(player, payload);
    }

    public static void send(Iterable<class_3222> players, class_2960 identifier, class_2540 buf) {
        registerS2CPayloadType(identifier);

        BufPayload payload = new BufPayload(buf, identifier);
        NetworkManager.sendToPlayers(players, payload);
    }

    public static void sendAll(MinecraftServer server, class_2960 identifier, class_2540 buf) {
        send(server.method_3760().method_14571(), identifier, buf);
    }

    public static void registerReceiver(class_2960 identifier, ServerNetworkHandler handler) {
        BufPayload.Id<BufPayload> id = BufPayload.id(identifier);
        NetworkManager.registerReceiver(NetworkManager.Side.C2S, id, BufPayload.getCodec(id),
                (payload, context) -> {
                    class_2540 buf = new class_2540(Unpooled.wrappedBuffer(payload.getData()));

                    class_3222 player = null;
                    if (context.getPlayer() instanceof class_3222)
                        player = (class_3222) context.getPlayer();

                    handler.receive(context.getPlayer().method_5682(), player, buf);
                    buf.release();
                });
    }

    private static final List<class_2960> registeredList = new ArrayList<>();

    public static void registerS2CPayloadType(class_2960 identifier) {
        if (registeredList.contains(identifier)) return;
        registeredList.add(identifier);

        if (NetworkAggregator.S2C_CODECS.containsKey(identifier)) return;

        BufPayload.Id<BufPayload> id = BufPayload.id(identifier);
        NetworkManager.registerS2CPayloadType(id, BufPayload.getCodec(id));
    }

    @FunctionalInterface
    public interface ServerNetworkHandler {
        void receive(MinecraftServer server, class_3222 player, class_2540 buf);
    }
}
