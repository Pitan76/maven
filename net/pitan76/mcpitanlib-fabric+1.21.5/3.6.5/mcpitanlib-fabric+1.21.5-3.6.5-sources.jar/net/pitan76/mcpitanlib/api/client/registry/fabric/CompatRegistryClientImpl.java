package net.pitan76.mcpitanlib.api.client.registry.fabric;

import dev.architectury.registry.menu.MenuRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.ColorProviderRegistry;
import net.minecraft.class_1703;
import net.minecraft.class_2248;
import net.minecraft.class_322;
import net.minecraft.class_3917;
import net.minecraft.class_3936;
import net.minecraft.class_437;
import net.pitan76.mcpitanlib.api.client.registry.CompatRegistryClient;

public class CompatRegistryClientImpl {
    public static <H extends class_1703, S extends class_437 & class_3936<H>> void registerScreen(String modId, class_3917<? extends H> type, CompatRegistryClient.ScreenFactory<H, S> factory) {
        MenuRegistry.registerScreenFactory(type, factory::create);
    }

    public static void registerColorProviderBlock(class_322 provider, class_2248... blocks) {
        if (blocks == null || blocks.length == 0) {
            ColorProviderRegistry.BLOCK.register(provider);
        } else {
            ColorProviderRegistry.BLOCK.register(provider, blocks);
        }
    }
}
