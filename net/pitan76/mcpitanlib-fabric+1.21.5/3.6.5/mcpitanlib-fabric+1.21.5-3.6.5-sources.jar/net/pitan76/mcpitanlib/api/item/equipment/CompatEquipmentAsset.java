package net.pitan76.mcpitanlib.api.item.equipment;

import net.minecraft.class_10191;
import net.minecraft.class_5321;
import net.pitan76.mcpitanlib.api.util.CompatIdentifier;

public class CompatEquipmentAsset {
    private final class_5321<net.minecraft.class_10394> raw;

    @Deprecated
    public CompatEquipmentAsset(class_5321<net.minecraft.class_10394> key) {
        this.raw = key;
    }

    @Deprecated
    public class_5321<net.minecraft.class_10394> raw() {
        return raw;
    }

    public CompatIdentifier getId() {
        return CompatIdentifier.fromMinecraft(raw.method_29177());
    }

    @Deprecated
    public static CompatEquipmentAsset of(class_5321<net.minecraft.class_10394> key) {
        return new CompatEquipmentAsset(key);
    }

    public static CompatEquipmentAsset of(CompatIdentifier id) {
        return of(class_5321.method_29179(class_10191.field_55214, id.toMinecraft()));
    }

    public static CompatEquipmentAsset of(String id) {
        return of(CompatIdentifier.of(id));
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (!(obj instanceof CompatEquipmentAsset)) return false;
        CompatEquipmentAsset that = (CompatEquipmentAsset) obj;
        return raw.equals(that.raw);
    }

    @Override
    public int hashCode() {
        if (raw == null) return super.hashCode();
        return raw.hashCode();
    }
}
