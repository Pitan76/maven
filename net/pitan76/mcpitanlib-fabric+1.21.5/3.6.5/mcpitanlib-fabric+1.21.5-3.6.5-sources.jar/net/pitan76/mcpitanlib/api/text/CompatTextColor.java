package net.pitan76.mcpitanlib.api.text;

import net.minecraft.class_124;
import net.minecraft.class_5251;

public class CompatTextColor {
    private final class_5251 textColor;

    public static final CompatTextColor BLACK = of(class_5251.method_27718(class_124.field_1074));
    public static final CompatTextColor DARK_BLUE = of(class_5251.method_27718(class_124.field_1058));
    public static final CompatTextColor DARK_GREEN = of(class_5251.method_27718(class_124.field_1077));
    public static final CompatTextColor DARK_AQUA = of(class_5251.method_27718(class_124.field_1062));
    public static final CompatTextColor DARK_RED = of(class_5251.method_27718(class_124.field_1079));
    public static final CompatTextColor DARK_PURPLE = of(class_5251.method_27718(class_124.field_1064));
    public static final CompatTextColor GOLD = of(class_5251.method_27718(class_124.field_1065));
    public static final CompatTextColor GRAY = of(class_5251.method_27718(class_124.field_1080));
    public static final CompatTextColor DARK_GRAY = of(class_5251.method_27718(class_124.field_1063));
    public static final CompatTextColor BLUE = of(class_5251.method_27718(class_124.field_1078));
    public static final CompatTextColor GREEN = of(class_5251.method_27718(class_124.field_1060));
    public static final CompatTextColor AQUA = of(class_5251.method_27718(class_124.field_1075));
    public static final CompatTextColor RED = of(class_5251.method_27718(class_124.field_1061));
    public static final CompatTextColor LIGHT_PURPLE = of(class_5251.method_27718(class_124.field_1076));
    public static final CompatTextColor YELLOW = of(class_5251.method_27718(class_124.field_1054));
    public static final CompatTextColor WHITE = of(class_5251.method_27718(class_124.field_1068));

    public CompatTextColor(class_5251 textColor) {
        this.textColor = textColor;
    }

    public class_5251 getRaw() {
        return textColor;
    }

    public static CompatTextColor of(class_5251 textColor) {
        return new CompatTextColor(textColor);
    }

    public static CompatTextColor fromFormatting(class_124 formatting) {
        return new CompatTextColor(class_5251.method_27718(formatting));
    }

    public static CompatTextColor fromFormatting(CompatFormatting formatting) {
        return fromFormatting(formatting.getRaw());
    }

    public static CompatTextColor fromRgb(int rgb) {
        return new CompatTextColor(class_5251.method_27717(rgb));
    }

    public static CompatTextColor fromRgb(int r, int g, int b) {
        int rgb = (r << 16) | (g << 8) | b;
        return fromRgb(rgb);
    }

    public static CompatTextColor parse(String string) {
        try {
            return parseOrThrow(string);
        } catch (Exception e) {
            return null;
        }
    }

    public static CompatTextColor parseOrThrow(String string) {
        return new CompatTextColor(class_5251.method_27719(string).getOrThrow());
    }

    @Override
    public int hashCode() {
        return textColor.hashCode();
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        CompatTextColor other = (CompatTextColor) obj;
        return textColor.equals(other.textColor);
    }
}
