package net.pitan76.mcpitanlib.api.block;

import com.mojang.serialization.MapCodec;
import net.minecraft.block.*;
import net.minecraft.class_10;
import net.minecraft.class_1750;
import net.minecraft.class_1922;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2510;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2746;
import net.minecraft.class_2754;
import net.minecraft.class_2760;
import net.minecraft.class_2778;
import net.minecraft.class_3726;
import net.pitan76.mcpitanlib.api.block.v2.CompatBlockProvider;
import net.pitan76.mcpitanlib.api.block.v2.CompatibleBlockSettings;
import net.pitan76.mcpitanlib.api.event.block.AppendPropertiesArgs;
import net.pitan76.mcpitanlib.api.event.block.CanPathfindThroughArgs;
import net.pitan76.mcpitanlib.api.event.block.OutlineShapeEvent;
import net.pitan76.mcpitanlib.api.event.block.PlacementStateArgs;
import net.pitan76.mcpitanlib.api.state.property.CompatProperties;
import net.pitan76.mcpitanlib.api.state.property.DirectionProperty;
import net.pitan76.mcpitanlib.core.serialization.CompatMapCodec;

public class CompatStairsBlock extends class_2510 implements CompatBlockProvider {

    public static final DirectionProperty FACING = CompatProperties.HORIZONTAL_FACING;
    public static final class_2754<class_2760> HALF = class_2510.field_11572;
    public static final class_2754<class_2778> SHAPE = class_2510.field_11565;
    public static final class_2746 WATERLOGGED = class_2510.field_11573;

    public CompatibleBlockSettings compatSettings;

    /**
     * get compatible block settings
     * @return CompatibleBlockSettings
     */
    @Override
    public CompatibleBlockSettings getCompatSettings() {
        return compatSettings;
    }

    public CompatStairsBlock(class_2680 baseBlockState, class_2251 settings) {
        super(baseBlockState, settings);
    }

    public CompatStairsBlock(class_2680 baseBlockState, CompatibleBlockSettings settings) {
        this(baseBlockState, settings.build());
        this.compatSettings = settings;
    }

    public class_265 getOutlineShape(OutlineShapeEvent event) {
        return super.method_9530(event.state, event.world, event.pos, event.context);
    }

    public void appendProperties(AppendPropertiesArgs args) {
        super.method_9515(args.builder);
    }

    public class_2680 getPlacementState(PlacementStateArgs args) {
        return super.method_9605(args.ctx);
    }

    @Deprecated
    @Override
    public void method_9515(class_2689.class_2690<class_2248, class_2680> builder) {
        appendProperties(new AppendPropertiesArgs(builder));
    }

    @Deprecated
    @Override
    public class_2680 method_9605(class_1750 ctx) {
        return getPlacementState(new PlacementStateArgs(ctx));
    }

    @Deprecated
    @Override
    protected class_265 method_9530(class_2680 state, class_1922 world, class_2338 pos, class_3726 context) {
        return getOutlineShape(new OutlineShapeEvent(state, world, pos, context));
    }

    // ExtendBlockProvider
    @Deprecated
    @Override
    public void appendProperties(AppendPropertiesArgs args, Options options) {
        CompatBlockProvider.super.appendProperties(args, options);
    }

    @Deprecated
    @Override
    public class_2680 getPlacementState(PlacementStateArgs args, Options options) {
        return CompatBlockProvider.super.getPlacementState(args, options);
    }

    @Deprecated
    @Override
    public class_265 getOutlineShape(OutlineShapeEvent event, Options options) {
        return CompatBlockProvider.super.getOutlineShape(event, options);
    }

    @Deprecated
    @Override
    public MapCodec<? extends class_2510> method_53969() {
        return getCompatCodec().getCodec();
    }

    public CompatMapCodec<? extends class_2510> getCompatCodec() {
        return CompatMapCodec.of(super.method_53969());
    }

    @Deprecated
    @Override
    public boolean method_9516(class_2680 state, class_10 type) {
        return canPathfindThrough(new CanPathfindThroughArgs(state, type));
    }

    public boolean canPathfindThrough(CanPathfindThroughArgs args) {
        return super.method_9516(args.state, args.type);
    }

    @Override
    public Boolean canPathfindThrough(CanPathfindThroughArgs args, Options options) {
        return CompatBlockProvider.super.canPathfindThrough(args, options);
    }

    public class_2680 getBaseBlockState() {
        return super.field_11574;
    }
}
