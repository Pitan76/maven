package net.pitan76.mcpitanlib.api.state.property;

import net.minecraft.block.enums.*;
import net.minecraft.class_2350;
import net.minecraft.class_2741;
import net.minecraft.class_2745;
import net.minecraft.class_2747;
import net.minecraft.class_2760;
import net.minecraft.class_2764;
import net.minecraft.class_2769;
import net.minecraft.class_2771;
import net.minecraft.class_2778;
import net.minecraft.class_3542;

public class CompatProperties {
    public static final DirectionProperty FACING = new DirectionProperty(class_2741.field_12525);
    public static final DirectionProperty HORIZONTAL_FACING = new DirectionProperty(class_2741.field_12481);
    public static final DirectionProperty HOPPER_FACING = new DirectionProperty(class_2741.field_12545);
    public static final DirectionProperty VERTICAL_DIRECTION = new DirectionProperty(class_2741.field_28062);

    public static final BooleanProperty POWERED = new BooleanProperty(class_2741.field_12484);
    public static final BooleanProperty ENABLED = new BooleanProperty(class_2741.field_12515);
    public static final BooleanProperty WATERLOGGED = new BooleanProperty(class_2741.field_12508);
    public static final BooleanProperty LIT = new BooleanProperty(class_2741.field_12548);
    public static final BooleanProperty OCCUPIED = new BooleanProperty(class_2741.field_12528);
    public static final BooleanProperty ATTACHED = new BooleanProperty(class_2741.field_12493);
    public static final BooleanProperty HANGING = new BooleanProperty(class_2741.field_16561);
    public static final BooleanProperty BOTTOM = new BooleanProperty(class_2741.field_16562);
    public static final BooleanProperty OPEN = new BooleanProperty(class_2741.field_12537);
    public static final BooleanProperty UNSTABLE = new BooleanProperty(class_2741.field_12539);
    public static final BooleanProperty UP = new BooleanProperty(class_2741.field_12519);
    public static final BooleanProperty DOWN = new BooleanProperty(class_2741.field_12546);
    public static final BooleanProperty NORTH = new BooleanProperty(class_2741.field_12489);
    public static final BooleanProperty EAST = new BooleanProperty(class_2741.field_12487);
    public static final BooleanProperty SOUTH = new BooleanProperty(class_2741.field_12540);
    public static final BooleanProperty WEST = new BooleanProperty(class_2741.field_12527);

    public static final IntProperty POWER = new IntProperty(class_2741.field_12511);
    public static final IntProperty LAYERS = new IntProperty(class_2741.field_12536);
    public static final IntProperty NOTE = new IntProperty(class_2741.field_12524);
    public static final IntProperty ROTATION = new IntProperty(class_2741.field_12532);
    public static final IntProperty EGGS = new IntProperty(class_2741.field_12509);
    public static final IntProperty DELAY = new IntProperty(class_2741.field_12494);

    public static final EnumProperty<class_2760> BLOCK_HALF = new EnumProperty<>(class_2741.field_12518);
    public static final EnumProperty<class_2778> STAIR_SHAPE = new EnumProperty<>(class_2741.field_12503);
    public static final EnumProperty<class_2771> SLAB_TYPE = new EnumProperty<>(class_2741.field_12485);
    public static final EnumProperty<class_2745> CHEST_TYPE = new EnumProperty<>(class_2741.field_12506);
    public static final EnumProperty<class_2764> PISTON_TYPE = new EnumProperty<>(class_2741.field_12492);
    public static final EnumProperty<class_2350.class_2351> AXIS = new EnumProperty<>(class_2741.field_12496);
    public static final EnumProperty<class_2350.class_2351> HORIZONTAL_AXIS = new EnumProperty<>(class_2741.field_12529);
    public static final EnumProperty<class_2747> COMPARATOR_MODE = new EnumProperty<>(class_2741.field_12534);

    public static IProperty<?> of(class_2769<?> property) {
        if (property instanceof net.minecraft.class_2758) {
            return of((net.minecraft.class_2758) property);
        }
        if (property instanceof net.minecraft.class_2746) {
            return of((net.minecraft.class_2746) property);
        }
        if (property instanceof net.minecraft.class_2754) {
            if (property.method_11902() == class_2350.class) {
                return ofDir((net.minecraft.class_2754<class_2350>) property);
            }
            return of((net.minecraft.class_2754<?>) property);
        }
        return UnknownProperty.of(property);
    }

    public static IntProperty of(net.minecraft.class_2758 property) {
        if (property == class_2741.field_12511) return POWER;
        if (property == class_2741.field_12536) return LAYERS;
        if (property == class_2741.field_12524) return NOTE;
        if (property == class_2741.field_12532) return ROTATION;
        if (property == class_2741.field_12509) return EGGS;
        if (property == class_2741.field_12494) return DELAY;

        return new IntProperty(property);
    }

    public static BooleanProperty of(net.minecraft.class_2746 property) {
        if (property == class_2741.field_12484) return POWERED;
        if (property == class_2741.field_12515) return ENABLED;
        if (property == class_2741.field_12508) return WATERLOGGED;
        if (property == class_2741.field_12548) return LIT;
        if (property == class_2741.field_12528) return OCCUPIED;
        if (property == class_2741.field_12493) return ATTACHED;
        if (property == class_2741.field_16561) return HANGING;
        if (property == class_2741.field_16562) return BOTTOM;
        if (property == class_2741.field_12537) return OPEN;
        if (property == class_2741.field_12539) return UNSTABLE;
        if (property == class_2741.field_12519) return UP;
        if (property == class_2741.field_12546) return DOWN;
        if (property == class_2741.field_12489) return NORTH;
        if (property == class_2741.field_12487) return EAST;
        if (property == class_2741.field_12540) return SOUTH;
        if (property == class_2741.field_12527) return WEST;

        return new BooleanProperty(property);
    }

    public static <T extends Enum<T> & class_3542> EnumProperty<T> of(net.minecraft.class_2754<T> property) {
        if (property.equals(class_2741.field_12518)) return (EnumProperty) BLOCK_HALF;
        if (property.equals(class_2741.field_12503)) return (EnumProperty) STAIR_SHAPE;
        if (property.equals(class_2741.field_12485)) return (EnumProperty) SLAB_TYPE;
        if (property.equals(class_2741.field_12506)) return (EnumProperty) CHEST_TYPE;
        if (property.equals(class_2741.field_12492)) return (EnumProperty) PISTON_TYPE;
        if (property.equals(class_2741.field_12496)) return (EnumProperty) AXIS;
        if (property.equals(class_2741.field_12529)) return (EnumProperty) HORIZONTAL_AXIS;
        if (property.equals(class_2741.field_12534)) return (EnumProperty) COMPARATOR_MODE;

        return new EnumProperty<>(property);
    }

    public static DirectionProperty ofDir(net.minecraft.class_2754<class_2350> property) {
        if (property == class_2741.field_12525) return FACING;
        if (property == class_2741.field_12481) return HORIZONTAL_FACING;
        if (property == class_2741.field_12545) return HOPPER_FACING;
        if (property == class_2741.field_28062) return VERTICAL_DIRECTION;

        return new DirectionProperty(property);
    }
}
