package net.pitan76.mcpitanlib.api.item.stack;

import java.util.List;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_9290;
import net.minecraft.class_9334;

public class LoreUtil {
    public static boolean hasLore(class_1799 stack) {
        return stack.method_57826(class_9334.field_49632);
    }

    public static List<class_2561> getLore(class_1799 stack) {
        if (!hasLore(stack)) return List.of();
        return stack.method_58694(class_9334.field_49632).comp_2400();
    }

    public static List<String> getLoreAsStringList(class_1799 stack) {
        return getLore(stack).stream()
                .map(class_2561::getString)
                .toList();
    }

    public static String getLoreAsString(class_1799 stack) {
        return getLoreAsStringList(stack).stream()
                .reduce("", (a, b) -> a + "\n" + b);
    }

    public static void setLore(class_1799 stack, List<class_2561> lore) {
        stack.method_57379(class_9334.field_49632, new class_9290(lore));
    }

    public static void setLoreStringList(class_1799 stack, List<String> lore) {
        setLore(stack, lore.stream()
                .map(class_2561::method_30163)
                .toList());
    }

    public static void setLore(class_1799 stack, String lore) {
        setLore(stack, lore.lines()
                .map(class_2561::method_30163)
                .toList());
    }
}
