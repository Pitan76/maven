package net.pitan76.mcpitanlib.api.block;

import net.minecraft.class_10712;
import net.minecraft.class_1747;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_2248;
import net.minecraft.class_2561;
import net.pitan76.mcpitanlib.api.event.item.ItemAppendTooltipEvent;

import java.util.function.Consumer;

@Deprecated
public class BlockItemByExtendBlock1215 extends class_1747 {
    private ExtendBlock block;
    private ExtendBlockProvider provider;

    public BlockItemByExtendBlock1215(ExtendBlock block, class_1793 settings) {
        super(block, settings);
        this.block = block;
    }

    public BlockItemByExtendBlock1215(ExtendBlockProvider provider, class_1793 settings) {
        super((class_2248) provider, settings);
        this.provider = provider;
    }

    @Override
    public void method_67187(class_1799 stack, class_9635 context, class_10712 displayComponent, Consumer<class_2561> textConsumer, class_1836 type) {
        if (block != null)
            block.appendTooltip(new ItemAppendTooltipEvent(stack, context, displayComponent, textConsumer, type));

        if (provider != null)
            provider.appendTooltip(new ItemAppendTooltipEvent(stack, context, displayComponent, textConsumer, type), new ExtendBlockProvider.Options());
    }
}
