package net.pitan76.mcpitanlib.api.recipe.v2;

import net.minecraft.class_1860;
import net.pitan76.mcpitanlib.api.util.CompatIdentifier;
import net.pitan76.mcpitanlib.api.util.RecipeUtil;

@Deprecated
public class CompatRecipeNonEntry<T extends class_1860<?>> extends CompatRecipeEntry<T> {
    public CompatRecipeNonEntry(T recipe) {
        super(CompatIdentifier.EMPTY, "", RecipeUtil.CompatibilityCraftingRecipeCategory.MISC, recipe);
    }

    public static CompatRecipeNonEntry<?> create(class_1860<?> recipe) {
        return new CompatRecipeNonEntry<>(recipe);
    }

    @Override
    public T getRecipe() {
        return super.getRecipe();
    }

    public class_1860<?> getRawRecipe() {
        return super.getRecipe();
    }
}
