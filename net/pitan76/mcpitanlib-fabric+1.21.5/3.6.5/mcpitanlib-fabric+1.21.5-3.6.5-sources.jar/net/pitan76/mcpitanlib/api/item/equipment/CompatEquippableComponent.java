package net.pitan76.mcpitanlib.api.item.equipment;

import net.minecraft.class_10192;

public class CompatEquippableComponent {
    private final class_10192 raw;

    @Deprecated
    public CompatEquippableComponent(class_10192 component) {
        this.raw = component;
    }

    @Deprecated
    public class_10192 raw() {
        return raw;
    }

    @Deprecated
    public static CompatEquippableComponent of(class_10192 component) {
        return new CompatEquippableComponent(component);
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (!(obj instanceof CompatEquippableComponent)) return false;
        CompatEquippableComponent that = (CompatEquippableComponent) obj;
        return raw().equals(that.raw());
    }

    @Override
    public int hashCode() {
        if (raw() == null) return super.hashCode();
        return raw().hashCode();
    }
}
