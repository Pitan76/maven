package net.pitan76.mcpitanlib.api.enchantment;

import net.minecraft.class_1799;
import net.minecraft.class_1887;
import net.minecraft.class_1890;
import net.minecraft.class_1937;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.minecraft.class_6880;
import net.minecraft.class_7887;
import net.pitan76.mcpitanlib.api.util.EnchantmentUtil;
import org.jetbrains.annotations.Nullable;

import java.util.Optional;

public class CompatEnchantment {
    private final class_5321<class_1887> registryKey;

    @Deprecated
    public CompatEnchantment(class_5321<class_1887> registryKey) {
        this.registryKey = registryKey;
    }

    public CompatEnchantment of(class_2960 identifier) {
        return EnchantmentUtil.getEnchantment(identifier);
    }

    public class_2960 getId() {
        return registryKey.method_41185();
    }

    @Deprecated
    public class_5321<class_1887> getRegistryKey() {
        return registryKey;
    }

    public String toString() {
        return getId().toString();
    }

    public boolean equals(Object obj) {
        if (obj instanceof CompatEnchantment) {
            return ((CompatEnchantment) obj).getId().equals(getId());
        }
        return false;
    }

    @Deprecated
    public class_6880<class_1887> getEntry(@Nullable class_1937 world) {
        Optional<class_6880.class_6883<class_1887>> optionalEntry;
        if (world == null) {
            optionalEntry = class_7887.method_46817()
                    .method_58561(registryKey);
        } else {
            optionalEntry = world.method_30349().method_58561(registryKey);
        }

        return optionalEntry.orElseThrow();
    }

    public class_1887 getEnchantment(@Nullable class_1937 world) {
        return getEntry(world).comp_349();
    }

    public int getLevel(class_1799 stack, @Nullable class_1937 world) {
        return class_1890.method_8225(getEntry(world), stack);
    }
}
