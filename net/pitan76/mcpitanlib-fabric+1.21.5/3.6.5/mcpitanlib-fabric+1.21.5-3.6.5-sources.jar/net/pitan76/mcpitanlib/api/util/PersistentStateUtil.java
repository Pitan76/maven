package net.pitan76.mcpitanlib.api.util;

import com.mojang.serialization.Codec;
import net.minecraft.class_10741;
import net.minecraft.class_18;
import net.minecraft.class_1937;
import net.minecraft.class_2487;
import net.minecraft.class_26;
import net.minecraft.class_3218;
import net.minecraft.class_4284;
import net.minecraft.server.MinecraftServer;
import net.pitan76.mcpitanlib.api.event.nbt.ReadNbtArgs;
import net.pitan76.mcpitanlib.api.event.nbt.WriteNbtArgs;
import net.pitan76.mcpitanlib.api.world.CompatiblePersistentState;

import java.util.function.Function;
import java.util.function.Supplier;

public class PersistentStateUtil {
    public static <T extends class_18> T getOrCreate(class_26 manager, String id, Supplier<T> supplier, Function<class_2487, T> function) {
        Codec<T> codec = class_2487.field_25128.xmap(
                // NBT -> PersistentState
                (nbt) -> {
                    T state = supplier.get();

                    if (state instanceof CompatiblePersistentState)
                        ((CompatiblePersistentState) state).readNbt(new ReadNbtArgs(nbt));

                    return state;
                },
                // PersistentState -> NBT
                (state) -> {
                    if (state instanceof CompatiblePersistentState)
                        return ((CompatiblePersistentState) state).writeNbt(new WriteNbtArgs(new class_2487()));

                    return NbtUtil.create();
                }
        );

        class_10741<T> type = new class_10741<>(id, supplier, codec, class_4284.field_19212);
        return manager.method_17924(type);
    }

    public static class_26 getManagerFromServer(MinecraftServer server) {
        return server.method_3847(class_1937.field_25179).method_17983();
    }

    public static class_26 getManagerFromWorld(class_3218 world) {
        return world.method_17983();
    }

    public static void markDirty(class_18 state) {
        state.method_80();
    }
}