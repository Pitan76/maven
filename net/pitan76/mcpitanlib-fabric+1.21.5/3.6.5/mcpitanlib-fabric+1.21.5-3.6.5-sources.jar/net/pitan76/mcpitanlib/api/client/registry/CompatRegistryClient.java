package net.pitan76.mcpitanlib.api.client.registry;

import dev.architectury.injectables.annotations.ExpectPlatform;
import dev.architectury.registry.client.level.entity.EntityModelLayerRegistry;
import dev.architectury.registry.client.level.entity.EntityRendererRegistry;
import dev.architectury.registry.client.particle.ParticleProviderRegistry;
import dev.architectury.registry.client.rendering.BlockEntityRendererRegistry;
import dev.architectury.registry.client.rendering.RenderTypeRegistry;
import dev.architectury.registry.menu.MenuRegistry;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_10442;
import net.minecraft.class_1058;
import net.minecraft.class_1059;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1921;
import net.minecraft.class_2248;
import net.minecraft.class_2394;
import net.minecraft.class_2396;
import net.minecraft.class_2561;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_2960;
import net.minecraft.class_322;
import net.minecraft.class_327;
import net.minecraft.class_3611;
import net.minecraft.class_3917;
import net.minecraft.class_3936;
import net.minecraft.class_4002;
import net.minecraft.class_437;
import net.minecraft.class_5599;
import net.minecraft.class_5601;
import net.minecraft.class_5607;
import net.minecraft.class_5617;
import net.minecraft.class_5819;
import net.minecraft.class_630;
import net.minecraft.class_707;
import net.minecraft.class_776;
import net.minecraft.class_824;
import net.minecraft.class_827;
import net.minecraft.class_898;
import net.minecraft.class_918;
import net.pitan76.mcpitanlib.MCPitanLib;
import net.pitan76.mcpitanlib.api.client.color.CompatBlockColorProvider;
import net.pitan76.mcpitanlib.api.client.render.CompatRenderLayer;
import net.pitan76.mcpitanlib.api.client.render.EntityModelLayerContext;

import java.util.List;
import java.util.function.Supplier;

@Environment(EnvType.CLIENT)
public class CompatRegistryClient {
    public static <H extends class_1703, S extends class_437 & class_3936<H>> void registerScreen(class_3917<? extends H> type, ScreenFactory<H, S> factory) {
        registerScreen(MCPitanLib.MOD_ID, type, factory);
    }

    public static <H extends class_1703, S extends class_437 & class_3936<H>> void registerScreen(String modId, class_3917<? extends H> type, ScreenFactory<H, S> factory) {
        MenuRegistry.registerScreenFactory(type, factory::create);
    }

    public interface ScreenFactory<H extends class_1703, S extends class_437 & class_3936<H>> {
        S create(H handler, class_1661 inventory, class_2561 text);
    }

    public static <T extends class_2394> void registerParticle(class_2396<T> type, class_707<T> factory) {
        ParticleProviderRegistry.register(type, factory);
    }

    public static <T extends class_2394> void registerParticle(class_2396<T> type, DeferredParticleProvider<T> provider) {
        ParticleProviderRegistry.register(type, spriteSet -> provider.create(new ExtendedSpriteSet() {
            @Override
            public class_1059 getAtlas() {
                return spriteSet.getAtlas();
            }

            @Override
            public List<class_1058> getSprites() {
                return spriteSet.getSprites();
            }

            @Override
            public class_1058 method_18138(int age, int maxAge) {
                return spriteSet.method_18138(age, maxAge);
            }

            @Override
            public class_1058 method_18139(class_5819 random) {
                return spriteSet.method_18139(random);
            }
        }));
    }

    public static void registerEntityModelLayer(class_5601 layer, EntityModelLayerContext context) {
        EntityModelLayerRegistry.register(layer, () -> class_5607.method_32110(context.getData(), context.getWidth(), context.getHeight()));
    }

    public static <T extends class_1297> void registerEntityRenderer(Supplier<? extends class_1299<? extends T>> type, class_5617<T> provider) {
        EntityRendererRegistry.register(type, provider);
    }

    @FunctionalInterface
    public interface DeferredParticleProvider<T extends class_2394> {
        class_707<T> create(ExtendedSpriteSet spriteSet);
    }

    public interface ExtendedSpriteSet extends class_4002 {
        class_1059 getAtlas();

        List<class_1058> getSprites();
    }

    public static void registryClientSpriteAtlasTexture(class_2960 identifier) {
        //registryClientSprite(PlayerScreenHandler.BLOCK_ATLAS_TEXTURE, identifier);
    }

    public static void registryClientSpriteAtlasTexture(class_1058 sprite) {
        //registryClientSprite(PlayerScreenHandler.BLOCK_ATLAS_TEXTURE, sprite);
    }

    public static void registryClientSprite(class_2960 atlasId, class_2960 identifier) {
        // ～1.19.2
    }

    public static void registryClientSprite(class_2960 atlasId, class_1058 sprite) {
        // ～1.19.2
    }

    public static <T extends class_2586> void registerBlockEntityRenderer(class_2591<T> type, BlockEntityRendererFactory<T> provider) {
        BlockEntityRendererRegistry.register(type, ctx -> provider.create(new BlockEntityRendererFactory.Context(
                ctx.method_32139(), ctx.method_32141(), ctx.method_65558(), ctx.method_43335(), ctx.method_43334(), ctx.method_32142(), ctx.method_32143()
        )));
    }

    @FunctionalInterface
    public interface BlockEntityRendererFactory<T extends class_2586> {
        class_827<T> create(Context ctx);

        class Context {
            private final class_824 renderDispatcher;
            private final class_776 renderManager;
            private final class_10442 itemModelManager;
            private final class_918 itemRenderer;
            private final class_898 entityRenderDispatcher;
            private final class_5599 layerRenderDispatcher;
            private final class_327 textRenderer;

            public Context(class_824 renderDispatcher, class_776 renderManager, class_10442 itemModelManager, class_918 itemRenderer, class_898 entityRenderDispatcher, class_5599 layerRenderDispatcher, class_327 textRenderer) {
                this.renderDispatcher = renderDispatcher;
                this.renderManager = renderManager;
                this.itemModelManager = itemModelManager;
                this.itemRenderer = itemRenderer;
                this.entityRenderDispatcher = entityRenderDispatcher;
                this.layerRenderDispatcher = layerRenderDispatcher;
                this.textRenderer = textRenderer;
            }

            public class_824 getRenderDispatcher() {
                return this.renderDispatcher;
            }

            public class_776 getRenderManager() {
                return this.renderManager;
            }

            public class_898 getEntityRenderDispatcher() {
                return this.entityRenderDispatcher;
            }

            public class_10442 getItemModelManager() {
                return itemModelManager;
            }

            public class_918 getItemRenderer() {
                return this.itemRenderer;
            }

            public class_5599 getLayerRenderDispatcher() {
                return this.layerRenderDispatcher;
            }

            public class_630 getLayerModelPart(class_5601 modelLayer) {
                return this.layerRenderDispatcher.method_32072(modelLayer);
            }

            public class_327 getTextRenderer() {
                return this.textRenderer;
            }
        }
    }


    public static void registerRenderTypeBlock(class_1921 layer, class_2248 block) {
        RenderTypeRegistry.register(layer, block);
    }

    public static void registerRenderTypeFluid(class_1921 layer, class_3611 fluid) {
        RenderTypeRegistry.register(layer, fluid);
    }

    public static void registerCutoutBlock(class_2248 block) {
        registerRenderTypeBlock(class_1921.method_23581(), block);
    }

    public static <T extends class_2586> void registerCompatBlockEntityRenderer(class_2591<T> type, BlockEntityRendererFactory<T> provider) {
        BlockEntityRendererRegistry.register(type, ctx -> provider.create(new BlockEntityRendererFactory.Context(
                ctx.method_32139(), ctx.method_32141(), ctx.method_65558(), ctx.method_43335(), ctx.method_43334(), ctx.method_32142(), ctx.method_32143()
        )));
    }

    public static void registerRenderTypeBlock(CompatRenderLayer layer, class_2248 block) {
        registerRenderTypeBlock(layer.layer, block);
    }

    public static void registerRenderTypeFluid(CompatRenderLayer layer, class_3611 fluid) {
        registerRenderTypeFluid(layer.layer, fluid);
    }

    @ExpectPlatform
    public static void registerColorProviderBlock(class_322 provider, class_2248... blocks) {
        throw new AssertionError("This method should be replaced by the platform implementation");
    }

    public static void registerColorProviderBlock(CompatBlockColorProvider provider, class_2248... blocks) {
        registerColorProviderBlock((class_322) provider, blocks);
    }
}
