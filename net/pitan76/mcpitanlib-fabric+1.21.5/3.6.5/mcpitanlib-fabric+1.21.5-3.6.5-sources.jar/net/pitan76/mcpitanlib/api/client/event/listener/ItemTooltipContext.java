package net.pitan76.mcpitanlib.api.client.event.listener;

import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_2561;
import net.pitan76.mcpitanlib.api.text.TextComponent;
import net.pitan76.mcpitanlib.api.util.TextUtil;

import java.util.List;

public class ItemTooltipContext {

    public class_1799 stack;
    public List<class_2561> texts;
    public class_1792.class_9635 tooltipContext;

    @Deprecated
    public class_1836 type;

    public ItemTooltipContext(class_1799 stack, List<class_2561> texts, class_1792.class_9635 tooltipContext, class_1836 type) {
        this.stack = stack;
        this.texts = texts;
        this.tooltipContext = tooltipContext;
        this.type = type;
    }

    public class_1799 getStack() {
        return stack;
    }

    public List<class_2561> getTexts() {
        return texts;
    }

    public class_1792.class_9635 getTooltipContext() {
        return tooltipContext;
    }

    @Deprecated
    public class_1836 getType() {
        return type;
    }

    public void addTooltip(class_2561 text) {
        texts.add(text);
    }

    public void addTooltip(List<class_2561> texts) {
        this.texts.addAll(texts);
    }

    public boolean isAdvanced() {
        return type.method_8035();
    }

    public boolean isCreative() {
        return type.method_47370();
    }

    public void addTooltip(TextComponent textComponent) {
        addTooltip(textComponent.getText());
    }

    public void addTooltip(String text) {
        addTooltip(TextUtil.literal(text));
    }
}
