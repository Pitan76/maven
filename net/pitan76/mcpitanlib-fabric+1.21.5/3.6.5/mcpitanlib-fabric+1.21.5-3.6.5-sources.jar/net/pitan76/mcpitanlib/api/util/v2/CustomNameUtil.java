package net.pitan76.mcpitanlib.api.util.v2;

import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_9334;
import net.pitan76.mcpitanlib.api.text.TextComponent;
import net.pitan76.mcpitanlib.api.util.TextUtil;

public class CustomNameUtil {

    public static void setCustomName(class_1799 stack, class_2561 name) {
        stack.method_57379(class_9334.field_49631, name);
    }

    public static void setCustomName(class_1799 stack, String name) {
        setCustomNameFromString(stack, name);
    }

    public static void setCustomNameFromString(class_1799 stack, String name) {
        setCustomName(stack, TextUtil.literal(name));
    }

    public static void setCustomNameFromTranslatable(class_1799 stack, String key) {
        setCustomName(stack, TextUtil.translatable(key));
    }

    public static void setCustomName(class_1799 stack, TextComponent name) {
        setCustomName(stack, name.getText());
    }

    public static class_2561 getCustomName(class_1799 stack) {
        return stack.method_58694(class_9334.field_49631);
    }

    public static String getCustomNameAsString(class_1799 stack) {
        return getCustomName(stack).getString();
    }

    public static TextComponent getCustomNameAsTextComponent(class_1799 stack) {
        return new TextComponent(getCustomName(stack));
    }

    public static boolean hasCustomName(class_1799 stack) {
        return stack.method_57826(class_9334.field_49631);
    }

    public static void removeCustomName(class_1799 stack) {
        stack.method_57381(class_9334.field_49631);
    }
}
