package net.pitan76.mcpitanlib.api.entity.effect;

import org.jetbrains.annotations.Nullable;

import java.util.Optional;
import net.minecraft.class_1291;
import net.minecraft.class_1293;
import net.minecraft.class_5321;

public class CompatStatusEffectInstance {
    private final class_1293 instance;
    
    @Deprecated
    public CompatStatusEffectInstance(class_1293 instance) {
        this.instance = instance;
    }

    public class_1293 getInstance() {
        return instance;
    }

    public Optional<CompatStatusEffect> getCompatStatusEffect() {
        Optional<class_5321<class_1291>> optional = instance.method_5579().method_40230();
        return optional.map(CompatStatusEffect::new);
    }

    public CompatStatusEffectInstance(CompatStatusEffect effect) {
        this(effect, 0, 0);
    }

    public CompatStatusEffectInstance(CompatStatusEffect effect, int duration) {
        this(effect, duration, 0);
    }

    public CompatStatusEffectInstance(CompatStatusEffect effect, int duration, int amplifier) {
        this(effect, duration, amplifier, false, true);
    }

    public CompatStatusEffectInstance(CompatStatusEffect effect, int duration, int amplifier, boolean ambient, boolean visible) {
        this(effect, duration, amplifier, ambient, visible, visible);
    }

    public CompatStatusEffectInstance(CompatStatusEffect effect, int duration, int amplifier, boolean ambient, boolean showParticles, boolean showIcon) {
        this(effect, duration, amplifier, ambient, showParticles, showIcon, null);
    }
    
    public CompatStatusEffectInstance(CompatStatusEffect effect, int duration, int amplifier, boolean ambient, boolean showParticles, boolean showIcon, @Nullable class_1293 hiddenEffect) {
        this.instance = new class_1293(effect.getEntry(null), duration, amplifier, ambient, showParticles, showIcon, hiddenEffect);
    }

    public int getDuration() {
        return instance.method_5584();
    }

    public int getAmplifier() {
        return instance.method_5578();
    }

    public boolean isAmbient() {
        return instance.method_5591();
    }

    public boolean showParticles() {
        return instance.method_5581();
    }

    public boolean showIcon() {
        return instance.method_5592();
    }

    public boolean isInfinite() {
        return instance.method_48559();
    }
}
