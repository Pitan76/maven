package net.pitan76.mcpitanlib.api.item.tool;

import net.minecraft.class_1792;
import net.minecraft.class_1856;
import net.minecraft.class_2248;
import net.minecraft.class_3481;
import net.minecraft.class_3489;
import net.minecraft.class_6862;
import net.minecraft.class_9886;
import net.pitan76.mcpitanlib.api.util.IngredientUtil;

public interface CompatibleToolMaterial {

    int getCompatMiningLevel();

    float getCompatAttackDamage();

    float getCompatMiningSpeedMultiplier();

    default class_1856 getCompatRepairIngredient() {
        return IngredientUtil.fromTagByIdentifier(getRepairTag().comp_327());
    }

    int getCompatDurability();

    int getCompatEnchantability();

    default class_6862<class_2248> getInverseTag() {

        return level2inverseTag(getCompatMiningLevel());
    }

    public static class_6862<class_2248> level2inverseTag(int level) {
        switch (level) {
            case 1:
                return class_3481.field_49930;
            case 2:
                return class_3481.field_49928;
            case 3:
                return class_3481.field_49927;
            case 4:
                return class_3481.field_49929;
            case 5:
                return class_3481.field_49926;
            case 6:
                return class_3481.field_49925;

            default:
                return class_3481.field_49930;
        }
    }

    @Deprecated
    default float getAttackDamage() {
        return getCompatAttackDamage();
    }

    @Deprecated
    default float getMiningSpeedMultiplier() {
        return getCompatMiningSpeedMultiplier();
    }

    @Deprecated
    default class_1856 getRepairIngredient() {
        return getCompatRepairIngredient();
    }

    @Deprecated
    default int getDurability() {
        return getCompatDurability();
    }

    @Deprecated
    default int getEnchantability() {
        return getCompatEnchantability();
    }

    default class_6862<class_1792> getRepairTag() {
        return class_3489.field_52382;
    }

    default class_9886 build() {
        return new class_9886(getInverseTag(), getCompatDurability(), getCompatMiningSpeedMultiplier(), getCompatAttackDamage(), getCompatEnchantability(), getRepairTag());
    }
}