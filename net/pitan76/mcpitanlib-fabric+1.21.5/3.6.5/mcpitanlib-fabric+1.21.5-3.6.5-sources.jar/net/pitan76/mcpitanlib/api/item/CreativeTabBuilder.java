package net.pitan76.mcpitanlib.api.item;

import dev.architectury.registry.CreativeTabRegistry;
import net.minecraft.class_1761;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.pitan76.mcpitanlib.api.util.CompatIdentifier;
import net.pitan76.mcpitanlib.api.util.IdentifierUtil;
import net.pitan76.mcpitanlib.api.util.TextUtil;
import net.pitan76.mcpitanlib.core.registry.MCPLRegistry1_20;
import net.pitan76.mcpitanlib.midohra.item.ItemGroupWrapper;

import java.util.function.Supplier;

public class CreativeTabBuilder {
    private final class_2960 identifier;
    private class_2561 displayName = null;
    private Supplier<class_1799> iconSupplier = null;
    private boolean noRenderedName = false;
    private boolean noScrollbar = false;
    private boolean special = false;
    private String texture;

    @Deprecated
    // Recommend: create(identifier)
    public CreativeTabBuilder(class_2960 identifier) {
        this.identifier = identifier;
    }

    public static CreativeTabBuilder create(class_2960 identifier) {
        return new CreativeTabBuilder(identifier);
    }

    public static CreativeTabBuilder create(CompatIdentifier identifier) {
        return create(identifier.toMinecraft());
    }

    public CreativeTabBuilder setDisplayName(class_2561 text) {
        this.displayName = text;
        return this;
    }

    /**
     * Set icon
     * @param iconSupplier Icon supplier
     * @return CreativeTabBuilder
     */
    public CreativeTabBuilder setIcon(Supplier<class_1799> iconSupplier) {
        this.iconSupplier = iconSupplier;
        return this;
    }

    /**
     * Set icon (Already registered item only)
     * @param item Item
     * @return CreativeTabBuilder
     */
    public CreativeTabBuilder setIcon(class_1792 item) {
        return setIcon(() -> new class_1799(item));
    }

    public void noRenderedName() {
        this.noRenderedName = true;
    }

    public void noScrollbar() {
        this.noScrollbar = true;
    }

    public void special() {
        this.special = true;
    }

    public void setTexture(String texture) {
        this.texture = texture;
    }

    /**
     * Build ItemGroup (If loader is forge, not recommended)
     * @return ItemGroup
     */
    public class_1761 build() {
        return CreativeTabRegistry.create((builder -> {
            if (displayName != null) builder.method_47321(displayName);
            else builder.method_47321(TextUtil.translatable("itemGroup." + identifier.method_12836() + "." + identifier.method_12832()));

            if (iconSupplier != null) builder.method_47320(iconSupplier);
            if (noRenderedName) builder.method_47322();
            if (noScrollbar) builder.method_47323();
            if (special) builder.method_47315();
            if (texture != null) builder.method_47319(IdentifierUtil.id(texture));
        }));
    }

    @SuppressWarnings("deprecation")
    public ItemGroupWrapper getBuiltWrapper() {
        if (MCPLRegistry1_20.REGISTRY_SUPPLIER_ITEM_GROUP_CACHE.containsKey(identifier))
            return ItemGroupWrapper.of(MCPLRegistry1_20.REGISTRY_SUPPLIER_ITEM_GROUP_CACHE.get(identifier).getOrNull());

        return ItemGroupWrapper.of(build());
    }

    public class_2960 getIdentifier() {
        return identifier;
    }

    public CompatIdentifier getCompatIdentifier() {
        return CompatIdentifier.fromMinecraft(identifier);
    }
}
