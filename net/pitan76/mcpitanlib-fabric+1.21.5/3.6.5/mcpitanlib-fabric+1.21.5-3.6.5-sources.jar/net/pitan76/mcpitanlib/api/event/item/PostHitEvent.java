package net.pitan76.mcpitanlib.api.event.item;

import net.minecraft.class_1304;
import net.minecraft.class_1309;
import net.minecraft.class_1799;
import net.pitan76.mcpitanlib.api.event.BaseEvent;

public class PostHitEvent extends BaseEvent {
    public class_1799 stack;
    public class_1309 target;
    public class_1309 attacker;

    public PostHitEvent(class_1799 stack, class_1309 target, class_1309 attacker) {
        this.stack = stack;
        this.target = target;
        this.attacker = attacker;
    }

    public class_1799 getStack() {
        return stack;
    }

    public class_1309 getAttacker() {
        return attacker;
    }

    public class_1309 getTarget() {
        return target;
    }

    /**
     * Damages the stack in the given slot
     * @param amount the amount of damage to deal
     * @param slot the slot to damage
     */
    public void damageStack(int amount, class_1304 slot) {
        stack.method_7970(amount, attacker, slot);
    }
}
