package net.pitan76.mcpitanlib.api.entity.attribute;

import net.pitan76.mcpitanlib.api.util.CompatIdentifier;

public class CompatEntityAttributeModifier {
    private final net.minecraft.class_1322 raw;

    @Deprecated
    public CompatEntityAttributeModifier(net.minecraft.class_1322 raw) {
        this.raw = raw;
    }

    @Deprecated
    public static CompatEntityAttributeModifier of(net.minecraft.class_1322 raw) {
        return new CompatEntityAttributeModifier(raw);
    }

    public static CompatEntityAttributeModifier of(CompatIdentifier id, double value, AttrModifierOperation operation) {
        return new CompatEntityAttributeModifier(new net.minecraft.class_1322(id.toMinecraft(), value, operation.raw()));
    }

    @Deprecated
    public net.minecraft.class_1322 raw() {
        return raw;
    }

    public AttrModifierOperation getOperation() {
        return AttrModifierOperation.of(raw().comp_2450());
    }

    public double getValue() {
        return raw().comp_2449();
    }

    public CompatIdentifier getId() {
        return CompatIdentifier.fromMinecraft(raw().comp_2447());
    }

    @Override
    public String toString() {
        return raw().toString();
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (!(obj instanceof CompatEntityAttributeModifier)) return false;
        CompatEntityAttributeModifier that = (CompatEntityAttributeModifier) obj;
        return raw().equals(that.raw());
    }

    @Override
    public int hashCode() {
        if (raw() == null) return super.hashCode();
        return raw().hashCode();
    }
}
