package net.pitan76.mcpitanlib.api.util.v1;

import net.minecraft.class_1747;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_2248;
import net.minecraft.class_2960;
import net.minecraft.class_7923;
import net.pitan76.mcpitanlib.api.block.BlockItemByExtendBlock1215;
import net.pitan76.mcpitanlib.api.block.ExtendBlock;
import net.pitan76.mcpitanlib.api.block.ExtendBlockProvider;
import net.pitan76.mcpitanlib.api.item.CompatibleItemSettings;
import net.pitan76.mcpitanlib.api.tag.TagKey;

import java.util.ArrayList;
import java.util.List;

public class ItemUtilV1 {
    public static class_1792 item(class_2960 id) {
        return class_7923.field_41178.method_63535(id);
    }

    public static boolean isEqual(class_1792 item, class_1792 item2) {
        return item == item2;
    }

    public static boolean isOf(class_1799 stack, class_1792 item) {
        return stack.method_31574(item);
    }

    public static boolean isIn(class_1799 stack, TagKey<class_1792> tagKey) {
        return isIn(stack.method_7909(), tagKey);
    }

    public static boolean isIn(class_1792 item, TagKey<class_1792> tagKey) {
        if (item.method_40131().method_40220(tagKey.getTagKey())) return true;
        return tagKey.isOf(item);
    }

    public static boolean isExist(class_2960 identifier) {
        return class_7923.field_41178.method_10250(identifier);
    }
    public static class_2960 toID(class_1792 item) {
        return class_7923.field_41178.method_10221(item);
    }

    public static class_1792 fromId(class_2960 identifier) {
        return class_7923.field_41178.method_63535(identifier);
    }

    @Deprecated
    public static class_1747 ofBlock(class_2248 block, class_1792.class_1793 settings) {
        if (block instanceof ExtendBlock) {
            return new BlockItemByExtendBlock1215((ExtendBlock) block, settings);
        }

        if (block instanceof ExtendBlockProvider) {
            return new BlockItemByExtendBlock1215((ExtendBlockProvider) block, settings);
        }

        return new class_1747(block, settings);
    }

    public static class_1747 ofBlock(class_2248 block, CompatibleItemSettings settings) {
        return ofBlock(block, settings.build());
    }

    @Deprecated
    public static class_1792 of(class_1792.class_1793 settings) {
        return new class_1792(settings);
    }

    public static class_1792 of(CompatibleItemSettings settings) {
        return of(settings.build());
    }

    public static List<class_1792> getAllItems() {
        List<class_1792> items = new ArrayList<>();
        for (class_1792 item : class_7923.field_41178) {
            items.add(item);
        }
        return items;
    }

    public static int getRawId(class_1792 item) {
        return class_7923.field_41178.method_10206(item);
    }

    public static class_1792 fromIndex(int index) {
        return class_7923.field_41178.method_10200(index);
    }
}
