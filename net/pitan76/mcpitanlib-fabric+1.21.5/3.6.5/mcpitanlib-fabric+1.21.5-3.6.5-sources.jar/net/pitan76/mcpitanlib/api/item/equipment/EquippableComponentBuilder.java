package net.pitan76.mcpitanlib.api.item.equipment;

import net.minecraft.class_10192;
import net.minecraft.class_1299;
import net.minecraft.class_7871;
import net.minecraft.class_7923;
import net.pitan76.mcpitanlib.api.item.ArmorEquipmentType;
import net.pitan76.mcpitanlib.api.sound.CompatSoundEvent;
import net.pitan76.mcpitanlib.api.tag.TagKey;
import net.pitan76.mcpitanlib.api.util.CompatIdentifier;

public class EquippableComponentBuilder {

    public ArmorEquipmentType equipmentType;
    public CompatSoundEvent equipSound;
    public CompatSoundEvent shearingSound;
    public boolean equipOnInteract = false;
    public boolean canBeSheared = false;
    public CompatEquipmentAsset model;
    public TagKey<?> allowedEntities = null;

    public EquippableComponentBuilder() {

    }

    public EquippableComponentBuilder(ArmorEquipmentType equipmentType) {
        this.equipmentType = equipmentType;
    }

    public EquippableComponentBuilder equipmentType(ArmorEquipmentType equipmentType) {
        this.equipmentType = equipmentType;
        return this;
    }

    public EquippableComponentBuilder equipSound(CompatSoundEvent equipSound) {
        this.equipSound = equipSound;
        return this;
    }

    public EquippableComponentBuilder shearingSound(CompatSoundEvent shearingSound) {
        this.shearingSound = shearingSound;
        return this;
    }

    public EquippableComponentBuilder equipOnInteract(boolean equipOnInteract) {
        this.equipOnInteract = equipOnInteract;
        return this;
    }

    public EquippableComponentBuilder canBeSheared(boolean canBeSheared) {
        this.canBeSheared = canBeSheared;
        return this;
    }

    public EquippableComponentBuilder model(CompatEquipmentAsset model) {
        this.model = model;
        return this;
    }

    public EquippableComponentBuilder model(CompatIdentifier id) {
        return model(CompatEquipmentAsset.of(id));
    }

    public EquippableComponentBuilder allowedEntities(TagKey<?> allowedEntities) {
        this.allowedEntities = allowedEntities;
        return this;
    }

    public EquippableComponentBuilder allowedEntities(CompatIdentifier tagId) {
        return allowedEntities(TagKey.create(TagKey.Type.ENTITY_TYPE, tagId));
    }

    public EquippableComponentBuilder allowedEntities(String tagId) {
        return allowedEntities(CompatIdentifier.of(tagId));
    }

    public CompatEquippableComponent build() {
        class_10192.class_10217 component = class_10192.method_64202(equipmentType.getSlot());
        if (equipSound != null)
            component.method_64205(equipSound.getEntry() != null ? equipSound.getEntry() : equipSound.getReference());

        component.method_66701(equipOnInteract);
        if (model != null) component.method_64204(model.raw());
        if (allowedEntities != null) {
            class_7871<class_1299<?>> registryEntryLookup = class_7923.method_62715(class_7923.field_41177);
            component.method_64206(registryEntryLookup.method_46735((net.minecraft.class_6862<class_1299<?>>) allowedEntities.getTagKey()));
        }

        return CompatEquippableComponent.of(component.method_64203());
    }
}
