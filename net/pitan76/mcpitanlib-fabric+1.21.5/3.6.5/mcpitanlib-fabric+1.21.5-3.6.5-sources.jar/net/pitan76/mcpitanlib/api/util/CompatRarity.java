package net.pitan76.mcpitanlib.api.util;

import net.minecraft.class_124;
import net.minecraft.class_1814;

public class CompatRarity implements CompatStringIdentifiable {
    private final class_1814 rarity;

    public static final CompatRarity NONE = of(class_1814.field_8906);
    public static final CompatRarity COMMON = of(class_1814.field_8906);
    public static final CompatRarity UNCOMMON = of(class_1814.field_8907);
    public static final CompatRarity RARE = of(class_1814.field_8903);
    public static final CompatRarity EPIC = of(class_1814.field_8904);

    public CompatRarity(class_1814 rarity) {
        this.rarity = rarity;
    }

    public static CompatRarity of(class_1814 rarity) {
        return new CompatRarity(rarity);
    }

    public class_1814 get() {
        return rarity;
    }

    public class_124 getFormatting() {
        return rarity.method_58413();
    }

    public String getName() {
        return rarity.name();
    }

    @Override
    public String asString_compat() {
        return getName();
    }

    public static CompatRarity fromString(String name) {
        switch (name) {
            case "common":
                return COMMON;
            case "uncommon":
                return UNCOMMON;
            case "rare":
                return RARE;
            case "epic":
                return EPIC;
            default:
                return NONE;
        }
    }
}
