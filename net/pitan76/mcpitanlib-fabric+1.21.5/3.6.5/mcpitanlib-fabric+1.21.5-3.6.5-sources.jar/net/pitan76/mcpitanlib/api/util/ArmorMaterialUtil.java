package net.pitan76.mcpitanlib.api.util;

import net.minecraft.class_1856;
import net.minecraft.class_2960;
import net.minecraft.class_3414;
import net.pitan76.mcpitanlib.api.item.ArmorEquipmentType;
import net.pitan76.mcpitanlib.api.item.CompatibleArmorMaterial;

public class ArmorMaterialUtil {
    public static CompatibleArmorMaterial create(String name, int[] durability, int[] protectionAmounts, int enchantability, class_3414 equipSound, float toughness, float knockbackResistance, class_1856 repairIngredient) {
        return create(IdentifierUtil.id(name), durability, protectionAmounts, enchantability, equipSound, toughness, knockbackResistance, repairIngredient);
    }
    public static CompatibleArmorMaterial create(String name, int durability, int protectionAmount, int enchantability, class_3414 equipSound, float toughness, float knockbackResistance, class_1856 repairIngredient) {
        return create(IdentifierUtil.id(name), durability, protectionAmount, enchantability, equipSound, toughness, knockbackResistance, repairIngredient);
    }

    @Deprecated
    public static CompatibleArmorMaterial create(class_2960 id, int[] durability, int[] protectionAmounts, int enchantability, class_3414 equipSound, float toughness, float knockbackResistance, class_1856 repairIngredient) {
        return new CompatibleArmorMaterial() {
            @Override
            public int getDurability(ArmorEquipmentType type) {
                switch (type.getSlot()) {
                    case field_6169 -> {
                        return durability[0];
                    }
                    case field_6174 -> {
                        return durability[1];
                    }
                    case field_6172 -> {
                        return durability[2];
                    }
                    case field_6166 -> {
                        return durability[3];
                    }
                    default -> {
                        return 0;
                    }
                }
            }

            @Override
            public int getProtection(ArmorEquipmentType type) {
                switch (type.getSlot()) {
                    case field_6169 -> {
                        return protectionAmounts[0];
                    }
                    case field_6174 -> {
                        return protectionAmounts[1];
                    }
                    case field_6172 -> {
                        return protectionAmounts[2];
                    }
                    case field_6166 -> {
                        return protectionAmounts[3];
                    }
                    default -> {
                        return 0;
                    }
                }
            }

            @Override
            public int getEnchantability() {
                return enchantability;
            }

            @Override
            public class_3414 getEquipSound() {
                return equipSound;
            }

            @Override
            public class_1856 getRepairIngredient() {
                return repairIngredient;
            }

            @Override
            public class_2960 getId() {
                return id;
            }

            @Override
            public float getToughness() {
                return toughness;
            }

            @Override
            public float getKnockbackResistance() {
                return knockbackResistance;
            }
        };
    }

    @Deprecated
    public static CompatibleArmorMaterial create(class_2960 id, int durability, int protectionAmount, int enchantability, class_3414 equipSound, float toughness, float knockbackResistance, class_1856 repairIngredient) {
        return new CompatibleArmorMaterial() {
            @Override
            public int getDurability(ArmorEquipmentType type) {
                return durability;
            }

            @Override
            public int getProtection(ArmorEquipmentType type) {
                return protectionAmount;
            }

            @Override
            public int getEnchantability() {
                return enchantability;
            }

            @Override
            public class_3414 getEquipSound() {
                return equipSound;
            }

            @Override
            public class_1856 getRepairIngredient() {
                return repairIngredient;
            }

            @Override
            public class_2960 getId() {
                return id;
            }

            @Override
            public float getToughness() {
                return toughness;
            }

            @Override
            public float getKnockbackResistance() {
                return knockbackResistance;
            }
        };
    }
}
