package net.pitan76.mcpitanlib.api.util.inventory;

import net.minecraft.class_1661;
import net.minecraft.class_1799;
import net.minecraft.class_2371;
import net.pitan76.mcpitanlib.api.entity.Player;

public class PlayerInventoryUtil {
    public static Player getPlayer(class_1661 playerInventory) {
        return new Player(playerInventory.field_7546);
    }

    public static int getSelectedSlot(class_1661 playerInventory) {
        return playerInventory.method_67532();
    }

    public static void setSelectedSlot(class_1661 playerInventory, int slot) {
        playerInventory.method_61496(slot);
    }

    public static void dropAllItems(class_1661 inv) {
        inv.method_7388();
    }

    public static class_2371<class_1799> getMain(class_1661 inv) {
        return inv.method_67533();
    }

    public static class_2371<class_1799> getArmor(class_1661 inv) {
        class_2371<class_1799> stacks = class_2371.method_10213(4, class_1799.field_8037);
        stacks.set(0, inv.method_5438(36));
        stacks.set(1, inv.method_5438(37));
        stacks.set(2, inv.method_5438(38));
        stacks.set(3, inv.method_5438(39));
        return stacks;
    }

    public static class_2371<class_1799> getOffHand(class_1661 inv) {
        class_2371<class_1799> stacks = class_2371.method_10213(1, class_1799.field_8037);
        stacks.set(0, inv.method_5438(class_1661.field_30639));
        return stacks;
    }

    public static class_1799 getMainHandStack(class_1661 inv) {
        return inv.field_7546.method_6047();
    }
}
