package net.pitan76.mcpitanlib.api.util.block;

import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_2248;
import net.pitan76.mcpitanlib.api.block.CompatibleBlockSettings;
import net.pitan76.mcpitanlib.api.tag.TagKey;
import net.pitan76.mcpitanlib.api.text.TextComponent;
import net.pitan76.mcpitanlib.api.util.CompatIdentifier;
import net.pitan76.mcpitanlib.api.util.v2.BlockUtilV2;

import java.util.ArrayList;
import java.util.List;

@SuppressWarnings("deprecation")
public class BlockUtil {
    /**
     * Check if two blocks are equal.
     * @param block Block to compare.
     * @param block2 Block to compare.
     * @return If two blocks are equal.
     */
    public static boolean isEqual(class_2248 block, class_2248 block2) {
        return net.pitan76.mcpitanlib.api.util.BlockUtil.isEqual(block, block2);
    }

    /**
     * Get block from CompatIdentifier.
     * @param id CompatIdentifier of the block.
     * @return Block of the CompatIdentifier.
     */
    public static class_2248 fromId(CompatIdentifier id) {
        return net.pitan76.mcpitanlib.api.util.BlockUtil.fromId(id);
    }

    public static class_2248 fromId(String id) {
        return fromId(CompatIdentifier.of(id));
    }

    public static class_2248 fromId(String namespace, String path) {
        return fromId(CompatIdentifier.of(namespace, path));
    }

    /**
     * Get CompatIdentifier from Block.
     * @param block Block to get CompatIdentifier.
     * @return CompatIdentifier of the Block.
     */
    public static CompatIdentifier toId(class_2248 block) {
        return net.pitan76.mcpitanlib.api.util.BlockUtil.toCompatID(block);
    }

    public static String toIdAsString(class_2248 block) {
        return toId(block).toString();
    }

    /**
     * Check if the block exist.
     * @param id CompatIdentifier of the block.
     * @return If the block exist.
     */
    public static boolean isExist(CompatIdentifier id) {
        return net.pitan76.mcpitanlib.api.util.BlockUtil.isExist(id);
    }

    public static boolean isExist(String id) {
        return isExist(CompatIdentifier.of(id));
    }

    public static boolean isExist(String namespace, String path) {
        return isExist(CompatIdentifier.of(namespace, path));
    }

    public static boolean isMinecraftBlock(class_2248 block) {
        return CompatIdentifier.isMinecraftNamespace(toId(block));
    }

    /**
     * Create a new Block
     * @param settings Block settings
     * @return The new Block
     */
    public static class_2248 create(CompatibleBlockSettings settings) {
        return net.pitan76.mcpitanlib.api.util.BlockUtil.of(settings);
    }

    /**
     * Get all blocks.
     * @return List of all blocks.
     */
    public static List<class_2248> getBlocks() {
        return net.pitan76.mcpitanlib.api.util.BlockUtil.getAllBlocks();
    }

    /**
     * Get blocks from tag key.
     * @param tagKey Tag key of the blocks.
     * @return Blocks of the tag key.
     */
    public static List<class_2248> getInTag(TagKey<class_2248> tagKey) {
        return net.pitan76.mcpitanlib.api.util.BlockUtil.getBlocks(tagKey);
    }

    /**
     * Get blocks from tag key.
     * @param id CompatIdentifier of the tag key.
     * @return Blocks of the tag key.
     */
    public static List<class_2248> getInTag(CompatIdentifier id) {
        return net.pitan76.mcpitanlib.api.util.BlockUtil.getBlocks(id.toMinecraft());
    }

    public static List<class_2248> getInTag(String id) {
        return getInTag(CompatIdentifier.of(id));
    }

    public static List<class_2248> getInTag(String namespace, String path) {
        return getInTag(CompatIdentifier.of(namespace, path));
    }

    /**
     * Check if the block is in the tag.
     * @param block Block to check.
     * @param tagKey Tag key of the tag.
     * @return If the block is in the tag.
     */
    public static boolean isInTag(class_2248 block, TagKey<class_2248> tagKey) {
        return net.pitan76.mcpitanlib.api.util.BlockUtil.isIn(block, tagKey);
    }

    /**
     * Check if the block is in the tag.
     * @param block Block to check.
     * @param id CompatIdentifier of the tag.
     * @return If the block is in the tag.
     */
    public static boolean isInTag(class_2248 block, CompatIdentifier id) {
        return net.pitan76.mcpitanlib.api.util.BlockUtil.isBlockInTag(block, id.toMinecraft());
    }

    public static boolean isInTag(class_2248 block, String id) {
        return isInTag(block, CompatIdentifier.of(id));
    }

    public static boolean isInTag(class_2248 block, String namespace, String path) {
        return isInTag(block, CompatIdentifier.of(namespace, path));
    }

    /**
     * Get raw id of the block.
     * @param block Block to get raw id.
     * @return Raw id of the block.
     */
    public static int getRawId(class_2248 block) {
        return net.pitan76.mcpitanlib.api.util.BlockUtil.getRawId(block);
    }

    /**
     * Get block from raw id.
     * @param rawId Raw id of the block.
     * @return Block of the raw id.
     */
    public static class_2248 fromRawId(int rawId) {
        return net.pitan76.mcpitanlib.api.util.BlockUtil.fromIndex(rawId);
    }

    /**
     * Get blocks in the namespace.
     * @param namespace Namespace of the blocks.
     * @return List of blocks in the namespace.
     */
    public static List<class_2248> getBlocksInNamespace(String namespace) {
        List<class_2248> blocks = new ArrayList<>();

        for (class_2248 block : getBlocks()) {
            if (toId(block).getNamespace().equals(namespace)) {
                blocks.add(block);
            }
        }

        return blocks;
    }

    /**
     * Get number of all blocks.
     * @return Number of all blocks.
     */
    public static int getNumberOfBlocks() {
        return getBlocks().size();
    }

    /**
     * Get item from block.
     * @param block Block
     * @return Item
     */
    public static class_1792 toItem(class_2248 block) {
        return block.method_8389();
    }

    /**
     * Get name of the block.
     * @param block Block
     * @return Name of the block.
     */
    public static String getNameAsString(class_2248 block) {
        return block.method_9518().getString();
    }

    /**
     * Get name of the block.
     * @param block Block
     * @return Name of the block.
     */
    public static TextComponent getName(class_2248 block) {
        return new TextComponent(block.method_9518());
    }

    /**
     * Get translation key of the block.
     * @param block Block
     * @return Translation key of the block.
     */
    public static String getTranslationKey(class_2248 block) {
        return block.method_63499();
    }

    public static class_2248 fromItem(class_1792 item) {
        return BlockUtilV2.fromItem(item);
    }

    public static class_2248 fromItem(class_1799 stack) {
        return BlockUtilV2.fromItem(stack);
    }

    public static float getHardness(class_2248 block) {
        return block.method_36555();
    }
}
