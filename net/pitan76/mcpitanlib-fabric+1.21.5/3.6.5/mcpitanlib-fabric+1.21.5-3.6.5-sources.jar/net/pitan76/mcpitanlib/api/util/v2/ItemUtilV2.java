package net.pitan76.mcpitanlib.api.util.v2;

import net.minecraft.class_1792;
import net.minecraft.class_2960;
import net.pitan76.mcpitanlib.api.tag.TagKey;
import net.pitan76.mcpitanlib.api.util.IdentifierUtil;
import net.pitan76.mcpitanlib.api.util.ItemUtil;

import java.util.ArrayList;
import java.util.List;

public class ItemUtilV2 {
    /**
     * Get all items in the tag.
     * @param tagKey TagKey of the tag.
     * @return List of items in the tag.
     */
    public static List<class_1792> getItems(TagKey<class_1792> tagKey) {
        return getItems(tagKey, ItemUtil.getAllItems());
    }

    /**
     * Get given the list of items in the tag.
     * @param tagKey TagKey of the tag.
     * @param items List of items to search.
     * @return List of items in the tag.
     */
    public static List<class_1792> getItems(TagKey<class_1792> tagKey, List<class_1792> items) {
        List<class_1792> result = new ArrayList<>();
        for (class_1792 item : items) {
            if (!ItemUtil.isIn(item, tagKey)) continue;
            result.add(item);
        }
        return result;
    }

    /**
     * Get all items in the tag.
     * @param identifier Identifier of the tag.
     * @return List of items in the tag.
     */
    public static List<class_1792> getItems(class_2960 identifier) {
        return getItems((TagKey<class_1792>) TagKey.create(TagKey.Type.ITEM, identifier));
    }

    /**
     * Get given the list of items in the tag.
     * @param identifier Identifier of the tag.
     * @param items List of items to search.
     * @return List of items in the tag.
     */
    public static List<class_1792> getItems(class_2960 identifier, List<class_1792> items) {
        return getItems((TagKey<class_1792>) TagKey.create(TagKey.Type.ITEM, identifier), items);
    }

    /**
     * Get all items in the tag.
     * @param id String of the tag.
     * @return List of items in the tag.
     */
    public static List<class_1792> getItems(String id) {
        return getItems(IdentifierUtil.id(id));
    }

    /**
     * Get given the list of items in the tag.
     * @param id String of the tag.
     * @param items List of items to search.
     * @return List of items in the tag.
     */
    public static List<class_1792> getItems(String id, List<class_1792> items) {
        return getItems(IdentifierUtil.id(id), items);
    }

    /**
     * Check if the item is in the tag.
     * @param item Item to check.
     * @param identifier Identifier of the tag.
     * @return True if the item is in the tag.
     */
    public static boolean isItemInTag(class_1792 item, class_2960 identifier) {
        return ItemUtil.isIn(item, (TagKey<class_1792>) TagKey.create(TagKey.Type.ITEM, identifier));
    }

    /**
     * Check if the item is in the tag.
     * @param item Item to check.
     * @param id String of the tag.
     * @return True if the item is in the tag.
     */
    public static boolean isItemInTag(class_1792 item, String id) {
        return isItemInTag(item, IdentifierUtil.id(id));
    }
}
