package net.pitan76.mcpitanlib.api.util.event;

import net.minecraft.class_2248;
import net.pitan76.mcpitanlib.api.event.block.BlockBreakEvent;
import net.pitan76.mcpitanlib.api.event.block.BlockPlacedEvent;
import net.pitan76.mcpitanlib.api.event.block.ItemScattererUtil;
import net.pitan76.mcpitanlib.api.event.block.StateReplacedEvent;

public class BlockEventGenerator {
    public static void onPlaced(class_2248 block, BlockPlacedEvent e) {
        block.method_9567(e.world, e.pos, e.state, e.placer, e.stack);
    }

    public static void onBreak(class_2248 block, BlockBreakEvent e) {
        block.method_9576(e.world, e.pos, e.state, e.getPlayerEntity());
    }

    public static void onStateReplaced(class_2248 block, StateReplacedEvent e) {
        ItemScattererUtil.onStateReplaced(e);
    }
}
