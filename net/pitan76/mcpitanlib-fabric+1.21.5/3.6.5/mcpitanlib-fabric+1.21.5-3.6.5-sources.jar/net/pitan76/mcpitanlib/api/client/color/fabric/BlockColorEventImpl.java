package net.pitan76.mcpitanlib.api.client.color.fabric;

import net.minecraft.class_2586;
import net.pitan76.mcpitanlib.api.tile.RenderAttachmentBlockEntity;

public class BlockColorEventImpl {
    public static Object getRenderDataD(class_2586 blockEntity) {
        if (blockEntity instanceof RenderAttachmentBlockEntity) {
            return ((RenderAttachmentBlockEntity) blockEntity).getCompatRenderData();
        }

        if (blockEntity instanceof net.pitan76.mcpitanlib.api.tile.RenderDataBlockEntity) {
            return ((net.pitan76.mcpitanlib.api.tile.RenderDataBlockEntity) blockEntity).getCompatRenderData();
        }

        return blockEntity.getRenderData();
    }
}