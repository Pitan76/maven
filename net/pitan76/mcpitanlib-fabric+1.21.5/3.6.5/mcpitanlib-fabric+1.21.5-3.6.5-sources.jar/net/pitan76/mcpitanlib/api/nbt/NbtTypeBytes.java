package net.pitan76.mcpitanlib.api.nbt;

import net.minecraft.class_2520;

public class NbtTypeBytes {
    public static final byte END = class_2520.field_33250;
    public static final byte BYTE = class_2520.field_33251;
    public static final byte SHORT = class_2520.field_33252;
    public static final byte INT = class_2520.field_33253;
    public static final byte LONG = class_2520.field_33254;
    public static final byte FLOAT = class_2520.field_33255;
    public static final byte DOUBLE = class_2520.field_33256;
    public static final byte BYTE_ARRAY = class_2520.field_33257;
    public static final byte STRING = class_2520.field_33258;
    public static final byte LIST = class_2520.field_33259;
    public static final byte COMPOUND = class_2520.field_33260;
    public static final byte INT_ARRAY = class_2520.field_33261;
    public static final byte LONG_ARRAY = class_2520.field_33262;
    public static final byte NUMBER = class_2520.field_33253;
}
