package net.pitan76.mcpitanlib.api.util.recipe;

import it.unimi.dsi.fastutil.ints.IntList;
import net.minecraft.class_1662;
import net.minecraft.class_1799;
import net.minecraft.class_1860;
import net.pitan76.mcpitanlib.api.recipe.CompatibleRecipeEntry;
import net.pitan76.mcpitanlib.api.util.ItemStackUtil;
import net.pitan76.mcpitanlib.api.util.ItemUtil;

public class RecipeMatcherUtil {
    public static class_1799 getStackFromId(int itemId) {
        return ItemStackUtil.create(ItemUtil.fromIndex(itemId));
    }

    public static int getItemId(class_1799 stack) {
        return ItemUtil.getRawId(stack.method_7909());
    }

    public static boolean match(class_1662<?> matcher, CompatibleRecipeEntry entry, IntList output) {
        return match(matcher, entry.getRecipe(), output);
    }

    public static boolean match(class_1662<?> matcher, CompatibleRecipeEntry entry, IntList output, int multiplier) {
        return match(matcher, entry.getRecipe(), output, multiplier);
    }

    @Deprecated
    public static boolean match(class_1662<?> matcher, class_1860<?> recipe, IntList output) {
        return false;
        //return matcher.match(recipe, output);
    }

    @Deprecated
    public static boolean match(class_1662<?> matcher, class_1860<?> recipe, IntList output, int multiplier) {
        return false;
        //return matcher.match(recipe, output, multiplier);
    }

    public static void clear(class_1662<?> matcher) {
        matcher.method_7409();
    }
}
