package net.pitan76.mcpitanlib.api.util;

import java.util.Set;
import net.minecraft.class_1799;
import net.minecraft.class_2487;
import net.minecraft.class_9279;
import net.minecraft.class_9334;

/**
 * カスタムデータのユーティリティクラス
 */
public class CustomDataUtil {
    /**
     * NBTを取得する。存在しない場合は新しいNBTを作成する。
     * @param stack ItemStack
     * @return NBT
     */
    public static class_2487 getOrCreateNbt(class_1799 stack) {
        if (!hasNbt(stack)) {
            return NbtUtil.create();
        }

        return getNbt(stack);
    }

    /**
     * NBTを設定する。
     * @param stack ItemStack
     * @param nbt NBT
     */
    public static void setNbt(class_1799 stack, class_2487 nbt) {
        stack.method_57379(class_9334.field_49628, class_9279.method_57456(nbt));
    }
    
    /**
     * NBTが存在するかどうかを取得する。
     * @param stack ItemStack
     * @return NBTが存在するかどうか
     */
    public static boolean hasNbt(class_1799 stack) {
        return stack.method_58694(class_9334.field_49628) != null;
    }
    
    /**
     * NBTを取得する。
     * @param stack ItemStack
     * @return NBT
     */
    public static class_2487 getNbt(class_1799 stack) {
        if (stack.method_58694(class_9334.field_49628) == null)
            return NbtUtil.create();

        return stack.method_58694(class_9334.field_49628).method_57461();
    }
    
    /**
     * 値を設定する。
     * @param stack ItemStack
     * @param key キー
     * @param value 値
     */
    public static void put(class_1799 stack, String key, class_2487 value) {
        class_2487 nbt = getOrCreateNbt(stack);
        NbtUtil.put(nbt, key, value);
        setNbt(stack, nbt);
    }
    
    /**
     * 値を取得する。
     * @param stack ItemStack
     * @param key キー
     * @return 値
     */
    public static class_2487 get(class_1799 stack, String key) {
        class_2487 nbt = getNbt(stack);
        return nbt.method_68568(key);
    }
    
    /**
     * 値を削除する。
     * @param stack ItemStack
     * @param key キー
     */
    public static void remove(class_1799 stack, String key) {
        class_2487 nbt = getNbt(stack);
        nbt.method_10551(key);
        setNbt(stack, nbt);
    }
    
    /**
     * 値が存在するかどうかを取得する。
     * @param stack ItemStack
     * @param key キー
     * @return 値が存在するかどうか
     */
    public static boolean has(class_1799 stack, String key) {
        if (!hasNbt(stack))
            return false;

        class_2487 nbt = getNbt(stack);
        return nbt.method_10545(key);
    }
    
    /**
     * 指定した型の値を取得する
     * @param stack ItemStack
     * @param key キー
     * @param clazz クラス
     * @param <T> 値
     */
    public static <T> T get(class_1799 stack, String key, Class<T> clazz) {
        class_2487 nbt = getNbt(stack);
        return NbtUtil.get(nbt, key, clazz);
    }
    
    /**
     * 値を設定する。
     * @param stack ItemStack
     * @param key キー
     * @param value 値
     */
    public static <T> void set(class_1799 stack, String key, T value) {
        class_2487 nbt = getOrCreateNbt(stack);
        NbtUtil.set(nbt, key, value);
        setNbt(stack, nbt);
    }
    
    /**
     * キーの一覧を取得する。
     * @param stack ItemStack
     * @return キーの一覧
     */
    public static Set<String> getKeys(class_1799 stack) {
        class_2487 nbt = getNbt(stack);
        return NbtUtil.getKeys(nbt);
    }

    /**
     * set(stack, key, value) のエイリアス
     * @param stack ItemStack
     * @param key キー
     * @param value 値
     */
    public static <T> void put(class_1799 stack, String key, T value) {
        set(stack, key, value);
    }

    /**
     * has(stack, key) のエイリアス
     * @param stack ItemStack
     * @param key キー
     * @return 値が存在するかどうか
     */
    public static boolean contains(class_1799 stack, String key) {
        return has(stack, key);
    }

    /**
     * 1.20.3以前下位互換のための修正用
     * @param stack ItemStack
     * @param keys 移植するキー
     */
    public static void fix_oldNbt(class_1799 stack, String[] keys) {

    }

    /**
     * カスタムNBTを削除する
     * @param stack ItemStack
     */
    public static void remove(class_1799 stack) {
        stack.method_57381(class_9334.field_49628);
    }
}
