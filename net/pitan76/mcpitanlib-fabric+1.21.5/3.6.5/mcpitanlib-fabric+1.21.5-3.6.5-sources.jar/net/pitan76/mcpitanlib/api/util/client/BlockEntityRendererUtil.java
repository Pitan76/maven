package net.pitan76.mcpitanlib.api.util.client;

import net.minecraft.class_5614;
import net.pitan76.mcpitanlib.api.client.registry.CompatRegistryClient;

public class BlockEntityRendererUtil {
    public static class_5614.class_5615 convert(CompatRegistryClient.BlockEntityRendererFactory.Context ctx) {
        return new class_5614.class_5615(ctx.getRenderDispatcher(), ctx.getRenderManager(), ctx.getItemModelManager(), ctx.getItemRenderer(), ctx.getEntityRenderDispatcher(), ctx.getLayerRenderDispatcher(), ctx.getTextRenderer());
    }

    public static CompatRegistryClient.BlockEntityRendererFactory.Context convert(class_5614.class_5615 ctx) {
        return new CompatRegistryClient.BlockEntityRendererFactory.Context(ctx.method_32139(), ctx.method_32141(), ctx.method_65558(), ctx.method_43335(), ctx.method_43334(), ctx.method_32142(), ctx.method_32143());
    }
}
