package net.pitan76.mcpitanlib.api.event.v0.event;

import net.minecraft.class_1860;
import net.minecraft.class_2960;
import net.minecraft.class_3300;
import net.minecraft.class_3695;
import net.pitan76.mcpitanlib.api.recipe.CompatibleRecipeEntry;
import net.pitan76.mcpitanlib.api.recipe.v2.CompatRecipeEntry;
import net.pitan76.mcpitanlib.api.recipe.v3.CompatRecipe;
import net.pitan76.mcpitanlib.midohra.recipe.entry.RecipeEntry;

import java.util.SortedMap;

public class RecipeManagerEvent {

    @Deprecated
    private SortedMap<class_2960, class_1860<?>> sortedMap;

    public class_3300 resourceManager;
    public class_3695 profiler;

    public RecipeManagerEvent(SortedMap<class_2960, class_1860<?>> sortedMap, class_3300 resourceManager, class_3695 profiler) {
        this.sortedMap = sortedMap;
        this.resourceManager = resourceManager;
        this.profiler = profiler;
    }

    public class_3695 getProfiler() {
        return profiler;
    }

    public class_3300 getResourceManager() {
        return resourceManager;
    }

    public net.pitan76.mcpitanlib.midohra.resource.ResourceManager getResourceManagerM() {
        return net.pitan76.mcpitanlib.midohra.resource.ResourceManager.of(resourceManager);
    }

    public void putCompatibleRecipeEntry(class_2960 id, CompatibleRecipeEntry entry) {
        putCompatibleRecipeEntry(entry);
    }

    public void putCompatibleRecipeEntry(CompatibleRecipeEntry entry) {
        sortedMap.put(entry.getId(), entry.getRecipe());
    }

    public <T extends class_1860<?>> void putCompatibleRecipeEntry(CompatRecipeEntry<T> entry) {
        sortedMap.put(entry.getId(), entry.getRecipe());
    }

    public void putRecipeEntry(RecipeEntry entry) {
        sortedMap.put(entry.getId().toMinecraft(), entry.getRawRecipe());
    }

    public void putRecipe(CompatRecipe recipe) {
        sortedMap.put(recipe.getId(), recipe.getRecipe());
    }
}
