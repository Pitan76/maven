package net.pitan76.mcpitanlib.api.entity.attribute;

import net.minecraft.class_1320;
import net.minecraft.class_5134;
import net.minecraft.class_6880;

public class CompatEntityAttributes {

    public static final CompatEntityAttribute ARMOR = of(class_5134.field_23724);
    public static final CompatEntityAttribute ARMOR_TOUGHNESS = of(class_5134.field_23725);
    public static final CompatEntityAttribute ATTACK_DAMAGE = of(class_5134.field_23721);
    public static final CompatEntityAttribute ATTACK_KNOCKBACK = of(class_5134.field_23722);
    public static final CompatEntityAttribute ATTACK_SPEED = of(class_5134.field_23723);
    public static final CompatEntityAttribute FOLLOW_RANGE = of(class_5134.field_23717);
    public static final CompatEntityAttribute KNOCKBACK_RESISTANCE = of(class_5134.field_23718);
    public static final CompatEntityAttribute LUCK = of(class_5134.field_23726);
    public static final CompatEntityAttribute MOVEMENT_SPEED = of(class_5134.field_23719);
    public static final CompatEntityAttribute MAX_HEALTH = of(class_5134.field_23716);
    public static final CompatEntityAttribute JUMP_STRENGTH = of(class_5134.field_23728);
    public static final CompatEntityAttribute GRAVITY = of(class_5134.field_49078);
    public static final CompatEntityAttribute FLYING_SPEED = of(class_5134.field_23720);
    public static final CompatEntityAttribute BLOCK_BREAK_SPEED = of(class_5134.field_49076);
    public static final CompatEntityAttribute BLOCK_INTERACTION_RANGE = of(class_5134.field_47758);

    public static CompatEntityAttribute of(class_6880<class_1320> attribute) {
        return CompatEntityAttribute.of(attribute);
    }
}
