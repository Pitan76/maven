package net.pitan76.mcpitanlib.api.util;

import net.minecraft.class_10286;
import net.minecraft.class_1263;
import net.minecraft.class_1799;
import net.minecraft.class_1852;
import net.minecraft.class_1856;
import net.minecraft.class_1860;
import net.minecraft.class_1863;
import net.minecraft.class_1867;
import net.minecraft.class_1869;
import net.minecraft.class_1937;
import net.minecraft.class_2371;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_3955;
import net.minecraft.class_3956;
import net.minecraft.class_5321;
import net.minecraft.class_7710;
import net.minecraft.class_7924;
import net.minecraft.class_8786;
import net.minecraft.class_9694;
import net.minecraft.class_9695;
import net.minecraft.recipe.*;
import net.pitan76.mcpitanlib.api.recipe.CompatRecipeType;
import net.pitan76.mcpitanlib.api.recipe.MatchGetter;
import net.pitan76.mcpitanlib.api.recipe.input.CompatRecipeInput;
import net.pitan76.mcpitanlib.api.recipe.v2.CompatRecipeEntry;
import net.pitan76.mcpitanlib.api.recipe.v2.CompatRecipeNonEntry;
import net.pitan76.mcpitanlib.api.registry.CompatRegistryLookup;
import net.pitan76.mcpitanlib.api.util.collection.ItemStackList;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Optional;

public class RecipeUtil {
    public static class_1867 createShapelessRecipe(class_2960 id, String group, CompatibilityCraftingRecipeCategory category, class_1799 output, class_2371<class_1856> input) {
        return new class_1867(group, class_7710.valueOf(category.name()), output, input);
    }

    public static class_1867 createShapelessRecipe(class_2960 id, String group, class_1799 output, class_2371<class_1856> input) {
        return createShapelessRecipe(id, group, CompatibilityCraftingRecipeCategory.MISC, output, input);
    }

    @Deprecated
    public static <C extends class_9695> class_1799 craft_2(class_1860<C> recipe, C inventory, class_1937 world) {
        return recipe.method_8116(inventory, world.method_30349());
    }

    @Deprecated
    public static <C extends class_9695> class_1799 getOutput_2(class_1860<C> recipe, class_1937 world) {
        return craft_2(recipe, (C) class_9694.field_51631, world);
    }

    public static class_1799 craft(class_1860<?> recipe, class_1263 inventory, class_1937 world) {
        if (inventory instanceof class_9695) {
            class_1860<class_9695> inputRecipe = (class_1860<class_9695>) recipe;
            return inputRecipe.method_8116((class_9695) inventory, world.method_30349());
        }
        return class_1799.field_8037;
    }

    public static class_1799 getOutput(class_1860<?> recipe, class_1937 world) {
        return getOutput(recipe, RegistryLookupUtil.getRegistryLookup(world));
    }

    public static List<class_1860<?>> getAllRecipes(class_1937 world) {
        class_10286 iRecipeManager = getRecipeManager(world);
        if (!(iRecipeManager instanceof class_1863))
            return new ArrayList<>();

        class_1863 recipeManager = (class_1863) iRecipeManager;

        Collection<class_8786<?>> recipes = recipeManager.method_8126();
        List<class_1860<?>> outRecipes = new ArrayList<>();
        for (Object recipeEntryObj : recipes) {
            if (recipeEntryObj instanceof class_8786) {
                class_8786<?> recipeEntry = (class_8786<?>) recipeEntryObj;
                if (recipeEntry.comp_1933() instanceof class_1860) {
                    outRecipes.add(recipeEntry.comp_1933());
                }
            }
        }
        return outRecipes;
    }

    public static List<CompatRecipeNonEntry<?>> getAllCompatRecipeEntry(class_1937 world) {
        List<class_1860<?>> recipes = getAllRecipes(world);
        List<CompatRecipeNonEntry<?>> outRecipes = new ArrayList<>();
        for (class_1860<?> recipe : recipes) {
            outRecipes.add(new CompatRecipeNonEntry<>(recipe));
        }
        return outRecipes;
    }

    public static class_3956<?> getType(class_1860<?> recipe) {
        return recipe.method_17716();
    }

    public static class_2960 getId(class_1860<?> recipe) {
        return IdentifierUtil.id(recipe.getClass().hashCode() + "");
    }

    public static <I extends class_9695, T extends class_1860<I>> CompatRecipeEntry<T> getFirstMatch(class_10286 iRecipeManager, CompatRecipeType<T> type, CompatRecipeInput<I> input, class_1937 world) {
        if (!(iRecipeManager instanceof class_1863))
            return new CompatRecipeEntry<>(null);

        class_1863 recipeManager = (class_1863) iRecipeManager;

        Optional<class_8786<T>> recipe = recipeManager.method_8132(type.getType(), input.getInput(), world);
        return recipe.map(CompatRecipeEntry::new).orElseGet(() -> new CompatRecipeEntry<>(null));
    }

    public static <I extends class_9695, T extends class_1860<I>> CompatRecipeEntry<T> getFirstMatch(class_10286 iRecipeManager, CompatRecipeType<T> type, CompatRecipeInput<I> input, class_1937 world, CompatIdentifier identifier) {
        if (!(iRecipeManager instanceof class_1863))
            return new CompatRecipeEntry<>(null);

        class_1863 recipeManager = (class_1863) iRecipeManager;

        Optional<class_8786<T>> recipe = recipeManager.method_42299(type.getType(), input.getInput(), world, class_5321.method_29179(class_7924.field_52178, identifier.toMinecraft()));
        return recipe.map(CompatRecipeEntry::new).orElseGet(() -> new CompatRecipeEntry<>(null));
    }

    public static <I extends class_9695, T extends class_1860<I>> CompatRecipeEntry<T> getFirstMatch(class_1937 world, CompatRecipeType<T> type, CompatRecipeInput<I> input) {
        return getFirstMatch(getRecipeManager(world), type, input, world);
    }

    public static <I extends class_9695, T extends class_1860<I>> CompatRecipeEntry<T> getFirstMatch(class_1937 world, CompatRecipeType<T> type, CompatRecipeInput<I> input, CompatIdentifier identifier) {
        return getFirstMatch(getRecipeManager(world), type, input, world, identifier);
    }

    public static class_10286 getRecipeManager(class_1937 world) {
        return world.method_8433();
    }

    public Optional<class_8786<?>> get(class_1937 world, CompatIdentifier id) {
        return get(getRecipeManager(world), id);
    }

    public Optional<class_8786<?>> get(class_10286 iRecipeManager, CompatIdentifier id) {
        if (!(iRecipeManager instanceof class_1863))
            return Optional.empty();
        class_1863 recipeManager = (class_1863) iRecipeManager;

        return recipeManager.method_8130(class_5321.method_29179(class_7924.field_52178, id.toMinecraft()));
    }

    public static <I extends class_9695, T extends class_1860<I>> MatchGetter<I, T> createCachedMatchGetter(class_3956<T> type) {
        return (input, world) -> {
            Optional<class_8786<T>> optional = class_1863.method_42302(type).method_42303(input.getInput(), (class_3218) world);
            return optional.map(CompatRecipeEntry::new);
        };
    }

    public static <I extends class_9695, T extends class_1860<I>> MatchGetter<I, T> createCachedMatchGetter(CompatRecipeType<T> type) {
        return createCachedMatchGetter(type.getType());
    }

    public static class_2371<class_1856> getInputs(class_1860<?> recipe) {
        List<class_1856> ingredients = recipe.method_61671().method_64675();

        class_2371<class_1856> outIngredients = class_2371.method_37434(ingredients.size());

        for (int i = 0; i < ingredients.size(); i++) {
            outIngredients.set(i, ingredients.get(i));
        }

        return outIngredients;
    }

    public static class_2371<class_1856> getInputs(CompatRecipeEntry<?> recipeEntry) {
        return getInputs(recipeEntry.getRecipe());
    }

    public static ItemStackList getInputsAsStack(class_1860<?> recipe) {
        class_2371<class_1856> ingredients = getInputs(recipe);
        ItemStackList stacks = ItemStackList.ofSize(ingredients.size(), ItemStackUtil.empty());
        for (class_1856 ingredient : ingredients) {
            stacks.addAll(IngredientUtil.getMatchingStacksAsList(ingredient));
        }
        return stacks;
    }

    public static ItemStackList getInputsAsStack(CompatRecipeEntry<?> recipeEntry) {
        return getInputsAsStack(recipeEntry.getRecipe());
    }

    public static class_1799 getOutput(class_1860<?> recipe, CompatRegistryLookup registryLookup) {
        if (recipe instanceof class_1867) {
            class_1867 shapelessRecipe = (class_1867) recipe;
            return shapelessRecipe.method_17729(class_9694.field_51631, registryLookup.getRegistryLookup());
        }

        if (recipe instanceof class_1869) {
            class_1869 shapedRecipe = (class_1869) recipe;
            return shapedRecipe.method_17727(class_9694.field_51631, registryLookup.getRegistryLookup());
        }

        if (recipe instanceof class_3955) {
            class_3955 craftingRecipe = (class_3955) recipe;
            return craftingRecipe.method_8116(class_9694.field_51631, registryLookup.getRegistryLookup());
        }

        if (recipe instanceof class_1852) {
            class_1852 specialCraftingRecipe = (class_1852) recipe;
            return specialCraftingRecipe.method_8116(class_9694.field_51631, registryLookup.getRegistryLookup());
        }

        return recipe.method_8116(null, registryLookup.getRegistryLookup());
    }

    public static class_1799 getOutput(CompatRecipeEntry<?> recipeEntry, CompatRegistryLookup registryLookup) {
        return getOutput(recipeEntry.getRecipe(), registryLookup);
    }

    public static CompatRecipeType<?> getType(CompatRecipeEntry<?> recipeEntry) {
        return CompatRecipeType.of(recipeEntry.getRecipe().method_17716());
    }

    public static  <I extends class_9695, T extends class_1860<I>> ItemStackList getRemainder(CompatRecipeEntry<T> recipeEntry, CompatRecipeInput<I> input) {
        return ItemStackList.method_10211();
        //return ItemStackList.of(recipeEntry.getRecipe().getRemainder(input.getInput()));
    }

    public enum CompatibilityCraftingRecipeCategory {
        BUILDING,
        REDSTONE,
        EQUIPMENT,
        MISC;
    }
}
