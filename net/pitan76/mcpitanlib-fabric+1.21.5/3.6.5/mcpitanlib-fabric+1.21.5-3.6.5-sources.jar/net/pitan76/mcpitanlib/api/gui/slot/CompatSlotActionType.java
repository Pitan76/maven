package net.pitan76.mcpitanlib.api.gui.slot;

import net.minecraft.class_1713;

public class CompatSlotActionType {
    public static final CompatSlotActionType PICKUP = new CompatSlotActionType(class_1713.field_7790);
    public static final CompatSlotActionType QUICK_MOVE = new CompatSlotActionType(class_1713.field_7794);
    public static final CompatSlotActionType SWAP = new CompatSlotActionType(class_1713.field_7791);
    public static final CompatSlotActionType THROW = new CompatSlotActionType(class_1713.field_7795);
    public static final CompatSlotActionType CLONE = new CompatSlotActionType(class_1713.field_7796);
    public static final CompatSlotActionType QUICK_CRAFT = new CompatSlotActionType(class_1713.field_7789);
    public static final CompatSlotActionType PICKUP_ALL = new CompatSlotActionType(class_1713.field_7793);
    
    public final class_1713 raw;
    
    protected CompatSlotActionType(class_1713 raw) {
        this.raw = raw;
    }

    public static CompatSlotActionType of(class_1713 raw) {
        if (raw == class_1713.field_7790) return PICKUP;
        if (raw == class_1713.field_7794) return QUICK_MOVE;
        if (raw == class_1713.field_7791) return SWAP;
        if (raw == class_1713.field_7795) return THROW;
        if (raw == class_1713.field_7796) return CLONE;
        if (raw == class_1713.field_7789) return QUICK_CRAFT;
        if (raw == class_1713.field_7793) return PICKUP_ALL;
        return new CompatSlotActionType(raw);
    }

    public boolean isSwapOrPickupOrQuickMoveOrThrow() {
        return raw == class_1713.field_7791 || raw == class_1713.field_7790 || raw == class_1713.field_7794 || raw == class_1713.field_7795;
    }

    public class_1713 getRaw() {
        return raw;
    }
    
    public int getIndex() {
        return raw.method_68805();
    }

    public String getName() {
        return raw.name();
    }

    public boolean isOf(CompatSlotActionType type) {
        return raw == type.raw;
    }
}
