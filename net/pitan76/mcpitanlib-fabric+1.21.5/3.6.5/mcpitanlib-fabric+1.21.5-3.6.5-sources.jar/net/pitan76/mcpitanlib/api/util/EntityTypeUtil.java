package net.pitan76.mcpitanlib.api.util;

import net.minecraft.class_1299;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_7923;

public class EntityTypeUtil {
    public static class_2960 toID(class_1299<?> entityType) {
        return class_7923.field_41177.method_10221(entityType);
    }

    public static class_1299<?> fromId(class_2960 identifier) {
        return class_7923.field_41177.method_63535(identifier);
    }

    public static boolean isExist(class_2960 identifier) {
        return class_7923.field_41177.method_10250(identifier);
    }

    public static CompatIdentifier toCompatID(class_1299<?> entityType) {
        return CompatIdentifier.fromMinecraft(toID(entityType));
    }

    public static class_1299<?> fromId(CompatIdentifier identifier) {
        return fromId(identifier.toMinecraft());
    }

    public static boolean isExist(CompatIdentifier identifier) {
        return isExist(identifier.toMinecraft());
    }

    public static int getRawId(class_1299<?> type) {
        return class_7923.field_41177.method_10206(type);
    }

    public static class_1299<?> fromIndex(int index) {
        return class_7923.field_41177.method_10200(index);
    }

    public static class_2561 getName(class_1299<?> entityType) {
        return entityType.method_5897();
    }

    public static String getTranslationKey(class_1299<?> entityType) {
        return entityType.method_5882();
    }
}
