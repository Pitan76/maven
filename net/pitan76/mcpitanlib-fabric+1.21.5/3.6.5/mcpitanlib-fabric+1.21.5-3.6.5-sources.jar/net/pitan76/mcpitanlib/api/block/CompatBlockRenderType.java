package net.pitan76.mcpitanlib.api.block;

import net.minecraft.class_2464;

public class CompatBlockRenderType {

    public static final CompatBlockRenderType MODEL = of(class_2464.field_11458);
    public static final CompatBlockRenderType ENTITYBLOCK_ANIMATED = of(class_2464.field_11458);
    public static final CompatBlockRenderType INVISIBLE = of(class_2464.field_11455);

    @Deprecated
    public final class_2464 renderType;

    public CompatBlockRenderType(class_2464 renderType) {
        this.renderType = renderType;
    }

    public static CompatBlockRenderType of(class_2464 renderType) {
        return new CompatBlockRenderType(renderType);
    }

    public class_2464 toMinecraft() {
        return renderType;
    }
}
