package net.pitan76.mcpitanlib.api.util.client.widget;

import net.minecraft.class_2561;
import net.minecraft.class_327;
import net.minecraft.class_342;
import net.pitan76.mcpitanlib.api.client.render.handledscreen.RenderArgs;
import net.pitan76.mcpitanlib.api.util.TextUtil;

public class TextFieldUtil {
    public static void setFocused(class_342 widget, boolean focused) {
        widget.method_25365(focused);
    }

    public static void render(class_342 widget, RenderArgs args) {
        widget.method_25394(args.drawObjectDM.getContext(), args.mouseX, args.mouseY, args.delta);
    }

    public static void setEditable(class_342 widget, boolean editable) {
        widget.method_1888(editable);
    }

    public static void setMaxLength(class_342 widget, int maxLength) {
        widget.method_1880(maxLength);
    }

    public static void setSuggestion(class_342 widget, String suggestion) {
        widget.method_1887(suggestion);
    }

    public static void setText(class_342 widget, String text) {
        widget.method_1852(text);
    }

    public static String getText(class_342 widget) {
        return widget.method_1882();
    }

    public static void setDrawsBackground(class_342 widget, boolean drawsBackground) {
        widget.method_1858(drawsBackground);
    }

    public static void setFocusUnlocked(class_342 widget, boolean focusUnlocked) {
        widget.method_1856(focusUnlocked);
    }

    public static boolean isFocused(class_342 widget) {
        return widget.method_25370();
    }

    public static boolean keyPressed(class_342 widget, int keyCode, int scanCode, int modifiers) {
        return widget.method_25404(keyCode, scanCode, modifiers);
    }

    public static boolean keyReleased(class_342 widget, int keyCode, int scanCode, int modifiers) {
        return widget.method_16803(keyCode, scanCode, modifiers);
    }

    public static boolean charTyped(class_342 widget, char chr, int modifiers) {
        return widget.method_25400(chr, modifiers);
    }

    public static class_342 create(class_327 renderer, int x, int y, int width, int height, class_2561 text) {
        return new class_342(renderer, x, y, width, height, text);
    }

    public static class_342 create(class_327 renderer, int width, int height, class_2561 text) {
        return new class_342(renderer, width, height, text);
    }

    public static class_342 create(class_327 renderer, int x, int y, int width, int height) {
        return new class_342(renderer, x, y, width, height, TextUtil.empty());
    }

    public static class_342 create(class_327 renderer, int width, int height) {
        return new class_342(renderer, width, height, TextUtil.empty());
    }
}
