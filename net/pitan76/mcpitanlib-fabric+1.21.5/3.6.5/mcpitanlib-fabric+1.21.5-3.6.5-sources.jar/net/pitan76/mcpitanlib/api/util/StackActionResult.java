package net.pitan76.mcpitanlib.api.util;

import net.minecraft.class_1269;
import net.minecraft.class_1799;
import net.pitan76.mcpitanlib.api.event.result.EventResult;

import java.util.Optional;

public class StackActionResult extends CompatActionResult {
    private final class_1799 stack;
    private final CompatActionResult compatActionResult;

    public StackActionResult(class_1269 actionResult, EventResult eventResult, class_1799 stack) {
        this(new CompatActionResult(actionResult, eventResult), stack);
    }

    public StackActionResult(CompatActionResult actionResult, class_1799 stack) {
        super(null, null);
        compatActionResult = actionResult;
        this.stack = stack;
    }

    @Override
    public class_1269 toActionResult() {
        return compatActionResult.toActionResult();
    }

    @Override
    public EventResult toEventResult() {
        return compatActionResult.toEventResult();
    }

    @Deprecated
    @Override
    public Optional<class_1799> getNewHandStack() {
        if (hasNewStack())
            return compatActionResult.getNewHandStack();

        return Optional.empty();
    }

    public boolean hasNewStack() {
        return compatActionResult.getNewHandStack().isPresent();
    }

    public boolean hasStack() {
        return getStack() != null;
    }

    public CompatActionResult asCompatActionResult() {
        return compatActionResult;
    }

    public static StackActionResult create(CompatActionResult compatActionResult, class_1799 stack) {
        if (compatActionResult.getNewHandStack().isPresent())
            return new StackActionResult(compatActionResult, compatActionResult.getNewHandStack().get());

        return new StackActionResult(compatActionResult, stack);
    }

    public static StackActionResult create(CompatActionResult compatActionResult) {
        return new StackActionResult(compatActionResult, null);
    }

    public static StackActionResult create(class_1269 actionResult, EventResult eventResult, class_1799 stack) {
        return new StackActionResult(actionResult, eventResult, stack);
    }

    public static StackActionResult create(class_1269 actionResult, class_1799 stack) {
        return new StackActionResult(actionResult, null, stack);
    }

    public static StackActionResult success(class_1799 stack) {
        CompatActionResult compatActionResult = CompatActionResult.create(class_1269.field_5812.method_61393(stack));
        return create(compatActionResult, stack);
    }

    public static StackActionResult successServer(class_1799 stack) {
        CompatActionResult compatActionResult = CompatActionResult.create(class_1269.field_52422.method_61393(stack));
        return create(compatActionResult, stack);
    }

    public static StackActionResult consume(class_1799 stack) {
        CompatActionResult compatActionResult = CompatActionResult.create(class_1269.field_21466.method_61393(stack));
        return create(compatActionResult, stack);
    }

    public static StackActionResult pass(class_1799 stack) {
        return create(CompatActionResult.PASS, stack);
    }

    public static StackActionResult pass() {
        return create(CompatActionResult.PASS);
    }

    public static StackActionResult fail(class_1799 stack) {
        return create(CompatActionResult.FAIL, stack);
    }

    public static StackActionResult fail() {
        return create(CompatActionResult.FAIL);
    }

    public class_1799 getStack() {
        return stack;
    }
}
