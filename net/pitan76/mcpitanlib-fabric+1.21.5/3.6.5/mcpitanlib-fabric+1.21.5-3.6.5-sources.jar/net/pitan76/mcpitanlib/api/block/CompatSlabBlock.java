package net.pitan76.mcpitanlib.api.block;

import com.mojang.serialization.MapCodec;
import net.minecraft.class_10;
import net.minecraft.class_1750;
import net.minecraft.class_2248;
import net.minecraft.class_2482;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2771;
import net.pitan76.mcpitanlib.api.block.v2.CompatBlockProvider;
import net.pitan76.mcpitanlib.api.block.v2.CompatibleBlockSettings;
import net.pitan76.mcpitanlib.api.event.block.AppendPropertiesArgs;
import net.pitan76.mcpitanlib.api.event.block.CanPathfindThroughArgs;
import net.pitan76.mcpitanlib.api.event.block.PlacementStateArgs;
import net.pitan76.mcpitanlib.api.state.property.BooleanProperty;
import net.pitan76.mcpitanlib.api.state.property.CompatProperties;
import net.pitan76.mcpitanlib.api.state.property.EnumProperty;
import net.pitan76.mcpitanlib.core.serialization.CompatMapCodec;

public class CompatSlabBlock extends class_2482 implements CompatBlockProvider {

    public static final EnumProperty<class_2771> TYPE = CompatProperties.of(class_2482.field_11501);
    public static final BooleanProperty WATERLOGGED = CompatProperties.of(class_2482.field_11502);

    public CompatibleBlockSettings settings;

    @Override
    public CompatibleBlockSettings getCompatSettings() {
        return settings;
    }

    public CompatSlabBlock(class_2251 settings) {
        super(settings);
    }

    public CompatSlabBlock(CompatibleBlockSettings settings) {
        this(settings.build());
    }

    public void appendProperties(AppendPropertiesArgs args) {
        super.method_9515(args.builder);
    }

    public class_2680 getPlacementState(PlacementStateArgs args) {
        return super.method_9605(args.ctx);
    }

    @Deprecated
    @Override
    public void method_9515(class_2689.class_2690<class_2248, class_2680> builder) {
        appendProperties(new AppendPropertiesArgs(builder));
    }

    @Deprecated
    @Override
    public class_2680 method_9605(class_1750 ctx) {
        return getPlacementState(new PlacementStateArgs(ctx));
    }

    // ExtendBlockProvider
    @Deprecated
    @Override
    public void appendProperties(AppendPropertiesArgs args, Options options) {
        CompatBlockProvider.super.appendProperties(args, options);
    }

    @Deprecated
    @Override
    public class_2680 getPlacementState(PlacementStateArgs args, Options options) {
        return CompatBlockProvider.super.getPlacementState(args, options);
    }

    @Deprecated
    @Override
    public MapCodec<? extends class_2482> method_53969() {
        return getCompatCodec().getCodec();
    }

    public CompatMapCodec<? extends class_2482> getCompatCodec() {
        return CompatMapCodec.of(super.method_53969());
    }

    @Deprecated
    @Override
    public boolean method_9516(class_2680 state, class_10 type) {
        return canPathfindThrough(new CanPathfindThroughArgs(state, type));
    }

    public boolean canPathfindThrough(CanPathfindThroughArgs args) {
        return super.method_9516(args.state, args.type);
    }

    @Override
    public Boolean canPathfindThrough(CanPathfindThroughArgs args, Options options) {
        return CompatBlockProvider.super.canPathfindThrough(args, options);
    }
}
