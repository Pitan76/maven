package net.pitan76.mcpitanlib.api.util;

import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1838;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_3965;
import net.pitan76.mcpitanlib.api.entity.Player;
import net.pitan76.mcpitanlib.api.event.item.ItemUseEvent;
import net.pitan76.mcpitanlib.api.event.item.ItemUseOnBlockEvent;
import net.pitan76.mcpitanlib.api.event.item.ItemUseOnEntityEvent;
import net.pitan76.mcpitanlib.api.item.args.UseActionArgs;
import net.pitan76.mcpitanlib.api.item.consume.CompatUseAction;

public class InteractUtil {

    public static StackActionResult useItem(class_1792 item, ItemUseEvent event) {
        CompatActionResult result = CompatActionResult.create(item.method_7836(event.getWorld(), event.user.getEntity(), event.getHand()));
        return StackActionResult.create(result, event.getStack());
    }

    public static CompatActionResult useItemOnBlock(class_1792 item, class_1838 context) {
        return CompatActionResult.create(item.method_7884(context));
    }

    public static CompatActionResult useItemOnBlock(class_1792 item, ItemUseOnBlockEvent event) {
        return useItemOnBlock(item, event.toIUC());
    }

    public static CompatActionResult useItemOnEntity(class_1792 item, ItemUseOnEntityEvent event) {
        return CompatActionResult.create(item.method_7847(event.getStack(), event.getUser().getEntity(), event.getEntity(), event.getHand()));
    }

    public static CompatUseAction getUseAction(class_1792 item, UseActionArgs args) {
        return CompatUseAction.of(item.method_7853(args.stack));
    }

    public static CompatUseAction getUseAction(class_1792 item, class_1799 stack) {
        return CompatUseAction.of(item.method_7853(stack));
    }

    public static CompatActionResult useBlock(class_2680 state, class_1937 world, Player player, class_3965 hitResult) {
        return BlockStateUtil.onUse(state, world, player, hitResult);
    }

    public static CompatActionResult useBlock(class_2680 state, class_1937 world, Player player, class_2350 dir, class_2338 blockPos) {
        return BlockStateUtil.onUse(state, world, player, dir, blockPos);
    }

    public static boolean onStoppingUsing(class_1792 item, class_1799 stack, class_1937 world, Player player, int remainingUseTicks) {
        return item.method_7840(stack, world, player.getEntity(), remainingUseTicks);
    }
}
