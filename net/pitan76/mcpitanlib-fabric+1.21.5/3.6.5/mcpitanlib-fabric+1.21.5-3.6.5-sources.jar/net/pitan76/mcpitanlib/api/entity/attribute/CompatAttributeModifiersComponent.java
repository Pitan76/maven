package net.pitan76.mcpitanlib.api.entity.attribute;

import net.minecraft.class_9285;

public class CompatAttributeModifiersComponent {
    private final class_9285 raw;

    @Deprecated
    public CompatAttributeModifiersComponent(class_9285 component) {
        this.raw = component;
    }

    @Deprecated
    public class_9285 raw() {
        return raw;
    }

    public static CompatAttributeModifiersComponent of(class_9285 component) {
        return new CompatAttributeModifiersComponent(component);
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        CompatAttributeModifiersComponent that = (CompatAttributeModifiersComponent) obj;
        return raw.equals(that.raw);
    }

    @Override
    public int hashCode() {
        return raw.hashCode();
    }
}
