package net.pitan76.mcpitanlib.api.client.event.fabric;

import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.class_4184;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_4604;
import net.minecraft.class_638;
import net.minecraft.class_757;
import net.minecraft.class_761;
import net.minecraft.class_765;
import net.minecraft.client.render.*;
import net.pitan76.mcpitanlib.api.client.event.listener.BeforeBlockOutlineEvent;
import net.pitan76.mcpitanlib.api.client.event.listener.BeforeBlockOutlineListener;
import net.pitan76.mcpitanlib.api.client.event.listener.WorldRenderContext;
import net.pitan76.mcpitanlib.api.client.event.listener.WorldRenderContextListener;
import org.jetbrains.annotations.Nullable;
import org.joml.Matrix4f;

public class WorldRenderRegistryImpl {
    public static void registerWorldRenderBeforeBlockOutline(BeforeBlockOutlineListener listener) {
        WorldRenderEvents.BEFORE_BLOCK_OUTLINE.register(((worldRenderContext, hitResult) -> listener.beforeBlockOutline(new BeforeBlockOutlineEvent(
        new WorldRenderContext() {
            @Override
            public class_761 getWorldRenderer() {
                return worldRenderContext.worldRenderer();
            }

            @Override
            public class_4587 getMatrixStack() {
                return worldRenderContext.matrixStack();
            }

            @Override
            public float getTickDelta() {
                return worldRenderContext.tickCounter().method_60636();
            }

            @Override
            public class_4184 getCamera() {
                return worldRenderContext.camera();
            }

            @Override
            public class_757 getGameRenderer() {
                return worldRenderContext.gameRenderer();
            }

            @Override
            public class_765 getLightmapTextureManager() {
                return getGameRenderer().method_22974();
            }

            @Override
            public Matrix4f getProjectionMatrix() {
                return worldRenderContext.projectionMatrix();
            }

            @Override
            public class_638 getWorld() {
                return worldRenderContext.world();
            }

            @Override
            public boolean isAdvancedTranslucency() {
                return worldRenderContext.advancedTranslucency();
            }

            @Override
            public @Nullable class_4597 getConsumers() {
                return worldRenderContext.consumers();
            }

            @Override
            public @Nullable class_4604 getFrustum() {
                return worldRenderContext.frustum();
            }
        }, hitResult))));
    }

    public static void registerWorldRenderAfterLevel(WorldRenderContextListener listener) {
        WorldRenderEvents.END.register((context -> {
            listener.render(new WorldRenderContext() {
                @Override
                public class_761 getWorldRenderer() {
                    return context.worldRenderer();
                }

                @Override
                public class_4587 getMatrixStack() {
                    return context.matrixStack();
                }

                @Override
                public float getTickDelta() {
                    return context.tickCounter().method_60636();
                }

                @Override
                public class_4184 getCamera() {
                    return context.camera();
                }

                @Override
                public class_757 getGameRenderer() {
                    return context.gameRenderer();
                }

                @Override
                public class_765 getLightmapTextureManager() {
                    return getGameRenderer().method_22974();
                }

                @Override
                public Matrix4f getProjectionMatrix() {
                    return context.projectionMatrix();
                }

                @Override
                public class_638 getWorld() {
                    return context.world();
                }

                @Override
                public boolean isAdvancedTranslucency() {
                    return context.advancedTranslucency();
                }

                @Override
                public @Nullable class_4597 getConsumers() {
                    return context.consumers();
                }

                @Override
                public @Nullable class_4604 getFrustum() {
                    return context.frustum();
                }
            });
        }));
    }
}
