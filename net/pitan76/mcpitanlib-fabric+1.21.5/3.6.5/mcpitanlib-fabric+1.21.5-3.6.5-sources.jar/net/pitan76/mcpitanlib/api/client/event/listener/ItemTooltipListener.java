package net.pitan76.mcpitanlib.api.client.event.listener;

import java.util.List;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_2561;

@FunctionalInterface
public interface ItemTooltipListener {
    void onTooltip(ItemTooltipContext context);

    default void onTooltip(class_1799 stack, List<class_2561> texts, class_1792.class_9635 tooltipContext, class_1836 type) {
        onTooltip(new ItemTooltipContext(stack, texts, tooltipContext, type));
    }
}