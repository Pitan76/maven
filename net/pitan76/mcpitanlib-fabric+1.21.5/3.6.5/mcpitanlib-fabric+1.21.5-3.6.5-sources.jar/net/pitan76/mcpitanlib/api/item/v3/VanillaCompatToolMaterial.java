package net.pitan76.mcpitanlib.api.item.v3;

import net.minecraft.class_2248;
import net.minecraft.class_6862;
import net.minecraft.class_9886;
import net.pitan76.mcpitanlib.api.tag.item.RepairIngredientTag;

public class VanillaCompatToolMaterial implements CompatToolMaterial {
    private final class_9886 material;

    public static final VanillaCompatToolMaterial WOOD = of(class_9886.field_52585);
    public static final VanillaCompatToolMaterial STONE = of(class_9886.field_52586);
    public static final VanillaCompatToolMaterial IRON = of(class_9886.field_52587);
    public static final VanillaCompatToolMaterial GOLD = of(class_9886.field_52589);
    public static final VanillaCompatToolMaterial DIAMOND = of(class_9886.field_52588);
    public static final VanillaCompatToolMaterial NETHERITE = of(class_9886.field_52590);

    protected VanillaCompatToolMaterial(class_9886 material) {
        this.material = material;
    }

    private static VanillaCompatToolMaterial of(class_9886 material) {
        return new VanillaCompatToolMaterial(material);
    }

    @Override
    public RepairIngredientTag getRepairIngredientTag() {
        return new RepairIngredientTag(material.comp_2935());
    }

    @Override
    public int getCompatDurability() {
        return material.comp_2931();
    }

    @Override
    public float getCompatMiningSpeedMultiplier() {
        return material.comp_2932();
    }

    @Override
    public float getCompatAttackDamage() {
        return material.comp_2933();
    }

    @Override
    public int getCompatMiningLevel() {
        class_6862<class_2248> tag = material.comp_2930();
        if (tag == class_9886.field_52585.comp_2930()) return 0;
        if (tag == class_9886.field_52586.comp_2930()) return 1;
        if (tag == class_9886.field_52587.comp_2930()) return 2;
        if (tag == class_9886.field_52589.comp_2930()) return 2;
        if (tag == class_9886.field_52588.comp_2930()) return 3;
        if (tag == class_9886.field_52590.comp_2930()) return 4;
        return -1;
    }

    @Override
    public int getCompatEnchantability() {
        return material.comp_2934();
    }

    @Deprecated
    public class_9886 toMinecraft() {
        return material;
    }

    @Override
    public class_9886 build() {
        return material;
    }
}
