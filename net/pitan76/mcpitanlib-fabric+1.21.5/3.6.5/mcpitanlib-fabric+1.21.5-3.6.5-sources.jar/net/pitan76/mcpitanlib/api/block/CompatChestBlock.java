package net.pitan76.mcpitanlib.api.block;

import net.minecraft.class_2281;
import net.minecraft.class_2338;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_2595;
import net.minecraft.class_2680;
import net.pitan76.mcpitanlib.api.block.v2.CompatBlockProvider;
import net.pitan76.mcpitanlib.api.block.v2.CompatibleBlockSettings;
import net.pitan76.mcpitanlib.api.event.block.TileCreateEvent;

import java.util.function.Supplier;

public class CompatChestBlock extends class_2281 implements CompatBlockProvider {
    public CompatChestBlock(class_2251 settings, Supplier<class_2591<? extends class_2595>> supplier) {
        super(supplier, settings);
    }

    public CompatibleBlockSettings compatSettings;

    public CompatChestBlock(CompatibleBlockSettings settings, Supplier<class_2591<? extends class_2595>> supplier) {
        this(settings.build(), supplier);
    }

    /**
     * @deprecated Use {@link #createBlockEntity(TileCreateEvent)} instead.
     */
    @Deprecated
    @Override
    public class_2586 method_10123(class_2338 pos, class_2680 state) {
        return createBlockEntity(new TileCreateEvent(pos, state));
    }

    /**
     * @see ExtendBlockEntityProvider#createBlockEntity(TileCreateEvent)
     */
    public class_2586 createBlockEntity(TileCreateEvent event) {
        return super.method_10123(event.getBlockPos(), event.getBlockState());
    }

    @Override
    public CompatibleBlockSettings getCompatSettings() {
        return compatSettings;
    }
}
