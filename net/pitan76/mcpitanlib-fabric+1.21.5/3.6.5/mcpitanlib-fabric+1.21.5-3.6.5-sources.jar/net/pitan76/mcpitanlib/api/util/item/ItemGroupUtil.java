package net.pitan76.mcpitanlib.api.util.item;

import net.minecraft.class_1761;
import net.minecraft.class_2960;
import net.minecraft.class_7923;
import net.pitan76.mcpitanlib.api.util.CompatIdentifier;

public class ItemGroupUtil {
    public static class_2960 toID(class_1761 itemGroup) {
        return class_7923.field_44687.method_10221(itemGroup);
    }

    public static class_1761 fromId(class_2960 identifier) {
        return class_7923.field_44687.method_63535(identifier);
    }

    public static boolean isExist(class_2960 identifier) {
        return class_7923.field_44687.method_10250(identifier);
    }

    public static CompatIdentifier toCompatID(class_1761 itemGroup) {
        return CompatIdentifier.fromMinecraft(toID(itemGroup));
    }

    public static class_1761 fromId(CompatIdentifier identifier) {
        return fromId(identifier.toMinecraft());
    }

    public static boolean isExist(CompatIdentifier identifier) {
        return isExist(identifier.toMinecraft());
    }

    public static int getRawId(class_1761 itemGroup) {
        return class_7923.field_44687.method_10206(itemGroup);
    }

    public static class_1761 fromIndex(int index) {
        return class_7923.field_44687.method_10200(index);
    }
}
