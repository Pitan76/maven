package net.pitan76.mcpitanlib.api.item.v2;

import net.minecraft.class_10712;
import net.minecraft.class_1269;
import net.minecraft.class_1747;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_1838;
import net.minecraft.class_2248;
import net.minecraft.class_2561;
import net.pitan76.mcpitanlib.api.event.item.ItemAppendTooltipEvent;
import net.pitan76.mcpitanlib.api.event.item.ItemUseOnBlockEvent;
import net.pitan76.mcpitanlib.api.util.CompatActionResult;
import net.pitan76.mcpitanlib.mixin.ItemUsageContextMixin;

import java.util.List;
import java.util.function.Consumer;

public class ExtendBlockItem extends class_1747 implements CompatItemProvider {

    public CompatibleItemSettings settings;

    @Deprecated
    public ExtendBlockItem(class_2248 block, class_1793 settings) {
        super(block, settings);
    }

    public ExtendBlockItem(class_2248 block, CompatibleItemSettings settings) {
        this(block, settings.build());
        this.settings = settings;
    }

    @Override
    public CompatibleItemSettings getCompatSettings() {
        return settings;
    }

    @Deprecated
    @Override
    public class_1269 method_7884(class_1838 context) {
        ItemUsageContextMixin contextAccessor = (ItemUsageContextMixin) context;
        return onRightClickOnBlock(new ItemUseOnBlockEvent(context.method_8036(), context.method_20287(), contextAccessor.getHit())).toActionResult();
    }

    @Deprecated
    @Override
    public CompatActionResult onRightClickOnBlock(ItemUseOnBlockEvent event, Options options) {
        return CompatItemProvider.super.onRightClickOnBlock(event, options);
    }

    public CompatActionResult onRightClickOnBlock(ItemUseOnBlockEvent event) {
        return CompatActionResult.create(super.method_7884(event.toIUC()));
    }

    @Deprecated
    @Override
    public void method_67187(class_1799 stack, class_9635 context, class_10712 displayComponent, Consumer<class_2561> textConsumer, class_1836 type) {
        appendTooltip(new ItemAppendTooltipEvent(stack, context, displayComponent, textConsumer, type));
    }

    @Deprecated
    @Override
    public void appendTooltip(ItemAppendTooltipEvent event, Options options) {
        CompatItemProvider.super.appendTooltip(event, options);
    }

    public void appendTooltip(ItemAppendTooltipEvent event) {
        super.method_67187(event.getStack(), event.getContext(), event.displayComponent, event.textConsumer, event.type);
    }

    @Override
    public class_2248 method_7711() {
        return super.method_7711();
    }
}
