package net.pitan76.mcpitanlib.api.nbt;

import java.io.DataOutput;
import java.io.IOException;
import net.minecraft.class_1799;
import net.minecraft.class_2487;
import net.minecraft.class_2520;
import net.minecraft.class_4614;
import net.minecraft.class_5627;
import net.minecraft.class_6836;
import net.minecraft.class_9279;
import net.minecraft.class_9334;

@Deprecated
public class NbtTag {
    public class_2487 nbt;

    public NbtTag() {
        super();
    }

    /**
     * Create NbtTag instance
     * @return NbtTag instance
     */
    public static NbtTag create() {
        return new NbtTag();
    }

    /**
     * Cast to NbtTag
     * @param nbt Nbt Object
     * @return NbtTag
     */
    public static NbtTag from(Object nbt) {
        if (nbt instanceof class_2487) {
            return (NbtTag) nbt;
        }
        return (NbtTag) nbt;
    }

    /**
     * Check item stack nbt
     * @param stack Item stack
     * @return boolean
     */
    public static boolean hasNbt(class_1799 stack) {
        return !stack.method_57353().method_57837();
    }

    /**
     * Get nbt from item stack
     * @param stack Item stack
     * @return NbtTag
     */
    public static NbtTag getNbt(class_1799 stack) {
        return from(stack.method_58694(class_9334.field_49628).method_57461());
    }

    /**
     * Set nbt to item stack
     * @param stack Item stack
     * @param nbt NbtTag
     */
    public static void setNbt(class_1799 stack, NbtTag nbt) {
        stack.method_57379(class_9334.field_49628, class_9279.method_57456(nbt.nbt));
    }

    public boolean contains(String key) {
        return nbt.method_10545(key);
    }

    public void write(DataOutput output) throws IOException {
        nbt.method_10713(output);
    }

    public byte getType() {
        return nbt.method_10711();
    }

    public class_4614<class_2487> getNbtType() {
        return nbt.method_23258();
    }

    public class_2520 copy() {
        return nbt.method_10553();
    }

    public int getSizeInBytes() {
        return nbt.method_47988();
    }

    public void accept(class_5627 visitor) {
        nbt.method_32289(visitor);
    }

    public class_6836.class_6838 doAccept(class_6836 visitor) {
        return nbt.method_39850(visitor);
    }
}