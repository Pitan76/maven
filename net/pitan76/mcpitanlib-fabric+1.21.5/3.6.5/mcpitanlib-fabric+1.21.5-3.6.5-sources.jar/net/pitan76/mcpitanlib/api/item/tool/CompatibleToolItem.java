package net.pitan76.mcpitanlib.api.item.tool;

import net.minecraft.class_1309;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.pitan76.mcpitanlib.api.event.item.PostHitEvent;
import net.pitan76.mcpitanlib.api.event.item.PostMineEvent;
import net.pitan76.mcpitanlib.api.item.v2.CompatibleItemSettings;
import net.pitan76.mcpitanlib.api.item.v2.CompatItemProvider;

public class CompatibleToolItem extends class_1792 implements CompatItemProvider {

    public CompatibleToolMaterial material;

    public CompatibleItemSettings settings;

    @Deprecated
    protected CompatibleToolItem(class_1793 settings) {
        super(settings);
    }

    public CompatibleToolItem(CompatibleToolMaterial material, CompatibleItemSettings settings) {
        this(settings.build().method_66331(material.build(), null, 0, 0, 0));
        this.material = material;
        this.settings = settings;
    }

    @Override
    public CompatibleItemSettings getCompatSettings() {
        return settings;
    }

    public boolean overrideIsSuitableFor(class_2680 state) {
        return super.method_58405(method_7854(), state);
    }

    @Deprecated
    @Override
    public boolean method_58405(class_1799 stack, class_2680 state) {
        return overrideIsSuitableFor(state);
    }

    public float overrideGetMiningSpeedMultiplier(class_1799 stack, class_2680 state) {
        return 1.0F;
    }

    @Deprecated
    @Override
    public float method_58404(class_1799 stack, class_2680 state) {
        return overrideGetMiningSpeedMultiplier(stack, state) * material.getCompatMiningSpeedMultiplier();
    }

    @Deprecated
    @Override
    public void method_7873(class_1799 stack, class_1309 target, class_1309 attacker) {
        postHit(new PostHitEvent(stack, target, attacker));
    }

    @Deprecated
    @Override
    public boolean method_7879(class_1799 stack, class_1937 world, class_2680 state, class_2338 pos, class_1309 miner) {
        return postMine(new PostMineEvent(stack, world, state, pos, miner));
    }

    /**
     * post hit event
     * @param event PostHitEvent
     * @return boolean
     */
    public boolean postHit(PostHitEvent event) {
        super.method_7873(event.stack, event.target, event.attacker);
        return true;
    }

    /**
     * post mine event
     * @param event PostMineEvent
     * @return boolean
     */
    public boolean postMine(PostMineEvent event) {
        return super.method_7879(event.stack, event.world, event.state, event.pos, event.miner);
    }
}
