package net.pitan76.mcpitanlib.api.item;

import net.minecraft.class_10712;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1282;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1814;
import net.minecraft.class_1836;
import net.minecraft.class_1838;
import net.minecraft.class_1839;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.pitan76.mcpitanlib.api.event.item.*;
import net.pitan76.mcpitanlib.api.util.CompatActionResult;
import net.pitan76.mcpitanlib.api.util.StackActionResult;
import net.pitan76.mcpitanlib.core.Dummy;
import net.pitan76.mcpitanlib.mixin.ItemUsageContextMixin;

import java.util.List;
import java.util.function.Consumer;

public class ExtendItem extends class_1792 {

    public ExtendItem(class_1793 settings) {
        super(settings);
    }

    public ExtendItem(CompatibleItemSettings settings) {
        super(settings.build());
    }

    @Deprecated
    @Override
    public class_1269 method_7836(class_1937 world, class_1657 user, class_1268 hand) {
        return onRightClick(new ItemUseEvent(world, user, hand)).toActionResult();
    }

    @Deprecated
    @Override
    public class_1269 method_7884(class_1838 context) {
        ItemUsageContextMixin contextAccessor = (ItemUsageContextMixin) context;
        return onRightClickOnBlock(new ItemUseOnBlockEvent(context.method_8036(), context.method_20287(), contextAccessor.getHit())).toActionResult();
    }

    @Deprecated
    @Override
    public class_1799 method_7861(class_1799 stack, class_1937 world, class_1309 user) {
        return onFinishUsing(new ItemFinishUsingEvent(stack, world, user));
    }

    @Deprecated
    @Override
    public class_1269 method_7847(class_1799 stack, class_1657 user, class_1309 entity, class_1268 hand) {
        return onRightClickOnEntity(new ItemUseOnEntityEvent(stack, user, entity, hand)).toActionResult();
    }

    @Override
    public class_1839 method_7853(class_1799 stack) {
        return super.method_7853(stack);
    }

    @Deprecated
    //@Override
    public boolean hasRecipeRemainder() {
        return hasRecipeRemainder(new Dummy());
    }

    @Deprecated
    @Override
    public void method_67187(class_1799 stack, class_9635 context, class_10712 displayComponent, Consumer<class_2561> textConsumer, class_1836 type) {
        appendTooltip(new ItemAppendTooltipEvent(stack, context, displayComponent, textConsumer, type));
    }

    @Deprecated
    @Override
    public void method_7843(class_1799 stack, class_1937 world) {
        onCraft(new CraftEvent(stack, world));
    }

    @Deprecated
    @Override
    public void method_7873(class_1799 stack, class_1309 target, class_1309 attacker) {
        postHit(new PostHitEvent(stack, target, attacker));
    }

    @Deprecated
    @Override
    public boolean method_7879(class_1799 stack, class_1937 world, class_2680 state, class_2338 pos, class_1309 miner) {
        return postMine(new PostMineEvent(stack, world, state, pos, miner));
    }

    /**
     * item right click event
     *
     * @param event ItemUseEvent
     * @return ActionResultType
     */
    public StackActionResult onRightClick(ItemUseEvent event) {
        return StackActionResult.create(CompatActionResult.create(super.method_7836(event.world, event.user.getPlayerEntity(), event.hand)), event.stack);
    }

    /**
     * item right click event on block
     * @param event ItemUseOnBlockEvent
     * @return ActionResultType
     */
    public CompatActionResult onRightClickOnBlock(ItemUseOnBlockEvent event) {
        return CompatActionResult.create(super.method_7884(event.toIUC()));
    }

    /**
     * item finish using event
     * @param event ItemFinishUsingEvent
     * @return ItemStack
     */
    public class_1799 onFinishUsing(ItemFinishUsingEvent event) {
        return super.method_7861(event.stack, event.world, event.user);
    }

    /**
     * item right click event on entity
     * @param event ItemUseOnEntityEvent
     * @return ActionResultType
     */
    public CompatActionResult onRightClickOnEntity(ItemUseOnEntityEvent event) {
        return CompatActionResult.create(super.method_7847(event.stack, event.user.getEntity(), event.entity, event.hand));
    }

    /**
     * check if item has recipe remainder
     * @param dummy Dummy
     * @return boolean
     */
    public boolean hasRecipeRemainder(Dummy dummy) {
        return false;
    }

    /**
     * append tooltip to item
     * @param event ItemAppendTooltipEvent
     */
    public void appendTooltip(ItemAppendTooltipEvent event) {
        super.method_67187(event.stack, event.context, event.displayComponent, event.textConsumer, event.type);
    }

    /**
     * on craft event
     * @param event CraftEvent
     */
    public void onCraft(CraftEvent event) {
        super.method_7843(event.stack, event.world);
    }

    /**
     * post hit event
     * @param event PostHitEvent
     * @return boolean
     */
    public boolean postHit(PostHitEvent event) {
        super.method_7873(event.stack, event.target, event.attacker);
        return true;
    }

    /**
     * post mine event
     * @param event PostMineEvent
     * @return boolean
     */
    public boolean postMine(PostMineEvent event) {
        return super.method_7879(event.stack, event.world, event.state, event.pos, event.miner);
    }

    // -1.20.6
    public class_1814 getRarity(class_1799 stack) {
        return class_1814.field_8906;
    }

    @Deprecated
    public boolean isEnchantable(class_1799 stack) {
        return isEnchantable(new EnchantableArgs(stack));
    }

    public boolean isEnchantable(EnchantableArgs args) {
        return false;
    }

    @Deprecated
    public int getEnchantability() {
        return getEnchantability(new EnchantabilityArgs());
    }

    public int getEnchantability(EnchantabilityArgs args) {
        return 0;
    }

    @Deprecated
    @Override
    public int method_31571(class_1799 stack) {
        return getItemBarColor(new ItemBarColorArgs(stack));
    }

    public int getItemBarColor(ItemBarColorArgs args) {
        return super.method_31571(args.stack);
    }

    @Deprecated
    @Override
    public boolean method_31567(class_1799 stack) {
        return isItemBarVisible(new ItemBarVisibleArgs(stack));
    }

    public boolean isItemBarVisible(ItemBarVisibleArgs args) {
        return super.method_31567(args.stack);
    }

    @Deprecated
    @Override
    public int method_31569(class_1799 stack) {
        return getItemBarStep(new ItemBarStepArgs(stack));
    }

    public int getItemBarStep(ItemBarStepArgs args) {
        return super.method_31569(args.stack);
    }

    @Deprecated
    @Override
    public float method_58403(class_1297 target, float baseAttackDamage, class_1282 damageSource) {
        return getBonusAttackDamage(new BonusAttackDamageArgs(target, baseAttackDamage, damageSource));
    }

    public float getBonusAttackDamage(BonusAttackDamageArgs args) {
        return super.method_58403(args.target, args.baseAttackDamage, args.damageSource);
    }

    @Deprecated
    //@Override
    public boolean canRepair(class_1799 stack, class_1799 ingredient) {
        return canRepair(new CanRepairArgs(stack, ingredient));
    }

    public boolean canRepair(CanRepairArgs args) {
        return false;
    }

    @Deprecated
    @Override
    public boolean method_7885(class_1799 stack, class_2680 state, class_1937 world, class_2338 pos, class_1309 user) {
        return canMine(new CanMineArgs(stack, state, world, pos, user));
    }

    public boolean canMine(CanMineArgs args) {
        return super.method_7885(args.stack, args.state, args.world, args.pos, args.entity);
    }
}
