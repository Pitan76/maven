package net.pitan76.mcpitanlib.api.tag.item;

import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1856;
import net.minecraft.class_3489;
import net.minecraft.class_6862;
import net.minecraft.class_7924;
import net.pitan76.mcpitanlib.api.util.CompatIdentifier;
import net.pitan76.mcpitanlib.api.util.IngredientUtil;
import net.pitan76.mcpitanlib.api.util.item.ItemUtil;

public class RepairIngredientTag {

    public static final RepairIngredientTag REPAIRS_LEATHER_ARMOR = new RepairIngredientTag(class_3489.field_54059);
    public static final RepairIngredientTag REPAIRS_CHAIN_ARMOR = new RepairIngredientTag(class_3489.field_54060);
    public static final RepairIngredientTag REPAIRS_IRON_ARMOR = new RepairIngredientTag(class_3489.field_54061);
    public static final RepairIngredientTag REPAIRS_GOLD_ARMOR = new RepairIngredientTag(class_3489.field_54062);
    public static final RepairIngredientTag REPAIRS_DIAMOND_ARMOR = new RepairIngredientTag(class_3489.field_54063);
    public static final RepairIngredientTag REPAIRS_NETHERITE_ARMOR = new RepairIngredientTag(class_3489.field_54064);
    public static final RepairIngredientTag REPAIRS_TURTLE_HELMET = new RepairIngredientTag(class_3489.field_54065);
    public static final RepairIngredientTag REPAIRS_WOLF_ARMOR = new RepairIngredientTag(class_3489.field_54066);
    public static final RepairIngredientTag WOODEN_TOOL_MATERIALS = new RepairIngredientTag(class_3489.field_52381);
    public static final RepairIngredientTag STONE_TOOL_MATERIALS = new RepairIngredientTag(class_3489.field_23802);
    public static final RepairIngredientTag IRON_TOOL_MATERIALS = new RepairIngredientTag(class_3489.field_52382);
    public static final RepairIngredientTag GOLDEN_TOOL_MATERIALS = new RepairIngredientTag(class_3489.field_52385);
    public static final RepairIngredientTag DIAMOND_TOOL_MATERIALS = new RepairIngredientTag(class_3489.field_52386);
    public static final RepairIngredientTag NETHERITE_TOOL_MATERIALS = new RepairIngredientTag(class_3489.field_52387);

    private class_6862<class_1792> tag;

    public RepairIngredientTag(CompatIdentifier identifier) {
        this.tag = class_6862.method_40092(class_7924.field_41197, identifier.toMinecraft());
    }

    @Deprecated
    public RepairIngredientTag(class_6862<class_1792> tag) {
        this.tag = tag;
    }

    @Deprecated
    public class_6862<class_1792> getTag() {
        return tag;
    }

    @Deprecated
    public class_1856 getIngredient() {
        return IngredientUtil.fromTagByIdentifier(tag.comp_327());
    }

    public boolean contains(class_1792 item) {
        if (item == null || tag == null)
            return false;

        return ItemUtil.isInTag(item, CompatIdentifier.fromMinecraft(tag.comp_327()));
    }

    public boolean contains(class_1799 stack) {
        if (stack.method_7960() || tag == null)
            return false;

        return getIngredient().method_8093(stack);
    }
}
