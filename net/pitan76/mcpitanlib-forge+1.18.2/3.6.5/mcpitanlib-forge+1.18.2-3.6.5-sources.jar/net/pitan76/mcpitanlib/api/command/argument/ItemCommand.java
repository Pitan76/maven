package net.pitan76.mcpitanlib.api.command.argument;

import net.minecraft.commands.arguments.item.ItemArgument;
import net.minecraft.world.item.Item;
import net.pitan76.mcpitanlib.api.event.ItemCommandEvent;
import net.pitan76.mcpitanlib.api.event.ServerCommandEvent;

public abstract class ItemCommand extends RequiredCommand<Item> {
    @Override
    public ItemArgument getArgumentType() {
        return ItemArgument.m_120960_();
    }

    public abstract void execute(ItemCommandEvent event);

    @Override
    public void execute(ServerCommandEvent event) {
        execute((ItemCommandEvent) event);
    }
}
