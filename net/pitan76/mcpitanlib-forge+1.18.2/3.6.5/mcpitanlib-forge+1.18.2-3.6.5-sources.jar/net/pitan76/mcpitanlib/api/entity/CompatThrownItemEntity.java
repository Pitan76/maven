package net.pitan76.mcpitanlib.api.entity;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.projectile.ThrowableItemProjectile;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;
import net.pitan76.mcpitanlib.api.event.entity.CollisionEvent;
import net.pitan76.mcpitanlib.api.event.entity.EntityHitEvent;
import net.pitan76.mcpitanlib.api.event.entity.InitDataTrackerArgs;
import net.pitan76.mcpitanlib.api.event.nbt.ReadNbtArgs;
import net.pitan76.mcpitanlib.api.event.nbt.WriteNbtArgs;
import net.pitan76.mcpitanlib.midohra.entity.IEntityM;

public abstract class CompatThrownItemEntity extends ThrowableItemProjectile implements IEntityM {

    public CompatThrownItemEntity(EntityType<? extends ThrowableItemProjectile> entityType, Level world) {
        super(entityType, world);
    }

    public CompatThrownItemEntity(EntityType<? extends ThrowableItemProjectile> entityType, double d, double e, double f, Level world) {
        super(entityType, d, e, f, world);
    }

    public CompatThrownItemEntity(EntityType<? extends ThrowableItemProjectile> entityType, LivingEntity livingEntity, Level world) {
        super(entityType, livingEntity, world);
    }

    public abstract Item getDefaultItemOverride();

    @Deprecated
    @Override
    protected Item m_7881_() {
        return getDefaultItemOverride();
    }

    public ItemStack callGetItem() {
        return super.m_7846_();
    }

    @Deprecated
    @Override
    public ItemStack m_7846_() {
        return callGetItem();
    }

    public void callSetItem(ItemStack stack) {
        super.m_37446_(stack);
    }

    @Deprecated
    @Override
    public void m_37446_(ItemStack stack) {
        callSetItem(stack);
    }

    public void callHandleStatus(byte status) {
        super.m_7822_(status);
    }

    @Deprecated
    @Override
    public void m_7822_(byte status) {
        callHandleStatus(status);
    }

    public void onEntityHit(EntityHitEvent event) {
        super.m_5790_(event.entityHitResult);
    }

    @Deprecated
    @Override
    protected void m_5790_(EntityHitResult entityHitResult) {
        onEntityHit(new EntityHitEvent(entityHitResult));
    }

    public void onCollision(CollisionEvent event) {
        super.m_6532_(event.hitResult);
    }

    @Deprecated
    @Override
    protected void m_6532_(HitResult hitResult) {
        onCollision(new CollisionEvent(hitResult));
    }

    // ------------------ ExtendEntity ------------------

    @Deprecated
    @Override
    public void m_8097_() {
        initDataTracker(new InitDataTrackerArgs(f_19804_));
    }

    public void initDataTracker(InitDataTrackerArgs args) {
        super.m_8097_();
    }

    public void readCustomDataFromNbt(ReadNbtArgs nbt) {
        super.m_7378_(nbt.getNbt());
    }

    public void writeCustomDataToNbt(WriteNbtArgs nbt) {
        super.m_7380_(nbt.getNbt());
    }

    @Deprecated
    @Override
    public void m_7378_(CompoundTag nbt) {
        readCustomDataFromNbt(new ReadNbtArgs(nbt));
    }

    @Deprecated
    @Override
    public void m_7380_(CompoundTag nbt) {
        writeCustomDataToNbt(new WriteNbtArgs(nbt));
    }

    public void writeNbt(WriteNbtArgs args) {
        super.m_20240_(args.getNbt());
    }

    public void readNbt(ReadNbtArgs args) {
        super.m_20258_(args.getNbt());
    }

    @Deprecated
    @Override
    public CompoundTag m_20240_(CompoundTag nbt) {
        writeNbt(new WriteNbtArgs(nbt));
        return nbt;
    }

    @Deprecated
    @Override
    public void m_20258_(CompoundTag nbt) {
        readNbt(new ReadNbtArgs(nbt));
    }

    @Override
    public Level m_183503_() {
        return super.m_183503_();
    }

    public void setStack(net.pitan76.mcpitanlib.midohra.item.ItemStack stack) {
        callSetItem(stack.toMinecraft());
    }

    public net.pitan76.mcpitanlib.midohra.item.ItemStack getStackM() {
        return net.pitan76.mcpitanlib.midohra.item.ItemStack.of(callGetItem());
    }
}
