package net.pitan76.mcpitanlib.api.util.item;

import net.minecraft.network.chat.TranslatableComponent;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.CreativeModeTab;
import net.pitan76.mcpitanlib.api.util.CompatIdentifier;

public class ItemGroupUtil {
    public static ResourceLocation toID(CreativeModeTab itemGroup) {
        if (itemGroup.m_40786_() instanceof TranslatableComponent) {
            TranslatableComponent translatableText = (TranslatableComponent) itemGroup.m_40786_();
                String[] strings = translatableText.m_131328_().split("\\.");

                if (strings.length == 3)
                    return new ResourceLocation(strings[1], strings[2]);
        }

        return CompatIdentifier.empty().toMinecraft();
    }

    public static CreativeModeTab fromId(ResourceLocation identifier) {
        return null;
    }

    public static boolean isExist(ResourceLocation identifier) {
        return false;
    }

    public static CompatIdentifier toCompatID(CreativeModeTab itemGroup) {
        return CompatIdentifier.fromMinecraft(toID(itemGroup));
    }

    public static CreativeModeTab fromId(CompatIdentifier identifier) {
        return fromId(identifier.toMinecraft());
    }

    public static boolean isExist(CompatIdentifier identifier) {
        return isExist(identifier.toMinecraft());
    }

    public static int getRawId(CreativeModeTab itemGroup) {
        return itemGroup.m_40775_();
    }

    public static CreativeModeTab fromIndex(int index) {
        return CreativeModeTab.f_40748_[index];
    }
}
