package net.pitan76.mcpitanlib.api.block;

import net.minecraft.block.*;
import net.minecraft.world.item.DyeColor;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.material.Material;
import net.minecraft.world.level.material.MaterialColor;
import net.pitan76.mcpitanlib.api.sound.CompatBlockSoundGroup;

import java.util.function.Function;
import java.util.function.ToIntFunction;

@Deprecated
public class CompatibleBlockSettings {

    protected final BlockBehaviour.Properties settings;

    public CompatibleBlockSettings() {
        this.settings = BlockBehaviour.Properties.m_60939_(Material.f_76278_);
    }

    @Deprecated
    public static CompatibleBlockSettings of() {
        return new CompatibleBlockSettings();
    }

    public CompatibleBlockSettings(CompatibleMaterial material, MaterialColor mapColor) {
        this.settings = BlockBehaviour.Properties.m_60944_(material.getMaterial(), mapColor);
    }

    public CompatibleBlockSettings(CompatibleMaterial material, DyeColor dyeColor) {
        this.settings = BlockBehaviour.Properties.m_60941_(material.getMaterial(), dyeColor);
    }

    public CompatibleBlockSettings(CompatibleMaterial material) {
        this.settings = BlockBehaviour.Properties.m_60939_(material.getMaterial());
    }

    @Deprecated
    public CompatibleBlockSettings(Material material) {
        this.settings = BlockBehaviour.Properties.m_60939_(material);
    }

    public CompatibleBlockSettings(CompatibleMaterial material, Function<BlockState, MaterialColor> mapColor) {
        this.settings = BlockBehaviour.Properties.m_60947_(material.getMaterial(), mapColor);
    }

    @Deprecated
    public static CompatibleBlockSettings of(CompatibleMaterial material, MaterialColor mapColor) {
        return new CompatibleBlockSettings(material, mapColor);
    }

    @Deprecated
    public static CompatibleBlockSettings of(CompatibleMaterial material, DyeColor dyeColor) {
        return new CompatibleBlockSettings(material, dyeColor);
    }

    @Deprecated
    public static CompatibleBlockSettings of(Material material) {
        return new CompatibleBlockSettings(material);
    }

    @Deprecated
    public static CompatibleBlockSettings of(CompatibleMaterial material) {
        return new CompatibleBlockSettings(material);
    }

    @Deprecated
    public static CompatibleBlockSettings of(CompatibleMaterial material, Function<BlockState, MaterialColor> mapColor) {
        return new CompatibleBlockSettings(material, mapColor);
    }

    public CompatibleBlockSettings(BlockBehaviour block) {
        this.settings = BlockBehaviour.Properties.m_60926_(block);
    }

    @Deprecated
    public static CompatibleBlockSettings copy(BlockBehaviour block) {
        return new CompatibleBlockSettings(block);
    }

    public CompatibleBlockSettings air() {
        settings.m_60996_();
        return this;
    }

    public CompatibleBlockSettings blockVision(BlockBehaviour.StatePredicate predicate) {
        settings.m_60971_(predicate);
        return this;
    }

    public CompatibleBlockSettings postProcess(BlockBehaviour.StatePredicate predicate) {
        settings.m_60982_(predicate);
        return this;
    }

    public CompatibleBlockSettings solidBlock(BlockBehaviour.StatePredicate predicate) {
        settings.m_60924_(predicate);
        return this;
    }

    public CompatibleBlockSettings suffocates(BlockBehaviour.StatePredicate predicate) {
        settings.m_60960_(predicate);
        return this;
    }

    public CompatibleBlockSettings mapColor(MaterialColor color) {
        settings.m_155949_(color);
        return this;
    }

    public CompatibleBlockSettings mapColor(DyeColor color) {
        settings.m_155949_(color.m_41069_());
        return this;
    }

    @Deprecated
    public CompatibleBlockSettings mapColor(Function<BlockState, MaterialColor> color) {
        return this;
    }

    @Deprecated
    public CompatibleBlockSettings dropsLike(Block source) {
        settings.m_60916_(source);
        return this;
    }

    public CompatibleBlockSettings breakInstantly() {
        settings.m_60966_();
        return this;
    }

    public CompatibleBlockSettings dropsNothing() {
        settings.m_60993_();
        return this;
    }

    public CompatibleBlockSettings dynamicBounds() {
        settings.m_60988_();
        return this;
    }

    public CompatibleBlockSettings hardness(float hardness) {
        settings.m_155954_(hardness);
        return this;
    }

    public CompatibleBlockSettings noBlockBreakParticles() {
        //?
        return this;
    }

    public CompatibleBlockSettings requiresTool() {
        settings.m_60999_();
        return this;
    }

    public CompatibleBlockSettings noCollision() {
        settings.m_60910_();
        return this;
    }

    public CompatibleBlockSettings nonOpaque() {
        settings.m_60955_();
        return this;
    }

    public CompatibleBlockSettings resistance(float resistance) {
        settings.m_155956_(resistance);
        return this;
    }

    public CompatibleBlockSettings strength(float strength) {
        settings.m_60978_(strength);
        return this;
    }

    public CompatibleBlockSettings strength(float hardness, float resistance) {
        settings.m_60913_(hardness, resistance);
        return this;
    }

    public CompatibleBlockSettings ticksRandomly() {
        settings.m_60977_();
        return this;
    }

    public CompatibleBlockSettings sounds(SoundType blockSoundGroup) {
        settings.m_60918_(blockSoundGroup);
        return this;
    }

    public CompatibleBlockSettings sounds(CompatBlockSoundGroup blockSoundGroup) {
        return sounds(blockSoundGroup.get());
    }

    public CompatibleBlockSettings luminance(ToIntFunction<BlockState> luminance) {
        settings.m_60953_(luminance);
        return this;
    }

    public CompatibleBlockSettings jumpVelocityMultiplier(float jumpVelocityMultiplier) {
        settings.m_60967_(jumpVelocityMultiplier);
        return this;
    }

    public CompatibleBlockSettings slipperiness(float slipperiness) {
        settings.m_60911_(slipperiness);
        return this;
    }

    public CompatibleBlockSettings velocityMultiplier(float velocityMultiplier) {
        settings.m_60956_(velocityMultiplier);
        return this;
    }

    public CompatibleBlockSettings emissiveLighting(BlockBehaviour.StatePredicate predicate) {
        settings.m_60991_(predicate);
        return this;
    }

    public CompatibleBlockSettings offset(BlockBehaviour.OffsetType offsetType) {
        // ?
        return this;
    }

    public CompatibleBlockSettings allowsSpawning(BlockBehaviour.StateArgumentPredicate<net.minecraft.world.entity.EntityType<?>> predicate) {
        settings.m_60922_(predicate);
        return this;
    }

    public BlockBehaviour.Properties build() {
        return settings;

    }
}
