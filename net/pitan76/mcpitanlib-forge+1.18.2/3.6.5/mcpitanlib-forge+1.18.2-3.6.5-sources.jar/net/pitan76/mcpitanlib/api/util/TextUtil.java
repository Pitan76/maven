package net.pitan76.mcpitanlib.api.util;

import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.KeybindComponent;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.network.chat.Style;
import net.minecraft.network.chat.TextComponent;
import net.minecraft.network.chat.TranslatableComponent;
import net.minecraft.text.*;
import net.pitan76.mcpitanlib.api.text.TextConverter;

public class TextUtil {
    public static MutableComponent literal(String string) {
        //return Text.literal(string);
        return new TextComponent(string);
    }

    public static MutableComponent translatable(String key) {
        //return Text.translatable(key);
        return new TranslatableComponent(key);
    }

    public static MutableComponent translatable(String key, Object... args) {
        //return Text.translatable(key, args);
        return new TranslatableComponent(key, args);
    }

    public static MutableComponent empty() {
        //return Text.empty();
        return literal("");
    }

    public static MutableComponent keybind(String string) {
        //return Text.keybind(string);
        return new KeybindComponent(string);
    }

    public static String txt2str(Component text) {
        return text.getString();
    }

    public static MutableComponent setStyle(MutableComponent text, Style style) {
        return text.m_6270_(style);
    }

    public static Style getStyle(MutableComponent text) {
        return text.m_7383_();
    }

    public static MutableComponent withColor(MutableComponent text, int color) {
        return setStyle(text, StyleUtil.withColor(text.m_7383_(), color));
    }

    public static MutableComponent withBold(MutableComponent text, boolean bold) {
        return setStyle(text, StyleUtil.withBold(text.m_7383_(), bold));
    }

    public static MutableComponent append(MutableComponent text, Component sibling) {
        return text.m_7220_(sibling);
    }

    public static MutableComponent append(MutableComponent text, String string) {
        return text.m_130946_(string);
    }

    public static MutableComponent of(String string) {
        return literal(string);
    }

    public static MutableComponent convert(String text) {
        return TextConverter.convert(text, false);
    }

    public static MutableComponent convertWithTranslatable(String text) {
        return TextConverter.convert(text, true);
    }

    public static boolean contains(Component text, Component text1) {
        return text.getString().contains(text1.getString());
    }
}