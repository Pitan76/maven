package net.pitan76.mcpitanlib.api.client.registry.forge;

import net.minecraft.client.color.block.BlockColor;
import net.minecraft.world.level.block.Block;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.ColorHandlerEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.pitan76.mcpitanlib.MCPitanLib;

import java.util.HashMap;
import java.util.Map;

@Mod.EventBusSubscriber(modid = MCPitanLib.MOD_ID, bus = Mod.EventBusSubscriber.Bus.FORGE, value = Dist.CLIENT)
public class CompatRegistryClientImpl {

    public static Map<BlockColor, Block[]> blockColorProviders = new HashMap<>();

    public static void registerColorProviderBlock(BlockColor provider, Block... blocks) {
        blockColorProviders.put(provider, blocks);
    }

    @SubscribeEvent
    public static void registerBlockColors(ColorHandlerEvent.Block event){
        if (blockColorProviders.isEmpty()) return;

        for (Map.Entry<BlockColor, Block[]> entry : blockColorProviders.entrySet()) {
            BlockColor provider = entry.getKey();
            Block[] blocks = entry.getValue();

            if (blocks == null || blocks.length == 0) {
                event.getBlockColors().m_92589_(provider);
            } else {
                event.getBlockColors().m_92589_(provider, blocks);
            }
        }
    }
}
