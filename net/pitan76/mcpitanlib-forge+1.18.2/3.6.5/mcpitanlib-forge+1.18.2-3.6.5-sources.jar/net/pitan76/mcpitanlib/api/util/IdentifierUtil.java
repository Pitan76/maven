package net.pitan76.mcpitanlib.api.util;

import net.minecraft.resources.ResourceLocation;

public class IdentifierUtil {
    public static ResourceLocation id(String id) {
        return new ResourceLocation(id);
    }

    public static ResourceLocation id(String namespace, String path) {
        return new ResourceLocation(namespace, path);
    }

    public static String toString(ResourceLocation identifier) {
        return identifier.toString();
    }

    public static String getNamespace(ResourceLocation identifier) {
        return identifier.m_135827_();
    }

    public static String getPath(ResourceLocation identifier) {
        return identifier.m_135815_();
    }

    public static ResourceLocation from(CompatIdentifier id) {
        if (id == null)
            return null;

        return id.toMinecraft();
    }
}
