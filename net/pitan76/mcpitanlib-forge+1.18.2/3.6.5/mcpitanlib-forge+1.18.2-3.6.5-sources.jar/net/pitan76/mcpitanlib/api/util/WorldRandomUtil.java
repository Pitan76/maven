package net.pitan76.mcpitanlib.api.util;

import net.minecraft.world.level.Level;

public class WorldRandomUtil {
    public static int nextInt(Level world) {
        return world.m_5822_().nextInt();
    }

    public static int nextInt(Level world, int bound) {
        return world.m_5822_().nextInt(bound);
    }

    public static long nextLong(Level world) {
        return world.m_5822_().nextLong();
    }

    public static double nextDouble(Level world) {
        return world.m_5822_().nextDouble();
    }

    public static double nextGaussian(Level world) {
        return world.m_5822_().nextGaussian();
    }

    public static float nextFloat(Level world) {
        return world.m_5822_().nextFloat();
    }

    public static int nextBetween(Level world, int min, int max) {
        return nextInt(world, max - min + 1) + min;
    }

    public static int nextBetweenExclusive(Level world, int min, int max) {
        if (min >= max) {
            throw new IllegalArgumentException("bound - origin is non positive");
        } else {
            return min + nextInt(world, max - min);
        }
    }
}
