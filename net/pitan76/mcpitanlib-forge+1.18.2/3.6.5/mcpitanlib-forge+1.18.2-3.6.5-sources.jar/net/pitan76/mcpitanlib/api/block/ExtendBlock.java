package net.pitan76.mcpitanlib.api.block;

import com.google.common.collect.ImmutableMap;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.MenuProvider;
import net.minecraft.world.SimpleMenuProvider;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.material.FluidState;
import net.minecraft.world.level.pathfinder.PathComputationType;
import net.minecraft.world.level.storage.loot.LootContext;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.VoxelShape;
import net.pitan76.mcpitanlib.api.entity.Player;
import net.pitan76.mcpitanlib.api.event.block.*;
import net.pitan76.mcpitanlib.api.event.block.result.BlockBreakResult;
import net.pitan76.mcpitanlib.api.event.item.ItemAppendTooltipEvent;
import net.pitan76.mcpitanlib.api.util.CompatActionResult;
import net.pitan76.mcpitanlib.api.util.TextUtil;
import net.pitan76.mcpitanlib.core.serialization.CompatMapCodec;
import org.jetbrains.annotations.Nullable;

import java.util.List;
import java.util.Random;
import java.util.function.Function;

public class ExtendBlock extends Block {
    public CompatibleBlockSettings compatSettings;

    public ExtendBlock(Properties settings) {
        super(settings);
    }

    public ExtendBlock(CompatibleBlockSettings settings) {
        super(settings.build());
        this.compatSettings = settings;
    }

    /**
     * get compatible block settings
     * @return CompatibleBlockSettings
     */
    public CompatibleBlockSettings getCompatSettings() {
        return compatSettings;
    }

    /**
     * get collision voxel shape
     * @param event CollisionShapeEvent
     * @return VoxelShape
     */
    public VoxelShape getCollisionShape(CollisionShapeEvent event) {
        return super.m_5939_(event.state, event.world, event.pos, event.context);
    }

    @Deprecated
    @Override
    public VoxelShape m_5939_(BlockState state, BlockGetter world, BlockPos pos, CollisionContext context) {
        return getCollisionShape(new CollisionShapeEvent(state, world, pos, context));
    }

    /**
     * get outline voxel shape
     * @param event OutlineShapeEvent
     * @return VoxelShape
     */
    public VoxelShape getOutlineShape(OutlineShapeEvent event) {
        return super.m_5940_(event.state, event.world, event.pos, event.context);
    }

    @Deprecated
    @Override
    public VoxelShape m_5940_(BlockState state, BlockGetter world, BlockPos pos, CollisionContext context) {
        return getOutlineShape(new OutlineShapeEvent(state, world, pos, context));
    }

    /**
     * block scheduled tick event
     * @param event BlockScheduledTickEvent
     */
    public void scheduledTick(BlockScheduledTickEvent event) {
        super.m_7458_(event.state, event.world, event.pos, event.random.getJavaRandom());
    }

    @Override
    @Deprecated
    public void m_7458_(BlockState state, ServerLevel world, BlockPos pos, Random random) {
        scheduledTick(new BlockScheduledTickEvent(state, world, pos, random));
    }

    @Override
    @Deprecated
    public InteractionResult m_6227_(BlockState state, Level world, BlockPos pos, net.minecraft.world.entity.player.Player player, InteractionHand hand, BlockHitResult hit) {
        return onRightClick(new BlockUseEvent(state, world, pos, player, hand, hit)).toActionResult();
    }

    /**
     * block right click event
     * @param event ActionResultType
     * @return BlockUseEvent
     */
    public CompatActionResult onRightClick(BlockUseEvent event) {
        return CompatActionResult.create(super.m_6227_(event.state, event.world, event.pos, event.player.getPlayerEntity(), event.hand, event.hit));
    }

    @Deprecated
    @Nullable
    @Override
    public MenuProvider m_7246_(BlockState state, Level world, BlockPos pos) {
        return new SimpleMenuProvider((syncId, inventory, player) ->
                createScreenHandler(new ScreenHandlerCreateEvent(state, world, pos, syncId, inventory, player)), getScreenTitle()
        );
    }

    /**
     * screen handler create event
     * @param event ScreenHandlerCreateEvent
     * @return ScreenHandler
     */
    @Nullable
    public AbstractContainerMenu createScreenHandler(ScreenHandlerCreateEvent event) {
        return null;
    }

    /**
     * get screen title
     * @return Text
     */
    @Nullable
    public Component getScreenTitle() {
        return TextUtil.literal("");
    }

    @Override
    @Deprecated
    public void m_6402_(Level world, BlockPos pos, BlockState state, @Nullable LivingEntity placer, ItemStack itemStack) {
        onPlaced(new BlockPlacedEvent(world, pos, state, placer, itemStack));
    }

    /**
     * block placed event
     * @param event BlockPlacedEvent
     */
    public void onPlaced(BlockPlacedEvent event) {
        super.m_6402_(event.world, event.pos, event.state, event.placer, event.stack);
    }

    @Override
    @Deprecated
    public void m_5707_(Level world, BlockPos pos, BlockState state, net.minecraft.world.entity.player.Player player) {
        onBreak(new BlockBreakEvent(world, pos, state, player));
    }

    /**
     * block break event
     * @param event BlockBreakEvent
     * @return BlockBreakResult
     */
    public BlockBreakResult onBreak(BlockBreakEvent event) {
        super.m_5707_(event.world, event.pos, event.state, event.getPlayerEntity());
        return new BlockBreakResult(event.state);
    }

    @Override
    @Deprecated
    public ItemStack m_7397_(BlockGetter world, BlockPos pos, BlockState state) {
        return getPickStack(new PickStackEvent(world, pos, state));
    }

    /**
     * block pick stack event
     * @param event PickStackEvent
     * @return ItemStack
     */
    public ItemStack getPickStack(PickStackEvent event) {
        return super.m_7397_(event.blockView, event.pos, event.state);
    }

    @Override
    @Deprecated
    public void m_6810_(BlockState state, Level world, BlockPos pos, BlockState newState, boolean moved) {
        onStateReplaced(new StateReplacedEvent(state, world, pos, newState, moved));
    }

    /**
     * block state replaced event
     * @param event StateReplacedEvent
     */
    public void onStateReplaced(StateReplacedEvent event) {
        super.m_6810_(event.state, event.world, event.pos, event.newState, event.moved);
    }

    @Deprecated
    @Override
    public List<ItemStack> m_7381_(BlockState state, LootContext.Builder builder) {
        return getDroppedStacks(new DroppedStacksArgs(state, builder));
    }

    /**
     * block dropped stacks event
     * @param args DroppedStacksArgs
     * @return List<ItemStack>
     */
    public List<ItemStack> getDroppedStacks(DroppedStacksArgs args) {
        return super.m_7381_(args.state, args.builder);
    }

    @Deprecated
    @Override
    public void m_6861_(BlockState state, Level world, BlockPos pos, Block sourceBlock, BlockPos sourcePos, boolean notify) {
        neighborUpdate(new NeighborUpdateEvent(state, world, pos, sourceBlock, sourcePos, notify));
    }

    /**
     * block neighbor update event
     * @param event NeighborUpdateEvent
     */
    public void neighborUpdate(NeighborUpdateEvent event) {
        super.m_6861_(event.state, event.world, event.pos, event.sourceBlock, event.sourcePos, event.notify);
    }

    @Deprecated
    @Override
    public void m_7926_(StateDefinition.Builder<Block, BlockState> builder) {
        appendProperties(new AppendPropertiesArgs(builder));
    }

    /**
     * append properties event
     * @param args AppendPropertiesArgs
     */
    public void appendProperties(AppendPropertiesArgs args) {
        super.m_7926_(args.builder);
    }

    /**
     * Compatible for getDefaultState()
     * @return default block state
     */
    public BlockState getNewDefaultState() {
        return super.m_49966_();
    }

    /**
     * Compatible for setDefaultState()
     * @param state BlockState
     */
    public void setNewDefaultState(BlockState state) {
        super.m_49959_(state);
    }

    @Deprecated
    @Override
    public @Nullable BlockState m_5573_(BlockPlaceContext ctx) {
        return this.getPlacementState(new PlacementStateArgs(ctx, this));
    }

    /**
     * get placement state
     * @param args PlacementStateArgs
     * @return BlockState
     */
    public @Nullable BlockState getPlacementState(PlacementStateArgs args) {
        return super.m_5573_(args.ctx);
    }

    @Deprecated
    @Override
    public void m_5871_(ItemStack stack, @Nullable BlockGetter world, List<Component> tooltip, TooltipFlag context) {
        appendTooltip(new ItemAppendTooltipEvent(stack, world, tooltip, context));
    }

    /**
     * append tooltip to item
     * @param event ItemAppendTooltipEvent
     */
    public void appendTooltip(ItemAppendTooltipEvent event) {
        super.m_5871_(event.stack, event.blockView, event.tooltip, event.context);
    }

    @Deprecated
    @Override
    public boolean m_7357_(BlockState state, BlockGetter world, BlockPos pos, PathComputationType type) {
        return canPathfindThrough(new CanPathfindThroughArgs(state, world, pos, type));
    }

    @SuppressWarnings("removal")
    public boolean canPathfindThrough(CanPathfindThroughArgs args) {
        return super.m_7357_(args.state, args.getBlockView(), args.getPos(), args.type);
    }

    @Deprecated
    @Override
    public void m_7892_(BlockState state, Level world, BlockPos pos, Entity entity) {
        onEntityCollision(new EntityCollisionEvent(state, world, pos, entity));
    }

    public void onEntityCollision(EntityCollisionEvent e) {
        super.m_7892_(e.state, e.world, e.pos, e.entity);
    }

    @Deprecated
    @Override
    public void m_6256_(BlockState state, Level world, BlockPos pos, net.minecraft.world.entity.player.Player player) {
        onBlockBreakStart(new BlockBreakStartEvent(state, world, pos, new Player(player)));
    }

    public void onBlockBreakStart(BlockBreakStartEvent e) {
        super.m_6256_(e.state, e.world, e.pos, e.player.getPlayerEntity());
    }

    public CompatMapCodec<? extends Block> getCompatCodec() {
        return CompatMapCodec.of();
    }

    @Deprecated
    @Override
    public FluidState m_5888_(BlockState state) {
        return getFluidState(new FluidStateArgs(state));
    }

    public FluidState getFluidState(FluidStateArgs args) {
        return super.m_5888_(args.getState());
    }

    @Deprecated
    @Override
    public BlockState m_7417_(BlockState state, Direction direction, BlockState neighborState, LevelAccessor world, BlockPos pos, BlockPos neighborPos) {
        return getStateForNeighborUpdate(new StateForNeighborUpdateArgs(state, direction, neighborState, world, pos, neighborPos));
    }

    public BlockState getStateForNeighborUpdate(StateForNeighborUpdateArgs args) {
        return super.m_7417_(args.state, args.direction, args.neighborState, args.world, args.pos, args.neighborPos);
    }

    @Deprecated
    @Override
    protected ImmutableMap<BlockState, VoxelShape> m_152458_(Function<BlockState, VoxelShape> stateToShape) {
        return getShapesForStates(new ShapesForStatesArgs(stateToShape));
    }

    public ImmutableMap<BlockState, VoxelShape> getShapesForStates(ShapesForStatesArgs args) {
        return super.m_152458_(args.stateToShape);
    }

    public StateDefinition<Block, BlockState> callGetStateManager() {
        return super.m_49965_();
    }
}
