package net.pitan76.mcpitanlib.api.util;

import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.packs.resources.Resource;
import net.minecraft.server.packs.resources.ResourceManager;

public class ResourceUtil {
    public static Resource getResource(ResourceManager resourceManager, ResourceLocation identifier) throws IOException {
        return resourceManager.m_142591_(identifier);
    }

    public static InputStream getInputStream(Resource resource) {
        return resource.m_6679_();
    }

    public static Map<ResourceLocation, Resource> findResources(ResourceManager resourceManager, String startingPath, String endingPath) throws IOException {
        Map<ResourceLocation, Resource> map = new HashMap<>();
        for (ResourceLocation identifier : resourceManager.m_6540_(startingPath, s -> s.endsWith(endingPath))) {
            map.put(identifier, resourceManager.m_142591_(identifier));
        }
        return map;
    }

    public static void close(Resource resource) throws IOException {
        resource.close();
    }
}
